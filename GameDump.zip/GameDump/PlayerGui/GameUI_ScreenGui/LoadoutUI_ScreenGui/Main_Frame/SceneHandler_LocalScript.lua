-- Roblox: Players.SilverAce293026.PlayerGui.GameUI.LoadoutUI.Main.SceneHandler
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Players__2 = game:GetService("Players");
local l__TweenService__3 = game:GetService("TweenService");
local u1 = require(l__ReplicatedStorage__1.ReplicatedConfig).Mode ~= "Tycoon";
local l__MainViewport__4 = script.Parent.MainViewport;
local l__WorldModel__5 = l__MainViewport__4:WaitForChild("WorldModel");
local u2 = {
    displayCharCFrame = l__WorldModel__5:WaitForChild("LoadoutScene"):WaitForChild("HumPart").CFrame,
    attachmentGunCFrame = l__WorldModel__5.LoadoutScene:WaitForChild("GunPart").CFrame
};
local l__LocalPlayer__6 = l__Players__2.LocalPlayer;
local l__ReplicatedConfig__7 = require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig"));
local l__AttachmentsEnabled__8 = l__ReplicatedConfig__7.FeatureToggles.AttachmentsEnabled;
local _ = l__ReplicatedConfig__7.FeatureToggles.CamosEnabled;
local v3 = {
    changeWeapon = script.Parent:WaitForChild("ChangeWeapon"),
    changeNVG = script.Parent:WaitForChild("ChangeNVG"),
    setAttachment = script.Parent:WaitForChild("SetAttachment"),
    resetAttachments = script.Parent:WaitForChild("ResetAttachments"),
    setCamo = script.Parent:WaitForChild("SetCamo"),
    InitAttachments = script.Parent:WaitForChild("InitAttachments")
};
local u4 = {
    getWeaponForcedAttachments = game:GetService("ReplicatedStorage"):WaitForChild("PlayerEvents"):WaitForChild("GetWeaponForcedAttachments")
};
local u5 = {
    engine = l__ReplicatedStorage__1:WaitForChild("ACS_Engine"),
    gunModels = l__ReplicatedStorage__1.ACS_Engine:WaitForChild("GunModels"),
    accessories = l__ReplicatedStorage__1.ACS_Engine:WaitForChild("Accessories"),
    nvgs = l__ReplicatedStorage__1.ACS_Engine.Accessories:WaitForChild("NVG"),
    modules = l__ReplicatedStorage__1.ACS_Engine:WaitForChild("Modules"),
    camosUtil = require(l__ReplicatedStorage__1.ACS_Engine.Modules:WaitForChild("CamosUtil"))
};
local l__AttachmentsUtil__9 = require(u5.modules:WaitForChild("AttachmentsUtil"));
local l__Attachments__10 = game:GetService("ReplicatedStorage"):WaitForChild("WeaponProgression"):WaitForChild("Attachments");
require(l__Attachments__10);
local u6 = {
    animation = l__MainViewport__4:WaitForChild("Animation"),
    idle = l__MainViewport__4:WaitForChild("IdleAnimation")
};
local u7 = {};
local u8 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local l__LoadoutRig__11 = l__ReplicatedStorage__1:WaitForChild("LoadoutRig");
local u9 = nil;
local u10 = nil;
local u11 = nil;
local u12 = nil;
local function v14(p13) --[[ Line: 77 ]]
    -- upvalues: u9 (ref), u10 (ref), l__WorldModel__5 (copy)
    if p13:IsA("BasePart") or (p13:IsA("Part") or (p13:IsA("MeshPart") or p13:IsA("Decal"))) then
        if u9 == nil or not p13:IsDescendantOf(u9) then
            if u10 == nil or not p13:IsDescendantOf(u10) then
                if p13.Parent ~= l__WorldModel__5.LoadoutScene then
                    p13.Transparency = 1;
                end;
            end;
        end;
    end;
end;
if u1 then
    l__WorldModel__5.DescendantAdded:Connect(v14);
    for _, v15 in l__WorldModel__5:GetDescendants() do
        v14(v15);
    end;
end;
local function u21(p16, p17) --[[ Line: 98 ]]
    local v18 = p17.Handle:FindFirstChildOfClass("Attachment");
    local v19 = Instance.new("Weld");
    v19.Name = "AccessoryWeld";
    v19.Part0 = p17.Handle;
    if v18 then
        local v20 = p16:FindFirstChild(tostring(v18), true);
        v19.C0 = v18.CFrame;
        v19.C1 = v20.CFrame;
        v19.Part1 = v20.Parent;
    else
        v19.C1 = CFrame.new(0, p16.Head.Size.Y / 2, 0) * p17.AttachmentPoint:inverse();
        v19.Part1 = p16.Head;
    end;
    p17.Handle.CFrame = v19.Part1.CFrame * v19.C1 * v19.C0:inverse();
    p17.Parent = p16;
    v19.Parent = p17.Handle;
end;
local function u26(p22) --[[ Line: 117 ]]
    local v23 = p22:FindFirstChild("Handle");
    for _, v24 in p22:GetDescendants() do
        if v24:IsA("BasePart") then
            if v24:HasTag("ShowVPOnly") then
                v24.Transparency = 1;
            end;
            v24.Anchored = false;
            v24.CanCollide = false;
            if v24 ~= v23 then
                local v25 = Instance.new("WeldConstraint", v24);
                v25.Name = "HandleWeld";
                v25.Part0 = v24;
                v25.Part1 = v23;
            end;
        end;
    end;
end;
local function u29(p27) --[[ Line: 138 ]]
    -- upvalues: u9 (ref)
    if u9 then
        local l__RightHand__12 = u9.RightHand;
        if p27 then
            local l__Handle__13 = p27:WaitForChild("Handle");
            local v28 = Instance.new("Motor6D", l__Handle__13);
            v28.Name = "LoadoutM6";
            v28.Part0 = l__RightHand__12;
            v28.Part1 = l__Handle__13;
            v28.C1 = (CFrame.new(-0.3, -0.2, -0.4) * CFrame.Angles(-1.5707963267948966, 0, 0)):Inverse();
        end;
    end;
end;
local function u30() --[[ Line: 153 ]]
    -- upvalues: u9 (ref), l__LoadoutRig__11 (copy), l__WorldModel__5 (copy), l__Players__2 (copy), l__LocalPlayer__6 (copy), u2 (copy), u7 (copy), u6 (copy)
    if u9 then
        u9:Destroy();
        u9 = nil;
    end;
    u9 = l__LoadoutRig__11:Clone();
    u9.Parent = l__WorldModel__5;
    u9:WaitForChild("Humanoid"):ApplyDescription((l__Players__2:GetHumanoidDescriptionFromUserId(l__LocalPlayer__6.UserId)));
    u9:PivotTo(u2.displayCharCFrame);
    local l__Humanoid__14 = u9.Humanoid;
    u7.animationTrack = l__Humanoid__14:LoadAnimation(u6.animation);
    u7.idleTrack = l__Humanoid__14:LoadAnimation(u6.idle);
    u7.idleTrack:Play();
    return u9;
end;
local function u32() --[[ Line: 181 ]]
    -- upvalues: u9 (ref), u30 (copy), u1 (copy), l__MainViewport__4 (copy)
    if not u9 then
        u30();
    end;
    if l__MainViewport__4.CurrentCamera then
        l__MainViewport__4.CurrentCamera:Destroy();
        l__MainViewport__4.CurrentCamera = nil;
    end;
    local v31 = Instance.new("Camera", script);
    local l__HumanoidRootPart__15 = u9:WaitForChild("HumanoidRootPart");
    v31.CFrame = CFrame.new(l__HumanoidRootPart__15.Position + l__HumanoidRootPart__15.CFrame.LookVector * 3 + Vector3.new(0, 2, 0) + l__HumanoidRootPart__15.CFrame.RightVector * -2, l__HumanoidRootPart__15.Position + Vector3.new(0, 1.7, 0));
    l__MainViewport__4.CurrentCamera = v31;
end;
local function u33() --[[ Line: 202 ]]
    -- upvalues: u10 (ref), l__MainViewport__4 (copy), u9 (ref), l__WorldModel__5 (copy), u2 (copy), u1 (copy), l__TweenService__3 (copy), u8 (copy)
    if u10 then
        local l__CurrentCamera__16 = l__MainViewport__4.CurrentCamera;
        local l__Handle__17 = u10.Handle;
        if l__Handle__17:FindFirstChild("LoadoutM6") then
            l__Handle__17:FindFirstChild("LoadoutM6"):Destroy();
        end;
        u9.Parent = nil;
        u10.Parent = l__WorldModel__5;
        u10:PivotTo(u2.attachmentGunCFrame);
        if u1 then
            l__CurrentCamera__16.CFrame = CFrame.new(l__Handle__17.Position + l__Handle__17.CFrame.LookVector * 0 + Vector3.new(0, 0, 0) + l__Handle__17.CFrame.RightVector * -4) * CFrame.Angles(0, -1.5707963267948966, 0);
        else
            l__TweenService__3:Create(l__CurrentCamera__16, u8, {
                CFrame = CFrame.new(l__Handle__17.Position + l__Handle__17.CFrame.LookVector * 0 + Vector3.new(0, 0, 0) + l__Handle__17.CFrame.RightVector * -4) * CFrame.Angles(0, -1.5707963267948966, 0)
            }):Play();
        end;
    end;
end;
local u34 = {};
local function u42(p35, p36) --[[ Line: 256 ]]
    -- upvalues: u10 (ref), u34 (ref), l__AttachmentsUtil__9 (copy), u12 (ref), u42 (copy)
    if not u10 then
        return;
    end;
    if p36 then
        local v37 = l__AttachmentsUtil__9.getAttDataFromHash(p35);
        if not v37 then
            return;
        end;
        local v38 = l__AttachmentsUtil__9.loadAttachments(u10, { v37 });
        for v39, v40 in u34 do
            if l__AttachmentsUtil__9.getAttachmentCategoryFromIndex(v39) == v37.Category then
                v40:Destroy();
                u34[v39] = nil;
                break;
            end;
        end;
        u34[p35] = v38[v37.Category];
    elseif u34[p35] then
        local v41 = l__AttachmentsUtil__9.getAttachmentCategoryFromIndex(p35);
        if v41 and l__AttachmentsUtil__9.attachmentChangedCallbacks[v41] then
            l__AttachmentsUtil__9.attachmentChangedCallbacks[v41](u10, u34[p35], false);
        end;
        u34[p35]:Destroy();
        u34[p35] = nil;
        if u12[v41] then
            u42(u12[v41], true);
        end;
    end;
end;
local function v46(p43) --[[ Line: 350 ]]
    -- upvalues: u11 (ref), u5 (copy), u21 (copy), u9 (ref)
    if u11 then
        u11:Destroy();
        u11 = nil;
    end;
    if p43 == nil or p43 == "" then
    else
        local v44 = u5.nvgs:FindFirstChild(p43):FindFirstChild("MWTNVG_Up");
        if v44 then
            local v45 = v44:Clone();
            u21(v45, u9);
            u11 = v45;
        end;
    end;
end;
local function v48(p47) --[[ Line: 370 ]]
    -- upvalues: u10 (ref), u5 (copy)
    if u10 then
        u5.camosUtil.applyCamoToGun(u10, p47);
    end;
end;
local function v53() --[[ Line: 385 ]]
    -- upvalues: u10 (ref), u34 (ref), l__AttachmentsUtil__9 (copy), u12 (ref), u42 (copy)
    if u10 then
        for v49, v50 in u34 do
            local v51 = l__AttachmentsUtil__9.getAttachmentCategoryFromIndex(v49);
            if v51 and l__AttachmentsUtil__9.attachmentChangedCallbacks[v51] then
                l__AttachmentsUtil__9.attachmentChangedCallbacks[v51](u10, u34[v49], false);
            end;
            v50:Destroy();
        end;
        u34 = {};
        if u12 and u10 then
            for _, v52 in u12 do
                u42(v52, true);
            end;
        end;
    end;
end;
function v3.changeWeapon.OnInvoke(p54) --[[ Line: 295 ]]
    -- upvalues: u10 (ref), u12 (ref), u9 (ref), l__MainViewport__4 (copy), u32 (copy), l__TweenService__3 (copy), u8 (copy), u7 (copy), l__WorldModel__5 (copy), u5 (copy), u4 (copy), u26 (copy), u29 (copy), u42 (copy)
    if u10 then
        u10:Destroy();
        u10 = nil;
    end;
    u12 = nil;
    if not (u9 and l__MainViewport__4.CurrentCamera) then
        u32();
    end;
    local l__HumanoidRootPart__18 = u9.HumanoidRootPart;
    local v55 = CFrame.new(l__HumanoidRootPart__18.Position + l__HumanoidRootPart__18.CFrame.LookVector * 3 + Vector3.new(0, 2, 0) + l__HumanoidRootPart__18.CFrame.RightVector * -2, l__HumanoidRootPart__18.Position + Vector3.new(0, 1.7, 0));
    l__TweenService__3:Create(l__MainViewport__4.CurrentCamera, u8, {
        CFrame = v55
    }):Play();
    if p54 then
        local v56 = u5.gunModels:FindFirstChild(p54);
        if v56 then
            u12 = u4.getWeaponForcedAttachments:InvokeServer(p54);
            if u7.animationTrack then
                u7.animationTrack:Play();
            end;
            local v57 = v56:Clone();
            u26(v57);
            v57.Parent = u9;
            v57.PrimaryPart = v57.Handle;
            u29(v57);
            u10 = v57;
            for _, v58 in u12 do
                u42(v58, true);
            end;
        end;
    elseif u7.animationTrack then
        u7.animationTrack:Stop();
        u9.Parent = l__WorldModel__5;
    end;
end;
v3.changeNVG.Event:Connect(v46);
v3.setAttachment.Event:Connect(u42);
v3.resetAttachments.OnInvoke = v53;
v3.setCamo.Event:Connect(v48);
v3.InitAttachments.Event:Connect(function() --[[ Name: setupAttachmentsView, Line 243 ]]
    -- upvalues: l__AttachmentsEnabled__8 (copy), u33 (copy)
    if l__AttachmentsEnabled__8 then
        u33();
    end;
end);