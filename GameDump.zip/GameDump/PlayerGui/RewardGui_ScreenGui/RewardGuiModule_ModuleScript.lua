-- Roblox: Players.SilverAce293026.PlayerGui.RewardGui.RewardGuiModule
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__Reward__1 = script.Parent:WaitForChild("Reward");
local l__Item__2 = l__Reward__1:WaitForChild("Item");
local l__Background__3 = l__Reward__1:WaitForChild("Background");
local l__Icon__4 = l__Background__3:WaitForChild("Icon");
local l__OK__5 = l__Reward__1:WaitForChild("Buttons"):WaitForChild("OK");
local l__RewardSound__6 = script:WaitForChild("RewardSound");
local function u5(p2, u3) --[[ Line: 15 ]]
    -- upvalues: l__Item__2 (copy), l__Icon__4 (copy), l__Background__3 (copy), l__OK__5 (copy), l__Reward__1 (copy), l__RewardSound__6 (copy)
    local l__Text__7 = p2.Text;
    local l__Image__8 = p2.Image;
    local v4 = p2.Color or Color3.fromRGB(85, 85, 255);
    if not (l__Text__7 and l__Image__8) then
        error("Incomplete definition");
    end;
    l__Item__2.Text = l__Text__7;
    l__Icon__4.Image = l__Image__8;
    l__Background__3.ImageColor3 = v4;
    l__OK__5.ButtonFrame.Button.Activated:Once(function() --[[ Line: 28 ]]
        -- upvalues: l__Reward__1 (ref), u3 (copy)
        l__Reward__1.Visible = false;
        if u3 then
            u3();
        end;
    end);
    l__Reward__1.Visible = true;
    l__RewardSound__6:Play();
end;
function v1.ShowReward(p6, p7) --[[ Line: 38 ]]
    -- upvalues: u5 (copy)
    u5(p6, p7);
end;
function v1.ShowRewardAndYield(p8) --[[ Line: 42 ]]
    -- upvalues: u5 (copy)
    local u9 = false;
    u5(p8, function() --[[ Line: 45 ]]
        -- upvalues: u9 (ref)
        u9 = true;
    end);
    repeat
        task.wait();
    until u9;
end;
return v1;