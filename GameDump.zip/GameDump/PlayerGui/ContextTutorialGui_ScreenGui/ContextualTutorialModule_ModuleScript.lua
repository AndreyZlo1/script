-- Roblox: Players.SilverAce293026.PlayerGui.ContextTutorialGui.ContextualTutorialModule
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__UserInputService__1 = game:GetService("UserInputService");
local l__TweenService__2 = game:GetService("TweenService");
local l__ContextFrame__3 = script.Parent:WaitForChild("ContextFrame");
local l__ContextCell__4 = l__ContextFrame__3:WaitForChild("ContextCell");
local u2 = l__UserInputService__1:GetLastInputType();
local function u7(p3) --[[ Line: 13 ]]
    -- upvalues: u2 (ref), l__UserInputService__1 (copy)
    local v4 = p3:GetAttribute("ActionName");
    local v5 = p3:GetAttribute("PCInputString");
    local v6 = p3:GetAttribute("ConsoleKeyCode");
    local l__TextLabel__5 = p3.TextLabel;
    local l__ImageLabel__6 = p3.ImageLabel;
    if u2 == Enum.UserInputType.Gamepad1 then
        l__ImageLabel__6.Visible = true;
        l__TextLabel__5.Size = UDim2.new(0.9, 0, 1, 0);
        l__TextLabel__5.Text = v4;
        l__ImageLabel__6.Image = l__UserInputService__1:GetImageForKeyCode(v6);
    else
        l__ImageLabel__6.Visible = false;
        l__TextLabel__5.Size = UDim2.new(1, 0, 1, 0);
        l__TextLabel__5.Text = v4 .. " - " .. v5;
    end;
end;
local function u9() --[[ Line: 34 ]]
    -- upvalues: l__ContextFrame__3 (copy), u2 (ref), l__ContextCell__4 (copy), u7 (copy)
    l__ContextFrame__3.Visible = u2 ~= Enum.UserInputType.Touch;
    for _, v8 in ipairs(l__ContextFrame__3:GetChildren()) do
        if v8.Name ~= "UIListLayout" and v8 ~= l__ContextCell__4 then
            u7(v8);
        end;
    end;
end;
l__UserInputService__1.LastInputTypeChanged:Connect(function(p10) --[[ Line: 42 ]]
    -- upvalues: u2 (ref), u9 (copy)
    u2 = p10;
    u9();
end);
function v1.clear() --[[ Line: 49 ]]
    -- upvalues: l__ContextFrame__3 (copy), l__ContextCell__4 (copy)
    for _, v11 in ipairs(l__ContextFrame__3:GetChildren()) do
        if v11.Name ~= "UIListLayout" and v11 ~= l__ContextCell__4 then
            v11:Destroy();
        end;
    end;
end;
function v1.fade(p12) --[[ Line: 56 ]]
    -- upvalues: l__ContextFrame__3 (copy), l__ContextCell__4 (copy), l__TweenService__2 (copy)
    local v13 = TweenInfo.new(1, Enum.EasingStyle.Linear, Enum.EasingDirection.In, 0, false, p12 or 0);
    for _, u14 in ipairs(l__ContextFrame__3:GetChildren()) do
        if u14.Name ~= "UIListLayout" and u14 ~= l__ContextCell__4 then
            local v15 = l__TweenService__2:Create(u14.TextLabel, v13, {
                TextTransparency = 1
            });
            l__TweenService__2:Create(u14.ImageLabel, v13, {
                ImageTransparency = 1
            }):Play();
            v15:Play();
            v15.Completed:Connect(function() --[[ Line: 64 ]]
                -- upvalues: u14 (copy)
                if u14 then
                    u14:Destroy();
                end;
            end);
        end;
    end;
end;
function v1.addLine(p16, p17, p18) --[[ Line: 70 ]]
    -- upvalues: l__ContextCell__4 (copy), l__ContextFrame__3 (copy), u7 (copy)
    local v19 = l__ContextCell__4:Clone();
    v19.Parent = l__ContextFrame__3;
    v19:SetAttribute("ActionName", p16);
    v19:SetAttribute("PCInputString", p17);
    v19:SetAttribute("ConsoleKeyCode", p18);
    u7(v19);
    v19.Visible = true;
end;
return v1;