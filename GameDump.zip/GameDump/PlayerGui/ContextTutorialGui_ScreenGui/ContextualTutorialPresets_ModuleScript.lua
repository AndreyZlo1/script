-- Roblox: Players.SilverAce293026.PlayerGui.ContextTutorialGui.ContextualTutorialPresets
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__ContextualTutorialModule__1 = require(script.Parent:WaitForChild("ContextualTutorialModule"));
local u2 = {
    Weapon = false,
    ArmedHeliPilot = false,
    UnarmedHeliPilot = false,
    HeliGunner = false,
    ArmedGroundVehicle = false,
    UnarmedGroundVehicle = false
};
function v1.startWeaponTutorial() --[[ Line: 18 ]]
    -- upvalues: u2 (copy), l__ContextualTutorialModule__1 (copy)
    if u2.Weapon then
    else
        l__ContextualTutorialModule__1.clear();
        l__ContextualTutorialModule__1.addLine("Fire", "Left Click", Enum.KeyCode.ButtonR2);
        l__ContextualTutorialModule__1.addLine("Aim", "Right Click", Enum.KeyCode.ButtonL2);
        l__ContextualTutorialModule__1.addLine("Reload", "R", Enum.KeyCode.ButtonX);
        l__ContextualTutorialModule__1.addLine("Inspect", "M", Enum.KeyCode.ButtonY);
        l__ContextualTutorialModule__1.addLine("Sprint", "Left Shift", Enum.KeyCode.ButtonL3);
        l__ContextualTutorialModule__1.addLine("Crouch", "C", Enum.KeyCode.ButtonB);
        l__ContextualTutorialModule__1.addLine("Toggle Aim", "T", Enum.KeyCode.ButtonR3);
        l__ContextualTutorialModule__1.addLine("Lean left", "Q", Enum.KeyCode.DPadLeft);
        l__ContextualTutorialModule__1.addLine("Lean right", "E", Enum.KeyCode.DPadRight);
    end;
end;
function v1.startArmedHeliTutorial() --[[ Line: 33 ]]
    -- upvalues: u2 (copy), l__ContextualTutorialModule__1 (copy)
    if u2.ArmedHeliPilot then
    else
        l__ContextualTutorialModule__1.clear();
        l__ContextualTutorialModule__1.addLine("Ascend (HOLD)", "W / Left Shift", Enum.KeyCode.ButtonR2);
        l__ContextualTutorialModule__1.addLine("Descend (HOLD)", "S / Left Ctrl", Enum.KeyCode.ButtonL2);
        l__ContextualTutorialModule__1.addLine("Pitch/Yaw", "Mouse", Enum.KeyCode.Thumbstick2);
        l__ContextualTutorialModule__1.addLine("Roll", "A / D", Enum.KeyCode.Thumbstick1);
        l__ContextualTutorialModule__1.addLine("Freelook", "Alt", Enum.KeyCode.ButtonR3);
        l__ContextualTutorialModule__1.addLine("Fire weapon", "Left Click", Enum.KeyCode.ButtonR1);
        l__ContextualTutorialModule__1.addLine("Swap weapon", "Q", Enum.KeyCode.ButtonY);
        l__ContextualTutorialModule__1.addLine("Flares", "F", Enum.KeyCode.DPadDown);
        l__ContextualTutorialModule__1.fade(15);
    end;
end;
function v1.startUnarmedHeliTutorial() --[[ Line: 49 ]]
    -- upvalues: u2 (copy), l__ContextualTutorialModule__1 (copy)
    if u2.UnarmedHeliPilot then
    else
        l__ContextualTutorialModule__1.clear();
        l__ContextualTutorialModule__1.addLine("Ascend (HOLD)", "W / Left Shift", Enum.KeyCode.ButtonR2);
        l__ContextualTutorialModule__1.addLine("Descend (HOLD)", "S / Left Ctrl", Enum.KeyCode.ButtonL2);
        l__ContextualTutorialModule__1.addLine("Pitch/Yaw", "Mouse", Enum.KeyCode.Thumbstick2);
        l__ContextualTutorialModule__1.addLine("Roll", "A / D", Enum.KeyCode.Thumbstick1);
        l__ContextualTutorialModule__1.addLine("Freelook", "Alt", Enum.KeyCode.ButtonR3);
        l__ContextualTutorialModule__1.addLine("Flares", "F", Enum.KeyCode.DPadDown);
        l__ContextualTutorialModule__1.fade(15);
    end;
end;
function v1.startUnarmedGroundVehicleTutorial() --[[ Line: 62 ]]
    -- upvalues: u2 (copy), l__ContextualTutorialModule__1 (copy)
    if u2.UnarmedGroundVehicle then
    else
        u2.UnarmedGroundVehicle = true;
        l__ContextualTutorialModule__1.clear();
        l__ContextualTutorialModule__1.addLine("Accelerate", "W", Enum.KeyCode.ButtonR2);
        l__ContextualTutorialModule__1.addLine("Brakes", "S", Enum.KeyCode.ButtonL2);
        l__ContextualTutorialModule__1.addLine("Steer", "A / D", Enum.KeyCode.Thumbstick1);
        l__ContextualTutorialModule__1.addLine("Handbrake", "Left Shift", Enum.KeyCode.ButtonX);
        l__ContextualTutorialModule__1.fade(15);
    end;
end;
function v1.startArmedGroundVehicleTutorial() --[[ Line: 73 ]]
    -- upvalues: u2 (copy), l__ContextualTutorialModule__1 (copy)
    if u2.ArmedGroundVehicle then
    else
        u2.ArmedGroundVehicle = true;
        l__ContextualTutorialModule__1.clear();
        l__ContextualTutorialModule__1.addLine("Accelerate", "W", Enum.KeyCode.ButtonR2);
        l__ContextualTutorialModule__1.addLine("Brakes", "S", Enum.KeyCode.ButtonL2);
        l__ContextualTutorialModule__1.addLine("Steer", "A / D", Enum.KeyCode.Thumbstick1);
        l__ContextualTutorialModule__1.addLine("Fire weapon", "Left Click", Enum.KeyCode.ButtonR1);
        l__ContextualTutorialModule__1.addLine("Swap weapon", "Q", Enum.KeyCode.ButtonY);
        l__ContextualTutorialModule__1.addLine("Handbrake", "Left Shift", Enum.KeyCode.ButtonX);
        l__ContextualTutorialModule__1.fade(15);
    end;
end;
return v1;