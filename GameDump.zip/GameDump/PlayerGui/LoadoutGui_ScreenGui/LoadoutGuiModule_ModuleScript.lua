-- Roblox: Players.SilverAce293026.PlayerGui.LoadoutGui.LoadoutGuiModule
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__StarterGui__1 = game:GetService("StarterGui");
local l__ReplicatedStorage__2 = game:GetService("ReplicatedStorage");
local l__Modules__3 = l__ReplicatedStorage__2:WaitForChild("Modules");
local l__MusicModule__4 = require(l__Modules__3:WaitForChild("MusicModule"));
local l__GuiModule__5 = require(l__Modules__3:WaitForChild("GuiModule"));
local l__BlackScreen__6 = script.Parent:WaitForChild("BlackScreen");
local l__LoadoutFrame__7 = script.Parent:WaitForChild("LoadoutFrame");
local l__ShopGui__8 = script.Parent.Parent:WaitForChild("ShopGui");
local l__TweenService__9 = game:GetService("TweenService");
local u2 = TweenInfo.new(0.2);
local u3 = require(l__ReplicatedStorage__2.ReplicatedConfig).Mode ~= "Tycoon";
function v1.toggleShow(u4, p5) --[[ Line: 20 ]]
    -- upvalues: l__LoadoutFrame__7 (copy), l__GuiModule__5 (copy), u3 (copy), l__ShopGui__8 (copy), l__StarterGui__1 (copy), l__TweenService__9 (copy), l__BlackScreen__6 (copy), u2 (copy), l__MusicModule__4 (copy)
    if l__LoadoutFrame__7.Visible == u4 then
    else
        if u4 then
            l__GuiModule__5.Sounds.loadoutIn();
            l__GuiModule__5.Sounds.startHangarAmbient();
        else
            l__GuiModule__5.Sounds.loadoutOut();
            l__GuiModule__5.Sounds.stopHangarAmbient();
        end;
        if u3 then
            l__ShopGui__8.Enabled = false;
        else
            l__ShopGui__8.Enabled = not u4;
            local v6 = game:GetService("Players").LocalPlayer.PlayerGui:FindFirstChild("CustomToolbar");
            if v6 then
                v6.Enabled = not u4;
            end;
            l__StarterGui__1:SetCoreGuiEnabled(Enum.CoreGuiType.PlayerList, not u4);
        end;
        if p5 then
            l__LoadoutFrame__7.Visible = u4;
            l__MusicModule__4.setHardpointPlaying(u4);
            game.Players.LocalPlayer.PlayerGui.LoadingGui.Enabled = not u4;
        else
            local v7 = l__TweenService__9:Create(l__BlackScreen__6, u2, {
                BackgroundTransparency = 0
            });
            v7.Completed:Connect(function() --[[ Line: 46 ]]
                -- upvalues: l__LoadoutFrame__7 (ref), u4 (copy), l__TweenService__9 (ref), l__BlackScreen__6 (ref), u2 (ref), l__MusicModule__4 (ref)
                l__LoadoutFrame__7.Visible = u4;
                l__TweenService__9:Create(l__BlackScreen__6, u2, {
                    BackgroundTransparency = 1
                }):Play();
                l__MusicModule__4.setHardpointPlaying(u4);
            end);
            v7:Play();
        end;
    end;
end;
return v1;