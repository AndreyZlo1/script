-- Roblox: Players.SilverAce293026.PlayerGui.LoadoutGui.LoadoutFrame.LoadoutScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Players__2 = game:GetService("Players");
local l__Modules__3 = l__ReplicatedStorage__1:WaitForChild("Modules");
local l__GuiModule__4 = require(l__Modules__3:WaitForChild("GuiModule"));
local _ = l__Players__2.LocalPlayer;
local l__ExpLevels__5 = require(l__ReplicatedStorage__1:WaitForChild("WeaponProgression"):WaitForChild("ExpLevels"));
local l__ReplicatedConfig__6 = require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig"));
local l__AttachmentsEnabled__7 = l__ReplicatedConfig__6.FeatureToggles.AttachmentsEnabled;
local l__CamosEnabled__8 = l__ReplicatedConfig__6.FeatureToggles.CamosEnabled;
local u1 = require(l__ReplicatedStorage__1.ReplicatedConfig).Mode ~= "Tycoon";
local u2 = {
    changeWeapon = script.Parent:WaitForChild("ChangeWeapon"),
    changeNVG = script.Parent:WaitForChild("ChangeNVG"),
    setAttachment = script.Parent:WaitForChild("SetAttachment"),
    resetAttachments = script.Parent:WaitForChild("ResetAttachments"),
    setCamo = script.Parent:WaitForChild("SetCamo")
};
local u3 = {
    engine = l__ReplicatedStorage__1:WaitForChild("ACS_Engine"),
    gunModels = l__ReplicatedStorage__1.ACS_Engine:WaitForChild("GunModels"),
    accessories = l__ReplicatedStorage__1.ACS_Engine:WaitForChild("Accessories"),
    nvgs = l__ReplicatedStorage__1.ACS_Engine.Accessories:WaitForChild("NVG"),
    modules = l__ReplicatedStorage__1.ACS_Engine:WaitForChild("Modules"),
    attachmentsUtil = require(l__ReplicatedStorage__1.ACS_Engine.Modules:WaitForChild("AttachmentsUtil")),
    camosUtil = require(l__ReplicatedStorage__1.ACS_Engine.Modules:WaitForChild("CamosUtil"))
};
local l__RootFrame__9 = script.Parent:WaitForChild("RootFrame");
local l__LoadoutFrame__10 = l__RootFrame__9:WaitForChild("LoadoutFrame");
local u4 = {
    "Primary",
    "Primary2",
    "Secondary",
    "Melee",
    "Equipment",
    "NVG"
};
local u5 = {};
for _, v6 in u4 do
    local v7 = l__LoadoutFrame__10:WaitForChild(v6);
    u5[v6] = {
        frame = v7,
        button = v7:WaitForChild("Button")
    };
end;
local u8 = {
    frame = script.Parent,
    module = require(script.Parent.Parent:WaitForChild("LoadoutGuiModule")),
    borderColors = {
        equipped = Color3.fromRGB(130, 35, 0),
        normal = Color3.fromRGB(255, 69, 0)
    }
};
local u9 = {
    frame = l__RootFrame__9:WaitForChild("SelectFrame")
};
u9.frame.Position = UDim2.new(1, 0, 0, 0);
u9.scroll = u9.frame:WaitForChild("ScrollFrame");
u9.proto = u9.scroll:WaitForChild("ProtoCell");
u9.proto.Visible = false;
local u10 = {};
local l__BottomAction__11 = script.Parent:WaitForChild("BottomAction");
u10.customise = l__BottomAction__11:WaitForChild("DCustomizeFrame");
u10.back = l__BottomAction__11:WaitForChild("YBackButton");
u10.purchase = l__BottomAction__11:WaitForChild("BPurchaseButton");
u10.equip = l__BottomAction__11:WaitForChild("CEquipButton");
u10.close = l__BottomAction__11:WaitForChild("ZCloseButton");
u10.unequip = l__BottomAction__11:WaitForChild("CUnequipButton");
u10.equipAttachment = l__BottomAction__11:WaitForChild("FEquipAttachmentButton");
u10.unequipAttachment = l__BottomAction__11:WaitForChild("FUnequipAttachmentButton");
u10.equipCamo = l__BottomAction__11:WaitForChild("FEquipCamoButton");
u10.unequipCamo = l__BottomAction__11:WaitForChild("FUnequipCamoButton");
u10.prosCons = {};
u10.prosCons.frame = l__BottomAction__11:WaitForChild("AProsCons");
u10.prosCons.prosTitle = u10.prosCons.frame:WaitForChild("ProsTitle");
u10.prosCons.consTitle = u10.prosCons.frame:WaitForChild("ConsTitle");
u10.prosCons.frame:WaitForChild("Presets");
u10.prosCons.prosProto = u10.prosCons.frame.Presets:WaitForChild("ProsProto");
u10.prosCons.consProto = u10.prosCons.frame.Presets:WaitForChild("ConsProto");
l__GuiModule__4.setupCloseButtonSounds(u10.close:WaitForChild("ButtonFrame"):WaitForChild("Button"));
local u11 = {
    categoryFrame = l__RootFrame__9:WaitForChild("GunsmithFrame")
};
u11.categoryProto = u11.categoryFrame:WaitForChild("Presets"):WaitForChild("ProtoCell");
u11.attachmentFrame = l__RootFrame__9:WaitForChild("GunsmithSelectFrame");
u11.attachmentPresets = u11.attachmentFrame:WaitForChild("Presets");
u11.attachmentProto = u11.attachmentPresets:WaitForChild("ProtoCell");
u11.attachmentScroll = u11.attachmentFrame:WaitForChild("ScrollFrame");
local u12 = {
    Equipped = u11.attachmentPresets:WaitForChild("UiGradientEquipped"),
    Selected = u11.attachmentPresets:WaitForChild("UiGradientSelected"),
    Unlocked = u11.attachmentPresets:WaitForChild("UiGradientUnlocked")
};
local u13 = {
    camoButtonFrame = u10.customise:WaitForChild("DCamoButton")
};
u13.camoButton = u13.camoButtonFrame:WaitForChild("ButtonFrame"):WaitForChild("Button");
u13.camosFrame = l__RootFrame__9:WaitForChild("CamosFrame");
u13.camosSelectFrame = l__RootFrame__9:WaitForChild("CamosSelectFrame");
u13.categoryProto = u13.camosFrame:WaitForChild("Presets"):WaitForChild("ProtoCell");
u13.camoProto = u13.camosSelectFrame:WaitForChild("Presets"):WaitForChild("ProtoCell");
local l__PlayerEvents__12 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents");
local u14 = {
    getCurrentLoadout = l__PlayerEvents__12:WaitForChild("GetCurrentLoadout"),
    requestUnlockedGuns = l__PlayerEvents__12:WaitForChild("RequestUnlockedGunsList"),
    requestSetGun = l__PlayerEvents__12:WaitForChild("RequestSetGun"),
    requestAllWeaponData = l__PlayerEvents__12:WaitForChild("RequestAllWeaponData"),
    getAllAttachments = l__PlayerEvents__12:WaitForChild("GetWeaponAttachments"),
    setAttachments = l__PlayerEvents__12:WaitForChild("RequestAttachmentEquip"),
    requestGuns = l__PlayerEvents__12:WaitForChild("RequestGuns"),
    getCamoData = l__PlayerEvents__12:WaitForChild("GetWeaponCamoData"),
    setCamo = l__PlayerEvents__12:WaitForChild("SetWeaponCamo"),
    getForcedAttachments = l__PlayerEvents__12:WaitForChild("GetWeaponForcedAttachments"),
    getGunUnlockSchemas = l__PlayerEvents__12:WaitForChild("GetGunUnlockSchemas")
};
local u15 = u14.getGunUnlockSchemas:InvokeServer();
while u15 == nil do
    task.wait(1);
    u15 = u14.getGunUnlockSchemas:InvokeServer();
end;
local u16 = nil;
local u17 = nil;
local u18 = nil;
local u19 = nil;
local u20 = nil;
local u21 = nil;
local u22 = nil;
local u23 = nil;
local u24 = nil;
local u25 = {};
local u26 = {};
local u27 = false;
local function u33(p28, p29) --[[ Line: 176 ]]
    -- upvalues: u3 (copy), l__GuiModule__4 (copy)
    local l__Viewport__13 = p29.Viewport;
    local v30 = p29:GetAttribute("ItemType") == "NVG";
    local v31;
    if v30 then
        v31 = u3.nvgs:WaitForChild(p28):WaitForChild("MWTNVG_Up"):WaitForChild("Handle");
    else
        v31 = u3.gunModels:WaitForChild(p28);
    end;
    if v31 then
        local v32 = v31:Clone();
        if not v30 then
            v32.PrimaryPart = v32.Handle;
        end;
        v32.Parent = l__Viewport__13;
        l__GuiModule__4.CameraZoom.zoomToExtents(l__Viewport__13.CurrentCamera, v32);
    end;
end;
local u34 = nil;
local function u35() --[[ Line: 199 ]]
    -- upvalues: u16 (ref), u17 (ref), u18 (ref), u19 (ref), u21 (ref), u22 (ref), u23 (ref), u20 (ref), u24 (ref), u25 (ref), u26 (ref), u34 (ref), u27 (ref)
    u16 = nil;
    u17 = nil;
    u18 = nil;
    u19 = nil;
    u21 = nil;
    u22 = nil;
    u23 = nil;
    u20 = nil;
    u24 = nil;
    u25 = {};
    u26 = {};
    u34 = nil;
    u27 = false;
end;
local function u47() --[[ Line: 229 ]]
    -- upvalues: u18 (ref), u27 (ref), u21 (ref), u26 (ref), u22 (ref), u23 (ref), u20 (ref), u14 (copy), u16 (ref), l__CamosEnabled__8 (copy), u13 (copy), u9 (copy), l__AttachmentsEnabled__7 (copy), u10 (copy)
    local v36;
    if u18 == nil then
        v36 = { "close" };
    elseif u27 then
        if u21 == nil then
            v36 = u22 == nil and { "back" } or (u22 == u23 and { "unequipCamo", "back" } or { "equipCamo", "back" });
        else
            v36 = table.find(u26, u21) and { "unequipAttachment", "back" } or { "equipAttachment", "back" };
        end;
    else
        local v37 = false;
        local v38;
        if u20 then
            v38 = u20;
        else
            u20 = u14.getCurrentLoadout:InvokeServer();
            v38 = u20;
        end;
        local v39 = u14.getAllAttachments:InvokeServer(u18);
        local v40 = v38[u16] and v38[u16].name == u18 and true or v37;
        if l__CamosEnabled__8 then
            u13.camoButtonFrame.Visible = true;
        end;
        v36 = v40 and { "customise", "unequip", "close" } or { "customise", "equip", "close" };
        if not v39 or #v39 == 0 then
            local v41 = table.find(v36, "customise");
            if v41 then
                table.remove(v36, v41);
            end;
            u13.camoButtonFrame.Visible = false;
        end;
        for _, v42 in u9.scroll:GetChildren() do
            if v42.Name == u18 and v42:GetAttribute("ItemType") == "NVG" then
                local v43 = table.find(v36, "customise");
                if v43 then
                    table.remove(v36, v43);
                end;
                u13.camoButtonFrame.Visible = false;
            end;
        end;
        if not l__AttachmentsEnabled__7 then
            local v44 = table.find(v36, "customise");
            if v44 then
                table.remove(v36, v44);
            end;
            u13.camoButtonFrame.Visible = false;
        end;
    end;
    for v45, v46 in u10 do
        if type(v46) ~= "table" then
            v46.Visible = table.find(v36, v45) ~= nil;
        end;
    end;
end;
local function u59(p48) --[[ Line: 311 ]]
    -- upvalues: u18 (ref), u25 (ref), u20 (ref), u14 (copy), u16 (ref), u13 (copy), u12 (copy), u22 (ref), u2 (copy), u47 (copy)
    if p48 then
        if u18 then
            local v49 = u25[u18];
            if v49 then
                local v50;
                if u20 then
                    v50 = u20;
                else
                    u20 = u14.getCurrentLoadout:InvokeServer();
                    v50 = u20;
                end;
                local v51 = v50[u16];
                if v51 then
                    local l__lvl__14 = v49.lvl;
                    if l__lvl__14 then
                        for _, u52 in p48 do
                            local u53 = u13.camoProto:Clone();
                            u53.Name = u52.Index;
                            u53.CamoName.Text = u52.Name;
                            local u54 = v51.camo == u52.Index;
                            if u52.Unlocked then
                                if u54 then
                                    u53.Price.Text = "Equipped";
                                    u12.Equipped:Clone().Parent = u53;
                                else
                                    u53.Price.Text = "Unlocked";
                                    u12.Unlocked:Clone().Parent = u53;
                                end;
                            elseif l__lvl__14 < u52.Level then
                                u53.Price.Text = "Locked - Level " .. tostring(u52.Level);
                                u53.LockOverlay.Visible = true;
                                u12.Unlocked:Clone().Parent = u53;
                            else
                                local l__SuffixAmount__15 = u52.SuffixAmount;
                                local l__KillsRequired__16 = u52.KillsRequired;
                                if l__SuffixAmount__15 and l__KillsRequired__16 then
                                    u53.Price.Text = "Locked - Get " .. tostring(l__KillsRequired__16) .. " " .. u52.Class .. " " .. tostring(u52.Required) .. " times";
                                else
                                    u53.Price.Text = "Locked - " .. tostring(u52.Required) .. " " .. u52.Class .. " required";
                                end;
                                u53.LockOverlay.Visible = true;
                                u12.Unlocked:Clone().Parent = u53;
                            end;
                            u53.Button.Activated:Connect(function() --[[ Line: 359 ]]
                                -- upvalues: u52 (copy), u22 (ref), u2 (ref), u54 (copy), u53 (copy), u12 (ref), u13 (ref), u47 (ref)
                                if u52.Unlocked then
                                    if u22 then
                                        u2.setCamo:Fire(nil);
                                    end;
                                    if u54 then
                                        u22 = u52.Index;
                                        u2.setCamo:Fire(u22);
                                        local v55 = u53:FindFirstChildOfClass("UIGradient");
                                        if v55 then
                                            v55:Destroy();
                                        end;
                                        u12.Equipped:Clone().Parent = u53;
                                    else
                                        local v56 = u53:FindFirstChildOfClass("UIGradient");
                                        if v56 then
                                            v56:Destroy();
                                        end;
                                        u12.Selected:Clone().Parent = u53;
                                        u22 = u52.Index;
                                        u2.setCamo:Fire(u22);
                                    end;
                                    for _, v57 in u13.camosSelectFrame.ScrollFrame:GetChildren() do
                                        if v57:IsA("Frame") and v57 ~= u53 then
                                            local v58 = v57:FindFirstChildOfClass("UIGradient");
                                            if v58.Name == u12.Selected.Name then
                                                v58:Destroy();
                                                u12.Unlocked:Clone().Parent = v57;
                                            end;
                                        end;
                                    end;
                                    u47();
                                end;
                            end);
                            u53.Parent = u13.camosSelectFrame.ScrollFrame;
                            u53.Visible = true;
                        end;
                    end;
                end;
            end;
        end;
    end;
end;
local function u71() --[[ Line: 413 ]]
    -- upvalues: u18 (ref), u13 (copy), u14 (copy), u3 (copy), u22 (ref), u23 (ref), u2 (copy), u59 (copy), u47 (copy)
    if u18 then
        for _, v60 in u13.camosFrame:GetChildren() do
            if v60:IsA("Frame") and v60 ~= u13.categoryProto then
                v60:Destroy();
            end;
        end;
        for _, v61 in u13.camosSelectFrame.ScrollFrame:GetChildren() do
            if v61:IsA("Frame") and v61 ~= u13.camoProto then
                v61:Destroy();
            end;
        end;
        local v62 = {};
        for _, v63 in u14.getCamoData:InvokeServer(u18) do
            for _, v64 in v63.CamoInfo do
                local l__Index__17 = v64.Index;
                local v65 = u3.camosUtil.getCategoryFromIndex(l__Index__17);
                if not v62[v65] then
                    v62[v65] = {};
                end;
                local v66 = {
                    Level = v63.Level,
                    Class = v63.Class,
                    Index = l__Index__17,
                    Required = v64.Required,
                    Unlocked = v64.Unlocked,
                    SuffixAmount = v64.SuffixAmount,
                    KillsRequired = v64.KillsRequired,
                    Name = u3.camosUtil.getNameFromIndex(l__Index__17)
                };
                table.insert(v62[v65], v66);
            end;
        end;
        for v67, u68 in v62 do
            local v69 = u13.categoryProto:Clone();
            v69.Button.Text = v67;
            v69.Parent = u13.camosFrame;
            v69.Visible = true;
            v69.Button.Activated:Connect(function() --[[ Line: 460 ]]
                -- upvalues: u13 (ref), u22 (ref), u23 (ref), u2 (ref), u59 (ref), u68 (copy), u47 (ref)
                for _, v70 in u13.camosSelectFrame.ScrollFrame:GetChildren() do
                    if v70:IsA("Frame") and v70 ~= u13.categoryProto then
                        v70:Destroy();
                    end;
                end;
                if u22 and u22 ~= u23 then
                    u2.setCamo:Fire(nil);
                end;
                u22 = nil;
                u59(u68);
                u47();
            end);
        end;
    end;
end;
local function u78(p72) --[[ Line: 482 ]]
    -- upvalues: u10 (copy)
    for _, v73 in u10.prosCons.frame:GetChildren() do
        if v73:IsA("Frame") then
            if v73 == u10.prosCons.prosTitle and true or v73 == u10.prosCons.consTitle then
                v73.Visible = false;
            else
                v73:Destroy();
            end;
        end;
    end;
    if p72 == nil then
    else
        local l__prosTitle__18 = u10.prosCons.prosTitle;
        local l__consTitle__19 = u10.prosCons.consTitle;
        l__prosTitle__18.Visible = #p72.Pros > 0;
        l__consTitle__19.Visible = #p72.Cons > 0;
        for _, v74 in p72.Pros do
            local v75 = u10.prosCons.prosProto:Clone();
            v75.TextLabel.Text = "<b>+</b> " .. v74;
            v75.Parent = u10.prosCons.frame;
            v75.Visible = true;
        end;
        for _, v76 in p72.Cons do
            local v77 = u10.prosCons.consProto:Clone();
            v77.TextLabel.Text = "<b>-</b> " .. v76;
            v77.Parent = u10.prosCons.frame;
            v77.Visible = true;
        end;
    end;
end;
local function u105(p79) --[[ Line: 518 ]]
    -- upvalues: u20 (ref), u14 (copy), u16 (ref), u18 (ref), u11 (copy), u12 (copy), u26 (ref), u21 (ref), u2 (copy), u78 (copy), u3 (copy), u47 (copy)
    local v80;
    if u20 then
        v80 = u20;
    else
        u20 = u14.getCurrentLoadout:InvokeServer();
        v80 = u20;
    end;
    local v81 = v80[u16];
    if not v81 then
        return;
    end;
    local v82 = u14.getForcedAttachments:InvokeServer(u18);
    for _, u83 in p79 do
        local u84;
        if v82 then
            local v85 = false;
            for _, v86 in v82 do
                if v86 == u83.ID then
                    v85 = true;
                    break;
                end;
            end;
            if not v85 then
                u84 = u11.attachmentProto:Clone();
                u84.Name = u83.ID;
                u84.AttachmentName.Text = u83.Name;
                u84.Visible = true;
                u84.Parent = u11.attachmentScroll;
                u84.LayoutOrder = u83.Rank or 0;
                if v81.attachments and table.find(v81.attachments, u83.ID) and true or false then
                    u84.Price.Text = "Equipped";
                    u12.Equipped:Clone().Parent = u84;
                else
                    if u83.Status == "Locked" then
                        u84.Price.Text = "Locked - Level " .. u83.Rank;
                        u84.LockOverlay.Visible = true;
                    elseif u83.Status == "Unlocked" then
                        u84.Price.Text = "Unlocked";
                    end;
                    u12.Unlocked:Clone().Parent = u84;
                end;
                u84.Button.Activated:Connect(function() --[[ Line: 567 ]]
                    -- upvalues: u83 (copy), u26 (ref), u21 (ref), u2 (ref), u78 (ref), u84 (copy), u12 (ref), u3 (ref), u11 (ref), u47 (ref)
                    if u83.Status == "Locked" then
                    else
                        local v96 = table.find(u26, u83.ID);
                        local v97 = u21;
                        if v97 then
                            u2.setAttachment:Fire(v97, false);
                            u78(nil);
                        end;
                        if v96 then
                            u21 = u83.ID;
                            u2.setAttachment:Fire(u21, true);
                            local v98 = u84:FindFirstChildOfClass("UIGradient");
                            if v98 then
                                v98:Destroy();
                            end;
                            u12.Equipped:Clone().Parent = u84;
                        else
                            local v99 = u84:FindFirstChildOfClass("UIGradient");
                            if v99 then
                                v99:Destroy();
                            end;
                            u12.Selected:Clone().Parent = u84;
                            u21 = u83.ID;
                            u2.setAttachment:Fire(u21, true);
                        end;
                        local v100 = u3.attachmentsUtil.getAttDataFromHash(u83.ID);
                        local v101 = u3.attachmentsUtil.getAttachmentModule(v100);
                        if v101 then
                            local v102 = require(v101);
                            if v102.UiStats then
                                u78(v102.UiStats);
                            end;
                        end;
                        for _, v103 in u11.attachmentScroll:GetChildren() do
                            if v103:IsA("Frame") and v103 ~= u84 then
                                local v104 = v103:FindFirstChildOfClass("UIGradient");
                                if v104.Name == u12.Selected.Name then
                                    v104:Destroy();
                                    u12.Unlocked:Clone().Parent = v103;
                                end;
                            end;
                        end;
                        u47();
                    end;
                end);
            end;
        else
            u84 = u11.attachmentProto:Clone();
            u84.Name = u83.ID;
            u84.AttachmentName.Text = u83.Name;
            u84.Visible = true;
            u84.Parent = u11.attachmentScroll;
            u84.LayoutOrder = u83.Rank or 0;
            if v81.attachments and table.find(v81.attachments, u83.ID) and true or false then
                u84.Price.Text = "Equipped";
                u12.Equipped:Clone().Parent = u84;
            else
                if u83.Status == "Locked" then
                    u84.Price.Text = "Locked - Level " .. u83.Rank;
                    u84.LockOverlay.Visible = true;
                elseif u83.Status == "Unlocked" then
                    u84.Price.Text = "Unlocked";
                end;
                u12.Unlocked:Clone().Parent = u84;
            end;
            u84.Button.Activated:Connect(function() --[[ Line: 567 ]]
                -- upvalues: u83 (copy), u26 (ref), u21 (ref), u2 (ref), u78 (ref), u84 (copy), u12 (ref), u3 (ref), u11 (ref), u47 (ref)
                if u83.Status == "Locked" then
                else
                    local v96 = table.find(u26, u83.ID);
                    local v97 = u21;
                    if v97 then
                        u2.setAttachment:Fire(v97, false);
                        u78(nil);
                    end;
                    if v96 then
                        u21 = u83.ID;
                        u2.setAttachment:Fire(u21, true);
                        local v98 = u84:FindFirstChildOfClass("UIGradient");
                        if v98 then
                            v98:Destroy();
                        end;
                        u12.Equipped:Clone().Parent = u84;
                    else
                        local v99 = u84:FindFirstChildOfClass("UIGradient");
                        if v99 then
                            v99:Destroy();
                        end;
                        u12.Selected:Clone().Parent = u84;
                        u21 = u83.ID;
                        u2.setAttachment:Fire(u21, true);
                    end;
                    local v100 = u3.attachmentsUtil.getAttDataFromHash(u83.ID);
                    local v101 = u3.attachmentsUtil.getAttachmentModule(v100);
                    if v101 then
                        local v102 = require(v101);
                        if v102.UiStats then
                            u78(v102.UiStats);
                        end;
                    end;
                    for _, v103 in u11.attachmentScroll:GetChildren() do
                        if v103:IsA("Frame") and v103 ~= u84 then
                            local v104 = v103:FindFirstChildOfClass("UIGradient");
                            if v104.Name == u12.Selected.Name then
                                v104:Destroy();
                                u12.Unlocked:Clone().Parent = v103;
                            end;
                        end;
                    end;
                    u47();
                end;
            end);
        end;
    end;
end;
local function u114() --[[ Line: 632 ]]
    -- upvalues: u18 (ref), u11 (copy), u14 (copy), u21 (ref), u26 (ref), u2 (copy), u78 (copy), u105 (copy), u47 (copy)
    if u18 then
        for _, v106 in u11.categoryFrame:GetChildren() do
            if v106:IsA("Frame") and v106 ~= u11.categoryProto then
                v106:Destroy();
            end;
        end;
        for _, v107 in u11.attachmentScroll:GetChildren() do
            if v107:IsA("Frame") and v107 ~= u11.attachmentProto then
                v107:Destroy();
            end;
        end;
        local v108 = {};
        for _, v109 in u14.getAllAttachments:InvokeServer(u18) do
            if not v108[v109.Category] then
                v108[v109.Category] = {};
            end;
            table.insert(v108[v109.Category], v109);
        end;
        for v110, u111 in v108 do
            local v112 = u11.categoryProto:Clone();
            v112.Button.Text = v110;
            v112.Parent = u11.categoryFrame;
            v112.Visible = true;
            v112.Button.Activated:Connect(function() --[[ Line: 665 ]]
                -- upvalues: u11 (ref), u21 (ref), u26 (ref), u2 (ref), u78 (ref), u105 (ref), u111 (copy), u47 (ref)
                for _, v113 in u11.attachmentScroll:GetChildren() do
                    if v113:IsA("Frame") and v113 ~= u11.attachmentProto then
                        v113:Destroy();
                    end;
                end;
                if u21 and not table.find(u26, u21) then
                    u2.setAttachment:Fire(u21, false);
                end;
                u21 = nil;
                u78(nil);
                u105(u111);
                u47();
            end);
        end;
    end;
end;
local function u120() --[[ Line: 690 ]]
    -- upvalues: u20 (ref), u14 (copy), u5 (copy), u33 (copy)
    local v115;
    if u20 then
        v115 = u20;
    else
        u20 = u14.getCurrentLoadout:InvokeServer();
        v115 = u20;
    end;
    for v116, v117 in u5 do
        local v118;
        if v115[v116] then
            v118 = v115[v116].name;
        else
            v118 = nil;
        end;
        local l__frame__20 = v117.frame;
        local l__Viewport__21 = l__frame__20.Viewport;
        if not l__Viewport__21.CurrentCamera then
            l__Viewport__21.CurrentCamera = Instance.new("Camera", script);
            local l__CurrentCamera__22 = l__Viewport__21.CurrentCamera;
            l__CurrentCamera__22.CFrame = l__CurrentCamera__22.CFrame * CFrame.Angles(0, 1.5707963267948966, 0);
        end;
        for _, v119 in l__Viewport__21:GetChildren() do
            v119:Destroy();
        end;
        if v118 ~= nil then
            u33(v118, l__frame__20);
        end;
    end;
end;
local function u122() --[[ Line: 716 ]]
    -- upvalues: u18 (ref), u14 (copy), u16 (ref), u9 (copy), u8 (copy), u2 (copy), u26 (ref), u20 (ref), u47 (copy), u120 (copy)
    if u18 then
        if u14.requestSetGun:InvokeServer(u18, u16) then
            for _, v121 in u9.scroll:GetChildren() do
                if v121:IsA("Frame") then
                    v121.BorderColor3 = v121.Name == u18 and u8.borderColors.equipped or u8.borderColors.normal;
                    v121.BorderSizePixel = v121.Name == u18 and 2 or 0;
                end;
            end;
            u2.resetAttachments:Invoke();
            u26 = {};
            u20 = u14.getCurrentLoadout:InvokeServer();
            u47();
            u120();
        end;
    end;
end;
u10.back.ButtonFrame.Button.Activated:Connect(function() --[[ Line: 741 ]]
    -- upvalues: u27 (ref), u21 (ref), u22 (ref), u47 (copy), u78 (copy), u2 (copy), u20 (ref), u14 (copy), u16 (ref), u26 (ref), u23 (ref), l__LoadoutFrame__10 (copy), u9 (copy), u11 (copy), u13 (copy)
    u27 = false;
    u21 = nil;
    u22 = nil;
    u47();
    u78(nil);
    u2.resetAttachments:Invoke();
    u2.setCamo:Fire(nil);
    local v123;
    if u20 then
        v123 = u20;
    else
        u20 = u14.getCurrentLoadout:InvokeServer();
        v123 = u20;
    end;
    if v123 and v123[u16] then
        u26 = v123[u16].attachments or {};
    end;
    for _, v124 in u26 do
        u2.setAttachment:Fire(v124, true);
    end;
    if u23 then
        u2.setCamo:Fire(u23);
    end;
    l__LoadoutFrame__10.Visible = true;
    u9.frame.Visible = true;
    u11.categoryFrame.Visible = false;
    u11.attachmentFrame.Visible = false;
    u13.camosFrame.Visible = false;
    u13.camosSelectFrame.Visible = false;
end);
u10.customise.DCustomizeButton.ButtonFrame.Button.Activated:Connect(function() --[[ Line: 777 ]]
    -- upvalues: u20 (ref), u14 (copy), u16 (ref), u18 (ref), u122 (copy), u27 (ref), u47 (copy), l__LoadoutFrame__10 (copy), u9 (copy), u114 (copy), u11 (copy)
    local v125;
    if u20 then
        v125 = u20;
    else
        u20 = u14.getCurrentLoadout:InvokeServer();
        v125 = u20;
    end;
    if not v125[u16] or v125[u16].name ~= u18 then
        u122();
    end;
    u27 = true;
    u47();
    l__LoadoutFrame__10.Visible = false;
    u9.frame.Visible = false;
    u114();
    u11.categoryFrame.Visible = true;
    u11.attachmentFrame.Visible = true;
end);
u13.camoButton.Activated:Connect(function() --[[ Line: 796 ]]
    -- upvalues: u20 (ref), u14 (copy), u16 (ref), u18 (ref), u122 (copy), u27 (ref), u47 (copy), l__LoadoutFrame__10 (copy), u9 (copy), u71 (copy), u13 (copy)
    local v126;
    if u20 then
        v126 = u20;
    else
        u20 = u14.getCurrentLoadout:InvokeServer();
        v126 = u20;
    end;
    if not v126[u16] or v126[u16].name ~= u18 then
        u122();
    end;
    u27 = true;
    u47();
    l__LoadoutFrame__10.Visible = false;
    u9.frame.Visible = false;
    u71();
    u13.camosFrame.Visible = true;
    u13.camosSelectFrame.Visible = true;
end);
u10.equip.ButtonFrame.Button.Activated:Connect(function() --[[ Line: 815 ]]
    -- upvalues: u122 (copy)
    u122();
end);
u10.unequip.ButtonFrame.Button.Activated:Connect(function() --[[ Line: 819 ]]
    -- upvalues: u18 (ref), u14 (copy), u16 (ref), u9 (copy), u8 (copy), u26 (ref), u2 (copy), u20 (ref), u47 (copy), u120 (copy)
    if u18 then
        if u14.requestSetGun:InvokeServer(nil, u16) then
            for _, v127 in u9.scroll:GetChildren() do
                if v127:IsA("Frame") then
                    v127.BorderColor3 = u8.borderColors.normal;
                end;
            end;
            u26 = {};
            u2.resetAttachments:Invoke();
            u20 = u14.getCurrentLoadout:InvokeServer();
            u47();
            u120();
        end;
    end;
end);
u10.equipCamo.ButtonFrame.Button.Activated:Connect(function() --[[ Line: 841 ]]
    -- upvalues: u18 (ref), u22 (ref), u23 (ref), u14 (copy), u13 (copy), u12 (copy), u20 (ref), u47 (copy), u2 (copy)
    if u18 then
        if u22 then
            if u23 == u22 then
            elseif u14.setCamo:InvokeServer(u18, u22) then
                u23 = u22;
                local v128 = u13.camosSelectFrame.ScrollFrame:WaitForChild(u22);
                if v128 then
                    local v129 = v128:FindFirstChildOfClass("UIGradient");
                    if v129 then
                        v129:Destroy();
                    end;
                    u12.Equipped:Clone().Parent = v128;
                    v128.Price.Text = "Equipped";
                end;
                for _, v130 in u13.camosSelectFrame.ScrollFrame:GetChildren() do
                    if v130:IsA("Frame") and v130 ~= v128 then
                        local v131 = v130:FindFirstChildOfClass("UIGradient");
                        if v131.Name == u12.Equipped.Name then
                            v131:Destroy();
                            u12.Unlocked:Clone().Parent = v130;
                            v130.Price.Text = "Unlocked";
                        end;
                    end;
                end;
                u20 = u14.getCurrentLoadout:InvokeServer();
                u47();
                u2.setCamo:Fire(u22);
            end;
        end;
    end;
end);
u10.unequipCamo.ButtonFrame.Button.Activated:Connect(function() --[[ Line: 882 ]]
    -- upvalues: u18 (ref), u22 (ref), u14 (copy), u23 (ref), u13 (copy), u12 (copy), u20 (ref), u47 (copy), u2 (copy)
    if u18 then
        if u22 then
            if u14.setCamo:InvokeServer(u18, nil) then
                u23 = nil;
                local v132 = u13.camosSelectFrame.ScrollFrame:FindFirstChild(u22);
                if v132 then
                    local v133 = v132:FindFirstChildOfClass("UIGradient");
                    if v133 then
                        v133:Destroy();
                    end;
                    u12.Selected:Clone().Parent = v132;
                    v132.Price.Text = "Unlocked";
                end;
                u20 = u14.getCurrentLoadout:InvokeServer();
                u47();
                u2.setCamo:Fire(nil);
            end;
        end;
    end;
end);
u10.equipAttachment.ButtonFrame.Button.Activated:Connect(function() --[[ Line: 907 ]]
    -- upvalues: u18 (ref), u21 (ref), u26 (ref), u14 (copy), u11 (copy), u12 (copy), u20 (ref), u47 (copy), u2 (copy)
    if not u18 then
        return;
    end;
    if not u21 then
        return;
    end;
    if table.find(u26, u21) then
        return;
    end;
    for v134, v135 in u26 do
        if string.sub(u21, 1, 1) == string.sub(v135, 1, 1) and v135 ~= u21 then
            table.remove(u26, v134);
            break;
        end;
    end;
    table.insert(u26, u21);
    if u14.setAttachments:InvokeServer(u18, u26) then
        local v136 = u11.attachmentScroll:FindFirstChild(u21);
        if v136 then
            local v137 = v136:FindFirstChildOfClass("UIGradient");
            if v137 then
                v137:Destroy();
            end;
            u12.Equipped:Clone().Parent = v136;
            v136.Price.Text = "Equipped";
        end;
        for _, v138 in u11.attachmentScroll:GetChildren() do
            if v138:IsA("Frame") and v138 ~= v136 then
                local v139 = v138:FindFirstChildOfClass("UIGradient");
                if v139.Name == u12.Equipped.Name then
                    v139:Destroy();
                    u12.Unlocked:Clone().Parent = v138;
                    v138.Price.Text = "Unlocked";
                end;
            end;
        end;
        u20 = u14.getCurrentLoadout:InvokeServer();
        u47();
        u2.setAttachment:Fire(u21, true);
    else
        table.remove(u26, table.find(u26, u21));
    end;
end);
u10.unequipAttachment.ButtonFrame.Button.Activated:Connect(function() --[[ Line: 959 ]]
    -- upvalues: u18 (ref), u21 (ref), u26 (ref), u14 (copy), u11 (copy), u12 (copy), u20 (ref), u47 (copy), u2 (copy)
    if u18 then
        if u21 then
            table.remove(u26, table.find(u26, u21));
            if u14.setAttachments:InvokeServer(u18, u26) then
                local v140 = u11.attachmentScroll:FindFirstChild(u21);
                if v140 then
                    local v141 = v140:FindFirstChildOfClass("UIGradient");
                    if v141 then
                        v141:Destroy();
                    end;
                    u12.Selected:Clone().Parent = v140;
                    v140.Price.Text = "Unlocked";
                end;
                u20 = u14.getCurrentLoadout:InvokeServer();
                u47();
                u2.setAttachment:Fire(u21, false);
                local v142 = u14.getForcedAttachments:InvokeServer(u18);
                if v142[string.sub(u21, 1, 1)] then
                    u2.setAttachment:Fire(v142[string.sub(u21, 1, 1)], true);
                end;
            else
                table.insert(u26, u21);
            end;
        end;
    end;
end);
u10.close.ButtonFrame.Button.Activated:Connect(function() --[[ Line: 992 ]]
    -- upvalues: u8 (copy), u1 (copy), u35 (copy), u14 (copy)
    u8.module.toggleShow(false, u1);
    u35();
    u14.requestGuns:FireServer();
end);
local function u157(u143, p144, p145) --[[ Line: 1004 ]]
    -- upvalues: u9 (copy), u25 (ref), l__ExpLevels__5 (copy), u33 (copy), l__GuiModule__4 (copy), u20 (ref), u14 (copy), u18 (ref), u16 (ref), u26 (ref), u23 (ref), u2 (copy), u47 (copy)
    local u146 = u9.proto:Clone();
    u146.Name = u143;
    u146.SlotName.Text = u143;
    u146:SetAttribute("ItemType", p144);
    if p144 ~= "NVG" and (p144 ~= "Equipment" and p144 ~= "Melee") then
        u146.LevelLabel.Visible = true;
        u146.ExpBar.Visible = true;
        local v147 = u25[u143];
        local v148, v149, v150;
        if v147 then
            v148 = v147.lvl;
            v149 = v147.lvlExp;
            v150 = l__ExpLevels__5[v148 + 1] or 100;
        else
            v148 = 0;
            v149 = 0;
            v150 = 1000;
        end;
        u146.LayoutOrder = -v148;
        u146.LevelLabel.Text = "Level " .. v148;
        u146.ExpBar.Fill.Size = UDim2.new(v149 / v150, 0, 1, 0);
    end;
    u33(u143, u146);
    l__GuiModule__4.setupLoadoutItemSounds(u146.Button);
    local u151;
    if u20 then
        u151 = u20;
    else
        u20 = u14.getCurrentLoadout:InvokeServer();
        u151 = u20;
    end;
    if p145 then
        return u146;
    end;
    u146.Button.Activated:Connect(function() --[[ Line: 1038 ]]
        -- upvalues: u151 (ref), u20 (ref), u14 (ref), u18 (ref), u143 (copy), u16 (ref), u26 (ref), u23 (ref), u2 (ref), u146 (copy), u9 (ref), u47 (ref)
        local v152;
        if u20 then
            v152 = u20;
        else
            u20 = u14.getCurrentLoadout:InvokeServer();
            v152 = u20;
        end;
        u151 = v152;
        if u18 == u143 then
            local v153 = u151[u16] and u151[u16].name == u18 and true or false;
            u18 = nil;
            u26 = {};
            u23 = nil;
            u2.resetAttachments:Invoke();
            u2.changeWeapon:Invoke(nil);
            u2.setCamo:Fire(nil);
            if not v153 then
                u146.BorderSizePixel = 0;
            end;
        else
            local v154 = u151[u16];
            if v154 ~= nil then
                v154 = v154.name;
            end;
            if u18 then
                local v155 = u9.scroll:FindFirstChild(u18);
                if v155 and v154 ~= u18 then
                    v155.BorderSizePixel = 0;
                end;
            end;
            if v154 == u143 then
                u26 = u151[u16].attachments or {};
                u23 = u151[u16].camo or nil;
            else
                u26 = {};
                u23 = nil;
            end;
            u18 = u143;
            u146.BorderSizePixel = 2;
            u2.resetAttachments:Invoke();
            u2.changeWeapon:Invoke(u18);
            u2.setCamo:Fire(u23);
            for _, v156 in u26 do
                u2.setAttachment:Fire(v156, true);
            end;
        end;
        u47();
    end);
    return u146;
end;
local function u183(p158) --[[ Line: 1102 ]]
    -- upvalues: u16 (ref), u5 (copy), u9 (copy), u2 (copy), u18 (ref), u47 (copy), u34 (ref), u14 (copy), u20 (ref), u157 (copy), u8 (copy), u26 (ref), u23 (ref), u33 (copy), u15 (ref)
    if u16 == p158 then
        local v159 = u5[p158];
        if v159 then
            v159.frame.BorderSizePixel = 0;
            local v160 = UDim2.new(1, 0, 0, 0);
            u9.frame:TweenPosition(v160, Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.25, true);
            u2.changeWeapon:Invoke(nil);
            u18 = nil;
            u16 = nil;
            u47();
            return;
        else
            return;
        end;
    end;
    u18 = nil;
    u47();
    for _, v161 in u9.scroll:GetChildren() do
        if v161:IsA("Frame") and v161 ~= u9.proto then
            v161:Destroy();
        end;
    end;
    u16 = p158;
    local v162;
    if u34 then
        v162 = u34;
    else
        u34 = u14.requestUnlockedGuns:InvokeServer();
        v162 = u34;
    end;
    local v163 = p158 == "Primary2" and "Primary" or p158;
    local v164 = v162[v163] or {};
    local v165;
    if u20 then
        v165 = u20;
    else
        u20 = u14.getCurrentLoadout:InvokeServer();
        v165 = u20;
    end;
    local v166 = v165[p158];
    local v167;
    if v166 then
        v167 = v166.name;
    else
        v167 = nil;
    end;
    local v168 = {};
    for _, v169 in v164 do
        local v170, v171;
        if p158 == "Primary" then
            local l__Primary2__23 = v165.Primary2;
            if not l__Primary2__23 or l__Primary2__23.name ~= v169 then
                table.insert(v168, v169);
                v170 = u157(v169, p158);
                v170:WaitForChild("Viewport");
                v170.Parent = u9.scroll;
                v170.Visible = true;
                v170.Name = v169;
                if v167 == v169 then
                    v170.BorderSizePixel = 2;
                    v170.BorderColor3 = u8.borderColors.equipped;
                    u18 = v169;
                    u2.resetAttachments:Invoke();
                    u2.changeWeapon:Invoke(u18);
                    if v166.attachments then
                        u26 = v166.attachments;
                        for _, v174 in u26 do
                            u2.setAttachment:Fire(v174, true);
                        end;
                    end;
                    if v166.camo then
                        u23 = v166.camo;
                        u2.setCamo:Fire(u23);
                    end;
                    u47();
                end;
                v171 = Instance.new("Camera");
                v171.CFrame = v171.CFrame * CFrame.Angles(0, 1.5707963267948966, 0);
                v170.Viewport.CurrentCamera = v171;
                u33(v169, v170);
            end;
        else
            if p158 ~= "Primary2" then
                table.insert(v168, v169);
                v170 = u157(v169, p158);
                v170:WaitForChild("Viewport");
                v170.Parent = u9.scroll;
                v170.Visible = true;
                v170.Name = v169;
                if v167 == v169 then
                    v170.BorderSizePixel = 2;
                    v170.BorderColor3 = u8.borderColors.equipped;
                    u18 = v169;
                    u2.resetAttachments:Invoke();
                    u2.changeWeapon:Invoke(u18);
                    if v166.attachments then
                        u26 = v166.attachments;
                        for _, v174 in u26 do
                            u2.setAttachment:Fire(v174, true);
                        end;
                    end;
                    if v166.camo then
                        u23 = v166.camo;
                        u2.setCamo:Fire(u23);
                    end;
                    u47();
                end;
                v171 = Instance.new("Camera");
                v171.CFrame = v171.CFrame * CFrame.Angles(0, 1.5707963267948966, 0);
                v170.Viewport.CurrentCamera = v171;
                u33(v169, v170);
            end;
            local l__Primary__24 = v165.Primary;
            if not l__Primary__24 or l__Primary__24.name ~= v169 then
                table.insert(v168, v169);
                v170 = u157(v169, p158);
                v170:WaitForChild("Viewport");
                v170.Parent = u9.scroll;
                v170.Visible = true;
                v170.Name = v169;
                if v167 == v169 then
                    v170.BorderSizePixel = 2;
                    v170.BorderColor3 = u8.borderColors.equipped;
                    u18 = v169;
                    u2.resetAttachments:Invoke();
                    u2.changeWeapon:Invoke(u18);
                    if v166.attachments then
                        u26 = v166.attachments;
                        for _, v174 in u26 do
                            u2.setAttachment:Fire(v174, true);
                        end;
                    end;
                    if v166.camo then
                        u23 = v166.camo;
                        u2.setCamo:Fire(u23);
                    end;
                    u47();
                end;
                v171 = Instance.new("Camera");
                v171.CFrame = v171.CFrame * CFrame.Angles(0, 1.5707963267948966, 0);
                v170.Viewport.CurrentCamera = v171;
                u33(v169, v170);
            end;
        end;
    end;
    while not u15[v163] do
        task.wait(1);
        u15 = u14.getGunUnlockSchemas:InvokeServer();
    end;
    for _, v175 in u15[v163] do
        if not table.find(v168, v175.name) then
            local v176, v177, v178;
            if v163 == "Primary" then
                local v179 = p158 == "Primary" and "Primary2" or "Primary";
                if v165[v179] == nil or v165[v179].name ~= v175.name then
                    v176 = v175.name;
                    v177 = u157(v176, p158, true);
                    v177:WaitForChild("Viewport");
                    v177.Parent = u9.scroll;
                    v177.Visible = true;
                    v177.Name = v176;
                    v177.LockOverlay.Visible = true;
                    v177.LayoutOrder = 3000;
                    v177.LockOverlay.Title.Text = "Locked - " .. v176;
                    v178 = v175.schema;
                    if v178 == "Group" then
                        v177.LockOverlay.Desc.Text = "Join the group to unlock";
                    elseif v178 == "Tycoon" then
                        v177.LockOverlay.Desc.Text = "Progress your tycoon to unlock";
                    elseif v178 == "Challenges" then
                        if v176 == "Infected Knife" then
                            v177.LockOverlay.Desc.Text = "Complete the Halloween challenge to unlock";
                        else
                            v177.LockOverlay.Desc.Text = "Challenge expired";
                        end;
                    elseif v178 == "Passes" then
                        v177.LayoutOrder = #v175.pass + 1000;
                        v177.LockOverlay.Desc.Text = "Purchase the " .. v175.pass .. " gamepass";
                    end;
                end;
            else
                v176 = v175.name;
                v177 = u157(v176, p158, true);
                v177:WaitForChild("Viewport");
                v177.Parent = u9.scroll;
                v177.Visible = true;
                v177.Name = v176;
                v177.LockOverlay.Visible = true;
                v177.LayoutOrder = 3000;
                v177.LockOverlay.Title.Text = "Locked - " .. v176;
                v178 = v175.schema;
                if v178 == "Group" then
                    v177.LockOverlay.Desc.Text = "Join the group to unlock";
                elseif v178 == "Tycoon" then
                    v177.LockOverlay.Desc.Text = "Progress your tycoon to unlock";
                elseif v178 == "Challenges" then
                    if v176 == "Infected Knife" then
                        v177.LockOverlay.Desc.Text = "Complete the Halloween challenge to unlock";
                    else
                        v177.LockOverlay.Desc.Text = "Challenge expired";
                    end;
                elseif v178 == "Passes" then
                    v177.LayoutOrder = #v175.pass + 1000;
                    v177.LockOverlay.Desc.Text = "Purchase the " .. v175.pass .. " gamepass";
                end;
            end;
        end;
    end;
    if not u18 then
        u2.resetAttachments:Invoke();
        u2.changeWeapon:Invoke(nil);
    end;
    for v180, v181 in u5 do
        v181.frame.BorderSizePixel = p158 == v180 and 2 or 0;
    end;
    local v182 = UDim2.new(0.68, 0, 0, 0);
    u9.frame:TweenPosition(v182, Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.25, true);
end;
u8.frame:GetPropertyChangedSignal("Visible"):Connect(function() --[[ Line: 1257 ]]
    -- upvalues: u35 (copy), u9 (copy), u47 (copy), u78 (copy), u2 (copy), l__LoadoutFrame__10 (copy), u11 (copy), u8 (copy), u25 (ref), u14 (copy), u20 (ref), u4 (copy), u24 (ref), u5 (copy), u120 (copy)
    u35();
    local v184 = UDim2.new(1, 0, 0, 0);
    u9.frame:TweenPosition(v184, Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.25, true);
    u47();
    u78(nil);
    u2.resetAttachments:Invoke();
    u2.changeWeapon:Invoke(nil);
    l__LoadoutFrame__10.Visible = true;
    u9.frame.Visible = true;
    u11.categoryFrame.Visible = false;
    u11.attachmentFrame.Visible = false;
    if u8.frame.Visible then
        u25 = u14.requestAllWeaponData:InvokeServer();
        if not u20 then
            u20 = u14.getCurrentLoadout:InvokeServer();
        end;
        while true do
            local v185;
            if true then
                if u20 then
                    v185 = u20;
                else
                    u20 = u14.getCurrentLoadout:InvokeServer();
                    v185 = u20;
                end;
            end;
            task.wait(2);
            if v185 ~= nil then
                local v186 = false;
                for _, v187 in u4 do
                    if v185[v187] then
                        v186 = true;
                        u2.changeWeapon:Invoke(v185[v187].name);
                        if v185[v187].attachments then
                            for _, v188 in v185[v187].attachments do
                                u2.setAttachment:Fire(v188, true);
                            end;
                        end;
                        if v185[v187].camo then
                            u2.setCamo:Fire(v185[v187].camo);
                        end;
                        u24 = v187;
                        break;
                    end;
                end;
                if not v186 then
                    u2.changeWeapon:Invoke(nil);
                end;
                for _, v189 in u5 do
                    v189.frame.BorderSizePixel = 0;
                end;
                u120();
                return;
            end;
        end;
    end;
end);
for u190, v191 in u5 do
    v191.frame.Button.Activated:Connect(function() --[[ Line: 1317 ]]
        -- upvalues: u183 (copy), u190 (copy)
        u183(u190);
    end);
end;