-- Roblox: Players.SilverAce293026.PlayerGui.LoadoutGui.LoadoutFrame.MainViewportScriptOld
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Players__2 = game:GetService("Players");
local l__LocalPlayer__3 = l__Players__2.LocalPlayer;
local l__Modules__4 = l__ReplicatedStorage__1:WaitForChild("Modules");
require(l__Modules__4:WaitForChild("GuiModule"));
local l__AttachmentsEnabled__5 = require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig")).FeatureToggles.AttachmentsEnabled;
local l__RenderGunBEvent__6 = script.Parent:WaitForChild("RenderGunBEvent");
local l__RootFrame__7 = script.Parent:WaitForChild("RootFrame");
l__RootFrame__7:WaitForChild("LoadoutFrame");
local l__Parent__8 = l__RootFrame__7.Parent;
local l__MainViewport__9 = l__Parent__8:WaitForChild("MainViewport");
local l__WorldModel__10 = l__MainViewport__9:WaitForChild("WorldModel");
local l__Animation__11 = l__MainViewport__9:WaitForChild("Animation");
local l__IdleAnimation__12 = l__MainViewport__9:WaitForChild("IdleAnimation");
local l__Button__13 = l__Parent__8:WaitForChild("BottomAction"):WaitForChild("DCustomizeFrame"):WaitForChild("DCustomizeButton"):WaitForChild("ButtonFrame"):WaitForChild("Button");
local l__Button__14 = l__Parent__8:WaitForChild("BottomAction"):WaitForChild("YBackButton"):WaitForChild("ButtonFrame"):WaitForChild("Button");
local l__HumPart__15 = l__WorldModel__10:WaitForChild("LoadoutScene"):WaitForChild("HumPart");
local l__GunModels__16 = l__ReplicatedStorage__1:WaitForChild("ACS_Engine"):WaitForChild("GunModels");
local l__NVG__17 = l__ReplicatedStorage__1.ACS_Engine:WaitForChild("Accessories"):WaitForChild("NVG");
l__ReplicatedStorage__1:WaitForChild("ACS_Engine"):WaitForChild("Attachments");
local l__AttachmentsUtil__18 = require(l__ReplicatedStorage__1.ACS_Engine:WaitForChild("Modules"):WaitForChild("AttachmentsUtil"));
local l__WeaponInHand__19 = l__Parent__8:WaitForChild("WeaponInHand");
local l__EquippedNVG__20 = l__Parent__8:WaitForChild("EquippedNVG");
local u1 = nil;
local u2 = nil;
local u3 = nil;
local u4 = nil;
local l__Modules__21 = l__ReplicatedStorage__1:WaitForChild("ACS_Engine"):WaitForChild("Modules");
require(l__Modules__21:WaitForChild("Utilities"));
local u5 = false;
local function u8() --[[ Line: 80 ]]
    -- upvalues: u4 (ref), l__ReplicatedStorage__1 (copy), l__WorldModel__10 (copy), l__LocalPlayer__3 (copy), l__Players__2 (copy), l__MainViewport__9 (copy), l__HumPart__15 (copy)
    if not u4 then
        u4 = l__ReplicatedStorage__1:WaitForChild("LoadoutRig"):Clone();
        u4.Parent = l__WorldModel__10;
        local v6 = u4;
        local l__UserId__22 = l__LocalPlayer__3.UserId;
        if l__UserId__22 > 0 then
            local v7 = l__Players__2:GetHumanoidDescriptionFromUserId(l__UserId__22);
            v6:WaitForChild("Humanoid"):ApplyDescription(v7);
        end;
    end;
    if not l__MainViewport__9.CurrentCamera then
        l__MainViewport__9.CurrentCamera = Instance.new("Camera");
    end;
    u4.Parent = l__WorldModel__10;
    local l__CurrentCamera__23 = l__MainViewport__9.CurrentCamera;
    local l__HumanoidRootPart__24 = u4:WaitForChild("HumanoidRootPart");
    l__HumanoidRootPart__24.CFrame = l__HumPart__15.CFrame;
    l__CurrentCamera__23.CFrame = CFrame.new(l__HumanoidRootPart__24.Position + l__HumanoidRootPart__24.CFrame.LookVector * 3 + Vector3.new(0, 2, 0) + l__HumanoidRootPart__24.CFrame.RightVector * -2, l__HumanoidRootPart__24.Position + Vector3.new(0, 1.7, 0));
end;
local function u12() --[[ Line: 105 ]]
    -- upvalues: l__AttachmentsEnabled__5 (copy), u1 (ref), l__MainViewport__9 (copy), l__HumPart__15 (copy), l__WorldModel__10 (copy), u4 (ref), u2 (ref), u5 (ref)
    if l__AttachmentsEnabled__5 then
        if u1 then
            if not l__MainViewport__9.CurrentCamera then
                l__MainViewport__9.CurrentCamera = Instance.new("Camera");
            end;
            local v9 = u1;
            local l__Handle__25 = v9:WaitForChild("Handle");
            local l__CurrentCamera__26 = l__MainViewport__9.CurrentCamera;
            l__Handle__25:FindFirstChild("Motor6D"):Destroy();
            v9.PrimaryPart = l__Handle__25;
            v9:SetPrimaryPartCFrame(l__HumPart__15.Parent.GunPart.CFrame);
            v9.Parent = l__WorldModel__10;
            u4:WaitForChild("HumanoidRootPart").Parent.Parent = nil;
            l__CurrentCamera__26.CFrame = CFrame.new(v9.PrimaryPart.Position + v9.PrimaryPart.CFrame.LookVector * 0 + Vector3.new(0, 0, 0) + v9.PrimaryPart.CFrame.RightVector * -4) * CFrame.Angles(0, -1.5707963267948966, 0);
            for _, v10 in pairs(v9.Nodes:GetChildren()) do
                local v11 = Instance.new("Folder");
                v11.Name = v10.Name .. "Folder";
                v11.Parent = v9;
            end;
            u2 = l__Handle__25.CFrame;
            u5 = true;
        else
            print("Weapon not found");
        end;
    end;
end;
l__RenderGunBEvent__6.Event:Connect(function(p13, p14) --[[ Line: 138 ]]
    -- upvalues: l__GunModels__16 (copy), l__AttachmentsUtil__18 (copy)
    local v15 = l__GunModels__16:FindFirstChild(p13);
    if v15 then
        local v16 = v15:Clone();
        l__AttachmentsUtil__18.loadAttachments(v16, p14);
    end;
end);
local function u22(p17, p18) --[[ Line: 153 ]]
    local v19 = p18.Handle:FindFirstChildOfClass("Attachment");
    local v20 = Instance.new("Weld");
    v20.Name = "AccessoryWeld";
    v20.Part0 = p18.Handle;
    if v19 then
        local v21 = p17:FindFirstChild(tostring(v19), true);
        v20.C0 = v19.CFrame;
        v20.C1 = v21.CFrame;
        v20.Part1 = v21.Parent;
    else
        v20.C1 = CFrame.new(0, p17.Head.Size.Y / 2, 0) * p18.AttachmentPoint:inverse();
        v20.Part1 = p17.Head;
    end;
    p18.Handle.CFrame = v20.Part1.CFrame * v20.C1 * v20.C0:inverse();
    p18.Parent = p17;
    v20.Parent = p18.Handle;
end;
l__EquippedNVG__20.Changed:Connect(function(p23) --[[ Line: 172 ]]
    -- upvalues: u3 (ref), l__NVG__17 (copy), u22 (copy), u4 (ref)
    if u3 then
        u3:Destroy();
        u3 = nil;
    end;
    if p23 == nil or p23 == "" then
    else
        u3 = l__NVG__17:WaitForChild(p23):WaitForChild("MWTNVG_Up"):Clone();
        u22(u4, u3);
    end;
end);
local function u29(_) --[[ Line: 182 ]]
    -- upvalues: u8 (copy), u1 (ref), u4 (ref), l__Animation__11 (copy), l__IdleAnimation__12 (copy)
    u8();
    local l__Handle__27 = u1:WaitForChild("Handle");
    for _, v24 in ipairs(u1:GetChildren()) do
        if v24:IsA("BasePart") then
            if v24 ~= l__Handle__27 then
                local v25 = Instance.new("WeldConstraint");
                v25.Part0 = l__Handle__27;
                v25.Part1 = v24;
                v25.Parent = v24;
            end;
            v24.Anchored = false;
            v24.CanCollide = false;
        end;
    end;
    local l__RightHand__28 = u4:WaitForChild("RightHand");
    local v26 = Instance.new("Motor6D");
    v26.Parent = l__Handle__27;
    v26.Part0 = l__RightHand__28;
    v26.Part1 = l__Handle__27;
    v26.C1 = (CFrame.new(-0.3, -0.2, -0.4) * CFrame.Angles(-1.5707963267948966, 0, 0)):Inverse();
    local v27 = u4:WaitForChild("Humanoid"):LoadAnimation(l__Animation__11);
    local v28 = u4.Humanoid:LoadAnimation(l__IdleAnimation__12);
    v27:Play();
    v28:Play();
end;
l__WeaponInHand__19.Changed:Connect(function(p30) --[[ Line: 213 ]]
    -- upvalues: u1 (ref), u5 (ref), u4 (ref), u8 (copy), l__GunModels__16 (copy), l__Animation__11 (copy), l__IdleAnimation__12 (copy)
    if u1 then
        u5 = false;
        u1:Destroy();
        u1 = nil;
    end;
    if p30 == nil or p30 == "" then
        if u4 then
            u4:Destroy();
            u4 = nil;
        end;
    else
        u8();
        u1 = l__GunModels__16:WaitForChild(p30):Clone();
        u1.Parent = u4;
        local l__Handle__29 = u1:WaitForChild("Handle");
        for _, v31 in ipairs(u1:GetDescendants()) do
            if v31:IsA("BasePart") then
                if v31 ~= l__Handle__29 then
                    local v32 = Instance.new("WeldConstraint");
                    v32.Part0 = l__Handle__29;
                    v32.Part1 = v31;
                    v32.Parent = v31;
                end;
                v31.Anchored = false;
                v31.CanCollide = false;
            end;
        end;
        local l__RightHand__30 = u4:WaitForChild("RightHand");
        local v33 = Instance.new("Motor6D");
        v33.Parent = l__Handle__29;
        v33.Part0 = l__RightHand__30;
        v33.Part1 = l__Handle__29;
        v33.C1 = (CFrame.new(-0.3, -0.2, -0.4) * CFrame.Angles(-1.5707963267948966, 0, 0)):Inverse();
        local v34 = u4:WaitForChild("Humanoid"):LoadAnimation(l__Animation__11);
        local v35 = u4.Humanoid:LoadAnimation(l__IdleAnimation__12);
        v34:Play();
        v35:Play();
        print("Weapon rendered");
    end;
end);
l__Button__13.MouseButton1Click:Connect(function() --[[ Line: 255 ]]
    -- upvalues: u12 (copy)
    u12();
end);
l__Button__14.MouseButton1Click:Connect(function() --[[ Line: 259 ]]
    -- upvalues: u29 (copy), u5 (ref)
    u29();
    u5 = false;
end);
local l__UserInputService__31 = game:GetService("UserInputService");
local l__RunService__32 = game:GetService("RunService");
local l__TweenService__33 = game:GetService("TweenService");
local u36 = false;
TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local u37 = nil;
local u38 = nil;
l__UserInputService__31.InputBegan:Connect(function(p39, p40) --[[ Line: 306 ]]
    -- upvalues: u5 (ref), u38 (ref), u36 (ref), u37 (ref), l__UserInputService__31 (copy), l__RunService__32 (copy), u1 (ref)
    if u5 then
        if p39.UserInputType == Enum.UserInputType.MouseButton1 then
            if p40 then
            else
                if u38 then
                    u38:Disconnect();
                    u38 = nil;
                end;
                u36 = true;
                if not u37 then
                    if u37 then
                        u37:Disconnect();
                        u37 = nil;
                    end;
                    local u41 = l__UserInputService__31:GetMouseLocation();
                    u37 = l__RunService__32.RenderStepped:Connect(function(p42) --[[ Line: 284 ]]
                        -- upvalues: u36 (ref), u41 (ref), l__UserInputService__31 (ref), u1 (ref)
                        if u36 then
                            local v43 = l__UserInputService__31:GetMouseLocation();
                            local v44 = v43 - u41;
                            u41 = v43;
                            if u1 then
                                local v45 = u1:FindFirstChild("Handle");
                                if v45 then
                                    local v46 = v44.X * p42 * 18;
                                    local v47 = v44.Y * p42 * 18;
                                    v45.CFrame = v45.CFrame * CFrame.Angles(0, math.rad(v46), (math.rad(v47)));
                                end;
                            end;
                        else
                            u41 = l__UserInputService__31:GetMouseLocation();
                        end;
                    end);
                end;
            end;
        end;
    end;
end);
l__UserInputService__31.InputEnded:Connect(function(p48, _) --[[ Line: 324 ]]
    -- upvalues: u5 (ref), u36 (ref), u37 (ref), u38 (ref), u1 (ref), l__RunService__32 (copy), u2 (ref), l__TweenService__33 (copy)
    if u5 then
        if p48.UserInputType == Enum.UserInputType.MouseButton1 then
            u36 = false;
            if u37 then
                u37:Disconnect();
                u37 = nil;
            end;
            if u38 then
                u38:Disconnect();
                u38 = nil;
            end;
            if u1 then
                local l__CFrame__34 = u1.Handle.CFrame;
                local u49 = 0;
                u38 = l__RunService__32.RenderStepped:Connect(function(p50) --[[ Line: 345 ]]
                    -- upvalues: u49 (ref), u1 (ref), u2 (ref), u38 (ref), l__TweenService__33 (ref), l__CFrame__34 (copy)
                    u49 = u49 + p50;
                    if u49 >= 0.3 then
                        u1.Handle.CFrame = u2;
                        u38:Disconnect();
                        u38 = nil;
                    else
                        local v51 = l__CFrame__34:Lerp(u2, (l__TweenService__33:GetValue(u49 / 0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)));
                        u1.Handle.CFrame = v51;
                    end;
                end);
            else
                print("uh");
            end;
        end;
    end;
end);