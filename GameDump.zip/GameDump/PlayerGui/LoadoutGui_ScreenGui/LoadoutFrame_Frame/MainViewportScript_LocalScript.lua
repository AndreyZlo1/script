-- Roblox: Players.SilverAce293026.PlayerGui.LoadoutGui.LoadoutFrame.MainViewportScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Players__2 = game:GetService("Players");
local l__TweenService__3 = game:GetService("TweenService");
local u1 = require(l__ReplicatedStorage__1.ReplicatedConfig).Mode ~= "Tycoon";
local v2 = {
    main = script.Parent:WaitForChild("BottomAction")
};
v2.customizeFrame = v2.main:WaitForChild("DCustomizeFrame");
v2.customizeButtonFrame = v2.customizeFrame:WaitForChild("DCustomizeButton");
v2.customizeButton = v2.customizeButtonFrame:WaitForChild("ButtonFrame"):WaitForChild("Button");
v2.camoFrame = v2.main.DCustomizeFrame:WaitForChild("DCamoButton");
v2.camoButtonFrame = v2.camoFrame:WaitForChild("ButtonFrame");
v2.camoButton = v2.camoButtonFrame:WaitForChild("Button");
v2.backButtonFrame = v2.main:WaitForChild("YBackButton");
v2.backButton = v2.backButtonFrame:WaitForChild("ButtonFrame"):WaitForChild("Button");
local l__MainViewport__4 = script.Parent.MainViewport;
local l__WorldModel__5 = l__MainViewport__4:WaitForChild("WorldModel");
local u3 = {
    displayCharCFrame = l__WorldModel__5:WaitForChild("LoadoutScene"):WaitForChild("HumPart").CFrame,
    attachmentGunCFrame = l__WorldModel__5.LoadoutScene:WaitForChild("GunPart").CFrame
};
local l__LocalPlayer__6 = l__Players__2.LocalPlayer;
local l__ReplicatedConfig__7 = require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig"));
local l__AttachmentsEnabled__8 = l__ReplicatedConfig__7.FeatureToggles.AttachmentsEnabled;
local l__CamosEnabled__9 = l__ReplicatedConfig__7.FeatureToggles.CamosEnabled;
local v4 = {
    changeWeapon = script.Parent:WaitForChild("ChangeWeapon"),
    changeNVG = script.Parent:WaitForChild("ChangeNVG"),
    setAttachment = script.Parent:WaitForChild("SetAttachment"),
    resetAttachments = script.Parent:WaitForChild("ResetAttachments"),
    setCamo = script.Parent:WaitForChild("SetCamo")
};
local u5 = {
    getWeaponForcedAttachments = game:GetService("ReplicatedStorage"):WaitForChild("PlayerEvents"):WaitForChild("GetWeaponForcedAttachments")
};
local u6 = {
    engine = l__ReplicatedStorage__1:WaitForChild("ACS_Engine"),
    gunModels = l__ReplicatedStorage__1.ACS_Engine:WaitForChild("GunModels"),
    accessories = l__ReplicatedStorage__1.ACS_Engine:WaitForChild("Accessories"),
    nvgs = l__ReplicatedStorage__1.ACS_Engine.Accessories:WaitForChild("NVG"),
    modules = l__ReplicatedStorage__1.ACS_Engine:WaitForChild("Modules"),
    camosUtil = require(l__ReplicatedStorage__1.ACS_Engine.Modules:WaitForChild("CamosUtil"))
};
local l__AttachmentsUtil__10 = require(u6.modules:WaitForChild("AttachmentsUtil"));
local l__Attachments__11 = game:GetService("ReplicatedStorage"):WaitForChild("WeaponProgression"):WaitForChild("Attachments");
require(l__Attachments__11);
local u7 = {
    animation = l__MainViewport__4:WaitForChild("Animation"),
    idle = l__MainViewport__4:WaitForChild("IdleAnimation")
};
local u8 = {};
local u9 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local l__LoadoutRig__12 = l__ReplicatedStorage__1:WaitForChild("LoadoutRig");
local u10 = nil;
local u11 = nil;
local u12 = nil;
local u13 = nil;
local function v15(p14) --[[ Line: 91 ]]
    -- upvalues: u10 (ref), u11 (ref), l__WorldModel__5 (copy)
    if p14:IsA("BasePart") or (p14:IsA("Part") or (p14:IsA("MeshPart") or p14:IsA("Decal"))) then
        if u10 == nil or not p14:IsDescendantOf(u10) then
            if u11 == nil or not p14:IsDescendantOf(u11) then
                if p14.Parent ~= l__WorldModel__5.LoadoutScene then
                    p14.Transparency = 1;
                end;
            end;
        end;
    end;
end;
if u1 then
    l__WorldModel__5.DescendantAdded:Connect(v15);
    for _, v16 in l__WorldModel__5:GetDescendants() do
        v15(v16);
    end;
end;
local function u22(p17, p18) --[[ Line: 112 ]]
    local v19 = p18.Handle:FindFirstChildOfClass("Attachment");
    local v20 = Instance.new("Weld");
    v20.Name = "AccessoryWeld";
    v20.Part0 = p18.Handle;
    if v19 then
        local v21 = p17:FindFirstChild(tostring(v19), true);
        v20.C0 = v19.CFrame;
        v20.C1 = v21.CFrame;
        v20.Part1 = v21.Parent;
    else
        v20.C1 = CFrame.new(0, p17.Head.Size.Y / 2, 0) * p18.AttachmentPoint:inverse();
        v20.Part1 = p17.Head;
    end;
    p18.Handle.CFrame = v20.Part1.CFrame * v20.C1 * v20.C0:inverse();
    p18.Parent = p17;
    v20.Parent = p18.Handle;
end;
local function u27(p23) --[[ Line: 131 ]]
    local v24 = p23:FindFirstChild("Handle");
    for _, v25 in p23:GetDescendants() do
        if v25:IsA("BasePart") then
            v25.Anchored = false;
            v25.CanCollide = false;
            if v25 ~= v24 then
                local v26 = Instance.new("WeldConstraint", v25);
                v26.Name = "HandleWeld";
                v26.Part0 = v25;
                v26.Part1 = v24;
            end;
        end;
    end;
end;
local function u30(p28) --[[ Line: 148 ]]
    -- upvalues: u10 (ref)
    if u10 then
        local l__RightHand__13 = u10.RightHand;
        if p28 then
            local l__Handle__14 = p28:WaitForChild("Handle");
            local v29 = Instance.new("Motor6D", l__Handle__14);
            v29.Name = "LoadoutM6";
            v29.Part0 = l__RightHand__13;
            v29.Part1 = l__Handle__14;
            v29.C1 = (CFrame.new(-0.3, -0.2, -0.4) * CFrame.Angles(-1.5707963267948966, 0, 0)):Inverse();
        end;
    end;
end;
local function u31() --[[ Line: 163 ]]
    -- upvalues: u10 (ref), l__LoadoutRig__12 (copy), l__WorldModel__5 (copy), l__Players__2 (copy), l__LocalPlayer__6 (copy), u3 (copy), u8 (copy), u7 (copy)
    if u10 then
        u10:Destroy();
        u10 = nil;
    end;
    u10 = l__LoadoutRig__12:Clone();
    u10.Parent = l__WorldModel__5;
    u10:WaitForChild("Humanoid"):ApplyDescription((l__Players__2:GetHumanoidDescriptionFromUserId(l__LocalPlayer__6.UserId)));
    u10:PivotTo(u3.displayCharCFrame);
    local l__Humanoid__15 = u10.Humanoid;
    u8.animationTrack = l__Humanoid__15:LoadAnimation(u7.animation);
    u8.idleTrack = l__Humanoid__15:LoadAnimation(u7.idle);
    u8.idleTrack:Play();
    return u10;
end;
local function u33() --[[ Line: 191 ]]
    -- upvalues: u10 (ref), u31 (copy), u1 (copy), l__MainViewport__4 (copy), l__WorldModel__5 (copy)
    if not u10 then
        u31();
    end;
    if u1 then
        l__MainViewport__4.BackgroundTransparency = 1;
        l__WorldModel__5.LoadoutScene.FloorPart.Transparency = 1;
    end;
    if l__MainViewport__4.CurrentCamera then
        l__MainViewport__4.CurrentCamera:Destroy();
        l__MainViewport__4.CurrentCamera = nil;
    end;
    local v32 = Instance.new("Camera", script);
    local l__HumanoidRootPart__16 = u10:WaitForChild("HumanoidRootPart");
    v32.CFrame = CFrame.new(l__HumanoidRootPart__16.Position + l__HumanoidRootPart__16.CFrame.LookVector * 3 + Vector3.new(0, 2, 0) + l__HumanoidRootPart__16.CFrame.RightVector * -2, l__HumanoidRootPart__16.Position + Vector3.new(0, 1.7, 0));
    l__MainViewport__4.CurrentCamera = v32;
end;
local function u34() --[[ Line: 213 ]]
    -- upvalues: u11 (ref), l__MainViewport__4 (copy), u10 (ref), l__WorldModel__5 (copy), u3 (copy), u1 (copy), l__TweenService__3 (copy), u9 (copy)
    if u11 then
        local l__CurrentCamera__17 = l__MainViewport__4.CurrentCamera;
        local l__Handle__18 = u11.Handle;
        if l__Handle__18:FindFirstChild("LoadoutM6") then
            l__Handle__18:FindFirstChild("LoadoutM6"):Destroy();
        end;
        u10.Parent = nil;
        u11.Parent = l__WorldModel__5;
        u11:PivotTo(u3.attachmentGunCFrame);
        if u1 then
            l__CurrentCamera__17.CFrame = CFrame.new(l__Handle__18.Position + l__Handle__18.CFrame.LookVector * 0 + Vector3.new(0, 0, 0) + l__Handle__18.CFrame.RightVector * -4) * CFrame.Angles(0, -1.5707963267948966, 0);
        else
            l__TweenService__3:Create(l__CurrentCamera__17, u9, {
                CFrame = CFrame.new(l__Handle__18.Position + l__Handle__18.CFrame.LookVector * 0 + Vector3.new(0, 0, 0) + l__Handle__18.CFrame.RightVector * -4) * CFrame.Angles(0, -1.5707963267948966, 0)
            }):Play();
        end;
    end;
end;
local u35 = {};
local function u43(p36, p37) --[[ Line: 268 ]]
    -- upvalues: u11 (ref), u35 (ref), l__AttachmentsUtil__10 (copy), u13 (ref), u43 (copy)
    print("setattachment");
    if not u11 then
        return;
    end;
    if p37 then
        local v38 = l__AttachmentsUtil__10.getAttDataFromHash(p36);
        if not v38 then
            return;
        end;
        local v39 = l__AttachmentsUtil__10.loadAttachments(u11, { v38 });
        for v40, v41 in u35 do
            if l__AttachmentsUtil__10.getAttachmentCategoryFromIndex(v40) == v38.Category then
                v41:Destroy();
                u35[v40] = nil;
                break;
            end;
        end;
        u35[p36] = v39[v38.Category];
    elseif u35[p36] then
        local v42 = l__AttachmentsUtil__10.getAttachmentCategoryFromIndex(p36);
        if v42 and l__AttachmentsUtil__10.attachmentChangedCallbacks[v42] then
            l__AttachmentsUtil__10.attachmentChangedCallbacks[v42](u11, u35[p36], false);
        end;
        u35[p36]:Destroy();
        u35[p36] = nil;
        if u13[v42] then
            u43(u13[v42], true);
        end;
    end;
end;
local function v47(p44) --[[ Line: 364 ]]
    -- upvalues: u12 (ref), u6 (copy), u22 (copy), u10 (ref)
    print("changenvg");
    if u12 then
        u12:Destroy();
        u12 = nil;
    end;
    if p44 == nil or p44 == "" then
    else
        local v45 = u6.nvgs:FindFirstChild(p44):FindFirstChild("MWTNVG_Up");
        if v45 then
            local v46 = v45:Clone();
            u22(v46, u10);
            u12 = v46;
        end;
    end;
end;
local function v49(p48) --[[ Line: 385 ]]
    -- upvalues: u11 (ref), u6 (copy)
    print("changecamo");
    if u11 then
        u6.camosUtil.applyCamoToGun(u11, p48);
    end;
end;
local function v50() --[[ Line: 391 ]]
    -- upvalues: u33 (copy), u30 (copy), u11 (ref), u10 (ref), l__WorldModel__5 (copy)
    u33();
    u30(u11);
    u10.Parent = l__WorldModel__5;
    if u11 then
        u11.Parent = l__WorldModel__5;
    end;
end;
local function v55() --[[ Line: 401 ]]
    -- upvalues: u11 (ref), u35 (ref), l__AttachmentsUtil__10 (copy), u13 (ref), u43 (copy)
    print("resetattachment");
    if u11 then
        for v51, v52 in u35 do
            local v53 = l__AttachmentsUtil__10.getAttachmentCategoryFromIndex(v51);
            if v53 and l__AttachmentsUtil__10.attachmentChangedCallbacks[v53] then
                l__AttachmentsUtil__10.attachmentChangedCallbacks[v53](u11, u35[v51], false);
            end;
            v52:Destroy();
        end;
        u35 = {};
        if u13 and u11 then
            for _, v54 in u13 do
                u43(v54, true);
            end;
        end;
    end;
end;
function v4.changeWeapon.OnInvoke(p56) --[[ Line: 308 ]]
    -- upvalues: u11 (ref), u13 (ref), u10 (ref), l__MainViewport__4 (copy), u33 (copy), l__TweenService__3 (copy), u9 (copy), u8 (copy), l__WorldModel__5 (copy), u6 (copy), u5 (copy), u27 (copy), u30 (copy), u43 (copy)
    print("changewep");
    if u11 then
        u11:Destroy();
        u11 = nil;
    end;
    u13 = nil;
    if not (u10 and l__MainViewport__4.CurrentCamera) then
        u33();
    end;
    local l__HumanoidRootPart__19 = u10.HumanoidRootPart;
    local v57 = CFrame.new(l__HumanoidRootPart__19.Position + l__HumanoidRootPart__19.CFrame.LookVector * 3 + Vector3.new(0, 2, 0) + l__HumanoidRootPart__19.CFrame.RightVector * -2, l__HumanoidRootPart__19.Position + Vector3.new(0, 1.7, 0));
    l__TweenService__3:Create(l__MainViewport__4.CurrentCamera, u9, {
        CFrame = v57
    }):Play();
    if p56 then
        local v58 = u6.gunModels:FindFirstChild(p56);
        if v58 then
            u13 = u5.getWeaponForcedAttachments:InvokeServer(p56);
            if u8.animationTrack then
                u8.animationTrack:Play();
            end;
            local v59 = v58:Clone();
            u27(v59);
            v59.Parent = u10;
            v59.PrimaryPart = v59.Handle;
            u30(v59);
            u11 = v59;
            for _, v60 in u13 do
                u43(v60, true);
            end;
        end;
    elseif u8.animationTrack then
        u8.animationTrack:Stop();
        u10.Parent = l__WorldModel__5;
    end;
end;
v4.changeNVG.Event:Connect(v47);
v4.setAttachment.Event:Connect(u43);
v4.resetAttachments.OnInvoke = v55;
v4.setCamo.Event:Connect(v49);
v2.customizeButton.Activated:Connect(function() --[[ Name: setupAttachmentsView, Line 254 ]]
    -- upvalues: l__AttachmentsEnabled__8 (copy), u34 (copy)
    print("setupattachment");
    if l__AttachmentsEnabled__8 then
        u34();
    end;
end);
v2.camoButton.Activated:Connect(function() --[[ Name: setupCamosView, Line 260 ]]
    -- upvalues: l__CamosEnabled__9 (copy), u34 (copy)
    if l__CamosEnabled__9 then
        u34();
    end;
end);
v2.backButton.Activated:Connect(v50);