-- Roblox: Players.SilverAce293026.PlayerGui.CustomToolbar.Background.Prototype.Gradient.Scanline
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__TweenService__1 = game:GetService("TweenService");
local v1 = TweenInfo.new(0.4, Enum.EasingStyle.Linear, Enum.EasingDirection.Out);
script.Parent.Position = UDim2.new(-1, 0, 0, 0);
local u2 = l__TweenService__1:Create(script.Parent, v1, {
    Position = UDim2.new(1, 0, 0, 0)
});
script:WaitForChild("Tween").Event:Connect(function() --[[ Line: 8 ]]
    -- upvalues: u2 (copy)
    u2:Cancel();
    script.Parent.Position = UDim2.new(-1, 0, 0, 0);
    u2:Play();
end);