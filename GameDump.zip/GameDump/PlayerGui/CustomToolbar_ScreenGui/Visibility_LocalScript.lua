-- Roblox: Players.SilverAce293026.PlayerGui.CustomToolbar.Visibility
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Parent__1 = script.Parent;
local l__Players__2 = game:GetService("Players");
local l__ReplicatedStorage__3 = game:GetService("ReplicatedStorage");
local l__ReplicatedConfig__4 = require(l__ReplicatedStorage__3:WaitForChild("ReplicatedConfig"));
local l__LocalPlayer__5 = l__Players__2.LocalPlayer;
local v1 = l__LocalPlayer__5.Character or l__LocalPlayer__5.CharacterAdded:Wait();
local u2 = { "TurretSeat", "GunnerSeat" };
if l__ReplicatedConfig__4.Mode == "Tycoon" then
    if l__LocalPlayer__5:GetAttribute("FirstSpawnDone") then
        script.Parent.Enabled = true;
    else
        l__LocalPlayer__5:SetAttribute("FirstSpawnDone", true);
    end;
end;
local l__Humanoid__6 = v1:WaitForChild("Humanoid");
l__Humanoid__6:GetPropertyChangedSignal("SeatPart"):Connect(function() --[[ Line: 22 ]]
    -- upvalues: l__Humanoid__6 (copy), u2 (copy), l__Parent__1 (copy)
    local v3 = l__Humanoid__6.SeatPart ~= nil;
    local v4;
    if v3 then
        v4 = l__Humanoid__6.SeatPart.Parent.Name == "Required";
    else
        v4 = v3;
    end;
    local v5;
    if v3 then
        v5 = table.find(u2, l__Humanoid__6.SeatPart.Name);
    else
        v5 = v3;
    end;
    if v3 and (v4 or v5) then
        l__Parent__1.Enabled = false;
    else
        l__Parent__1.Enabled = true;
    end;
end);