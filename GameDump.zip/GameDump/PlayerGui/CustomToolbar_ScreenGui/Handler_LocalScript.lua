-- Roblox: Players.SilverAce293026.PlayerGui.CustomToolbar.Handler
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Players__1 = game:GetService("Players");
local l__LocalPlayer__2 = l__Players__1.LocalPlayer;
local l__Backpack__3 = l__LocalPlayer__2:WaitForChild("Backpack");
local l__UserInputService__4 = game:GetService("UserInputService");
game:GetService("GuiService");
local l__ReplicatedStorage__5 = game:GetService("ReplicatedStorage");
local l__WeaponProgression__6 = l__ReplicatedStorage__5:WaitForChild("WeaponProgression");
local l__Attachments__7 = require(l__WeaponProgression__6:WaitForChild("Attachments"));
local l__ACS_Engine__8 = l__ReplicatedStorage__5:WaitForChild("ACS_Engine");
local l__AttachmentsUtil__9 = require(l__ACS_Engine__8:WaitForChild("Modules"):WaitForChild("AttachmentsUtil"));
local l__TweenService__10 = game:GetService("TweenService");
local u1 = TweenInfo.new(0.5, Enum.EasingStyle.Quint, Enum.EasingDirection.Out, 0, false, 0);
local u2 = {};
local u3 = { "Fireworks", "First Aid Kit", "F-C4RP3T" };
local u4 = { "Turret" };
local l__Background__11 = script.Parent:WaitForChild("Background");
local l__Prototype__12 = l__Background__11:WaitForChild("Prototype");
local u5 = {
    { 0, Enum.KeyCode.Zero },
    { 1, Enum.KeyCode.One },
    { 2, Enum.KeyCode.Two },
    { 3, Enum.KeyCode.Three },
    { 4, Enum.KeyCode.Four },
    { 5, Enum.KeyCode.Five },
    { 6, Enum.KeyCode.Six },
    { 7, Enum.KeyCode.Seven },
    { 8, Enum.KeyCode.Eight },
    { 9, Enum.KeyCode.Nine }
};
local u6 = {
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9
};
local u7 = nil;
local function u12(p8) --[[ Line: 59 ]]
    -- upvalues: u2 (copy), u5 (copy), u6 (copy), u7 (ref)
    if not u2[p8] then
        return;
    end;
    u2[p8].Frame:Destroy();
    for _, v9 in u5 do
        if v9[2] == u2[p8].KeyCode then
            table.insert(u6, v9[1]);
            table.sort(u6, function(p10, p11) --[[ Line: 66 ]]
                if p10 == 0 then
                    return false;
                else
                    return p11 == 0 and true or p10 < p11;
                end;
            end);
            break;
        end;
    end;
    if u2[p8].InputConnection then
        u2[p8].InputConnection:Disconnect();
    end;
    u2[p8] = nil;
    if u7 == p8 then
        u7 = nil;
    end;
end;
local function u14(p13) --[[ Line: 82 ]]
    -- upvalues: u7 (ref), u2 (copy), l__TweenService__10 (copy), u1 (copy)
    if u7 then
        local l__Frame__13 = u2[u7].Frame;
        local l__LastTween__14 = u2[u7].LastTween;
        if l__LastTween__14 then
            l__LastTween__14:Pause();
        end;
        l__Frame__13.ActiveStroke.Enabled = false;
        u2[u7].LastTween = l__TweenService__10:Create(l__Frame__13, u1, {
            Size = UDim2.new(1, 0, 1, 0)
        });
        u2[u7].LastTween:Play();
        u7 = nil;
    end;
    if p13 then
        u7 = p13;
        local l__Frame__15 = u2[p13].Frame;
        local l__LastTween__16 = u2[u7].LastTween;
        if l__LastTween__16 then
            l__LastTween__16:Pause();
        end;
        u2[u7].LastTween = l__TweenService__10:Create(l__Frame__15, u1, {
            Size = UDim2.new(1.1, 0, 1.1, 0)
        });
        u2[u7].LastTween:Play();
        l__Frame__15.ActiveStroke.Enabled = true;
    end;
end;
local function u33(p15) --[[ Line: 108 ]]
    -- upvalues: l__Attachments__7 (copy), l__AttachmentsUtil__9 (copy)
    local function v23(p16) --[[ Line: 109 ]]
        -- upvalues: l__Attachments__7 (ref)
        local v17 = {
            "Optic",
            "Muzzle",
            "Foregrip",
            "Laser",
            "Ammo",
            "Barrel",
            "Stock",
            "Rear Grip"
        };
        local v18 = {};
        local v19 = p16:FindFirstChild("Customization");
        if not v19 then
            return {};
        end;
        for _, v20 in ipairs(v17) do
            local v21 = v19:GetAttribute(v20);
            if v21 then
                local v22 = l__Attachments__7.attachments[v21];
                if v22 then
                    v18[v20] = {
                        Name = v22.name,
                        Folder = v22.folder
                    };
                end;
            end;
        end;
        return v18, v19:GetAttribute("Camo");
    end;
    local l__ACS_Settings__17 = require(p15.ACS_Settings);
    local v24, _ = v23(p15);
    l__ACS_Settings__17.Attachments = v24;
    local v25 = {};
    local v26 = nil;
    for v27, v28 in pairs(l__ACS_Settings__17.Attachments or {}) do
        local v29 = typeof(v28) == "string" and {
            Name = v28
        } or v28;
        local v30 = {
            Name = v29.Name,
            Folder = v29.Folder,
            Category = v27
        };
        table.insert(v25, v30);
        local v31 = l__AttachmentsUtil__9.getAttachmentModule(v30);
        if v31 then
            local v32 = require(v31);
            if v32.AmmoCountOverride then
                v26 = v32.AmmoCountOverride;
            end;
        end;
    end;
    return v26 or l__ACS_Settings__17.Ammo;
end;
local function v52(u34) --[[ Line: 166 ]]
    -- upvalues: u2 (copy), u4 (copy), u6 (copy), u5 (copy), u12 (copy), l__Prototype__12 (copy), l__Background__11 (copy), u3 (copy), u33 (copy), l__UserInputService__4 (copy), l__Players__1 (copy), l__LocalPlayer__2 (copy), l__Backpack__3 (copy), u7 (ref), l__TweenService__10 (copy), u1 (copy), u14 (copy)
    if u2[u34] then
    elseif table.find(u4, u34.Name) then
    else
        local v35 = u6[1];
        if v35 then
            table.remove(u6, 1);
            local v36 = u5[v35];
            u2[u34] = {};
            u34.Destroying:Connect(function() --[[ Line: 178 ]]
                -- upvalues: u12 (ref), u34 (copy)
                u12(u34);
            end);
            local u37 = l__Prototype__12:Clone();
            u2[u34].Frame = u37;
            u37.Parent = l__Background__11;
            u37.WepName.Text = u34.Name;
            u37.Keybind.Text = v35;
            u37.Visible = true;
            u37.LayoutOrder = v35;
            u2[u34].KeyCode = v36[2];
            u2[u34].BindSlot = v36[1];
            local v38;
            if table.find(u3, u34.Name) then
                v38 = nil;
            else
                v38 = require(u34:WaitForChild("ACS_Settings"));
            end;
            if v38 and (v38.AmmoInGun and (v38.AmmoInGun > 0 and v38.Type ~= "Grenade")) then
                local u39 = u33(u34);
                local u40 = 0;
                local function v42(p41) --[[ Line: 201 ]]
                    -- upvalues: u40 (ref), u37 (copy), u39 (ref)
                    u40 = p41;
                    u37.Ammo.Text = string.format("%s / %s", p41, u39);
                end;
                local v43 = u39;
                u40 = v43;
                u37.Ammo.Text = string.format("%s / %s", v43, u39);
                u2[u34].UpdateFunc = v42;
                task.spawn(function() --[[ Line: 209 ]]
                    -- upvalues: u34 (copy), u39 (ref), u33 (ref), u40 (ref), u37 (copy)
                    local l__Customization__18 = u34:WaitForChild("Customization", 600);
                    if l__Customization__18 then
                        l__Customization__18.AttributeChanged:Connect(function() --[[ Line: 213 ]]
                            -- upvalues: u39 (ref), u33 (ref), u34 (ref), u40 (ref), u37 (ref)
                            u39 = u33(u34);
                            local v44 = u40;
                            u40 = v44;
                            u37.Ammo.Text = string.format("%s / %s", v44, u39);
                        end);
                        u39 = u33(u34);
                        local v45 = u40;
                        u40 = v45;
                        u37.Ammo.Text = string.format("%s / %s", v45, u39);
                    end;
                end);
            else
                u37.Ammo.Visible = false;
            end;
            u2[u34].InputConnection = l__UserInputService__4.InputBegan:Connect(function(p46, p47) --[[ Line: 225 ]]
                -- upvalues: l__Players__1 (ref), u2 (ref), u34 (copy), l__LocalPlayer__2 (ref), l__Backpack__3 (ref)
                if p47 then
                else
                    local l__SeatPart__19 = l__Players__1.LocalPlayer.Character.Humanoid.SeatPart;
                    if l__SeatPart__19 and l__SeatPart__19.Parent.Name == "Required" then
                    else
                        if p46.KeyCode == u2[u34].KeyCode then
                            local v48 = u34;
                            if not script.Parent.Enabled then
                                return;
                            end;
                            if v48.Parent == l__LocalPlayer__2.Character then
                                v48.Parent = l__Backpack__3;
                                return;
                            end;
                            local v49 = l__LocalPlayer__2.Character:FindFirstChildOfClass("Tool");
                            if v49 then
                                v49.Parent = l__Backpack__3;
                            end;
                            v48.Parent = l__LocalPlayer__2.Character;
                        end;
                    end;
                end;
            end);
            u37.Click.Activated:Connect(function() --[[ Line: 235 ]]
                -- upvalues: u34 (copy), l__LocalPlayer__2 (ref), l__Backpack__3 (ref)
                local v50 = u34;
                if script.Parent.Enabled then
                    if v50.Parent == l__LocalPlayer__2.Character then
                        v50.Parent = l__Backpack__3;
                    else
                        local v51 = l__LocalPlayer__2.Character:FindFirstChildOfClass("Tool");
                        if v51 then
                            v51.Parent = l__Backpack__3;
                        end;
                        v50.Parent = l__LocalPlayer__2.Character;
                    end;
                end;
            end);
            u34:GetPropertyChangedSignal("Parent"):Connect(function() --[[ Line: 239 ]]
                -- upvalues: u34 (copy), l__Backpack__3 (ref), u7 (ref), u2 (ref), l__TweenService__10 (ref), u1 (ref), l__LocalPlayer__2 (ref), u14 (ref)
                if u34.Parent == nil then
                else
                    if u34.Parent == l__Backpack__3 then
                        if u7 then
                            local l__Frame__20 = u2[u7].Frame;
                            local l__LastTween__21 = u2[u7].LastTween;
                            if l__LastTween__21 then
                                l__LastTween__21:Pause();
                            end;
                            l__Frame__20.ActiveStroke.Enabled = false;
                            u2[u7].LastTween = l__TweenService__10:Create(l__Frame__20, u1, {
                                Size = UDim2.new(1, 0, 1, 0)
                            });
                            u2[u7].LastTween:Play();
                            u7 = nil;
                        end;
                    elseif u34.Parent == l__LocalPlayer__2.Character then
                        u14(u34);
                    end;
                end;
            end);
        end;
    end;
end;
l__Backpack__3.ChildAdded:Connect(v52);
local u53 = u7;
for _, v54 in l__Backpack__3:GetChildren() do
    v52(v54);
end;
script:WaitForChild("UpdateBullets").Event:Connect(function(p55, p56) --[[ Line: 254 ]]
    -- upvalues: u2 (copy)
    if u2[p55] then
        if u2[p55].UpdateFunc then
            u2[p55].UpdateFunc(p56);
        end;
    end;
end);
script:WaitForChild("ReloadState").Event:Connect(function(u57, p58) --[[ Line: 260 ]]
    -- upvalues: u2 (copy), l__TweenService__10 (copy)
    if u2[u57] then
        if u2[u57].ReloadTween then
            u2[u57].ReloadTween:Pause();
            u2[u57].Frame.Reload.Size = UDim2.new(1, 0, 0, 0);
            u2[u57].Frame.Reload.BackgroundTransparency = 0.5;
        end;
        if p58 then
            local v59 = TweenInfo.new(p58, Enum.EasingStyle.Linear, Enum.EasingDirection.Out);
            local v60 = l__TweenService__10:Create(u2[u57].Frame.Reload, v59, {
                Size = UDim2.new(1, 0, 1, 0)
            });
            v60.Completed:Connect(function(p61) --[[ Line: 275 ]]
                -- upvalues: l__TweenService__10 (ref), u2 (ref), u57 (copy)
                if p61 == Enum.PlaybackState.Completed then
                    local v62 = TweenInfo.new(0.25, Enum.EasingStyle.Linear, Enum.EasingDirection.Out);
                    local v63 = l__TweenService__10:Create(u2[u57].Frame.Reload, v62, {
                        BackgroundTransparency = 1
                    });
                    u2[u57].ReloadTween = v63;
                    v63:Play();
                    u2[u57].Frame.Gradient.Scanline.Tween:Fire();
                end;
            end);
            u2[u57].ReloadTween = v60;
            v60:Play();
        end;
    end;
end);
local u64 = { Enum.UserInputType.Touch };
local u65 = { Enum.UserInputType.MouseButton1, Enum.UserInputType.MouseButton2, Enum.UserInputType.MouseMovement };
local u66 = {
    Enum.KeyCode.Thumbstick1,
    Enum.KeyCode.Thumbstick2,
    Enum.KeyCode.ButtonR2,
    Enum.KeyCode.ButtonR1,
    Enum.KeyCode.ButtonL2,
    Enum.KeyCode.ButtonL1
};
local u67 = 0;
local function v72(p68, _) --[[ Line: 298 ]]
    -- upvalues: u65 (copy), u66 (copy), u64 (copy), u67 (ref), u2 (copy), l__Background__11 (copy)
    for v69, v70 in { u65, u66, u64 } do
        if table.find(v70, p68.KeyCode) or table.find(v70, p68.UserInputType) then
            if u67 == v69 then
                return;
            else
                u67 = v69;
                for _, v71 in u2 do
                    local l__Frame__22 = v71.Frame;
                    if v69 > 1 then
                        l__Frame__22.Keybind.Visible = false;
                    else
                        l__Frame__22.Keybind.Visible = true;
                    end;
                end;
                if v69 > 2 then
                    l__Background__11.Size = UDim2.new(0, 50, 0, 40);
                    return;
                else
                    l__Background__11.Size = UDim2.new(0, 90, 0, 40);
                    return;
                end;
            end;
        end;
    end;
end;
l__UserInputService__4.InputBegan:Connect(v72);
l__UserInputService__4.InputChanged:Connect(v72);
l__UserInputService__4.InputBegan:Connect(function(p73, p74) --[[ Line: 315 ]]
    -- upvalues: u53 (ref), u2 (copy), l__LocalPlayer__2 (copy), l__Backpack__3 (copy)
    if p74 then
    elseif p73.KeyCode == Enum.KeyCode.ButtonR1 or p73.KeyCode == Enum.KeyCode.ButtonL1 then
        local v75 = not u53 and 0 or u2[u53].BindSlot;
        if v75 == 0 then
            if p73.KeyCode == Enum.KeyCode.ButtonR1 then
                local v76 = {
                    priority = 500,
                    tool = nil
                };
                for v77, v78 in u2 do
                    local l__BindSlot__23 = v78.BindSlot;
                    if l__BindSlot__23 < v76.priority then
                        v76.priority = l__BindSlot__23;
                        v76.tool = v77;
                    end;
                end;
                if v76.tool then
                    local l__tool__24 = v76.tool;
                    if script.Parent.Enabled then
                        if l__tool__24.Parent == l__LocalPlayer__2.Character then
                            l__tool__24.Parent = l__Backpack__3;
                        else
                            local v79 = l__LocalPlayer__2.Character:FindFirstChildOfClass("Tool");
                            if v79 then
                                v79.Parent = l__Backpack__3;
                            end;
                            l__tool__24.Parent = l__LocalPlayer__2.Character;
                        end;
                    end;
                end;
            else
                local v80 = {
                    priority = -500,
                    tool = nil
                };
                for v81, v82 in u2 do
                    local l__BindSlot__25 = v82.BindSlot;
                    if v80.priority < l__BindSlot__25 then
                        v80.priority = l__BindSlot__25;
                        v80.tool = v81;
                    end;
                end;
                if v80.tool then
                    local l__tool__26 = v80.tool;
                    if script.Parent.Enabled then
                        if l__tool__26.Parent == l__LocalPlayer__2.Character then
                            l__tool__26.Parent = l__Backpack__3;
                        else
                            local v83 = l__LocalPlayer__2.Character:FindFirstChildOfClass("Tool");
                            if v83 then
                                v83.Parent = l__Backpack__3;
                            end;
                            l__tool__26.Parent = l__LocalPlayer__2.Character;
                        end;
                    end;
                end;
            end;
        elseif p73.KeyCode == Enum.KeyCode.ButtonR1 then
            local v84 = {};
            for v85, v86 in u2 do
                local l__BindSlot__27 = v86.BindSlot;
                if l__BindSlot__27 and l__BindSlot__27 > v75 then
                    table.insert(v84, {
                        priority = l__BindSlot__27,
                        tool = v85
                    });
                end;
            end;
            table.sort(v84, function(p87, p88) --[[ Line: 356 ]]
                return p87.priority < p88.priority;
            end);
            local v89 = v84[1];
            local v90 = v89 and v89.tool or u53;
            if script.Parent.Enabled then
                if v90.Parent == l__LocalPlayer__2.Character then
                    v90.Parent = l__Backpack__3;
                else
                    local v91 = l__LocalPlayer__2.Character:FindFirstChildOfClass("Tool");
                    if v91 then
                        v91.Parent = l__Backpack__3;
                    end;
                    v90.Parent = l__LocalPlayer__2.Character;
                end;
            end;
        else
            local v92 = {};
            for v93, v94 in u2 do
                local l__BindSlot__28 = v94.BindSlot;
                if l__BindSlot__28 and v75 > l__BindSlot__28 then
                    table.insert(v92, {
                        priority = l__BindSlot__28,
                        tool = v93
                    });
                end;
            end;
            table.sort(v92, function(p95, p96) --[[ Line: 370 ]]
                return p95.priority > p96.priority;
            end);
            local v97 = v92[1];
            local v98 = v97 and v97.tool or u53;
            if script.Parent.Enabled then
                if v98.Parent == l__LocalPlayer__2.Character then
                    v98.Parent = l__Backpack__3;
                else
                    local v99 = l__LocalPlayer__2.Character:FindFirstChildOfClass("Tool");
                    if v99 then
                        v99.Parent = l__Backpack__3;
                    end;
                    v98.Parent = l__LocalPlayer__2.Character;
                end;
            end;
        end;
    end;
end);