-- Roblox: Players.SilverAce293026.PlayerGui.SkydiveGui.Background.TextArea.InputSchemes
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__UserInputService__1 = game:GetService("UserInputService");
local u1 = {
    Controller = { Enum.UserInputType.Gamepad1 },
    Mobile = { Enum.UserInputType.Touch },
    Desktop = { Enum.UserInputType.Keyboard, Enum.UserInputType.MouseMovement }
};
local l__ConsoleKey__2 = script.Parent:WaitForChild("ConsoleKey");
local l__KBMTouchKey__3 = script.Parent:WaitForChild("KBMTouchKey");
local function v7(p2, _) --[[ Line: 14 ]]
    -- upvalues: u1 (copy), l__ConsoleKey__2 (copy), l__KBMTouchKey__3 (copy)
    local l__UserInputType__4 = p2.UserInputType;
    local v3 = nil;
    for v4, v5 in u1 do
        if table.find(v5, l__UserInputType__4) then
            v3 = v4;
            break;
        end;
    end;
    if v3 then
        local v6 = v3 == "Controller";
        l__ConsoleKey__2.Visible = v6;
        l__KBMTouchKey__3.Visible = not v6;
        if v3 == "Mobile" then
            l__KBMTouchKey__3.Text = "TAP";
        else
            l__KBMTouchKey__3.Text = "SPACE";
        end;
    end;
end;
l__UserInputService__1.InputBegan:Connect(v7);
l__UserInputService__1.InputChanged:Connect(v7);
l__UserInputService__1.InputEnded:Connect(v7);