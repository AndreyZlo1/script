-- Roblox: Players.SilverAce293026.PlayerGui.GunsmithGui.GunsmithGuiModule
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__Players__1 = game:GetService("Players");
local l__StarterGui__2 = game:GetService("StarterGui");
local l__Modules__3 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local l__MusicModule__4 = require(l__Modules__3:WaitForChild("MusicModule"));
local l__BlackScreen__5 = script.Parent:WaitForChild("BlackScreen");
local l__LoadoutFrame__6 = script.Parent:WaitForChild("LoadoutFrame");
local l__ShopGui__7 = script.Parent.Parent:WaitForChild("ShopGui");
local l__TweenService__8 = game:GetService("TweenService");
local u2 = TweenInfo.new(0.2);
function v1.toggleShow(p3) --[[ Line: 19 ]]
    -- upvalues: l__LoadoutFrame__6 (copy), l__Players__1 (copy), l__StarterGui__2 (copy), l__ShopGui__7 (copy), l__TweenService__8 (copy), l__BlackScreen__5 (copy), u2 (copy), l__MusicModule__4 (copy)
    if l__LoadoutFrame__6.Visible == p3 then
    else
        local v4 = l__Players__1.LocalPlayer.PlayerGui:FindFirstChild("CustomToolbar");
        if v4 then
            v4.Enabled = not p3;
        end;
        l__StarterGui__2:SetCoreGuiEnabled(Enum.CoreGuiType.PlayerList, not p3);
        l__ShopGui__7.Enabled = not p3;
        l__TweenService__8:Create(l__BlackScreen__5, u2, {
            BackgroundTransparency = 0
        }):Play();
        task.wait(0.2);
        l__LoadoutFrame__6.Visible = p3;
        l__TweenService__8:Create(l__BlackScreen__5, u2, {
            BackgroundTransparency = 1
        }):Play();
        l__MusicModule__4.setHardpointPlaying(p3);
    end;
end;
return v1;