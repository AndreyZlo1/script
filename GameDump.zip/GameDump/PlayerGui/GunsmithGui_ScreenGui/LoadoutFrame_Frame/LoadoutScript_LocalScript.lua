-- Roblox: Players.SilverAce293026.PlayerGui.GunsmithGui.LoadoutFrame.LoadoutScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local _ = game:GetService("Players").LocalPlayer;
local l__Modules__2 = l__ReplicatedStorage__1:WaitForChild("Modules");
local l__GuiModule__3 = require(l__Modules__2:WaitForChild("GuiModule"));
local l__Parent__4 = script.Parent;
local l__RootFrame__5 = script.Parent:WaitForChild("RootFrame");
local l__LoadoutFrame__6 = l__RootFrame__5:WaitForChild("LoadoutFrame");
l__Parent__4:WaitForChild("MainViewport");
local l__CameraZoom__7 = l__GuiModule__3.CameraZoom;
local l__LoadoutGuiModule__8 = require(l__Parent__4.Parent:WaitForChild("LoadoutGuiModule"));
local l__GunModels__9 = l__ReplicatedStorage__1:WaitForChild("ACS_Engine"):WaitForChild("GunModels");
local l__NVG__10 = l__ReplicatedStorage__1.ACS_Engine:WaitForChild("Accessories"):WaitForChild("NVG");
local l__PlayerEvents__11 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents");
local l__GetCurrentLoadout__12 = l__PlayerEvents__11:WaitForChild("GetCurrentLoadout");
local l__RequestUnlockedGunsList__13 = l__PlayerEvents__11:WaitForChild("RequestUnlockedGunsList");
local l__RequestSetGun__14 = l__PlayerEvents__11:WaitForChild("RequestSetGun");
local l__Primary__15 = l__LoadoutFrame__6:WaitForChild("Primary");
local l__Primary2__16 = l__LoadoutFrame__6:WaitForChild("Primary2");
local l__Secondary__17 = l__LoadoutFrame__6:WaitForChild("Secondary");
local l__Melee__18 = l__LoadoutFrame__6:WaitForChild("Melee");
local l__Equipment__19 = l__LoadoutFrame__6:WaitForChild("Equipment");
local l__NVG__20 = l__LoadoutFrame__6:WaitForChild("NVG");
local u1 = {
    l__Primary__15:WaitForChild("Button"),
    l__Primary2__16:WaitForChild("Button"),
    l__Secondary__17:WaitForChild("Button"),
    l__Melee__18:WaitForChild("Button"),
    l__Equipment__19:WaitForChild("Button"),
    l__NVG__20:WaitForChild("Button")
};
local l__ScrollFrame__21 = l__RootFrame__5:WaitForChild("SelectFrame"):WaitForChild("ScrollFrame");
local u2 = l__ScrollFrame__21:WaitForChild("ProtoCell"):Clone();
local l__BottomAction__22 = script.Parent:WaitForChild("BottomAction");
local l__CloseButton__23 = l__BottomAction__22:WaitForChild("CloseButton");
local l__SelectButton__24 = l__BottomAction__22:WaitForChild("SelectButton");
local l__Button__25 = l__CloseButton__23:WaitForChild("ButtonFrame"):WaitForChild("Button");
local l__Button__26 = l__SelectButton__24:WaitForChild("ButtonFrame"):WaitForChild("Button");
local l__WeaponInHand__27 = l__Parent__4:WaitForChild("WeaponInHand");
local l__EquippedNVG__28 = l__Parent__4:WaitForChild("EquippedNVG");
local u3 = false;
local u4 = nil;
local u5 = nil;
local u6 = nil;
local function u9(u7) --[[ Line: 61 ]]
    -- upvalues: l__ScrollFrame__21 (copy)
    local function v8() --[[ Line: 62 ]]
        -- upvalues: l__ScrollFrame__21 (ref), u7 (copy)
        l__ScrollFrame__21.Visible = false;
        if u7 then
            u7();
        end;
    end;
    l__ScrollFrame__21:TweenPosition(UDim2.new(1, 0, 0, 0), Enum.EasingDirection.In, Enum.EasingStyle.Quad, 0.15, true, v8);
end;
local function u11() --[[ Line: 88 ]]
    -- upvalues: l__ScrollFrame__21 (copy), u6 (ref), u5 (ref), l__WeaponInHand__27 (copy), l__EquippedNVG__28 (copy), u4 (ref), u1 (copy)
    l__ScrollFrame__21.Visible = false;
    l__ScrollFrame__21.Position = UDim2.new(1, 0, 0, 0);
    u6 = nil;
    u5 = nil;
    l__WeaponInHand__27.Value = "";
    l__EquippedNVG__28.Value = "";
    u4 = nil;
    for _, v10 in ipairs(u1) do
        v10.Parent.BorderSizePixel = 0;
    end;
end;
local function u16(p12, p13) --[[ Line: 101 ]]
    -- upvalues: l__NVG__10 (copy), l__GunModels__9 (copy), l__CameraZoom__7 (copy)
    local l__Name__29 = p12.Name;
    p12:WaitForChild("SlotName").Text = p13 or (p12:GetAttribute("DisplayName") or l__Name__29);
    local l__Viewport__30 = p12:WaitForChild("Viewport");
    l__Viewport__30:ClearAllChildren();
    if not l__Viewport__30.CurrentCamera then
        l__Viewport__30.CurrentCamera = Instance.new("Camera");
        l__Viewport__30.CurrentCamera.CFrame = l__Viewport__30.CurrentCamera.CFrame * CFrame.Angles(0, 1.5707963267948966, 0);
    end;
    local v14 = nil;
    if p13 and p12:GetAttribute("ItemType") == "NVG" then
        v14 = l__NVG__10:WaitForChild(p13):WaitForChild("MWTNVG_Up"):WaitForChild("Handle");
    elseif p13 then
        v14 = l__GunModels__9:WaitForChild(p13);
    end;
    if v14 then
        local v15 = v14:Clone();
        v15.Parent = l__Viewport__30;
        l__CameraZoom__7.zoomToExtents(l__Viewport__30.CurrentCamera, v15);
    end;
end;
local function u19() --[[ Line: 184 ]]
    -- upvalues: l__GetCurrentLoadout__12 (copy), l__Primary__15 (copy), l__Primary2__16 (copy), l__Secondary__17 (copy), l__Melee__18 (copy), l__Equipment__19 (copy), l__NVG__20 (copy), u16 (copy), l__WeaponInHand__27 (copy)
    local v17 = l__GetCurrentLoadout__12:InvokeServer();
    for _, v18 in ipairs({
        l__Primary__15,
        l__Primary2__16,
        l__Secondary__17,
        l__Melee__18,
        l__Equipment__19,
        l__NVG__20
    }) do
        u16(v18, v17[v18.Name]);
    end;
    l__WeaponInHand__27.Value = v17.Primary or v17.Secondary;
end;
l__Parent__4:GetPropertyChangedSignal("Visible"):Connect(function() --[[ Line: 194 ]]
    -- upvalues: l__Parent__4 (copy), u11 (copy), u19 (copy)
    if l__Parent__4.Visible == true then
        u11();
        u19();
    else
        u11();
    end;
end);
l__Button__25.MouseButton1Click:Connect(function() --[[ Line: 203 ]]
    -- upvalues: u3 (ref), l__GuiModule__3 (copy), l__Button__25 (copy), l__LoadoutGuiModule__8 (copy), u6 (ref), u5 (ref), u4 (ref), u11 (copy)
    if u3 then
    else
        u3 = true;
        l__GuiModule__3.buttonPress(l__Button__25);
        l__LoadoutGuiModule__8.toggleShow(false);
        u6 = nil;
        u5 = nil;
        u4 = nil;
        l__GuiModule__3.buttonLift(l__Button__25);
        u3 = false;
        u11();
    end;
end);
l__Button__26.MouseButton1Click:Connect(function() --[[ Line: 216 ]]
    -- upvalues: u3 (ref), l__GuiModule__3 (copy), l__Button__26 (copy), l__RequestSetGun__14 (copy), u6 (ref), u5 (ref), u19 (copy), u9 (copy), u1 (copy), l__SelectButton__24 (copy), l__CloseButton__23 (copy)
    if u3 then
    else
        u3 = true;
        l__GuiModule__3.buttonPress(l__Button__26);
        if l__RequestSetGun__14:InvokeServer(u6, u5) then
            u6 = nil;
            u5 = nil;
            u19();
            u9();
            for _, v20 in ipairs(u1) do
                v20.Parent.BorderSizePixel = 0;
            end;
            l__SelectButton__24.Visible = false;
            l__CloseButton__23.Visible = true;
            l__GuiModule__3.buttonLift(l__Button__26);
            u3 = false;
        else
            l__GuiModule__3.buttonLift(l__Button__26);
            u3 = false;
        end;
    end;
end);
local u21 = u4;
local u22 = u6;
local u23 = u5;
for _, u24 in ipairs(u1) do
    u24.MouseButton1Click:Connect(function() --[[ Line: 240 ]]
        -- upvalues: u21 (ref), l__RequestUnlockedGunsList__13 (copy), u1 (copy), u23 (ref), u24 (copy), u9 (copy), l__GetCurrentLoadout__12 (copy), l__WeaponInHand__27 (copy), l__EquippedNVG__28 (copy), l__ScrollFrame__21 (copy), u2 (copy), l__Primary2__16 (copy), l__Primary__15 (copy), u16 (copy), l__SelectButton__24 (copy), l__CloseButton__23 (copy), u22 (ref)
        local v25 = u21 or l__RequestUnlockedGunsList__13:InvokeServer();
        u21 = v25;
        for _, v26 in ipairs(u1) do
            v26.Parent.BorderSizePixel = 0;
        end;
        if u23 == u24.Parent.Name then
            u23 = nil;
            u9();
            local v27 = l__GetCurrentLoadout__12:InvokeServer();
            l__WeaponInHand__27.Value = v27.Primary or (v27.Primary2 or v27.Secondary);
        else
            u24.Parent.BorderSizePixel = 3;
            u23 = u24.Parent.Name;
            if u24.Parent.SlotName.Text ~= u23 and (u24.Parent.SlotName.Text ~= "Primary 2" and u24.Parent.SlotName.Text ~= "Night Vision") then
                local l__Text__31 = u24.Parent.SlotName.Text;
                if u23 == "NVG" then
                    l__EquippedNVG__28.Value = l__Text__31;
                else
                    l__WeaponInHand__27.Value = l__Text__31;
                end;
            end;
            local u28 = v25[u23 == "Primary2" and "Primary" or u23];
            local u29 = u24.Parent:GetAttribute("ItemType");
            local function v34() --[[ Line: 133 ]]
                -- upvalues: l__ScrollFrame__21 (ref), u28 (copy), u2 (ref), u23 (ref), l__Primary2__16 (ref), l__Primary__15 (ref), u29 (copy), u16 (ref), l__SelectButton__24 (ref), l__CloseButton__23 (ref), u22 (ref), l__EquippedNVG__28 (ref), l__WeaponInHand__27 (ref)
                for _, v30 in ipairs(l__ScrollFrame__21:GetChildren()) do
                    if v30:IsA("Frame") then
                        v30:Destroy();
                    end;
                end;
                if #u28 < 1 then
                    u2:Clone().Parent = l__ScrollFrame__21;
                else
                    l__ScrollFrame__21.CanvasSize = UDim2.new(0, 0, #u28 * 0.15, #u28 * 5);
                    for _, v31 in ipairs(u28) do
                        if (u23 ~= "Primary" or l__Primary2__16.SlotName.Text ~= v31) and (u23 ~= "Primary2" or l__Primary__15.SlotName.Text ~= v31) then
                            local u32 = u2:Clone();
                            u32.Parent = l__ScrollFrame__21;
                            u32:SetAttribute("ItemType", u29);
                            u16(u32, v31);
                            u32.Button.MouseButton1Click:Connect(function() --[[ Line: 151 ]]
                                -- upvalues: l__ScrollFrame__21 (ref), u32 (copy), l__SelectButton__24 (ref), l__CloseButton__23 (ref), u22 (ref), l__EquippedNVG__28 (ref), l__WeaponInHand__27 (ref)
                                for _, v33 in ipairs(l__ScrollFrame__21:GetChildren()) do
                                    if v33:IsA("Frame") then
                                        v33.BorderSizePixel = 0;
                                    end;
                                end;
                                u32.BorderSizePixel = 3;
                                l__SelectButton__24.Visible = true;
                                l__CloseButton__23.Visible = false;
                                u22 = u32.SlotName.Text;
                                if u32:GetAttribute("ItemType") == "NVG" then
                                    l__EquippedNVG__28.Value = u22;
                                else
                                    l__WeaponInHand__27.Value = u22;
                                end;
                            end);
                        end;
                    end;
                    l__ScrollFrame__21.Visible = true;
                    l__ScrollFrame__21:TweenPosition(UDim2.new(0, 0, 0, 0), Enum.EasingDirection.In, Enum.EasingStyle.Quad, 0.15, true, nil);
                end;
            end;
            if l__ScrollFrame__21.Visible then
                u9(v34);
            else
                v34();
            end;
        end;
        l__CloseButton__23.Visible = true;
        l__SelectButton__24.Visible = false;
        u22 = nil;
    end);
end;