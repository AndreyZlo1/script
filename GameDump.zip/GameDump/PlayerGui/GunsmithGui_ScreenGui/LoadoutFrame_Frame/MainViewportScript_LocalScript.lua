-- Roblox: Players.SilverAce293026.PlayerGui.GunsmithGui.LoadoutFrame.MainViewportScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Players__2 = game:GetService("Players");
local l__LocalPlayer__3 = l__Players__2.LocalPlayer;
local l__Modules__4 = l__ReplicatedStorage__1:WaitForChild("Modules");
require(l__Modules__4:WaitForChild("GuiModule"));
local l__RootFrame__5 = script.Parent:WaitForChild("RootFrame");
l__RootFrame__5:WaitForChild("LoadoutFrame");
local l__Parent__6 = l__RootFrame__5.Parent;
local l__MainViewport__7 = l__Parent__6:WaitForChild("MainViewport");
local l__WorldModel__8 = l__MainViewport__7:WaitForChild("WorldModel");
local l__Animation__9 = l__MainViewport__7:WaitForChild("Animation");
local l__IdleAnimation__10 = l__MainViewport__7:WaitForChild("IdleAnimation");
local l__HumPart__11 = l__WorldModel__8:WaitForChild("LoadoutScene"):WaitForChild("HumPart");
local l__GunModels__12 = l__ReplicatedStorage__1:WaitForChild("ACS_Engine"):WaitForChild("GunModels");
local l__NVG__13 = l__ReplicatedStorage__1.ACS_Engine:WaitForChild("Accessories"):WaitForChild("NVG");
local l__WeaponInHand__14 = l__Parent__6:WaitForChild("WeaponInHand");
local l__EquippedNVG__15 = l__Parent__6:WaitForChild("EquippedNVG");
local u1 = nil;
local u2 = nil;
local u3 = nil;
local function u6() --[[ Line: 46 ]]
    -- upvalues: u3 (ref), l__ReplicatedStorage__1 (copy), l__WorldModel__8 (copy), l__LocalPlayer__3 (copy), l__Players__2 (copy), l__MainViewport__7 (copy), l__HumPart__11 (copy)
    if not u3 then
        u3 = l__ReplicatedStorage__1:WaitForChild("LoadoutRig"):Clone();
        u3.Parent = l__WorldModel__8;
        local v4 = u3;
        local l__UserId__16 = l__LocalPlayer__3.UserId;
        if l__UserId__16 > 0 then
            local v5 = l__Players__2:GetHumanoidDescriptionFromUserId(l__UserId__16);
            v4:WaitForChild("Humanoid"):ApplyDescription(v5);
        end;
    end;
    if not l__MainViewport__7.CurrentCamera then
        l__MainViewport__7.CurrentCamera = Instance.new("Camera");
    end;
    local l__CurrentCamera__17 = l__MainViewport__7.CurrentCamera;
    local l__HumanoidRootPart__18 = u3:WaitForChild("HumanoidRootPart");
    l__HumanoidRootPart__18.CFrame = l__HumPart__11.CFrame;
    l__CurrentCamera__17.CFrame = CFrame.new(l__HumanoidRootPart__18.Position + l__HumanoidRootPart__18.CFrame.LookVector * 3 + Vector3.new(0, 2, 0) + l__HumanoidRootPart__18.CFrame.RightVector * -2, l__HumanoidRootPart__18.Position + Vector3.new(0, 1.7, 0));
end;
local function u12(p7, p8) --[[ Line: 63 ]]
    local v9 = p8.Handle:FindFirstChildOfClass("Attachment");
    local v10 = Instance.new("Weld");
    v10.Name = "AccessoryWeld";
    v10.Part0 = p8.Handle;
    if v9 then
        local v11 = p7:FindFirstChild(tostring(v9), true);
        v10.C0 = v9.CFrame;
        v10.C1 = v11.CFrame;
        v10.Part1 = v11.Parent;
    else
        v10.C1 = CFrame.new(0, p7.Head.Size.Y / 2, 0) * p8.AttachmentPoint:inverse();
        v10.Part1 = p7.Head;
    end;
    p8.Handle.CFrame = v10.Part1.CFrame * v10.C1 * v10.C0:inverse();
    p8.Parent = p7;
    v10.Parent = p8.Handle;
end;
l__EquippedNVG__15.Changed:Connect(function(p13) --[[ Line: 82 ]]
    -- upvalues: u2 (ref), l__NVG__13 (copy), u12 (copy), u3 (ref)
    if u2 then
        u2:Destroy();
        u2 = nil;
    end;
    if p13 == nil or p13 == "" then
    else
        u2 = l__NVG__13:WaitForChild(p13):WaitForChild("MWTNVG_Up"):Clone();
        u12(u3, u2);
    end;
end);
l__WeaponInHand__14.Changed:Connect(function(p14) --[[ Line: 92 ]]
    -- upvalues: u1 (ref), u3 (ref), u6 (copy), l__GunModels__12 (copy), l__Animation__9 (copy), l__IdleAnimation__10 (copy)
    if u1 then
        u1:Destroy();
        u1 = nil;
    end;
    if p14 == nil or p14 == "" then
        if u3 then
            u3:Destroy();
            u3 = nil;
        end;
    else
        u6();
        u1 = l__GunModels__12:WaitForChild(p14):Clone();
        u1.Parent = u3;
        local l__Handle__19 = u1:WaitForChild("Handle");
        for _, v15 in ipairs(u1:GetChildren()) do
            if v15:IsA("BasePart") then
                if v15 ~= l__Handle__19 then
                    local v16 = Instance.new("WeldConstraint");
                    v16.Part0 = l__Handle__19;
                    v16.Part1 = v15;
                    v16.Parent = v15;
                end;
                v15.Anchored = false;
                v15.CanCollide = false;
            end;
        end;
        local l__RightHand__20 = u3:WaitForChild("RightHand");
        local v17 = Instance.new("Motor6D");
        v17.Parent = l__Handle__19;
        v17.Part0 = l__RightHand__20;
        v17.Part1 = l__Handle__19;
        v17.C1 = (CFrame.new(-0.3, -0.2, -0.4) * CFrame.Angles(-1.5707963267948966, 0, 0)):Inverse();
        local v18 = u3:WaitForChild("Humanoid"):LoadAnimation(l__Animation__9);
        local v19 = u3.Humanoid:LoadAnimation(l__IdleAnimation__10);
        v18:Play();
        v19:Play();
    end;
end);