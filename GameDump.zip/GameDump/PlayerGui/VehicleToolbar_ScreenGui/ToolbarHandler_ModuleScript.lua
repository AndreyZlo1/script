-- Roblox: Players.SilverAce293026.PlayerGui.VehicleToolbar.ToolbarHandler
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__UserInputService__1 = game:GetService("UserInputService");
local l__TweenService__2 = game:GetService("TweenService");
local l__Background__3 = script.Parent:WaitForChild("Background");
local l__Prototype__4 = l__Background__3:WaitForChild("Prototype");
local u2 = {};
local u3 = {};
local u4 = {
    { 0, Enum.KeyCode.Zero },
    { 1, Enum.KeyCode.One },
    { 2, Enum.KeyCode.Two },
    { 3, Enum.KeyCode.Three },
    { 4, Enum.KeyCode.Four },
    { 5, Enum.KeyCode.Five },
    { 6, Enum.KeyCode.Six },
    { 7, Enum.KeyCode.Seven },
    { 8, Enum.KeyCode.Eight },
    { 9, Enum.KeyCode.Nine }
};
local u5 = 0;
local u6 = { Enum.UserInputType.Touch };
local u7 = { Enum.UserInputType.MouseButton1, Enum.UserInputType.MouseButton2, Enum.UserInputType.MouseMovement };
local u8 = {
    Enum.KeyCode.Thumbstick1,
    Enum.KeyCode.Thumbstick2,
    Enum.KeyCode.ButtonR2,
    Enum.KeyCode.ButtonR1,
    Enum.KeyCode.ButtonL2,
    Enum.KeyCode.ButtonL1
};
local u9 = 0;
local function v14(p10, _) --[[ Line: 54 ]]
    -- upvalues: u7 (copy), u8 (copy), u6 (copy), u9 (ref), u3 (ref), l__Background__3 (copy)
    for v11, v12 in { u7, u8, u6 } do
        if table.find(v12, p10.KeyCode) or table.find(v12, p10.UserInputType) then
            if u9 == v11 then
                return;
            else
                u9 = v11;
                for _, v13 in u3 do
                    if v11 > 1 then
                        v13.Keybind.Visible = false;
                    else
                        v13.Keybind.Visible = true;
                    end;
                end;
                if v11 > 2 then
                    l__Background__3.Size = UDim2.new(0, 50, 0, 40);
                    return;
                else
                    l__Background__3.Size = UDim2.new(0, 90, 0, 40);
                    return;
                end;
            end;
        end;
    end;
end;
l__UserInputService__1.InputBegan:Connect(v14);
l__UserInputService__1.InputChanged:Connect(v14);
l__UserInputService__1.InputEnded:Connect(function(p15, p16) --[[ Line: 85 ]]
    -- upvalues: u4 (copy), u2 (ref), u5 (ref), u3 (ref), l__Background__3 (copy)
    if p16 then
        return;
    end;
    local v17 = false;
    local v18 = nil;
    for v19, v20 in u4 do
        if v20[2] == p15.KeyCode and v19 <= #u2 then
            v18 = v19;
            v17 = true;
            break;
        end;
    end;
    if v17 and v18 then
        u5 = v18;
        local v21 = u2[v18];
        for _, v22 in u3 do
            v22.ActiveStroke.Enabled = false;
        end;
        l__Background__3:FindFirstChild(v21.Name).ActiveStroke.Enabled = true;
        v21.OnStateChange("Equip");
    end;
end);
local function u29(p23, p24, p25) --[[ Line: 100 ]]
    -- upvalues: l__Background__3 (copy)
    local v26 = l__Background__3:FindFirstChild(p23);
    if v26 then
        if p25 then
            v26:SetAttribute("MaxAmmo", p25);
        end;
        local v27 = p25 or v26:GetAttribute("MaxAmmo");
        local v28 = math.clamp(p24, 0, v27);
        v26.Ammo.Text = `{v28} / {p25 or v26:GetAttribute("MaxAmmo")}`;
    end;
end;
function v1.Clear() --[[ Line: 125 ]]
    -- upvalues: u3 (ref), u2 (ref)
    for _, v30 in u3 do
        v30:Destroy();
    end;
    u3 = {};
    u2 = {};
end;
function v1.AddVehicleWeapon(p31, p32, p33, p34) --[[ Line: 134 ]]
    -- upvalues: u2 (ref), l__Prototype__4 (copy), l__Background__3 (copy), u29 (copy), u3 (ref), u5 (ref)
    local v35 = {
        Name = p31,
        Ammo = p32,
        MaxAmmo = p33,
        OnStateChange = p34
    };
    table.insert(u2, v35);
    local u36 = #u2;
    local v37 = l__Prototype__4:Clone();
    v37.Name = v35.Name;
    v37.WepName.Text = v35.Name;
    v37.Keybind.Text = tostring(u36);
    v37.Parent = l__Background__3;
    v37.Visible = true;
    u29(v35.Name, v35.Ammo, v35.MaxAmmo);
    table.insert(u3, v37);
    v37.Click.Activated:Connect(function() --[[ Line: 147 ]]
        -- upvalues: u36 (copy), u5 (ref), u2 (ref), u3 (ref), l__Background__3 (ref)
        local v38 = u36;
        u5 = v38;
        local v39 = u2[v38];
        for _, v40 in u3 do
            v40.ActiveStroke.Enabled = false;
        end;
        l__Background__3:FindFirstChild(v39.Name).ActiveStroke.Enabled = true;
        v39.OnStateChange("Equip");
    end);
    if u36 == 1 then
        u5 = u36;
        local v41 = u2[u36];
        for _, v42 in u3 do
            v42.ActiveStroke.Enabled = false;
        end;
        l__Background__3:FindFirstChild(v41.Name).ActiveStroke.Enabled = true;
        v41.OnStateChange("Equip");
    end;
end;
function v1.UpdateAmmo(p43, p44) --[[ Line: 157 ]]
    -- upvalues: l__Background__3 (copy)
    local v45 = l__Background__3:FindFirstChild(p43);
    if v45 then
        local v46 = v45:GetAttribute("MaxAmmo");
        local v47 = math.clamp(p44, 0, v46);
        v45.Ammo.Text = `{v47} / {v45:GetAttribute("MaxAmmo")}`;
    end;
end;
function v1.StartReload(p48, p49) --[[ Line: 161 ]]
    -- upvalues: l__Background__3 (copy), l__TweenService__2 (copy)
    local v50 = TweenInfo.new(p49, Enum.EasingStyle.Linear, Enum.EasingDirection.Out);
    local u51 = l__Background__3:FindFirstChild(p48);
    local v52 = l__TweenService__2:Create(u51.Reload, v50, {
        Size = UDim2.new(1, 0, 1, 0)
    });
    v52.Completed:Connect(function(p53) --[[ Line: 169 ]]
        -- upvalues: l__TweenService__2 (ref), u51 (copy)
        if p53 == Enum.PlaybackState.Completed then
            local v54 = TweenInfo.new(0.25, Enum.EasingStyle.Linear, Enum.EasingDirection.Out);
            local v55 = l__TweenService__2:Create(u51.Reload, v54, {
                BackgroundTransparency = 1
            });
            v55:Play();
            v55.Completed:Connect(function() --[[ Line: 177 ]]
                -- upvalues: u51 (ref)
                u51.Reload.Size = UDim2.new(1, 0, 0, 0);
                u51.Reload.BackgroundTransparency = 0.5;
            end);
            u51.Gradient.Scanline.Tween:Fire();
        end;
    end);
    v52:Play();
end;
l__UserInputService__1.InputEnded:Connect(function(p56, _) --[[ Line: 188 ]]
    -- upvalues: u5 (ref), u2 (ref), u3 (ref), l__Background__3 (copy)
    if script.Parent then
        if script.Parent.Enabled then
            if p56.KeyCode == Enum.KeyCode.ButtonY then
                local v57 = u5 + 1;
                local v58 = v57 <= 0 and #u2 or v57;
                local v59 = #u2 < v58 and 1 or v58;
                u5 = v59;
                local v60 = u2[v59];
                for _, v61 in u3 do
                    v61.ActiveStroke.Enabled = false;
                end;
                l__Background__3:FindFirstChild(v60.Name).ActiveStroke.Enabled = true;
                v60.OnStateChange("Equip");
            end;
        end;
    end;
end);
return v1;