-- Roblox: Players.SilverAce293026.PlayerGui.VehicleToolbar.Visibility
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Parent__1 = script.Parent;
local l__Players__2 = game:GetService("Players");
local l__ReplicatedStorage__3 = game:GetService("ReplicatedStorage");
local l__ReplicatedConfig__4 = require(l__ReplicatedStorage__3:WaitForChild("ReplicatedConfig"));
local l__LocalPlayer__5 = l__Players__2.LocalPlayer;
local v1 = l__LocalPlayer__5.Character or l__LocalPlayer__5.CharacterAdded:Wait();
if l__ReplicatedConfig__4.Mode == "Tycoon" then
    if l__LocalPlayer__5:GetAttribute("FirstSpawnDone") then
        script.Parent.Enabled = true;
    else
        l__LocalPlayer__5:SetAttribute("FirstSpawnDone", true);
    end;
end;
local l__Humanoid__6 = v1:WaitForChild("Humanoid");
l__Humanoid__6:GetPropertyChangedSignal("SeatPart"):Connect(function() --[[ Line: 17 ]]
    -- upvalues: l__Humanoid__6 (copy), l__Parent__1 (copy)
    local v2 = l__Humanoid__6.SeatPart ~= nil;
    local v3;
    if v2 then
        v3 = l__Humanoid__6.SeatPart.Parent.Name == "Required";
    else
        v3 = v2;
    end;
    if v2 and v3 then
        l__Parent__1.Enabled = true;
    else
        l__Parent__1.Enabled = false;
    end;
end);