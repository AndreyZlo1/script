-- Roblox: Players.SilverAce293026.PlayerGui.VehicleMenuNew.MenuManager.ActionsManager
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Modules__2 = l__ReplicatedStorage__1:WaitForChild("Modules");
local l__Simple__3 = require(l__Modules__2:WaitForChild("FormatNumber"):WaitForChild("Simple"));
local l__QuestData__4 = require(l__Modules__2:WaitForChild("QuestData"));
local l__UnlockParts__5 = require(l__Modules__2:WaitForChild("UnlockParts"));
local l__Parent__6 = script.Parent.Parent;
local l__Actions__7 = l__Parent__6:WaitForChild("Actions");
local l__Quest__8 = l__Parent__6:WaitForChild("Quest");
local u2 = {
    Purchase = l__Actions__7:WaitForChild("Purchase"),
    Spawn = l__Actions__7:WaitForChild("Spawn")
};
local l__LockText__9 = l__Actions__7:WaitForChild("LockText");
local u3 = nil;
local function u7(...) --[[ Line: 26 ]]
    -- upvalues: u2 (copy)
    local v4 = { ... };
    for v5, v6 in u2 do
        if table.find(v4, v5) then
            v6.Visible = true;
        else
            v6.Visible = false;
        end;
    end;
end;
function u1.Update(p8, p9) --[[ Line: 50 ]]
    -- upvalues: l__LockText__9 (copy), u7 (copy), u2 (copy), l__Actions__7 (copy), l__Quest__8 (copy), l__Simple__3 (copy), l__ReplicatedStorage__1 (copy), l__UnlockParts__5 (copy), l__QuestData__4 (copy)
    l__LockText__9.Visible = p8;
    if not p8 then
        u7("Spawn");
        l__Quest__8.Visible = false;
        l__Actions__7.Visible = true;
        u2.Purchase.Active = true;
        return;
    end;
    u7("Purchase");
    local l__UnlockRequirements__10 = p9.UnlockRequirements;
    u2.Purchase.Active = l__UnlockRequirements__10.Type ~= "Prestige";
    local v10 = l__Actions__7;
    local v11;
    if l__UnlockRequirements__10.Type == "Quest" then
        v11 = false;
    else
        v11 = l__UnlockRequirements__10.Type ~= "Parts";
    end;
    v10.Visible = v11;
    l__Quest__8.Visible = not l__Actions__7.Visible;
    if l__UnlockRequirements__10.Type == "Cash" then
        local v12 = l__Simple__3.Format(l__UnlockRequirements__10.Data);
        u2.Purchase.Label.Text = `Purchase - ${v12}`;
        return;
    end;
    if l__UnlockRequirements__10.Type == "Pass" then
        u2.Purchase.Label.Text = "Purchase Gamepass";
        return;
    end;
    if l__UnlockRequirements__10.Type == "Prestige" then
        u2.Purchase.Label.Text = `Unlocks at prestige {l__UnlockRequirements__10.Data}`;
        return;
    end;
    if l__UnlockRequirements__10.Type == "Parts" then
        for _, v13 in l__Quest__8:GetChildren() do
            if v13.Name == "QuestStep" then
                v13:Destroy();
            end;
        end;
        local v14 = l__ReplicatedStorage__1.PlayerEvents.GetUnlockedParts:InvokeServer()[l__UnlockRequirements__10.Data] or {};
        local v15 = #l__UnlockParts__5[l__UnlockRequirements__10.Data];
        local v16 = #v14;
        local v17 = l__Quest__8.Proto:Clone();
        v17.Info.StepText.Text = `Find <font color="rgb(255,85,0)">{l__UnlockRequirements__10.Data} Parts</font> around the map`;
        v17.Progress.Label.Text = `{v16} / {v15}`;
        v17.Progress.Bar.Fill.Size = UDim2.new(v16 / v15, 0, 1, 0);
        v17.Parent = l__Quest__8;
        v17.Name = "QuestStep";
        v17.Visible = true;
        return;
    end;
    if l__UnlockRequirements__10.Type ~= "Quest" then
        return;
    end;
    local l__Data__11 = l__UnlockRequirements__10.Data;
    local v18, v19, v20, v21, v22, v23, v24;
    for _, v30 in l__QuestData__4 do
        if v30.ID == l__Data__11 then
            v18 = l__ReplicatedStorage__1.PlayerEvents.Quests.GetQuestProgress:InvokeServer(l__UnlockRequirements__10.Data);
            for v31, v32 in l__Quest__8:GetChildren() do
                if v32.Name == "QuestStep" then
                    v32:Destroy();
                end;
            end;
            for v33, v34 in ipairs(v30.Steps) do
                v19 = v34.Type;
                v20 = v34.Data;
                v21 = v18[v33];
                v22 = `{v21.Current} / {v21.Goal}`;
                v23 = v19 ~= "DestroyVehicleType" and "Error - Please contact Khls" or `Destroy {v20.Amount} {string.lower(v20.Victim)} with the <font color="rgb(255,85,0)">{v20.Destroyer.Name}</font>`;
                v24 = l__Quest__8.Proto:Clone();
                v24.Info.StepText.Text = v23;
                v24.Progress.Label.Text = v22;
                v24.Progress.Bar.Fill.Size = UDim2.new(v21.Current / v21.Goal, 0, 1, 0);
                v24.Parent = l__Quest__8;
                v24.Name = "QuestStep";
                v24.Visible = true;
                if v21.Current >= v21.Goal then
                    v24.Info.Frame.BackgroundTransparency = 0;
                end;
            end;
            return;
        end;
    end;
    local v30 = nil;
    v18 = l__ReplicatedStorage__1.PlayerEvents.Quests.GetQuestProgress:InvokeServer(l__UnlockRequirements__10.Data);
    for v31, v32 in l__Quest__8:GetChildren() do
        if v32.Name == "QuestStep" then
            v32:Destroy();
        end;
    end;
    for v33, v34 in ipairs(v30.Steps) do
        v19 = v34.Type;
        v20 = v34.Data;
        v21 = v18[v33];
        v22 = `{v21.Current} / {v21.Goal}`;
        v23 = v19 ~= "DestroyVehicleType" and "Error - Please contact Khls" or `Destroy {v20.Amount} {string.lower(v20.Victim)} with the <font color="rgb(255,85,0)">{v20.Destroyer.Name}</font>`;
        v24 = l__Quest__8.Proto:Clone();
        v24.Info.StepText.Text = v23;
        v24.Progress.Label.Text = v22;
        v24.Progress.Bar.Fill.Size = UDim2.new(v21.Current / v21.Goal, 0, 1, 0);
        v24.Parent = l__Quest__8;
        v24.Name = "QuestStep";
        v24.Visible = true;
        if v21.Current >= v21.Goal then
            v24.Info.Frame.BackgroundTransparency = 0;
        end;
    end;
end;
function u1.SetVisible(p35) --[[ Line: 127 ]]
    -- upvalues: l__Actions__7 (copy), l__Quest__8 (copy)
    l__Actions__7.Visible = p35;
    l__Quest__8.Visible = false;
end;
function u1.SetSchema(p36) --[[ Line: 132 ]]
    -- upvalues: u3 (ref), u2 (copy)
    u3 = p36;
    u2.Spawn.Label.Text = p36.UseText;
end;
u2.Spawn.Activated:Connect(function() --[[ Line: 138 ]]
    -- upvalues: u3 (ref)
    u3.OnUse(u3.State.SelectedItem);
end);
u2.Purchase.Activated:Connect(function() --[[ Line: 144 ]]
    -- upvalues: u3 (ref), l__ReplicatedStorage__1 (copy), u1 (copy)
    local l__SelectedItem__12 = u3.State.SelectedItem;
    local l__UnlockRequirements__13 = u3.GetUnlockInfo(l__SelectedItem__12).UnlockRequirements;
    if l__UnlockRequirements__13.Type == "Cash" then
        if game.Players.LocalPlayer.leaderstats.Money.Value < l__UnlockRequirements__13.Data then
        else
            ({
                Ground = l__ReplicatedStorage__1.RequestVehiclePurchaseEvent,
                Helicopters = l__ReplicatedStorage__1.RequestHeliPurchaseEvent,
                Planes = l__ReplicatedStorage__1.RequestPlanePurchaseEvent
            })[u3.State.SelectedCategory]:FireServer(l__SelectedItem__12);
            u1.Update(false);
            script.Parent.RefreshUnlockCache:Fire();
            u1.MarkUnlocked(l__SelectedItem__12);
        end;
    elseif l__UnlockRequirements__13.Type == "Pass" then
        game:GetService("MarketplaceService"):PromptGamePassPurchase(game.Players.LocalPlayer, l__UnlockRequirements__13.Data);
    elseif l__UnlockRequirements__13.Type == "Prestige" then
    else
        local _ = l__UnlockRequirements__13.Type == "Quest";
    end;
end);
return u1;