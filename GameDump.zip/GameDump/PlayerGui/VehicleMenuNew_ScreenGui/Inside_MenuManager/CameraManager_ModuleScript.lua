-- Roblox: Players.SilverAce293026.PlayerGui.VehicleMenuNew.MenuManager.CameraManager
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__LocalPlayer__1 = game:GetService("Players").LocalPlayer;
local _ = script.Parent.Parent;
local u2 = nil;
function v1.SetSchema(p3) --[[ Line: 14 ]]
    -- upvalues: u2 (ref)
    u2 = p3;
end;
function v1.GotoPreviewCF(p4) --[[ Line: 18 ]]
    -- upvalues: u2 (ref), l__LocalPlayer__1 (copy)
    local v5 = u2.PreviewMode.Background[p4];
    local l__CurrentCamera__2 = workspace.CurrentCamera;
    l__CurrentCamera__2.CameraType = Enum.CameraType.Scriptable;
    l__CurrentCamera__2.CameraSubject = nil;
    local l__Value__3 = l__LocalPlayer__1:WaitForChild("AssociatedTycoon").Value;
    l__CurrentCamera__2.CFrame = workspace:WaitForChild(l__Value__3):WaitForChild("Constructions"):FindFirstChild(v5):FindFirstChild("MenuPreview").CFrame;
end;
function v1.ResetCamera() --[[ Line: 32 ]]
    -- upvalues: l__LocalPlayer__1 (copy)
    local l__CurrentCamera__4 = workspace.CurrentCamera;
    l__CurrentCamera__4.CameraType = Enum.CameraType.Custom;
    l__CurrentCamera__4.CameraSubject = l__LocalPlayer__1.Character.Humanoid;
end;
return v1;