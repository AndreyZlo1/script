-- Roblox: Players.SilverAce293026.PlayerGui.VehicleMenuNew.MenuManager.NavManager
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Money__2 = game:GetService("Players").LocalPlayer:WaitForChild("leaderstats"):WaitForChild("Money");
local l__FormatNumber__3 = l__ReplicatedStorage__1:WaitForChild("Modules"):WaitForChild("FormatNumber");
local l__Simple__4 = require(l__FormatNumber__3:WaitForChild("Simple"));
local l__Parent__5 = script.Parent.Parent;
local l__Nav__6 = l__Parent__5:WaitForChild("Nav");
local l__NavRight__7 = l__Parent__5:WaitForChild("NavRight");
local l__Header__8 = l__Nav__6:WaitForChild("Header");
local l__Primary__9 = l__Header__8:WaitForChild("Primary");
local l__Breadcrumb__10 = l__Header__8:WaitForChild("Breadcrumb");
local l__PrimaryUnder__11 = l__Header__8:WaitForChild("PrimaryUnder");
local l__Back__12 = l__Nav__6:WaitForChild("Back");
local l__Shortcut__13 = l__Back__12:WaitForChild("Shortcut");
local l__Button__14 = l__Back__12:WaitForChild("Button");
local l__Label__15 = l__NavRight__7:WaitForChild("MoneyFrame"):WaitForChild("Label");
function u1.Update(p2) --[[ Line: 30 ]]
    -- upvalues: l__Primary__9 (copy), l__PrimaryUnder__11 (copy), l__Breadcrumb__10 (copy)
    local l__HeadText__16 = p2.HeadText;
    local l__Breadcrumb__17 = p2.Breadcrumb;
    if l__Breadcrumb__17 then
        l__Primary__9.Visible = false;
        l__PrimaryUnder__11.Visible = true;
        l__Breadcrumb__10.Visible = true;
        l__PrimaryUnder__11.Text = l__HeadText__16;
        l__Breadcrumb__10.Text = l__Breadcrumb__17;
    else
        l__Primary__9.Visible = true;
        l__PrimaryUnder__11.Visible = false;
        l__Breadcrumb__10.Visible = false;
        l__Primary__9.Text = l__HeadText__16;
    end;
end;
function u1.RefreshMoney() --[[ Line: 51 ]]
    -- upvalues: l__Money__2 (copy), l__Simple__4 (copy), l__Label__15 (copy)
    l__Label__15.Text = `${l__Simple__4.Format(l__Money__2.Value)}`;
end;
function u1.SetBackShortcutVisible(p3) --[[ Line: 57 ]]
    -- upvalues: l__Shortcut__13 (copy)
    l__Shortcut__13.Visible = p3;
end;
function u1.OnBack() --[[ Line: 61 ]] end;
l__Button__14.Activated:Connect(function() --[[ Line: 65 ]]
    -- upvalues: u1 (copy)
    u1.OnBack();
end);
return u1;