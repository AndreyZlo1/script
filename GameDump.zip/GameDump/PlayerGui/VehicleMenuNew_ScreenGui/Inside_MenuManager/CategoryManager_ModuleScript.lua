-- Roblox: Players.SilverAce293026.PlayerGui.VehicleMenuNew.MenuManager.CategoryManager
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
local l__Categories__1 = script.Parent.Parent:WaitForChild("Categories");
local l__Proto__2 = l__Categories__1:WaitForChild("Proto");
local l__CameraManager__3 = require(script.Parent:WaitForChild("CameraManager"));
local u2 = {};
function u1.CreateButton(u3, p4) --[[ Line: 17 ]]
    -- upvalues: l__Proto__2 (copy), l__Categories__1 (copy), u2 (copy), u1 (copy)
    local v5 = l__Proto__2:Clone();
    v5.Name = u3;
    v5.Label.Text = u3;
    v5.Parent = l__Categories__1;
    u2[v5] = p4;
    v5.Activated:Connect(function() --[[ Line: 24 ]]
        -- upvalues: u1 (ref), u3 (copy)
        u1.SetCategory(u3);
    end);
    v5.Visible = true;
end;
function u1.SetCategory(p6) --[[ Line: 31 ]]
    -- upvalues: l__Categories__1 (copy), l__CameraManager__3 (copy), u2 (copy)
    local v7 = l__Categories__1:FindFirstChild(p6);
    if v7 then
        for _, v8 in l__Categories__1:GetChildren() do
            if v8:IsA("TextButton") and v8 ~= v7 then
                v8.BackgroundColor3 = Color3.fromRGB(0, 0, 0);
            end;
        end;
        v7.BackgroundColor3 = Color3.fromRGB(255, 85, 0);
        l__CameraManager__3.GotoPreviewCF(p6);
        u2[v7]();
    end;
end;
function u1.SetVisible(p9) --[[ Line: 46 ]]
    -- upvalues: l__Categories__1 (copy), l__Proto__2 (copy)
    for _, v10 in l__Categories__1:GetChildren() do
        if v10:IsA("TextButton") and v10 ~= l__Proto__2 then
            v10.Visible = table.find(p9, v10.Name);
        end;
    end;
end;
return u1;