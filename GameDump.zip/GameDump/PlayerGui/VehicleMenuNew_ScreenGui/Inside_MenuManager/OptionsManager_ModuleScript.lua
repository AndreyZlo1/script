-- Roblox: Players.SilverAce293026.PlayerGui.VehicleMenuNew.MenuManager.OptionsManager
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
game:GetService("RunService");
local l__Players__2 = game:GetService("Players");
local l__Parent__3 = script.Parent.Parent;
local l__Content__4 = l__Parent__3:WaitForChild("Options"):WaitForChild("Content");
local l__Stats__5 = l__Parent__3:WaitForChild("Stats");
local u2 = {
    Head = l__Stats__5:WaitForChild("DescHeader"),
    Body = l__Stats__5:WaitForChild("DescValue")
};
local u3 = {
    Head = l__Stats__5:WaitForChild("WeaponsHeader"),
    Proto = l__Stats__5:WaitForChild("WeaponProto")
};
local l__Proto__6 = l__Content__4:WaitForChild("Proto");
local u4 = nil;
local l__ActionsManager__7 = require(script.Parent:WaitForChild("ActionsManager"));
local l__GuiModule__8 = l__ReplicatedStorage__1:WaitForChild("Modules"):WaitForChild("GuiModule");
require(l__GuiModule__8:WaitForChild("CameraZoom"));
local u5 = {};
local u6 = nil;
function v1.SetSchema(p7) --[[ Line: 39 ]]
    -- upvalues: u4 (ref)
    u4 = p7;
end;
function v1.CreateItem(u8, u9) --[[ Line: 43 ]]
    -- upvalues: l__Proto__6 (copy), u4 (ref), l__Content__4 (copy), u5 (ref), u6 (ref), u2 (copy), l__Stats__5 (copy), u3 (copy), l__ActionsManager__7 (copy), l__Players__2 (copy)
    local l__Name__9 = u8.Name;
    local u10 = l__Proto__6:Clone();
    u10.Name = l__Name__9;
    u10.ItemName.Text = u8:GetAttribute("GarageName") or l__Name__9;
    local v11 = u9.Status == "Locked";
    u10.LockStatus.Text = v11 and "LOCKED" or "UNLOCKED";
    if type(u9.UnlockRequirements.Data) == "string" then
        u10.LayoutOrder = v11 and 100000000 or 1;
    else
        u10.LayoutOrder = v11 and (u9.UnlockRequirements.Data or 1) or 1;
    end;
    u10:SetAttribute("IsLocked", v11);
    local v12 = u8:Clone();
    local v13 = Instance.new("Camera");
    v13.Parent = u10;
    u10.ViewportFrame.CurrentCamera = v13;
    v12.Parent = u10.ViewportFrame;
    u4.OptionFitFunction(v12, u10.ViewportFrame);
    u10.Parent = l__Content__4;
    u10.Visible = true;
    table.insert(u5, u10);
    u10.TextButton.Activated:Connect(function() --[[ Line: 76 ]]
        -- upvalues: u6 (ref), u4 (ref), l__Name__9 (copy), u2 (ref), l__Stats__5 (ref), u8 (copy), u3 (ref), u5 (ref), u10 (copy), l__ActionsManager__7 (ref), u9 (copy), l__Players__2 (ref)
        if u6 then
            u6:Destroy();
            u6 = nil;
        end;
        u4.State.SelectedItem = l__Name__9;
        local v14 = u4.Descriptions[l__Name__9];
        u2.Head.Visible = v14 ~= nil;
        u2.Body.Visible = v14 ~= nil;
        if v14 then
            u2.Body.Text = v14;
        end;
        for _, v15 in l__Stats__5:GetChildren() do
            if v15.Name == "WeaponDisplay" then
                v15:Destroy();
            end;
        end;
        local v16 = u8.Params:FindFirstChild("Config");
        u3.Head.Visible = v16 ~= nil;
        if v16 then
            local v17 = require(v16);
            for _, v18 in v17.DriverWeapons or v17.Weapons do
                local v19 = u3.Proto:Clone();
                v19.Name = "WeaponDisplay";
                v19.Parent = l__Stats__5;
                v19.Label.Text = v18.Name;
                v19.Visible = true;
            end;
        end;
        for _, v20 in u5 do
            if v20.Name == l__Name__9 then
                v20.UIGradient.Offset = Vector2.new();
            else
                v20.UIGradient.Offset = Vector2.new(1, 1);
            end;
        end;
        if u10:GetAttribute("IsLocked") then
            l__ActionsManager__7.Update(true, u9);
        else
            l__ActionsManager__7.Update(false);
        end;
        local l__Value__10 = l__Players__2.LocalPlayer:WaitForChild("AssociatedTycoon").Value;
        local v21 = workspace:WaitForChild(l__Value__10);
        if u4.State.SelectedCategory ~= "Planes" then
            u6 = u8:Clone();
            u6.Parent = workspace;
            local v22 = u4.PreviewMode.Background[u4.State.SelectedCategory];
            local v23 = v21:WaitForChild("Constructions"):FindFirstChild(v22);
            u6:PivotTo(u4.PreviewMode.FitFunction(v23) * CFrame.new(u6:GetAttribute("SpawnOffset") or Vector3.new()));
        end;
    end);
end;
function v1.ClearPreviewModel() --[[ Line: 143 ]]
    -- upvalues: u6 (ref)
    if u6 then
        u6:Destroy();
        u6 = nil;
    end;
end;
function v1.ClearItems() --[[ Line: 150 ]]
    -- upvalues: u6 (ref), u5 (ref), l__Content__4 (copy), l__Proto__6 (copy)
    if u6 then
        u6:Destroy();
        u6 = nil;
    end;
    u5 = {};
    for _, v24 in l__Content__4:GetChildren() do
        if v24:IsA("Frame") and v24 ~= l__Proto__6 then
            v24:Destroy();
        end;
    end;
end;
function v1.MarkItemUnlocked(p25) --[[ Line: 163 ]]
    -- upvalues: l__Content__4 (copy)
    local v26 = l__Content__4:FindFirstChild(p25);
    if v26 then
        v26:SetAttribute("IsLocked", false);
    end;
end;
l__ActionsManager__7.MarkUnlocked = v1.MarkItemUnlocked;
return v1;