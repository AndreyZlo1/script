-- Roblox: Players.SilverAce293026.PlayerGui.VehicleMenuNew.Stats.DescValue.Sizing
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Parent__1 = script.Parent.Parent;
l__Parent__1:GetPropertyChangedSignal("AbsoluteSize"):Connect(function() --[[ Name: update, Line 8 ]]
    -- upvalues: l__Parent__1 (copy)
    script.Parent.TextSize = l__Parent__1.AbsoluteSize.Y / 222 * 14;
end);
script.Parent.TextSize = l__Parent__1.AbsoluteSize.Y / 222 * 14;