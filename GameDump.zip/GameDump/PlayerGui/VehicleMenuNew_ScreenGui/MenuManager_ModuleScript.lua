-- Roblox: Players.SilverAce293026.PlayerGui.VehicleMenuNew.MenuManager
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
local l__UserInputService__1 = game:GetService("UserInputService");
local l__ContextActionService__2 = game:GetService("ContextActionService");
local l__ReplicatedStorage__3 = game:GetService("ReplicatedStorage");
local l__StarterGui__4 = game:GetService("StarterGui");
local l__Parent__5 = script.Parent;
local l__NavManager__6 = require(script:WaitForChild("NavManager"));
local l__CategoryManager__7 = require(script:WaitForChild("CategoryManager"));
local l__OptionsManager__8 = require(script:WaitForChild("OptionsManager"));
local l__ActionsManager__9 = require(script:WaitForChild("ActionsManager"));
local l__CameraManager__10 = require(script:WaitForChild("CameraManager"));
local l__ShopGui__11 = l__Parent__5.Parent:WaitForChild("ShopGui");
l__Parent__5.Parent:WaitForChild("CustomToolbar");
local l__Modules__12 = l__ReplicatedStorage__3:WaitForChild("Modules");
require(l__Modules__12:WaitForChild("UnlockParts"));
local u2 = nil;
local u3 = {};
local u4 = {};
local u5 = false;
local function u11() --[[ Line: 31 ]]
    -- upvalues: u4 (copy), u2 (ref)
    if u4.Populated then
    else
        u4.Items = u2.GetAllItems();
        u4.Categories = {};
        local v6 = table.clone(u4.Items);
        for _, v7 in ipairs(u2.Categories) do
            local v8 = {
                Name = v7.Text,
                Items = {}
            };
            local l__FilterFunction__13 = v7.FilterFunction;
            for v9 = #v6, 1, -1 do
                local v10 = v6[v9];
                if not v10:GetAttribute("GarageRestriction") and l__FilterFunction__13(v10) then
                    table.insert(v8.Items, v10);
                    table.remove(v6, v9);
                end;
            end;
            table.insert(u4.Categories, v8);
        end;
        u4.Populated = true;
    end;
end;
local function u14() --[[ Line: 67 ]]
    -- upvalues: u1 (copy), u4 (copy), u2 (ref)
    u1.FlushCache("UnlockInfo");
    u4.UnlockInfo = {};
    for _, v12 in u4.Items do
        local l__Name__14 = v12.Name;
        local v13 = u2.GetUnlockInfo(l__Name__14);
        u4.UnlockInfo[l__Name__14] = v13;
    end;
end;
script:WaitForChild("RefreshUnlockCache").Event:Connect(u14);
function u1.Bind(p15) --[[ Line: 85 ]]
    -- upvalues: u2 (ref), u4 (copy)
    u2 = p15;
    u2.Cache = u4;
end;
function u1.Open(p16) --[[ Line: 90 ]]
    -- upvalues: u2 (ref), l__StarterGui__4 (copy), l__ActionsManager__9 (copy), u11 (copy), u14 (copy), l__NavManager__6 (copy), l__UserInputService__1 (copy), u3 (ref), u5 (ref), u4 (copy), l__CategoryManager__7 (copy), l__OptionsManager__8 (copy), l__CameraManager__10 (copy), l__ShopGui__11 (copy), l__ContextActionService__2 (copy), u1 (copy)
    u2.SetState({});
    l__StarterGui__4:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, false);
    l__ActionsManager__9.SetVisible(false);
    u11();
    u14();
    l__NavManager__6.Update(u2);
    l__NavManager__6.RefreshMoney();
    local v18 = l__UserInputService__1.InputBegan:Connect(function(p17) --[[ Line: 103 ]]
        -- upvalues: l__NavManager__6 (ref)
        if p17.UserInputType == Enum.UserInputType.Focus then
        else
            l__NavManager__6.SetBackShortcutVisible(p17.UserInputType == Enum.UserInputType.Gamepad1);
        end;
    end);
    table.insert(u3, v18);
    if not u5 then
        for _, u19 in pairs(u4.Categories) do
            local l__Name__15 = u19.Name;
            l__CategoryManager__7.CreateButton(l__Name__15, function() --[[ Line: 113 ]]
                -- upvalues: u2 (ref), l__Name__15 (copy), l__ActionsManager__9 (ref), l__OptionsManager__8 (ref), u19 (copy), u4 (ref)
                u2.State.SelectedCategory = l__Name__15;
                l__ActionsManager__9.SetVisible(false);
                l__OptionsManager__8.ClearItems();
                for _, v20 in u19.Items do
                    l__OptionsManager__8.CreateItem(v20, u4.UnlockInfo[v20.Name]);
                end;
            end);
        end;
    end;
    if p16 == "Ground" then
        l__CategoryManager__7.SetVisible({ "Ground" });
    else
        l__CategoryManager__7.SetVisible({ "Helicopters", "Planes" });
    end;
    u5 = true;
    l__OptionsManager__8.SetSchema(u2);
    l__ActionsManager__9.SetSchema(u2);
    l__CameraManager__10.SetSchema(u2);
    l__CategoryManager__7.SetCategory(p16);
    l__ShopGui__11.Enabled = false;
    script.Parent.Enabled = true;
    l__ContextActionService__2:BindActionAtPriority("MenuManagerClose", function(_, p21) --[[ Line: 143 ]]
        -- upvalues: u1 (ref)
        if p21 == Enum.UserInputState.End then
            u1.Close();
        end;
    end, false, 1000000, Enum.KeyCode.ButtonB);
end;
function u1.Close() --[[ Line: 149 ]]
    -- upvalues: l__CameraManager__10 (copy), l__ContextActionService__2 (copy), u3 (ref), l__StarterGui__4 (copy), l__OptionsManager__8 (copy), l__ShopGui__11 (copy)
    l__CameraManager__10.ResetCamera();
    l__ContextActionService__2:UnbindAction("MenuManagerClose");
    for _, v22 in u3 do
        v22:Disconnect();
    end;
    u3 = {};
    l__StarterGui__4:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, true);
    script.Parent.Enabled = false;
    l__OptionsManager__8.ClearPreviewModel();
    l__ShopGui__11.Enabled = true;
end;
function u1.FlushCache(p23) --[[ Line: 166 ]]
    -- upvalues: u4 (copy)
    u4[p23] = nil;
    u4.Populated = false;
end;
function u1.FlushAllCache() --[[ Line: 171 ]]
    -- upvalues: u4 (copy), u1 (copy)
    for v24, _ in u4 do
        u1.FlushCache(v24);
    end;
end;
l__NavManager__6.OnBack = u1.Close;
return u1;