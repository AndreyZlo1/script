-- Roblox: Players.SilverAce293026.PlayerGui.VehicleMenuNew.VehicleMenuSchema
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
game:GetService("RunService");
local l__AssociatedTycoon__2 = game:GetService("Players").LocalPlayer:WaitForChild("AssociatedTycoon");
local l__Planes__3 = l__ReplicatedStorage__1:WaitForChild("Planes");
local l__Vehicles__4 = l__ReplicatedStorage__1:WaitForChild("Vehicles");
local l__Helicopters__5 = l__ReplicatedStorage__1:WaitForChild("Helicopters");
local l__GuiModule__6 = l__ReplicatedStorage__1:WaitForChild("Modules"):WaitForChild("GuiModule");
local l__CameraZoom__7 = require(l__GuiModule__6:WaitForChild("CameraZoom"));
local l__FadeModule__8 = require(script.Parent.Parent:WaitForChild("FadeGui"):WaitForChild("FadeModule"));
local l__ReplicatedConfig__9 = require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig"));
local u2 = {
    Ground = l__ReplicatedStorage__1:WaitForChild("RequestGroundVehicleEvent"),
    Helicopters = l__ReplicatedStorage__1:WaitForChild("RequestHelicopterEvent"),
    Planes = l__ReplicatedStorage__1:WaitForChild("RequestPlaneEvent")
};
local l__MenuManager__10 = require(script.Parent.MenuManager);
u1.State = {};
function u1.SetState(p3) --[[ Line: 34 ]]
    -- upvalues: u1 (copy)
    u1.State = p3;
end;
u1.Breadcrumb = false;
u1.HeadText = "GARAGE";
u1.Categories = {
    {
        Text = "Ground",
        FilterFunction = function(p4) --[[ Name: FilterFunction, Line 46 ]]
            local v5 = p4.Required:FindFirstChildOfClass("VehicleSeat");
            return (v5.Name == "ApcSeat" or v5.Name == "VehicleSeat") and true or v5.Name == "TankSeat";
        end
    },
    {
        Text = "Helicopters",
        FilterFunction = function(p6) --[[ Name: FilterFunction, Line 55 ]]
            return p6.Required:FindFirstChildOfClass("VehicleSeat").Name == "HeliSeat";
        end
    },
    {
        Text = "Planes",
        FilterFunction = function(p7) --[[ Name: FilterFunction, Line 63 ]]
            return p7.Required:FindFirstChildOfClass("VehicleSeat").Name == "PlaneSeat";
        end
    }
};
u1.Progression = false;
function u1.StatInfoFunction(_) --[[ Line: 75 ]] end;
u1.Descriptions = {
    ATV = "A lightweight quad bike, used for quick off-road mobility.",
    ["BTR-80"] = "A Soviet 8-wheeled APC. Amphibious, lightly armored, and widely exported.",
    ["Dune Buggy"] = "A fast, open-frame vehicle built for agility on sand and rough terrain.",
    Humvee = "A versatile 4x4 military vehicle. Standard issue for the U.S. Army since the 1980s.",
    ["L-ATV"] = "A modern MRAP designed to replace the Humvee. Offers improved protection and mobility.",
    ["Leopard Evo"] = "A modern European MBT. Combines advanced armor with high mobility.",
    ["M142 HIMARS"] = "A mobile rocket artillery system. Fires rockets with pinpoint accuracy.",
    ["T-72"] = "A late Cold War era MBT. The most common tank to be used by the Warsaw Pact.",
    Tank = "An American MBT known for its heavy armor and firepower. Dominant since the Gulf War.",
    ["M4 Sherman"] = "An iconic WWII American medium tank. Reliable, versatile, and produced in massive numbers.",
    ["AH-1Z Viper"] = "A modern U.S. attack helicopter. Agile, with advanced targeting and missiles.",
    ["MH-6 Little Bird"] = "A light utility helicopter. Used for fast insertion and recon missions.",
    ["Mil-24 Hind"] = "A Soviet-era gunship. Heavily armed and adept at anti-ground missions.",
    ["RAH-66 Comanche"] = "A high-tech stealthy U.S. recon and attack helicopter with heavy-hitting rockets.",
    ["UH-60 Black Hawk"] = "A reliable U.S. utility helicopter. Known for troop transport and medevac roles.",
    ["F4 Phantom II"] = "A signature combat aircraft of the Cold War. Third generation supersonic jet interceptor and fighter-bomber.",
    ["Mig-23"] = "A Soviet variable-sweep wing fighter. Designed for high-speed interceptions.",
    ["F14 Tomcat"] = "An iconic U.S. Navy fighter. Twin engines, and unmatched dogfighting agility.",
    ["A-10 Warthog"] = "brrrrrrrrrt"
};
function u1.GetAllItems() --[[ Line: 107 ]]
    -- upvalues: l__Vehicles__4 (copy), l__Helicopters__5 (copy), l__Planes__3 (copy)
    local v8 = {};
    for _, v9 in { l__Vehicles__4:GetChildren(), l__Helicopters__5:GetChildren(), (l__Planes__3:GetChildren()) } do
        table.move(v9, 1, #v9, #v8 + 1, v8);
    end;
    return v8;
end;
function u1.GetUnlockInfo(p10) --[[ Line: 126 ]]
    -- upvalues: l__AssociatedTycoon__2 (copy), l__ReplicatedConfig__9 (copy)
    local v11 = workspace:FindFirstChild(l__AssociatedTycoon__2.Value);
    local v12 = v11.Vehicles:FindFirstChild(p10) or (v11.Helicopters:FindFirstChild(p10) or v11.Planes:FindFirstChild(p10));
    if not v12 then
        return {
            Status = "Unlocked"
        };
    end;
    local v13 = {};
    local v14;
    if v12:FindFirstChild("Cost") then
        v14 = {
            Type = "Cash",
            Data = v12.Cost.Value
        };
    elseif v12:FindFirstChild("PassId") then
        v14 = {
            Type = "Pass",
            Data = v12.PassId.Value
        };
    elseif v12:FindFirstChild("Prestige") then
        v14 = {
            Type = "Prestige",
            Data = v12.Prestige.Value
        };
    elseif v12:FindFirstChild("Quest") then
        v14 = {
            Type = "Quest",
            Data = v12.Quest.Value
        };
    else
        v14 = v12:FindFirstChild("Parts") and {
            Type = "Parts",
            Data = v12.Parts.Value
        } or v13;
    end;
    return l__ReplicatedConfig__9.IsKhlsServ and {
        Status = "Unlocked",
        UnlockRequirements = v14
    } or {
        Status = v12.Value and "Unlocked" or "Locked",
        UnlockRequirements = v14
    };
end;
u1.PreviewMode = {
    Type = "World",
    Background = {
        Ground = "Garage",
        Helicopters = "Helipad",
        Planes = "Helipad"
    },
    FitFunction = function(p15) --[[ Name: FitFunction, Line 184 ]]
        return p15.ModelPreview.CFrame;
    end
};
u1.OptionFitCameraPivot = CFrame.new();
function u1.OptionFitFunction(u16, u17) --[[ Line: 190 ]]
    -- upvalues: u1 (copy), l__CameraZoom__7 (copy)
    local l__SelectedCategory__11 = u1.State.SelectedCategory;
    if l__SelectedCategory__11 == "Helicopters" or l__SelectedCategory__11 == "Planes" then
        l__CameraZoom__7.setupWorldModel(u17, u16);
    end;
    task.delay(0.25, function() --[[ Line: 195 ]]
        -- upvalues: l__CameraZoom__7 (ref), u17 (copy), u16 (copy)
        l__CameraZoom__7.zoomToExtents(u17.CurrentCamera, u16, 135, -30);
    end);
end;
u1.InlineOptions = false;
u1.UseText = "Spawn";
function u1.OnStart(_) --[[ Line: 206 ]] end;
function u1.OnUse(p18) --[[ Line: 210 ]]
    -- upvalues: u1 (copy), l__MenuManager__10 (copy), l__FadeModule__8 (copy), u2 (copy)
    local l__SelectedCategory__12 = u1.State.SelectedCategory;
    l__MenuManager__10.Close();
    if l__SelectedCategory__12 == "Planes" then
        l__FadeModule__8.FadeYield(true, 0.3);
    end;
    u2[l__SelectedCategory__12]:FireServer(p18);
    task.wait(0.1);
    if l__SelectedCategory__12 == "Planes" then
        l__FadeModule__8.FadeYield(false, 0.3);
    end;
end;
function u1.OnSelect(_) --[[ Line: 223 ]] end;
function u1.OnBack() --[[ Line: 227 ]] end;
return u1;