-- Roblox: Players.SilverAce293026.PlayerGui.TopGui.HardpointUpdater
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Players__2 = game:GetService("Players");
local l__RunService__3 = game:GetService("RunService");
local l__ReplicatedConfig__4 = require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig"));
local l__LocalPlayer__5 = l__Players__2.LocalPlayer;
local u1 = Color3.new(0, 0.4, 1);
local u2 = Color3.new(1, 0.4, 0);
local u3 = Color3.new(1, 0.6, 0);
local u4 = Color3.new(1, 1, 1);
local u5 = Color3.new(0.686275, 0.686275, 0.686275);
local u6 = l__LocalPlayer__5:FindFirstChild("CurrentHardpoint") or Instance.new("StringValue");
u6.Name = "CurrentHardpoint";
u6.Parent = l__LocalPlayer__5;
local l__Hardpoints__6 = workspace:WaitForChild("Hardpoints");
local u7 = {
    l__Hardpoints__6:WaitForChild("Town"),
    l__Hardpoints__6:WaitForChild("Facility"),
    l__Hardpoints__6:WaitForChild("RiverDam"),
    l__Hardpoints__6:WaitForChild("RadioTower"),
    l__Hardpoints__6:WaitForChild("Warehouse")
};
local l__HardpointGuis__7 = workspace:WaitForChild("HardpointGuis");
local u8 = {
    l__HardpointGuis__7:WaitForChild("AGui"):WaitForChild("HardpointFrame"),
    l__HardpointGuis__7:WaitForChild("BGui"):WaitForChild("HardpointFrame"),
    l__HardpointGuis__7:WaitForChild("CGui"):WaitForChild("HardpointFrame"),
    l__HardpointGuis__7:WaitForChild("DGui"):WaitForChild("HardpointFrame"),
    l__HardpointGuis__7:WaitForChild("EGui"):WaitForChild("HardpointFrame")
};
local l__HardpointFrame__8 = script.Parent:WaitForChild("HardpointFrame");
local l__PrimaryLabel__9 = l__HardpointFrame__8.PrimaryLabel;
local l__ProgressFrame__10 = l__HardpointFrame__8.ProgressFrame;
local l__ProgressBar__11 = l__ProgressFrame__10.ProgressBar;
local function u18(p9, p10) --[[ Line: 62 ]]
    -- upvalues: l__LocalPlayer__5 (copy), u5 (copy), u4 (copy), u6 (copy), l__PrimaryLabel__9 (copy), l__ReplicatedConfig__4 (copy), l__Players__2 (copy), u1 (copy), u2 (copy)
    local l__PrimaryLabel__12 = p10.PrimaryLabel;
    local l__Value__13 = p9.OwningPlayer.Value;
    local v11 = p9:FindFirstChild("ColorZone");
    l__LocalPlayer__5:GetAttribute("MG_Team");
    if l__Value__13 == nil or l__Value__13 == "" and p9.OwningTeam.Value == "" then
        l__PrimaryLabel__12.TextColor3 = u5;
        local v12 = u4;
        if v11 ~= nil then
            for _, v13 in ipairs(v11:GetChildren()) do
                v13.Color = v12;
            end;
        end;
        if u6.Value == p9.Name then
            l__PrimaryLabel__9.TextColor3 = u5;
        end;
    else
        local v14;
        if l__ReplicatedConfig__4.Mode == "GroundWar" then
            local v15 = l__Players__2:FindFirstChild(l__Value__13);
            if v15 then
                v14 = v15:GetAttribute("MG_Team") == "Blue" and Color3.fromRGB(0, 0, 255) or Color3.fromRGB(255, 0, 0);
            else
                v14 = p9.OwningTeam.Value == "Blue" and Color3.fromRGB(0, 0, 255) or Color3.fromRGB(255, 0, 0);
            end;
        else
            v14 = l__Value__13 == l__LocalPlayer__5.Name and u1 or u2;
        end;
        l__PrimaryLabel__12.TextColor3 = v14;
        local v16;
        if v11 == nil then
            v16 = v14;
        else
            v16 = v14;
            for _, v17 in ipairs(v11:GetChildren()) do
                v17.Color = v14;
            end;
        end;
        if u6.Value == p9.Name then
            l__PrimaryLabel__9.TextColor3 = v16;
        end;
    end;
end;
local function u23(p19, p20) --[[ Line: 103 ]]
    -- upvalues: u6 (copy), l__ProgressFrame__10 (copy), l__ReplicatedConfig__4 (copy), l__Players__2 (copy), l__LocalPlayer__5 (copy), u1 (copy), u2 (copy), l__ProgressBar__11 (copy)
    local l__Value__14 = p19.CaptureProgress.Value;
    local l__ProgressFrame__15 = p20.ProgressFrame;
    local l__ProgressBar__16 = l__ProgressFrame__15.ProgressBar;
    local l__Value__17 = p19.CapturingPlayer.Value;
    if l__Value__14 >= 1 or l__Value__14 <= 0 then
        l__ProgressFrame__15.Visible = false;
        if u6.Value == p19.Name then
            l__ProgressFrame__10.Visible = false;
        end;
    else
        local v21;
        if l__ReplicatedConfig__4.Mode == "GroundWar" then
            local v22 = l__Players__2:FindFirstChild(l__Value__17);
            if v22 then
                v21 = v22:GetAttribute("MG_Team") == "Blue" and Color3.fromRGB(0, 0, 255) or Color3.fromRGB(255, 0, 0);
            else
                local l__Value__18 = p19.OwningTeam.Value;
                if l__Value__18 and (l__Value__18 == "Red" or l__Value__18 == "Blue") then
                    v21 = l__Value__18 == "Blue" and Color3.fromRGB(0, 0, 255) or Color3.fromRGB(255, 0, 0);
                else
                    v21 = Color3.fromRGB(255, 255, 255);
                end;
            end;
        else
            v21 = l__Value__17 == l__LocalPlayer__5.Name and u1 or u2;
        end;
        l__ProgressFrame__15.Visible = true;
        l__ProgressBar__16.Size = UDim2.new(l__Value__14, 0, 1, 0);
        l__ProgressBar__16.Position = UDim2.new((1 - l__Value__14) / 2, 0, 0, 0);
        l__ProgressBar__16.BackgroundColor3 = v21;
        if u6.Value == p19.Name then
            l__ProgressFrame__10.Visible = true;
            l__ProgressBar__11.Size = UDim2.new(l__Value__14, 0, 1, 0);
            l__ProgressBar__11.Position = UDim2.new((1 - l__Value__14) / 2, 0, 0, 0);
            l__ProgressBar__11.BackgroundColor3 = v21;
        end;
    end;
end;
local function u29(p24, p25) --[[ Line: 147 ]]
    -- upvalues: u3 (copy), u6 (copy), l__PrimaryLabel__9 (copy), l__ProgressBar__11 (copy), u18 (copy)
    local l__PrimaryLabel__19 = p25.PrimaryLabel;
    local l__ProgressBar__20 = p25.ProgressFrame.ProgressBar;
    local l__Value__21 = p24.IsContested.Value;
    local v26 = p24:FindFirstChild("ColorZone");
    if l__Value__21 == true then
        l__PrimaryLabel__19.TextColor3 = u3;
        l__ProgressBar__20.BackgroundColor3 = u3;
        if u6.Value == p24.Name then
            l__PrimaryLabel__9.TextColor3 = u3;
            l__ProgressBar__11.BackgroundColor3 = u3;
        end;
        local v27 = u3;
        if v26 == nil then
        else
            for _, v28 in ipairs(v26:GetChildren()) do
                v28.Color = v27;
            end;
        end;
    else
        u18(p24, p25);
    end;
end;
for u30, u31 in ipairs(u7) do
    u18(u31, u8[u30]);
    u23(u31, u8[u30]);
    u31:WaitForChild("OwningPlayer").Changed:Connect(function() --[[ Name: opConnector, Line 172 ]]
        -- upvalues: u18 (copy), u31 (copy), u8 (copy), u30 (copy)
        u18(u31, u8[u30]);
    end);
    u31:WaitForChild("CaptureProgress").Changed:Connect(function() --[[ Name: cpConnector, Line 176 ]]
        -- upvalues: u23 (copy), u31 (copy), u8 (copy), u30 (copy)
        u23(u31, u8[u30]);
    end);
    u31:WaitForChild("IsContested").Changed:Connect(function() --[[ Name: contestConnector, Line 180 ]]
        -- upvalues: u29 (copy), u31 (copy), u8 (copy), u30 (copy)
        u29(u31, u8[u30]);
    end);
end;
u6.Changed:Connect(function() --[[ Line: 189 ]]
    -- upvalues: u6 (copy), l__HardpointFrame__8 (copy), u7 (copy), u8 (copy), l__PrimaryLabel__9 (copy), u18 (copy), u23 (copy), u29 (copy)
    if u6.Value == "" then
        l__HardpointFrame__8.Visible = false;
        return;
    end;
    local l__Value__22 = u6.Value;
    for _, v37 in ipairs(u7) do
        if v37.Name == l__Value__22 then
            local v33 = 0;
            while true do
                if v33 == 0 then
                    v33 = -1;
                    local l__Value__23 = u6.Value;
                    local v34;
                    for v35, v36 in ipairs(u7) do
                        if v36.Name == l__Value__23 then
                            v34 = u8[v35];
                            l__HardpointFrame__8.Visible = true;
                            l__PrimaryLabel__9.Text = v34.PrimaryLabel.Text;
                            u18(v37, v34);
                            u23(v37, v34);
                            u29(v37, v34);
                            return;
                        end;
                    end;
                    v34 = nil;
                    goto l0;
                else
                    break;
                end;
            end;
        end;
    end;
    local v37 = nil;
    goto l1;
end);
l__RunService__3.RenderStepped:Connect(function() --[[ Line: 204 ]]
    -- upvalues: l__LocalPlayer__5 (copy), u7 (copy), u8 (copy)
    local l__Character__24 = l__LocalPlayer__5.Character;
    if l__Character__24 then
        local l__PrimaryPart__25 = l__Character__24.PrimaryPart;
        if l__PrimaryPart__25 then
            local v38 = l__LocalPlayer__5.PlayerGui:FindFirstChild("LoadingGui");
            if v38 then
                for v39, v40 in u7 do
                    local v41 = u8[v39]:FindFirstChild("DistanceLabel");
                    if v41 then
                        v41.Visible = not v38.Enabled;
                        local v42 = v40:FindFirstChild("TouchPart");
                        if v42 then
                            local l__Magnitude__26 = (l__PrimaryPart__25.Position - v42.Position).Magnitude;
                            local v43 = math.round(l__Magnitude__26 / 2.4);
                            v41.Text = string.format("%sm", v43);
                            if l__Magnitude__26 < 230 then
                                v41.TextTransparency = 1 - (l__Magnitude__26 - 200) / 30;
                            end;
                        end;
                    end;
                end;
            end;
        end;
    end;
end);