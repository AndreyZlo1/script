-- Roblox: Players.SilverAce293026.PlayerGui.TopGui.PickupUpdater
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__PickupFrame__1 = script.Parent:WaitForChild("PickupFrame");
local l__ProtoLabel__2 = l__PickupFrame__1:WaitForChild("ProtoLabel");
local l__DropPickedUp__3 = game:GetService("ReplicatedStorage"):WaitForChild("PlayerEvents"):WaitForChild("DropPickedUp");
local l__TweenService__4 = game:GetService("TweenService");
local u1 = TweenInfo.new(1.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local function u5(p2) --[[ Line: 10 ]]
    -- upvalues: l__ProtoLabel__2 (copy), l__PickupFrame__1 (copy), l__TweenService__4 (copy), u1 (copy)
    local u3 = l__ProtoLabel__2:Clone();
    u3.Parent = l__PickupFrame__1;
    u3.Text = "+ " .. p2;
    local v4 = l__TweenService__4:Create(u3, u1, {
        TextTransparency = 1
    });
    v4.Completed:Connect(function() --[[ Line: 19 ]]
        -- upvalues: u3 (copy)
        u3:Destroy();
    end);
    u3.Visible = true;
    u3:TweenPosition(UDim2.new(0, 0, 1.5, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Linear, 1.5);
    v4:Play();
end;
local u6 = {
    GiftPickup = "1 Gift",
    BigGiftPickup = "10 Gifts",
    ArmorPickup = "Armor",
    AmmoPickup = "Ammo",
    RPGPickup = "Launcher ammo",
    MoneyPickup = "$12,500"
};
l__DropPickedUp__3.OnClientEvent:Connect(function(p7) --[[ Line: 44 ]]
    -- upvalues: u6 (copy), u5 (copy)
    if u6[p7] then
        u5(u6[p7]);
    end;
end);