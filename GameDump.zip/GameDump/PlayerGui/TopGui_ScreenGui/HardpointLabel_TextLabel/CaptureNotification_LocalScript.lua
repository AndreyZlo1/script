-- Roblox: Players.SilverAce293026.PlayerGui.TopGui.HardpointLabel.CaptureNotification
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__LocalPlayer__1 = game:GetService("Players").LocalPlayer;
local l__NotificationFrame__2 = l__LocalPlayer__1:WaitForChild("PlayerGui"):WaitForChild("NotificationGui"):WaitForChild("NotificationFrame");
local l__NotificationLabel__3 = l__NotificationFrame__2:WaitForChild("NotificationLabel");
local l__CountdownLabel__4 = l__NotificationFrame__2:WaitForChild("CountdownLabel");
local l__TeamsFrame__5 = l__NotificationFrame__2:WaitForChild("TeamsFrame");
local l__ReplicatedStorage__6 = game:GetService("ReplicatedStorage");
local l__ReplicatedConfig__7 = require(l__ReplicatedStorage__6:WaitForChild("ReplicatedConfig"));
local u1 = Color3.new(0, 0.4, 1);
local u2 = Color3.new(1, 0.4, 0);
Color3.new(1, 0.6, 0);
Color3.new(1, 1, 1);
local l__Hardpoints__8 = workspace:WaitForChild("Hardpoints");
local v3 = {
    l__Hardpoints__8:WaitForChild("Town"),
    l__Hardpoints__8:WaitForChild("Facility"),
    l__Hardpoints__8:WaitForChild("RadioTower"),
    l__Hardpoints__8:WaitForChild("RiverDam"),
    l__Hardpoints__8:WaitForChild("Warehouse")
};
local u4 = {};
local u5 = {
    "Town",
    "Facility",
    "Radio Tower",
    "River Dam",
    "Warehouse"
};
for u6, v7 in ipairs(v3) do
    v7.OwningPlayer.Changed:Connect(function(p8) --[[ Line: 37 ]]
        -- upvalues: u4 (copy), u5 (copy), u6 (copy)
        if p8 == "" then
        else
            table.insert(u4, { p8, u5[u6] });
            task.wait(3);
            if #u4 > 0 then
                table.remove(u4, 1);
            end;
        end;
    end);
end;
if l__ReplicatedConfig__7.Mode == "Tycoon" then
    spawn(function() --[[ Line: 54 ]]
        -- upvalues: u4 (copy), l__LocalPlayer__1 (copy), u1 (copy), u2 (copy), l__NotificationLabel__3 (copy), l__CountdownLabel__4 (copy), l__TeamsFrame__5 (copy)
        while true do
            while true do
                task.wait();
                if #u4 <= 0 then
                    break;
                end;
                local v9 = u4[1][1];
                local v10 = u4[1][2];
                if v9 == l__LocalPlayer__1.Name then
                    script.Parent.Text = "You have captured the " .. v10 .. "! Your earnings are increased by 20%!";
                    script.Parent.TextColor3 = u1;
                else
                    script.Parent.Text = v9 .. " has captured the " .. v10 .. "! Their earnings are increased by 20%!";
                    script.Parent.TextColor3 = u2;
                end;
                if not (l__NotificationLabel__3.Visible or (l__CountdownLabel__4.Visible or l__TeamsFrame__5.Visible)) then
                    script.Parent.Visible = true;
                end;
            end;
            script.Parent.Visible = false;
        end;
    end);
else
    script.Parent.Visible = false;
end;