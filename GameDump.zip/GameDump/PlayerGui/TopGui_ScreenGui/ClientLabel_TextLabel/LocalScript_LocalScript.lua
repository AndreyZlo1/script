-- Roblox: Players.SilverAce293026.PlayerGui.TopGui.ClientLabel.LocalScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = game:GetService("Players").LocalPlayer.UserId * 2;
script.Parent.Text = `Client version {v1}`;