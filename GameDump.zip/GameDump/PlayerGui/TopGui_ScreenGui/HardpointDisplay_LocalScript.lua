-- Roblox: Players.SilverAce293026.PlayerGui.TopGui.HardpointDisplay
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Players__2 = game:GetService("Players");
game:GetService("RunService");
local l__LocalPlayer__3 = l__Players__2.LocalPlayer;
local l__ReplicatedConfig__4 = require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig"));
local l__Hardpoints__5 = workspace:WaitForChild("Hardpoints");
local l__HardpointGuis__6 = workspace:WaitForChild("HardpointGuis");
local u1 = {
    Alpha = {
        Name = "Town",
        Model = l__Hardpoints__5:WaitForChild("Town")
    },
    Bravo = {
        Name = "Radio Tower",
        Model = l__Hardpoints__5:WaitForChild("RadioTower")
    }
};
local u2 = {
    Blue = Color3.fromRGB(0, 0, 255),
    Red = Color3.fromRGB(255, 0, 0),
    Orange = Color3.fromRGB(255, 85, 0),
    Contested = Color3.fromRGB(255, 165, 0),
    Neutral = Color3.fromRGB(255, 255, 255),
    ["Task Force"] = Color3.fromRGB(0, 0, 255),
    Mercenaries = Color3.fromRGB(255, 0, 0)
};
for v3, v4 in u1 do
    local v5 = v3:sub(1, 1):upper();
    v4.UI = l__HardpointGuis__6:WaitForChild(string.format("%sGui", v5));
end;
local u6 = {
    Frame = script.Parent:WaitForChild("HardpointFrame")
};
u6.ProgressBar = u6.Frame:WaitForChild("ProgressFrame"):WaitForChild("ProgressBar");
u6.Label = u6.Frame:WaitForChild("PrimaryLabel");
local function u10(p7, p8) --[[ Line: 56 ]]
    for _, v9 in p7:WaitForChild("ColorZone"):GetChildren() do
        if v9:IsA("BasePart") then
            v9.Color = p8;
        end;
    end;
end;
local function u15(p11, p12) --[[ Line: 82 ]]
    -- upvalues: l__LocalPlayer__3 (copy)
    local l__Character__7 = l__LocalPlayer__3.Character;
    if l__Character__7 then
        local l__PrimaryPart__8 = l__Character__7.PrimaryPart;
        if l__PrimaryPart__8 then
            local v13 = p12:FindFirstChild("TouchPart");
            if v13 then
                local v14 = math.ceil((l__PrimaryPart__8.Position - v13.Position).Magnitude / 2.4);
                p11.Distance.Text = string.format("%sm", v14);
                return v14;
            end;
        end;
    end;
end;
local function u22(p16, p17, p18, p19) --[[ Line: 98 ]]
    -- upvalues: u6 (copy), u1 (copy)
    if p16 == nil then
        u6.Frame.Visible = false;
        return;
    end;
    u6.ProgressBar.BackgroundColor3 = p18 or p17;
    u6.Label.BackgroundColor3 = p17;
    u6.ProgressBar.Size = UDim2.new(p19, 0, 1, 0);
    local l__Label__9 = u6.Label;
    local v20;
    for _, v21 in u1 do
        if v21.Model == p16 then
            v20 = v21.Name;
            l__Label__9.Text = v20;
            u6.Frame.Visible = true;
            u6.ProgressBar.Parent.Visible = p19 ~= 1;
            return;
        end;
    end;
    v20 = nil;
    l__Label__9.Text = v20;
    u6.Frame.Visible = true;
    u6.ProgressBar.Parent.Visible = p19 ~= 1;
end;
local function u31(_, p23) --[[ Line: 115 ]]
    -- upvalues: u10 (copy), u2 (copy), l__LocalPlayer__3 (copy), u22 (copy)
    local l__Model__10 = p23.Model;
    local v24 = l__Model__10:GetAttribute("Contested");
    local v25 = l__Model__10:GetAttribute("CapturingProgress");
    if v24 then
        u10(l__Model__10, u2.Contested);
        local l__UI__11 = p23.UI;
        local l__Contested__12 = u2.Contested;
        local l__HardpointFrame__13 = l__UI__11.HardpointFrame;
        local l__HardpointName__14 = l__UI__11.HardpointName;
        local l__Fill__15 = l__HardpointFrame__13.Square.Fill;
        l__HardpointName__14.TextColor3 = l__Contested__12;
        l__Fill__15.BackgroundColor3 = l__Contested__12;
    else
        local v26 = l__Model__10:GetAttribute("CapturingSquad");
        local v27 = l__Model__10:GetAttribute("OwningSquad");
        local v28 = l__LocalPlayer__3:GetAttribute("SquadIndex");
        local v29 = v27 == v28 and u2.Blue or u2.Red;
        local v30 = v26 == v28 and u2.Blue or u2.Orange;
        if v27 then
            if not v26 or v27 == v28 then
                v30 = nil;
            end;
        else
            v29 = u2.Neutral;
        end;
        u10(l__Model__10, v29);
        local l__UI__16 = p23.UI;
        local l__HardpointFrame__17 = l__UI__16.HardpointFrame;
        local l__HardpointName__18 = l__UI__16.HardpointName;
        local l__Fill__19 = l__HardpointFrame__17.Square.Fill;
        l__HardpointName__18.TextColor3 = v29;
        l__Fill__19.BackgroundColor3 = v30 or v29;
        l__Fill__19.UIGradient.Offset = Vector2.new(0, -v25);
        if l__Model__10.Name == l__LocalPlayer__3:GetAttribute("CurrentHardpoint") then
            u22(l__Model__10, v29, v30, v25);
        end;
    end;
end;
local v32 = 0;
local l__HardpointLabel__20 = script.Parent:WaitForChild("HardpointLabel");
local u33 = v32;
for u34, u35 in u1 do
    local l__Model__21 = u35.Model;
    l__Model__21.AttributeChanged:Connect(function() --[[ Line: 188 ]]
        -- upvalues: u31 (copy), u34 (copy), u35 (copy)
        u31(u34, u35);
    end);
    l__Model__21:GetAttributeChangedSignal("OwningSquad"):Connect(function() --[[ Line: 192 ]]
        -- upvalues: l__Model__21 (copy), l__LocalPlayer__3 (copy), l__HardpointLabel__20 (copy), u35 (copy), l__ReplicatedConfig__4 (copy), u33 (ref)
        local v36 = l__Model__21:GetAttribute("OwningSquad");
        if v36 == l__LocalPlayer__3:GetAttribute("SquadIndex") then
            l__HardpointLabel__20.TextColor3 = Color3.fromRGB(0, 85, 255);
            local v37 = string.format("Your squad captured the %s! Your earnings have been increased by 10%%", u35.Name);
            if l__ReplicatedConfig__4.Mode == "Tycoon" then
                u33 = u33 + 1;
                l__HardpointLabel__20.Text = v37;
                l__HardpointLabel__20.Visible = true;
                local u38 = u33;
                task.delay(4, function() --[[ Line: 178 ]]
                    -- upvalues: u38 (copy), u33 (ref), l__HardpointLabel__20 (ref)
                    if u38 == u33 then
                        l__HardpointLabel__20.Visible = false;
                    end;
                end);
            end;
        else
            if v36 ~= nil and v36 ~= "" then
                l__HardpointLabel__20.TextColor3 = Color3.fromRGB(255, 85, 0);
                local v39 = string.format("An enemy squad captured the %s! Their earnings have been increased by 10%%", u35.Name);
                if l__ReplicatedConfig__4.Mode ~= "Tycoon" then
                    return;
                end;
                u33 = u33 + 1;
                l__HardpointLabel__20.Text = v39;
                l__HardpointLabel__20.Visible = true;
                local u40 = u33;
                task.delay(4, function() --[[ Line: 178 ]]
                    -- upvalues: u40 (copy), u33 (ref), l__HardpointLabel__20 (ref)
                    if u40 == u33 then
                        l__HardpointLabel__20.Visible = false;
                    end;
                end);
            end;
        end;
    end);
    l__Players__2.LocalPlayer:GetAttributeChangedSignal("SquadIndex"):Connect(function() --[[ Line: 204 ]]
        -- upvalues: u31 (copy), u34 (copy), u35 (copy)
        u31(u34, u35);
    end);
    u31(u34, u35);
end;
l__LocalPlayer__3:GetAttributeChangedSignal("CurrentHardpoint"):Connect(function() --[[ Line: 211 ]]
    -- upvalues: l__LocalPlayer__3 (copy), u22 (copy)
    local v41 = l__LocalPlayer__3:GetAttribute("CurrentHardpoint");
    if v41 == nil or v41 == "" then
        u22();
    end;
end);
while true do
    task.wait();
    local u42 = l__LocalPlayer__3:GetAttribute("MG_Name");
    if u42 then
        u42 = u42 ~= "Ground War";
    end;
    local l__CurrentCamera__22 = workspace.CurrentCamera;
    local _, v52 = pcall(function() --[[ Line: 225 ]]
        -- upvalues: u1 (copy), u15 (copy), l__CurrentCamera__22 (copy), u42 (copy)
        local v43 = script.Parent.AbsoluteSize / 2;
        for _, v44 in u1 do
            u15(v44.UI, v44.Model);
            local v45 = l__CurrentCamera__22:WorldToScreenPoint(v44.Model.TouchPart.Position);
            local v46 = Vector2.new(v45.X, v45.Y).X - v43.X;
            local v47 = math.abs(v46);
            if v47 < 60 then
                local l__UI__23 = v44.UI;
                local v48 = math.max(0, 0);
                local v49 = math.min(v48, 0.5);
                l__UI__23.Distance.TextTransparency = v48;
                l__UI__23.HardpointName.TextTransparency = v48;
                l__UI__23.HardpointFrame.Square.Backing.BackgroundTransparency = v49;
                l__UI__23.HardpointFrame.Square.Fill.BackgroundTransparency = v49;
                l__UI__23.HardpointFrame.Square.Phoenetic.TextTransparency = v49;
                l__UI__23.Distance.Visible = v48 < 0.1;
                l__UI__23.HardpointName.Visible = v48 < 0.1;
            else
                local l__UI__24 = v44.UI;
                local v50 = math.max((v47 - 60) / 100, 0);
                local v51 = math.min(v50, 0.5);
                l__UI__24.Distance.TextTransparency = v50;
                l__UI__24.HardpointName.TextTransparency = v50;
                l__UI__24.HardpointFrame.Square.Backing.BackgroundTransparency = v51;
                l__UI__24.HardpointFrame.Square.Fill.BackgroundTransparency = v51;
                l__UI__24.HardpointFrame.Square.Phoenetic.TextTransparency = v51;
                l__UI__24.Distance.Visible = v50 < 0.1;
                l__UI__24.HardpointName.Visible = v50 < 0.1;
            end;
            v44.UI.Enabled = not u42;
        end;
    end);
    if v52 then
        warn(v52);
    end;
end;