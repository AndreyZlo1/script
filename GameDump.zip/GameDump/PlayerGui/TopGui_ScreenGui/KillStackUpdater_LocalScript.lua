-- Roblox: Players.SilverAce293026.PlayerGui.TopGui.KillStackUpdater
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__LocalPlayer__1 = game:GetService("Players").LocalPlayer;
local l__TweenService__2 = game:GetService("TweenService");
local l__ReplicatedStorage__3 = game:GetService("ReplicatedStorage");
local l__KillEvent__4 = l__ReplicatedStorage__3:WaitForChild("GameplayEvents"):WaitForChild("KillEvent");
local l__AttachmentsEnabled__5 = require(l__ReplicatedStorage__3:WaitForChild("ReplicatedConfig")).FeatureToggles.AttachmentsEnabled;
l__LocalPlayer__1:WaitForChild("leaderstats");
local l__RunService__6 = game:GetService("RunService");
local l__KillStack__7 = script.Parent:WaitForChild("KillStack");
local l__MoneyCount__8 = l__KillStack__7:WaitForChild("MoneyCount");
local l__ExpCount__9 = l__KillStack__7:WaitForChild("ExpCount");
if not l__AttachmentsEnabled__5 then
    l__ExpCount__9:Destroy();
end;
local l__StackArea__10 = l__KillStack__7:WaitForChild("StackArea");
local l__ProtoStack__11 = l__StackArea__10:WaitForChild("ProtoStack");
local l__KillSound__12 = script:WaitForChild("KillSound");
local u1 = 0;
local u2 = 0;
local u3 = 0;
local u4 = 0;
local u5 = 0;
local u6 = true;
local v7 = UDim2.new(0.8, 0, 0.2, 0);
local u8 = UDim2.new(1.2, 0, 0.3, 0);
local v9 = TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local v10 = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local u11 = l__TweenService__2:Create(l__MoneyCount__8, v9, {
    TextTransparency = 1
});
local u12 = l__TweenService__2:Create(l__MoneyCount__8, v10, {
    Size = v7
});
local u13, u14;
if l__AttachmentsEnabled__5 then
    u13 = l__TweenService__2:Create(l__ExpCount__9, v9, {
        TextTransparency = 1
    });
    u14 = l__TweenService__2:Create(l__ExpCount__9, v10, {
        Size = v7
    });
else
    u14 = nil;
    u13 = nil;
end;
local u15 = TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
local function u27(p16, p17) --[[ Line: 73 ]]
    -- upvalues: u5 (ref), l__ProtoStack__11 (copy), l__StackArea__10 (copy), l__TweenService__2 (copy), u15 (copy)
    u5 = u5 + 1;
    local u18 = l__ProtoStack__11:Clone();
    u18.Name = "NewStack";
    u18.LayoutOrder = -u5;
    u18.Size = UDim2.new(1, 0, 0.2 + 0.2 * (p17 and (#p17 or 0) or 0), 0);
    u18.VictimLabel.Text = "killed " .. p16;
    local l__ConditionProto__13 = u18:WaitForChild("ConditionProto");
    table.sort(p17, function(p19, p20) --[[ Line: 87 ]]
        return p19.exp > p20.exp;
    end);
    for _, v21 in p17 do
        local l__name__14 = v21.name;
        local v22 = string.sub(l__name__14, 1, 1);
        local v23 = string.sub(l__name__14, 2);
        local v24 = string.upper(v22) .. v23;
        local v25 = l__ConditionProto__13:Clone();
        local l__exp__15 = v21.exp;
        v25.Visible = true;
        v25.Parent = u18;
        v25.Text = "<b>" .. v24 .. ":</b> +" .. l__exp__15 .. " XP";
    end;
    u18.Parent = l__StackArea__10;
    u18.Visible = true;
    local u26 = l__TweenService__2:Create(u18, u15, {
        GroupTransparency = 1
    });
    task.delay(3, function() --[[ Line: 107 ]]
        -- upvalues: u26 (copy), u18 (copy)
        u26:Play();
        task.wait(1);
        u18:Destroy();
    end);
end;
l__KillEvent__4.OnClientEvent:Connect(function(p28, p29, p30, p31) --[[ Name: onKillEvent, Line 157 ]]
    -- upvalues: u12 (copy), u11 (copy), l__AttachmentsEnabled__5 (copy), u14 (ref), u13 (ref), l__MoneyCount__8 (copy), l__ExpCount__9 (copy), u4 (ref), l__KillStack__7 (copy), u6 (ref), u3 (ref), u1 (ref), u2 (ref), u27 (copy), u8 (copy), l__KillSound__12 (copy)
    u12:Cancel();
    u11:Cancel();
    if l__AttachmentsEnabled__5 then
        u14:Cancel();
        u13:Cancel();
    end;
    l__MoneyCount__8.TextTransparency = 0;
    if l__AttachmentsEnabled__5 then
        l__ExpCount__9.TextTransparency = 0;
    end;
    u4 = u4 + 1;
    l__KillStack__7.Visible = true;
    u6 = false;
    u3 = tick();
    u1 = u1 + p29;
    if l__AttachmentsEnabled__5 then
        u2 = u2 + p30;
    end;
    u27(p28, p31);
    l__MoneyCount__8.Text = "+" .. u1 .. "$";
    if l__AttachmentsEnabled__5 then
        l__ExpCount__9.Text = "+" .. u2 .. " XP";
    end;
    u12:Cancel();
    l__MoneyCount__8.Size = u8;
    u12:Play();
    if l__AttachmentsEnabled__5 then
        u14:Cancel();
        l__ExpCount__9.Size = u8;
        u14:Play();
    end;
    l__KillSound__12.PlayOnRemove = true;
    l__KillSound__12.Parent = nil;
    l__KillSound__12.Parent = script;
    l__KillSound__12.PlayOnRemove = false;
end);
l__RunService__6.RenderStepped:Connect(function() --[[ Line: 183 ]]
    -- upvalues: u6 (ref), u3 (ref), u12 (copy), u11 (copy), l__AttachmentsEnabled__5 (copy), u14 (ref), u13 (ref), l__MoneyCount__8 (copy), l__ExpCount__9 (copy), u1 (ref), u2 (ref), l__KillStack__7 (copy), u4 (ref)
    if u6 then
    else
        if tick() - u3 >= 3 then
            u6 = true;
            u12:Cancel();
            u11:Cancel();
            if l__AttachmentsEnabled__5 then
                u14:Cancel();
                u13:Cancel();
            end;
            l__MoneyCount__8.TextTransparency = 0;
            if l__AttachmentsEnabled__5 then
                l__ExpCount__9.TextTransparency = 0;
            end;
            u11:Play();
            if l__AttachmentsEnabled__5 then
                u13:Play();
            end;
            task.wait(0.4);
            if u6 then
                u1 = 0;
                l__MoneyCount__8.Text = "+0$";
                if l__AttachmentsEnabled__5 then
                    u2 = 0;
                    l__ExpCount__9.Text = "+0 XP";
                end;
                l__KillStack__7.Visible = false;
                u4 = 0;
            end;
        end;
    end;
end);