-- Roblox: Players.SilverAce293026.PlayerGui.QuestGui.QuestGuiModule
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__TweenService__1 = game:GetService("TweenService");
local l__PlayerGui__2 = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui");
local v2 = TweenInfo.new(1, Enum.EasingStyle.Quint, Enum.EasingDirection.Out);
local l__Container__3 = script.Parent:WaitForChild("Container");
local l__Content__4 = l__Container__3:WaitForChild("Background"):WaitForChild("Content");
local l__Title__5 = l__Content__4:WaitForChild("Title");
local l__Desc__6 = l__Content__4:WaitForChild("Desc");
local l__Reward__7 = l__Content__4:WaitForChild("Reward");
local l__Step__8 = l__Content__4:WaitForChild("Step");
local l__ImageLabel__9 = l__Content__4:WaitForChild("ImageLabel");
local u3 = {
    Show = l__TweenService__1:Create(l__Container__3, v2, {
        GroupTransparency = 0,
        Position = UDim2.new(1, 10, 0.5, 0)
    }),
    Hide = l__TweenService__1:Create(l__Container__3, v2, {
        GroupTransparency = 1,
        Position = UDim2.new(1.2, 10, 0.5, 0)
    })
};
function v1.Set(p4, p5) --[[ Line: 41 ]]
    -- upvalues: l__Title__5 (copy), l__Reward__7 (copy), l__ImageLabel__9 (copy), l__Step__8 (copy), l__Desc__6 (copy), l__PlayerGui__2 (copy), u3 (copy)
    l__Title__5.Text = p4.Title;
    l__Reward__7.Text = string.format("Reward: %s", p4.Reward.Text);
    l__ImageLabel__9.Image = p4.Reward.Image;
    l__Step__8.Text = string.format("Step %s/%s", p5, #p4.Steps);
    local v6 = p4.Steps[p5];
    if v6 then
        l__Desc__6.Text = v6.Desc;
        repeat
            task.wait(0.1);
        until not l__PlayerGui__2:FindFirstChild("TutorialGui");
        u3.Show:Play();
    else
        warn("Invalid step", p5, "on quest", p4.Title);
    end;
end;
function v1.Clear() --[[ Line: 61 ]]
    -- upvalues: u3 (copy)
    u3.Hide:Play();
end;
return v1;