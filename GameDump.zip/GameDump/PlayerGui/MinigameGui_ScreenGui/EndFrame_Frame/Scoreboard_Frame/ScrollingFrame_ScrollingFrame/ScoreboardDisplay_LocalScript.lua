-- Roblox: Players.SilverAce293026.PlayerGui.MinigameGui.EndFrame.Scoreboard.ScrollingFrame.ScoreboardDisplay
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Players__2 = game:GetService("Players");
local l__MinigameEvent__3 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents"):WaitForChild("MinigameEvent");
local l__Parent__4 = script.Parent;
local l__Prototype__5 = l__Parent__4:WaitForChild("Prototype");
local function u2() --[[ Line: 12 ]]
    -- upvalues: l__Parent__4 (copy), l__Prototype__5 (copy)
    for _, v1 in l__Parent__4:GetChildren() do
        if v1:IsA("Frame") and v1 ~= l__Prototype__5 then
            v1:Destroy();
        end;
    end;
end;
local function u12(p3) --[[ Line: 20 ]]
    -- upvalues: l__Prototype__5 (copy), l__Players__2 (copy)
    local v4 = p3:GetAttribute("MG_Team");
    local v5 = p3:GetAttribute("MG_Stat_Kills") or 0;
    local v6 = p3:GetAttribute("MG_Stat_Deaths") or 0;
    local v7 = v5 / (v6 == 0 and 1 or v6);
    local v8 = v4 == "Blue" and Color3.fromRGB(0, 0, 255) or Color3.fromRGB(255, 0, 0);
    local v9 = string.format("%.2f", v7);
    local v10 = math.round(v7 * 100);
    local v11 = l__Prototype__5:Clone();
    v11.Name = p3.Name;
    v11.LayoutOrder = -v10;
    v11.BackgroundColor3 = v8;
    v11.HIcon.Image = l__Players__2:GetUserThumbnailAsync(p3.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size100x100);
    v11.HName.Text = p3.Name;
    v11.HKills.Text = v5;
    v11.HDeaths.Text = v6;
    v11.HKDR.Text = v9;
    return v11;
end;
local function u15() --[[ Line: 46 ]]
    -- upvalues: u2 (copy), l__Players__2 (copy), u12 (copy), l__Parent__4 (copy)
    u2();
    for _, u13 in l__Players__2:GetChildren() do
        task.spawn(function() --[[ Line: 49 ]]
            -- upvalues: u13 (copy), u12 (ref), l__Parent__4 (ref)
            if u13:GetAttribute("MG_Name") then
                local v14 = u12(u13);
                v14.Parent = l__Parent__4;
                v14.Visible = true;
            end;
        end);
    end;
end;
l__MinigameEvent__3.OnClientEvent:Connect(function(p16) --[[ Line: 58 ]]
    -- upvalues: u15 (copy)
    if p16 == "GameEnded" then
        u15();
    end;
end);