-- Roblox: Players.SilverAce293026.PlayerGui.MinigameGui.MinigameUI
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
local l__StarterGui__1 = game:GetService("StarterGui");
local l__RunService__2 = game:GetService("RunService");
local l__TweenService__3 = game:GetService("TweenService");
local l__Players__4 = game:GetService("Players");
local l__LocalPlayer__5 = l__Players__4.LocalPlayer;
local u2 = TweenInfo.new(1.25, Enum.EasingStyle.Quint, Enum.EasingDirection.Out);
local l__ContentArea__6 = script.Parent:WaitForChild("ContentArea");
local u3 = {
    TeamFrame = l__ContentArea__6:WaitForChild("Teams"),
    CountdownLabel = l__ContentArea__6:WaitForChild("Countdown"),
    Heading = l__ContentArea__6:WaitForChild("Heading"),
    Objectives = l__ContentArea__6:WaitForChild("Objectives"),
    Remaining = l__ContentArea__6:WaitForChild("Remaining"),
    NotifStack = l__ContentArea__6:WaitForChild("NotificationStack"),
    Players = l__ContentArea__6:WaitForChild("Players")
};
local u4 = {};
local l__EndText__7 = l__ContentArea__6:WaitForChild("EndText");
local l__BoundsText__8 = script.Parent:WaitForChild("BoundsText");
local l__EndFrameUI__9 = require(script:WaitForChild("EndFrameUI"));
local l__Prototype__10 = u3.NotifStack:WaitForChild("Prototype");
function u1.SetActiveElements(p5) --[[ Line: 32 ]]
    -- upvalues: u3 (copy), u4 (copy)
    local v6 = p5 or {};
    for v7, v8 in u3 do
        v8.Visible = table.find(v6, v8.Name);
        if not v8.Visible and u4[v7] then
            u4[v7]();
        end;
    end;
end;
local l__Prototype__11 = u3.Players:WaitForChild("Prototype");
function u1.SetPlayers(p9) --[[ Line: 44 ]]
    -- upvalues: u3 (copy), l__Prototype__11 (copy), l__Players__4 (copy), l__LocalPlayer__5 (copy)
    local v10 = {};
    for _, v11 in u3.Players:GetChildren() do
        if v11:IsA("Frame") and v11 ~= l__Prototype__11 then
            v10[v11.Name] = v11;
        end;
    end;
    for v12, v13 in v10 do
        if not p9[v12] then
            v13:Destroy();
        end;
    end;
    for v14, _ in p9 do
        if not v10[v14] then
            local v15 = l__Players__4:FindFirstChild(v14);
            if v15 then
                local v16 = l__Prototype__11:Clone();
                v16.Name = v14;
                v16.ImageLabel.Image = l__Players__4:GetUserThumbnailAsync(v15.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size180x180);
                v16.Parent = u3.Players;
            end;
        end;
    end;
    for v17, v18 in p9 do
        local v19 = u3.Players:FindFirstChild(v17);
        if v19 then
            v19.TextLabel.Text = v18;
            if v17 == l__LocalPlayer__5.Name then
                v19.BackgroundColor3 = Color3.fromRGB(255, 170, 0);
            end;
            v19.LayoutOrder = -v18;
        end;
    end;
    local v20 = {};
    for _, v21 in u3.Players:GetChildren() do
        if v21:IsA("Frame") and v21 ~= l__Prototype__11 then
            table.insert(v20, v21);
        end;
    end;
    table.sort(v20, function(p22, p23) --[[ Line: 101 ]]
        return p22.LayoutOrder < p23.LayoutOrder;
    end);
    for v24 = 1, #v20 do
        v20[v24].Visible = v24 <= 8;
    end;
    local v25 = {};
    for _, v26 in u3.Players:GetChildren() do
        if v26:IsA("Frame") and v26 ~= l__Prototype__11 then
            if v25[v26.Name] then
                v26:Destroy();
            else
                v25[v26.Name] = true;
            end;
        end;
    end;
end;
function u1.SetBoundsText(u27) --[[ Line: 125 ]]
    -- upvalues: l__TweenService__3 (copy), l__BoundsText__8 (copy), u2 (copy)
    local v28 = UDim2.new(0.5, 0, 0.06, 0);
    local v29 = UDim2.new(0, 0, 0.06, 0);
    if u27 then
        v29 = v28 or v29;
    end;
    local u30 = l__TweenService__3:Create(l__BoundsText__8, u2, {
        Size = v29
    });
    local u31 = l__TweenService__3:Create(l__BoundsText__8, u2, {
        TextTransparency = u27 and 0 or 1
    });
    local function v33(p32) --[[ Line: 140 ]]
        -- upvalues: u27 (copy), u31 (copy), u30 (copy)
        if p32 == Enum.PlaybackState.Completed then
            if u27 then
                u31:Play();
            else
                u30:Play();
            end;
        end;
    end;
    if u27 then
        u30.Completed:Connect(v33);
        u30:Play();
    else
        u31.Completed:Connect(v33);
        u31:Play();
    end;
end;
local function u37() --[[ Line: 159 ]]
    -- upvalues: u3 (copy), l__LocalPlayer__5 (copy)
    local l__Blue__12 = u3.TeamFrame.Blue;
    local l__Red__13 = u3.TeamFrame.Red;
    local v34 = l__LocalPlayer__5:GetAttribute("MG_Team");
    if v34 then
        for _, v35 in { l__Blue__12, l__Red__13 } do
            local v36 = v35.Name == "Red" and "Bravo" or "Alpha";
            if v35.Name == v34 then
                v35.NameLabel.Text = string.format("%s <b><font color=\'rgb(255,150,0)\'>(You)</font></b>", v36);
            else
                v35.NameLabel.Text = v36;
            end;
        end;
    end;
end;
function u1.UpdateTeams(p38, p39, p40) --[[ Line: 177 ]]
    -- upvalues: u3 (copy), u37 (copy)
    u3.TeamFrame.Target.Label.Text = p38;
    local l__Blue__14 = u3.TeamFrame.Blue;
    local l__Red__15 = u3.TeamFrame.Red;
    l__Blue__14.ProgressLabel.Text = math.floor(p39);
    l__Red__15.ProgressLabel.Text = math.floor(p40);
    l__Blue__14.Progress.Size = UDim2.new(p39 / p38, 0, 0.2, 0);
    l__Red__15.Progress.Size = UDim2.new(p40 / p38, 0, 0.2, 0);
    u37();
end;
l__LocalPlayer__5:GetAttributeChangedSignal("MG_Team"):Connect(u37);
local u41 = 0;
coroutine.wrap(function() --[[ Line: 197 ]]
    -- upvalues: u3 (copy), u41 (ref)
    while true do
        repeat
            task.wait(0.1);
        until u3.CountdownLabel.Visible and u41 > os.time();
        local v42 = u41 - os.time();
        local v43 = math.floor(v42 / 60);
        local v44 = string.format("%02d:%02d", v43, v42 % 60);
        u3.CountdownLabel.Text = v44;
    end;
end)();
function u1.SetCountdownGoal(p45) --[[ Line: 212 ]]
    -- upvalues: u41 (ref)
    u41 = p45;
end;
local l__Proto__16 = u3.Objectives:WaitForChild("Proto");
function u1.ClearObjectives() --[[ Line: 218 ]]
    -- upvalues: u3 (copy), l__Proto__16 (copy)
    for _, v46 in u3.Objectives:GetChildren() do
        if v46:IsA("Frame") and v46 ~= l__Proto__16 then
            v46:Destroy();
        end;
    end;
end;
local u47 = {};
function u1.SetObjectives(...) --[[ Line: 227 ]]
    -- upvalues: u1 (copy), l__Proto__16 (copy), u3 (copy), u47 (copy)
    u1.ClearObjectives();
    for _, v48 in { ... } do
        local v49 = string.upper((string.sub(v48, 1, 1)));
        local v50 = l__Proto__16:Clone();
        v50.Label.Text = v49;
        v50.Name = v48;
        v50.Parent = u3.Objectives;
        v50.Visible = true;
        u47[v48] = v50;
    end;
end;
function u1.SetObjectiveColor(p51, p52) --[[ Line: 242 ]]
    -- upvalues: u47 (copy)
    if u47[p51] then
        u47[p51].BorderColor3 = p52;
        u47[p51].Label.TextColor3 = p52;
    end;
end;
function u1.SetHeading(p53) --[[ Line: 249 ]]
    -- upvalues: u3 (copy)
    u3.Heading.Text = p53;
end;
function u1.SetRemaining(p54) --[[ Line: 254 ]]
    -- upvalues: u3 (copy)
    u3.Remaining.Text = p54;
end;
local u55 = {
    Frame = script.Parent:WaitForChild("SpectateControls")
};
u55.ButtonsFrame = u55.Frame:WaitForChild("Buttons");
u55.PreviousBtn = u55.ButtonsFrame:WaitForChild("Previous"):WaitForChild("ButtonFrame"):WaitForChild("Button");
u55.NextBtn = u55.ButtonsFrame:WaitForChild("Next"):WaitForChild("ButtonFrame"):WaitForChild("Button");
u55.Username = u55.Frame:WaitForChild("Username");
local u56 = false;
local u57 = {};
local u58 = {};
local u59 = 1;
function u1.SetSpectateables(p60) --[[ Line: 290 ]]
    -- upvalues: u58 (ref), u56 (ref), u59 (ref), u55 (copy), u3 (copy)
    local v61 = table.find(p60, game.Players.LocalPlayer);
    if v61 then
        table.remove(p60, v61);
    end;
    u58 = p60;
    if u56 then
        if not u56 then
            return;
        end;
        if #u58 == 0 then
            return;
        end;
        if u59 > #u58 and u59 == 1 then
            return;
        end;
        if u59 > #u58 then
            u59 = 1;
        elseif u59 < 1 then
            u59 = #u58;
        end;
        u55.Username.Text = u58[u59].Name;
        u3.Remaining.Visible = false;
    end;
end;
function u1.StartSpectating() --[[ Line: 302 ]]
    -- upvalues: u56 (ref), u59 (ref), u58 (ref), u55 (copy), u3 (copy), u57 (ref), l__RunService__2 (copy), l__StarterGui__1 (copy)
    if u56 then
    else
        u56 = true;
        u59 = 1;
        if u56 and (#u58 ~= 0 and (u59 <= #u58 or u59 ~= 1)) then
            if u59 > #u58 then
                u59 = 1;
            elseif u59 < 1 then
                u59 = #u58;
            end;
            u55.Username.Text = u58[u59].Name;
            u3.Remaining.Visible = false;
        end;
        u55.NextBtn.Activated:Connect(function() --[[ Line: 313 ]]
            -- upvalues: u59 (ref), u56 (ref), u58 (ref), u55 (ref), u3 (ref)
            u59 = u59 + 1;
            if u56 then
                if #u58 == 0 then
                elseif u59 > #u58 and u59 == 1 then
                else
                    if u59 > #u58 then
                        u59 = 1;
                    elseif u59 < 1 then
                        u59 = #u58;
                    end;
                    u55.Username.Text = u58[u59].Name;
                    u3.Remaining.Visible = false;
                end;
            end;
        end);
        u55.PreviousBtn.Activated:Connect(function() --[[ Line: 317 ]]
            -- upvalues: u59 (ref), u56 (ref), u58 (ref), u55 (ref), u3 (ref)
            u59 = u59 + -1;
            if u56 then
                if #u58 == 0 then
                elseif u59 > #u58 and u59 == 1 then
                else
                    if u59 > #u58 then
                        u59 = 1;
                    elseif u59 < 1 then
                        u59 = #u58;
                    end;
                    u55.Username.Text = u58[u59].Name;
                    u3.Remaining.Visible = false;
                end;
            end;
        end);
        table.insert(u57, l__RunService__2.RenderStepped:Connect(function() --[[ Line: 321 ]]
            -- upvalues: u58 (ref), u59 (ref)
            local v62 = u58[u59];
            if v62 then
                local l__Character__17 = v62.Character;
                if l__Character__17 then
                    local l__CurrentCamera__18 = workspace.CurrentCamera;
                    local v63 = l__Character__17:FindFirstChild("Humanoid");
                    if v63 then
                        l__CurrentCamera__18.CameraType = Enum.CameraType.Custom;
                        l__CurrentCamera__18.CameraSubject = v63;
                    end;
                end;
            end;
        end));
        u55.Frame.Visible = true;
        pcall(function() --[[ Line: 337 ]]
            -- upvalues: l__StarterGui__1 (ref)
            l__StarterGui__1:SetCore("ResetButtonCallBack", false);
        end);
    end;
end;
function u1.StopSpectating() --[[ Line: 342 ]]
    -- upvalues: u56 (ref), u55 (copy), u57 (ref), u58 (ref), l__StarterGui__1 (copy)
    if u56 then
        u55.Frame.Visible = false;
        for _, v64 in u57 do
            v64:Disconnect();
        end;
        u58 = {};
        u57 = {};
        u56 = false;
        pcall(function() --[[ Line: 351 ]]
            -- upvalues: l__StarterGui__1 (ref)
            l__StarterGui__1:SetCore("ResetButtonCallBack", true);
        end);
    end;
end;
function u1.ShowEndText(p65) --[[ Line: 357 ]]
    -- upvalues: l__EndText__7 (copy)
    l__EndText__7.Visible = true;
    l__EndText__7.Text = p65;
    task.delay(10, function() --[[ Line: 360 ]]
        -- upvalues: l__EndText__7 (ref)
        l__EndText__7.Visible = false;
    end);
end;
function u1.RunEndGameUI(p66, p67) --[[ Line: 366 ]]
    -- upvalues: l__EndFrameUI__9 (copy)
    script.Parent.DisplayOrder = 99999999;
    l__EndFrameUI__9.Set(p66, p67);
    l__EndFrameUI__9.Run();
    task.delay(3, function() --[[ Line: 370 ]]
        script.Parent.DisplayOrder = 0;
    end);
end;
function u1.HideEndGameUI() --[[ Line: 375 ]]
    -- upvalues: l__EndFrameUI__9 (copy)
    l__EndFrameUI__9.Hide();
end;
local u68 = 0;
function u1.CreateNotification(p69) --[[ Line: 381 ]]
    -- upvalues: u3 (copy), l__Prototype__10 (copy), u68 (ref)
    local v70 = {};
    for _, v71 in u3.NotifStack:GetChildren() do
        if v71:IsA("TextLabel") and v71 ~= l__Prototype__10 then
            table.insert(v70, v71);
        end;
    end;
    table.sort(v70, function(p72, p73) --[[ Line: 387 ]]
        return p72.LayoutOrder < p73.LayoutOrder;
    end);
    for v74, v75 in v70 do
        v75.TextTransparency = v74 / 4;
    end;
    local u76 = l__Prototype__10:Clone();
    u76.Text = p69;
    u76.LayoutOrder = -u68;
    u68 = u68 + 1;
    u76.Visible = true;
    u76.Parent = u3.NotifStack;
    task.delay(5, function() --[[ Line: 402 ]]
        -- upvalues: u76 (copy)
        u76:Destroy();
    end);
end;
return u1;