-- Roblox: Players.SilverAce293026.PlayerGui.MinigameGui.MinigameUI.EndFrameUI
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__EndFrame__1 = script.Parent.Parent:WaitForChild("EndFrame");
local l__EndText__2 = l__EndFrame__1:WaitForChild("EndText");
l__EndFrame__1:WaitForChild("Timer");
local l__Navbar__3 = l__EndFrame__1:WaitForChild("Navbar");
local l__Highlights__4 = l__EndFrame__1:WaitForChild("Highlights");
local l__Scoreboard__5 = l__EndFrame__1:WaitForChild("Scoreboard");
local l__TweenService__6 = game:GetService("TweenService");
local l__Players__7 = game:GetService("Players");
local l__ReplicatedStorage__8 = game:GetService("ReplicatedStorage");
local l__Modules__9 = l__ReplicatedStorage__8:WaitForChild("Modules");
require(l__Modules__9:WaitForChild("GuiModule"));
local l__LocalPlayer__10 = l__Players__7.LocalPlayer;
local l__FadeGui__11 = l__LocalPlayer__10:WaitForChild("PlayerGui"):WaitForChild("FadeGui");
local l__FadeModule__12 = require(l__FadeGui__11:WaitForChild("FadeModule"));
local u2 = TweenInfo.new(1.2, Enum.EasingStyle.Quint, Enum.EasingDirection.Out);
TweenInfo.new(0.4, Enum.EasingStyle.Quint, Enum.EasingDirection.In);
local u3 = TweenInfo.new(0.4, Enum.EasingStyle.Quint, Enum.EasingDirection.Out);
local function u4() --[[ Line: 27 ]]
    -- upvalues: l__EndFrame__1 (copy), l__Scoreboard__5 (copy), l__Highlights__4 (copy), l__Navbar__3 (copy), l__EndText__2 (copy)
    l__EndFrame__1.Visible = false;
    l__Scoreboard__5.Visible = false;
    l__Highlights__4.Visible = false;
    l__Navbar__3.Visible = false;
    l__EndText__2.Visible = false;
    l__EndText__2.UIGradient.Offset = Vector2.new(0, -1);
    l__EndText__2.Position = UDim2.new(0.5, 0, 0.5, 0);
    l__Navbar__3.Buttons.GroupTransparency = 1;
    l__Navbar__3.Buttons.Highlights.SelectionHighlight.Visible = true;
    l__Navbar__3.Buttons.Highlights.SELECT.UIGradient.Enabled = true;
    l__Navbar__3.Buttons.Scoreboard.SelectionHighlight.Visible = false;
    l__Navbar__3.Buttons.Scoreboard.SELECT.UIGradient.Enabled = false;
end;
local function u15(p5) --[[ Line: 46 ]]
    -- upvalues: l__TweenService__6 (copy), u3 (copy)
    local v6 = p5.Name == "Middle" and UDim2.new(0.3, 0, 1, 0) or UDim2.new(0.3, 0, 0.9, 0);
    p5.Size = UDim2.new(0.3, 0, 0, 0);
    p5.Player.MaxVisibleGraphemes = 0;
    p5.Reason.MaxVisibleGraphemes = 0;
    p5.Title.MaxVisibleGraphemes = 0;
    p5.Reason.Size = UDim2.new(0, 0, 0.05, 0);
    local l__BackgroundColor3__13 = p5.BackgroundColor3;
    p5.BackgroundColor3 = Color3.fromRGB(255, 255, 255);
    p5.UIGradient.Offset = Vector2.new(0, 1);
    p5.PlayerDisplay.ImageTransparency = 1;
    local v7 = l__TweenService__6:Create(p5, u3, {
        Size = v6
    });
    local u8 = l__TweenService__6:Create(p5, u3, {
        BackgroundColor3 = l__BackgroundColor3__13
    });
    local u9 = l__TweenService__6:Create(p5.UIGradient, u3, {
        Offset = Vector2.new(0, 0)
    });
    local u10 = l__TweenService__6:Create(p5.Title, u3, {
        MaxVisibleGraphemes = #p5.Title.Text
    });
    local u11 = l__TweenService__6:Create(p5.Reason, u3, {
        Size = UDim2.new(0.8, 0, 0.05, 0)
    });
    local u12 = l__TweenService__6:Create(p5.Reason, u3, {
        MaxVisibleGraphemes = #p5.Reason.Text
    });
    local u13 = l__TweenService__6:Create(p5.Player, u3, {
        MaxVisibleGraphemes = #p5.Player.Text
    });
    local u14 = l__TweenService__6:Create(p5.PlayerDisplay, u3, {
        ImageTransparency = 0
    });
    v7.Completed:Connect(function() --[[ Line: 89 ]]
        -- upvalues: u8 (copy), u9 (copy)
        u8:Play();
        u9:Play();
    end);
    u9.Completed:Connect(function() --[[ Line: 94 ]]
        -- upvalues: u10 (copy)
        u10:Play();
    end);
    u10.Completed:Connect(function() --[[ Line: 98 ]]
        -- upvalues: u11 (copy)
        u11:Play();
    end);
    u11.Completed:Connect(function() --[[ Line: 102 ]]
        -- upvalues: u12 (copy)
        u12:Play();
    end);
    u12.Completed:Connect(function() --[[ Line: 106 ]]
        -- upvalues: u13 (copy), u14 (copy)
        u13:Play();
        u14:Play();
    end);
    return v7, u13;
end;
function v1.Run() --[[ Line: 114 ]]
    -- upvalues: u4 (copy), l__EndText__2 (copy), l__TweenService__6 (copy), u2 (copy), l__Navbar__3 (copy), u3 (copy), u15 (copy), l__Highlights__4 (copy), l__FadeModule__12 (copy), l__EndFrame__1 (copy)
    u4();
    l__EndText__2.Visible = true;
    local v16 = l__TweenService__6:Create(l__EndText__2.UIGradient, u2, {
        Offset = Vector2.new(0, 1)
    });
    local u17 = l__TweenService__6:Create(l__EndText__2, u2, {
        Position = UDim2.new(0.5, 0, 0.09, 0)
    });
    local u18 = {};
    for _, v19 in { l__Navbar__3.TopLine, l__Navbar__3.BottomLine } do
        v19.Size = UDim2.new(0, 0, 0.05, 0);
        local v20 = l__TweenService__6;
        local v21 = u3;
        local v22 = {
            Size = UDim2.new(1, 0, 0.05, 0)
        };
        table.insert(u18, v20:Create(v19, v21, v22));
    end;
    local u23 = l__TweenService__6:Create(l__Navbar__3.Buttons, u3, {
        GroupTransparency = 0
    });
    local u24 = {};
    local u25, v26 = u15(l__Highlights__4.Middle);
    v26.Completed:Connect(function() --[[ Line: 140 ]]
        -- upvalues: u24 (ref)
        u24[1]:Play();
    end);
    local v27, v28 = u15(l__Highlights__4.Left);
    local u29, v30 = u15(l__Highlights__4.Right);
    l__Highlights__4.Visible = true;
    u24 = { v27, u29 };
    v28.Completed:Connect(function() --[[ Line: 150 ]]
        -- upvalues: u29 (copy)
        u29:Play();
    end);
    v16.Completed:Connect(function() --[[ Line: 154 ]]
        -- upvalues: u17 (copy), l__FadeModule__12 (ref)
        u17:Play();
        l__FadeModule__12.FadeAsync(false);
    end);
    u17.Completed:Connect(function() --[[ Line: 159 ]]
        -- upvalues: l__Navbar__3 (ref), u18 (copy)
        l__Navbar__3.Visible = true;
        u18[2]:Play();
    end);
    u18[2].Completed:Connect(function() --[[ Line: 164 ]]
        -- upvalues: u25 (copy)
        u25:Play();
    end);
    v30.Completed:Connect(function() --[[ Line: 168 ]]
        -- upvalues: u18 (copy)
        u18[1]:Play();
    end);
    u18[1].Completed:Connect(function() --[[ Line: 172 ]]
        -- upvalues: u23 (copy)
        u23:Play();
    end);
    l__EndFrame__1.Visible = true;
    v16:Play();
end;
local function u41(p31, p32, _) --[[ Line: 180 ]]
    -- upvalues: l__Players__7 (copy), l__ReplicatedStorage__8 (copy)
    local l__Name__14 = p32.Player.Name;
    local v33 = p32.Player:GetAttribute("MG_Team") == "Blue" and Color3.fromRGB(99, 141, 255) or Color3.fromRGB(234, 94, 76);
    p31.Player.Text = l__Name__14;
    p31.BackgroundColor3 = v33;
    p31.Reason.Text = p32.Reason;
    p31.Title.Text = p32.Title;
    local l__PlayerDisplay__15 = p31.PlayerDisplay;
    l__PlayerDisplay__15:ClearAllChildren();
    if l__PlayerDisplay__15.CurrentCamera then
        l__PlayerDisplay__15.CurrentCamera:Destroy();
    end;
    local v34 = Instance.new("Camera", script);
    l__PlayerDisplay__15.CurrentCamera = v34;
    local v35;
    if game:GetService("RunService"):IsStudio() then
        v35 = nil;
    else
        v35 = l__Players__7:GetHumanoidDescriptionFromUserId(p32.Player.UserId);
    end;
    local v36 = Instance.new("WorldModel");
    v36.Parent = l__PlayerDisplay__15;
    local v37 = l__ReplicatedStorage__8:WaitForChild("LoadoutRig"):Clone();
    v37.Parent = v36;
    if v35 then
        v37.Humanoid:ApplyDescription(v35);
    end;
    v37:PivotTo(CFrame.new());
    local v38 = Instance.new("Part");
    v38.Size = Vector3.new(100, 0.1, 100);
    v38.Transparency = 1;
    v38.CFrame = v37.HumanoidRootPart.CFrame * CFrame.new(0, -2, 0);
    v38.Anchored = true;
    v38.Parent = v36;
    v34.CFrame = CFrame.new((CFrame.new(v37.PrimaryPart.Position) * CFrame.new(Vector3.new(0, 1, -5))).Position, v37.PrimaryPart.Position);
    if v35 then
        v37.PrimaryPart.Anchored = false;
        local l__Humanoid__16 = v37.Humanoid;
        local v39 = Instance.new("Animation", l__PlayerDisplay__15);
        local l__IdleAnimation__17 = v35.IdleAnimation;
        v39.AnimationId = "rbxassetid://" .. (l__IdleAnimation__17 == 0 and 507766388 or l__IdleAnimation__17);
        local v40 = l__Humanoid__16:LoadAnimation(v39);
        v40.Looped = true;
        v40:Play();
    end;
end;
function v1.Set(p42, p43) --[[ Line: 242 ]]
    -- upvalues: u41 (copy), l__Highlights__4 (copy), l__EndText__2 (copy), l__LocalPlayer__10 (copy)
    local v44 = false;
    for _, v45 in p42 do
        if v45.Title == "MVP" then
            u41(l__Highlights__4.Middle, v45, 0);
        elseif v44 then
            u41(l__Highlights__4.Right, v45, -20);
        else
            u41(l__Highlights__4.Left, v45, 20);
            v44 = true;
        end;
    end;
    if p43 then
        if typeof(p43) == "string" then
            l__EndText__2.Text = p43 == l__LocalPlayer__10:GetAttribute("MG_Team") and "VICTORY" or "DEFEAT";
        else
            l__EndText__2.Text = p43 == l__LocalPlayer__10 and "VICTORY" or "DEFEAT";
        end;
    else
        l__EndText__2.Text = "TIE";
    end;
end;
function v1.Hide() --[[ Line: 268 ]]
    -- upvalues: u4 (copy)
    u4();
end;
local u46 = { l__Navbar__3:WaitForChild("Buttons"):WaitForChild("Highlights"), l__Navbar__3.Buttons:WaitForChild("Scoreboard") };
for _, u47 in u46 do
    local l__SELECT__18 = u47:WaitForChild("SELECT");
    l__SELECT__18.Activated:Connect(function() --[[ Line: 275 ]]
        -- upvalues: l__Scoreboard__5 (copy), u47 (copy), l__Highlights__4 (copy), u46 (copy), l__SELECT__18 (copy)
        l__Scoreboard__5.Visible = u47.Name == "Scoreboard";
        l__Highlights__4.Visible = u47.Name == "Highlights";
        for _, v48 in u46 do
            local v49 = l__SELECT__18 == v48.SELECT;
            v48.SelectionHighlight.Visible = v49;
            v48.SELECT.UIGradient.Enabled = v49;
        end;
    end);
end;
return v1;