-- Roblox: Players.SilverAce293026.PlayerGui.FadeGui.FadeModule
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
local l__Frame__1 = script.Parent:WaitForChild("Frame");
local l__TweenService__2 = game:GetService("TweenService");
TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
function u1.FadeAsync(p2, p3, p4) --[[ Line: 7 ]]
    -- upvalues: l__TweenService__2 (copy), l__Frame__1 (copy)
    local v5 = l__TweenService__2:Create(l__Frame__1, TweenInfo.new(p4 or 1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
        BackgroundTransparency = p2 and 0 or 1
    });
    if p3 then
        v5.Completed:Connect(p3);
    end;
    v5:Play();
end;
function u1.FadeYield(p6, p7) --[[ Line: 18 ]]
    -- upvalues: u1 (copy)
    local u8 = false;
    u1.FadeAsync(p6, function() --[[ Line: 21 ]]
        -- upvalues: u8 (ref)
        u8 = true;
    end, p7 or 1);
    print("Starting yield");
    repeat
        task.wait();
    until u8;
    print("Ended yield");
end;
return u1;