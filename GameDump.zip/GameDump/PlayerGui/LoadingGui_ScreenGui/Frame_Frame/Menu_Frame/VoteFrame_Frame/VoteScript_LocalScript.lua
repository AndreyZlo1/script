-- Roblox: Players.SilverAce293026.PlayerGui.LoadingGui.Frame.Menu.VoteFrame.VoteScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
if require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig")).Mode == "Deathmatch" then
    script.Parent.Parent:WaitForChild("IntermissionLabel").Position = UDim2.new(0.25, 0, 0.7, 0);
    local l__PlayerEvents__2 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents");
    local l__DMState__3 = l__ReplicatedStorage__1:WaitForChild("DMState");
    local l__Prototype__4 = script.Parent:WaitForChild("Container"):WaitForChild("Prototype");
    local u1 = {};
    local u2 = false;
    local u3 = nil;
    local u4 = {
        City = 17682996619,
        Villa = 17682993057,
        ["Mountain Base"] = 17682987549,
        Harbor = 17682976663,
        TestMap = 17682993057
    };
    for u5 = 1, 3 do
        u1[u5] = l__Prototype__4:Clone();
        u1[u5].Parent = script.Parent.Container;
        u1[u5].Background.VoteBtnFrame.BtnFrame.JoinBtn.Activated:Connect(function() --[[ Line: 28 ]]
            -- upvalues: l__PlayerEvents__2 (copy), u5 (copy), u2 (ref), u3 (ref)
            l__PlayerEvents__2.VoteEvent:FireServer(u5);
            u2 = true;
            u3 = u5;
            task.delay(30, function() --[[ Line: 33 ]]
                -- upvalues: u2 (ref), u3 (ref)
                u2 = false;
                u3 = nil;
            end);
        end);
    end;
    local function u11(p6, p7, p8, p9) --[[ Line: 40 ]]
        -- upvalues: u1 (copy), u3 (ref), u4 (copy)
        local v10 = u1[p6];
        v10.Background.Info.ModeLabel.Text = p7;
        v10.Background.Info.MapLabel.Text = p8;
        v10.Background.VotesLabel.Text = string.format("%s votes", p9 or 0);
        if u3 == p6 then
            v10.Background.SelectedStroke.Enabled = true;
            v10.Background.Info.ModeLabel.TextColor3 = Color3.fromRGB(255, 65, 0);
            v10.Background.VoteBtnFrame.Visible = false;
        else
            v10.Background.SelectedStroke.Enabled = false;
            v10.Background.Info.ModeLabel.TextColor3 = Color3.fromRGB(255, 255, 255);
            v10.Background.VoteBtnFrame.Visible = true;
        end;
        if u4[p8] then
            v10.Background.Image = string.format("rbxassetid://%s", u4[p8]);
        end;
    end;
    local function v18() --[[ Line: 62 ]]
        -- upvalues: l__DMState__3 (copy), u1 (copy), u11 (copy)
        local v12 = l__DMState__3:GetAttribute("Intermission");
        for _, v13 in u1 do
            v13.Visible = v12;
        end;
        script.Parent.Parent.GameNameLabel.Visible = not v12;
        for v14 = 1, 3 do
            local v15 = "Votable" .. v14;
            l__DMState__3:GetAttribute(v15);
            local v16;
            repeat
                task.wait();
                v16 = l__DMState__3:GetAttribute(v15);
            until v16;
            local v17 = string.split(v16, "|");
            u11(v14, v17[1], v17[2]:gsub("(%l)(%u)", "%1 %2"), (l__DMState__3:GetAttribute("Votes" .. v14)));
        end;
    end;
    repeat
        task.wait();
    until not script.Parent.Parent:WaitForChild("ProgressBar").Visible;
    l__DMState__3:GetAttributeChangedSignal("Intermission"):Connect(v18);
    l__DMState__3.Changed:Connect(v18);
    l__DMState__3.AttributeChanged:Connect(v18);
    v18();
end;