-- Roblox: Players.SilverAce293026.PlayerGui.DailySpin.SpinScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__MarketplaceService__1 = game:GetService("MarketplaceService");
local l__ReplicatedStorage__2 = game:GetService("ReplicatedStorage");
local l__PolicyService__3 = game:GetService("PolicyService");
local l__HapticService__4 = game:GetService("HapticService");
game:GetService("StarterGui");
local l__LocalPlayer__5 = game:GetService("Players").LocalPlayer;
local l__PlayerGui__6 = l__LocalPlayer__5:WaitForChild("PlayerGui");
local u1 = true;
pcall(function() --[[ Line: 11 ]]
    -- upvalues: l__PolicyService__3 (copy), l__LocalPlayer__5 (copy), u1 (ref)
    u1 = l__PolicyService__3:GetPolicyInfoForPlayerAsync(l__LocalPlayer__5).ArePaidRandomItemsRestricted;
end);
local l__PlayerEvents__7 = l__ReplicatedStorage__2:WaitForChild("PlayerEvents");
local l__RunService__8 = game:GetService("RunService");
local l__TweenService__9 = game:GetService("TweenService");
local l__ReplicatedConfig__10 = require(l__ReplicatedStorage__2:WaitForChild("ReplicatedConfig"));
local l__Area__11 = script.Parent:WaitForChild("Area");
local l__Inner__12 = l__Area__11:WaitForChild("Circle"):WaitForChild("Inner");
local l__ShopGui__13 = l__PlayerGui__6:WaitForChild("ShopGui");
local l__ShopModule__14 = require(l__ShopGui__13:WaitForChild("ShopModule"));
local l__RewardGui__15 = l__PlayerGui__6:WaitForChild("RewardGui");
local l__RewardGuiModule__16 = require(l__RewardGui__15:WaitForChild("RewardGuiModule"));
local u2 = {
    Yellow = Color3.fromHex("#FAB81B"),
    Purple = Color3.fromHex("#B759D7"),
    Blue = Color3.fromHex("#2B77CF"),
    Green = Color3.fromHex("#54B650"),
    White = Color3.fromHex("#D2C6D7")
};
local u3 = u1;
local u4 = {};
local u5 = {
    Yellow = "rbxassetid://17202234633",
    Purple = "rbxassetid://17202240989",
    Blue = "rbxassetid://17202246129",
    Green = "rbxassetid://17202251387",
    White = "rbxassetid://17202191249"
};
for v6 = 1, 8 do
    u4[v6] = l__Inner__12:WaitForChild(v6);
end;
local function u13(p7) --[[ Line: 52 ]]
    if p7 == 0 then
        return "0$";
    end;
    local v8 = math.floor(p7);
    local v9 = tostring(v8);
    local v10 = string.split(v9, ".")[1];
    local v11 = string.split(v10, "");
    if string.len(v10) <= 3 then
        return v10 .. "$";
    end;
    for v12 = string.len(v10) - 2, 2, -3 do
        table.insert(v11, v12, ",");
    end;
    return table.concat(v11, "") .. "$";
end;
local u21 = {
    Money = function(p14) --[[ Name: Money, Line 83 ]]
        -- upvalues: u13 (copy)
        return "Money", u13(p14.Value), "rbxassetid://17216499501";
    end,
    DoubleXP = function(p15) --[[ Name: DoubleXP, Line 87 ]]
        local l__Value__17 = p15.Value;
        local v16 = math.floor(l__Value__17 / 60);
        return "Double XP", string.format("%02d:%02d:%02d", v16, l__Value__17 % 60, 0);
    end,
    DoubleMoney = function(p17) --[[ Name: DoubleMoney, Line 92 ]]
        local l__Value__18 = p17.Value;
        local v18 = math.floor(l__Value__18 / 60);
        return "Double Money", string.format("%02d:%02d:%02d", v18, l__Value__18 % 60, 0);
    end,
    EventWeapon = function(p19) --[[ Name: EventWeapon, Line 97 ]]
        return "Special Weapon", p19.Value;
    end,
    Gamepass = function(p20) --[[ Name: Gamepass, Line 101 ]]
        -- upvalues: l__MarketplaceService__1 (copy)
        return "Gamepass", l__MarketplaceService__1:GetProductInfo(p20.Value, Enum.InfoType.GamePass).Name;
    end
};
local u22 = {};
local function v30(p23, p24) --[[ Line: 118 ]]
    -- upvalues: u4 (copy), u5 (copy), u21 (copy), l__Inner__12 (copy)
    local _ = p24.Chance;
    local v25 = u4[p23];
    if p24.Color then
        v25.Image = u5[p24.Color];
    else
        local v26 = u5;
        local l__Chance__19 = p24.Chance;
        v25.Image = v26[l__Chance__19 < 3 and "Yellow" or (l__Chance__19 < 14 and "Purple" or (l__Chance__19 < 40 and "Blue" or "White"))];
    end;
    local v27, v28, v29 = u21[p24.Type](p24);
    v25.Frame.Title.Text = v27;
    v25.Frame.Quantity.Text = v28;
    if p24.Image then
        v25.Icon.Image = p24.Image;
    else
        v25.Icon.Image = v29;
    end;
    l__Inner__12:WaitForChild(p23 .. "White").ImageTransparency = 1;
end;
for v31 = 1, 8 do
    local v32 = v31 == 1 and 0 or (v31 - 1) * 45;
    u22[v31] = {
        Min = v32,
        Max = v32 + 45
    };
    v30(v31, l__ReplicatedConfig__10.DailySpinRewards[v31]);
end;
local l__Chances__20 = l__Area__11:WaitForChild("Chances");
local v33 = table.clone(l__ReplicatedConfig__10.DailySpinRewards);
table.sort(v33, function(p34, p35) --[[ Line: 158 ]]
    return p34.Chance < p35.Chance;
end);
for _, v36 in v33 do
    local v37, v38, v39 = u21[v36.Type](v36);
    local v40 = l__Chances__20.Proto:Clone();
    v40.Label.Text = string.format("%s - %s - %s", v37, v38, v36.Chance .. "%");
    v40.Image.Image = v39 or (v36.Image or "rbxassetid://17201344359");
    local l__Label__21 = v40.Label;
    local l__Chance__22 = v36.Chance;
    l__Label__21.TextColor3 = u2[l__Chance__22 < 3 and "Yellow" or (l__Chance__22 < 14 and "Purple" or (l__Chance__22 < 40 and "Blue" or "White"))];
    v40.Parent = l__Area__11.Chances;
    v40.Visible = true;
end;
local u41 = {
    GetTime = l__PlayerEvents__7:WaitForChild("GetTimeTillNextSpin"),
    RedeemSpin = l__PlayerEvents__7:WaitForChild("RedeemSpin"),
    GetPremiumPrice = l__PlayerEvents__7:WaitForChild("GetSpinPrice"),
    PremiumSpin = l__PlayerEvents__7:WaitForChild("PremiumSpin")
};
local v42 = u41.GetTime:InvokeServer();
local function u45() --[[ Line: 195 ]]
    -- upvalues: u41 (copy), u3 (ref)
    local l__Button__23 = script.Parent.Area.Buttons.Spin.ButtonFrame.Button;
    local v43 = u41.GetTime:InvokeServer() == 0;
    if u3 then
        l__Button__23.Parent.Parent.Visible = v43;
    end;
    if v43 then
        l__Button__23.Text = "SPIN";
        l__Button__23.Frame.Visible = false;
    else
        local v44, _ = u41.GetPremiumPrice:InvokeServer();
        l__Button__23.Text = "" .. v44;
        l__Button__23.Frame.Visible = v44 == 49;
    end;
end;
local function u68(p46) --[[ Line: 214 ]]
    -- upvalues: l__Area__11 (copy), l__ShopGui__13 (copy), u22 (copy), l__TweenService__9 (copy), l__HapticService__4 (copy), l__RunService__8 (copy), u4 (copy), l__Inner__12 (copy)
    l__Area__11.Buttons.Visible = false;
    l__Area__11.CloseButton.Visible = false;
    l__ShopGui__13.UnderstoreFrame.SpinButton.Notice.Visible = false;
    local v47 = u22[p46];
    local u48 = math.random(v47.Min + 7, v47.Max - 7);
    local v49 = math.random(3, 5);
    local v50 = v49 * 360 + u48;
    local v51 = TweenInfo.new(v49 * 1.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out);
    local v52 = l__TweenService__9:Create(l__Area__11.Circle.Spinner, v51, {
        Rotation = v50
    });
    v52.Completed:Connect(function() --[[ Line: 236 ]]
        -- upvalues: l__Area__11 (ref), u48 (copy)
        l__Area__11.Circle.Spinner.Rotation = u48;
    end);
    v52:Play();
    local l__Gamepad1__24 = Enum.UserInputType.Gamepad1;
    local u53 = {
        [Enum.VibrationMotor.Large] = l__HapticService__4:IsMotorSupported(l__Gamepad1__24, Enum.VibrationMotor.Large),
        [Enum.VibrationMotor.Small] = l__HapticService__4:IsMotorSupported(l__Gamepad1__24, Enum.VibrationMotor.Small)
    };
    local u54 = nil;
    local v62 = l__RunService__8.RenderStepped:Connect(function(_) --[[ Line: 249 ]]
        -- upvalues: u4 (ref), l__Inner__12 (ref), l__Area__11 (ref), u54 (ref), u53 (copy), l__HapticService__4 (ref), l__Gamepad1__24 (copy)
        for v55 = 1, 8 do
            local v56 = u4[v55];
            local v57 = l__Inner__12[v55 .. "White"];
            local l__Rotation__25 = v57.Rotation;
            local v58 = l__Rotation__25 + 22.5;
            local _ = l__Rotation__25 + 45;
            local v59 = math.abs((v58 - l__Area__11.Circle.Spinner.Rotation % 360) / 22.5);
            local v60 = math.clamp(v59, 0, 1);
            if v60 < 0.9 and u54 ~= v55 then
                u54 = v55;
                script.Tick:Play();
                if u53[Enum.VibrationMotor.Large] or not u53[Enum.VibrationMotor.Small] then
                    if u53[Enum.VibrationMotor.Large] then
                        l__HapticService__4:SetMotor(l__Gamepad1__24, Enum.VibrationMotor.Large, 0.3);
                    end;
                else
                    l__HapticService__4:SetMotor(l__Gamepad1__24, Enum.VibrationMotor.Small, 0.5);
                end;
            end;
            v57.ImageTransparency = v60 * 0.35 + 0.65;
            local v61 = 1.2 - v60 * 0.1;
            v57.Size = UDim2.new(v61, 0, v61, 0);
            v56.Size = UDim2.new(v61, 0, v61, 0);
        end;
    end);
    v52.Completed:Wait();
    v62:Disconnect();
    for v63, v64 in u53 do
        if v64 then
            l__HapticService__4:SetMotor(Enum.UserInputType.Gamepad1, v63, 0);
        end;
    end;
    local v65 = l__Inner__12[p46 .. "White"];
    local v66 = l__TweenService__9:Create(v65, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 3, true), {
        ImageTransparency = 0.65
    });
    for _, v67 in { v65, u4[p46] } do
        l__TweenService__9:Create(v67, v51, {
            Size = UDim2.new(1.2, 0, 1.2, 0)
        }):Play();
    end;
    v66.Completed:Connect(function() --[[ Line: 318 ]]
        -- upvalues: l__Area__11 (ref)
        task.delay(1, function() --[[ Line: 319 ]]
            -- upvalues: l__Area__11 (ref)
            script.Parent.Area.Buttons.Spin.ButtonFrame.Button.Parent.Parent.Parent.Visible = true;
            l__Area__11.Buttons.Visible = true;
            l__Area__11.CloseButton.Visible = true;
        end);
    end);
    v66:Play();
    v66.Completed:Wait();
    v66:Cancel();
end;
l__Area__11:WaitForChild("Buttons"):WaitForChild("Spin"):WaitForChild("ButtonFrame"):WaitForChild("Button").Activated:Connect(function() --[[ Line: 333 ]]
    -- upvalues: u41 (copy), l__MarketplaceService__1 (copy), u68 (copy), l__Area__11 (copy), u45 (copy), l__ReplicatedConfig__10 (copy), u2 (copy), l__RewardGuiModule__16 (copy)
    local v69, v70 = u41.RedeemSpin:InvokeServer();
    if v69 then
        script.Parent.Area.Buttons.Spin.ButtonFrame.Button.Parent.Parent.Parent.Visible = false;
        u68(v70);
        local u71 = os.time() + 86399;
        task.spawn(function() --[[ Line: 182 ]]
            -- upvalues: u71 (copy), l__Area__11 (ref)
            while true do
                task.wait(0.2);
                local v72 = u71 - os.time();
                local v73 = math.floor(v72 / 60 / 60);
                local v74 = math.floor(v72 / 60 % 60);
                l__Area__11.Timer.Text = string.format("%02d:%02d:%02d", v73, v74, v72 % 60);
            end;
        end);
        u45();
        local v75 = l__ReplicatedConfig__10.DailySpinRewards[v70];
        local v76 = {
            Text = v69,
            Image = v75.Image or "rbxassetid://17201344359"
        };
        local v77 = v75.Color and u2[v75.Color];
        if not v77 then
            local v78 = u2;
            local l__Chance__26 = v75.Chance;
            v77 = v78[l__Chance__26 < 3 and "Yellow" or (l__Chance__26 < 14 and "Purple" or (l__Chance__26 < 40 and "Blue" or "White"))];
        end;
        v76.Color = v77;
        script.Parent.Area.Visible = false;
        l__RewardGuiModule__16.ShowReward(v76, function() --[[ Line: 359 ]]
            script.Parent.Area.Visible = true;
        end);
    else
        local _, v79 = u41.GetPremiumPrice:InvokeServer();
        l__MarketplaceService__1:PromptProductPurchase(game.Players.LocalPlayer, v79);
    end;
end);
if v42 == 0 then
    l__Area__11.Timer.Text = "READY NOW";
else
    local u80 = os.time() + v42;
    task.spawn(function() --[[ Line: 182 ]]
        -- upvalues: u80 (copy), l__Area__11 (copy)
        while true do
            task.wait(0.2);
            local v81 = u80 - os.time();
            local v82 = math.floor(v81 / 60 / 60);
            local v83 = math.floor(v81 / 60 % 60);
            l__Area__11.Timer.Text = string.format("%02d:%02d:%02d", v82, v83, v81 % 60);
        end;
    end);
    task.delay(v42, function() --[[ Line: 366 ]]
        -- upvalues: l__Area__11 (copy), u45 (copy)
        l__Area__11.Timer.Text = "READY NOW";
        u45();
    end);
end;
u45();
l__Area__11:WaitForChild("CloseButton"):WaitForChild("ButtonFrame"):WaitForChild("Button").Activated:Connect(function() --[[ Line: 392 ]]
    -- upvalues: l__Area__11 (copy), u45 (copy)
    script.Parent.Enabled = false;
    l__Area__11.Chances.Visible = false;
    l__Area__11.Timer.Visible = true;
    l__Area__11.Title.Visible = true;
    l__Area__11.Circle.Visible = true;
    l__Area__11.Buttons.Back.Visible = false;
    l__Area__11.Buttons.Chances.Visible = true;
    u45();
    l__Area__11.ChancesDisclaimer.Visible = false;
end);
l__Area__11.Buttons:WaitForChild("Back"):WaitForChild("ButtonFrame"):WaitForChild("Button").Activated:Connect(function() --[[ Line: 397 ]]
    -- upvalues: l__Area__11 (copy), u45 (copy)
    l__Area__11.Chances.Visible = false;
    l__Area__11.Timer.Visible = true;
    l__Area__11.Title.Visible = true;
    l__Area__11.Circle.Visible = true;
    l__Area__11.Buttons.Back.Visible = false;
    l__Area__11.Buttons.Chances.Visible = true;
    u45();
    l__Area__11.ChancesDisclaimer.Visible = false;
end);
l__Area__11.Buttons:WaitForChild("Chances"):WaitForChild("ButtonFrame"):WaitForChild("Button").Activated:Connect(function() --[[ Line: 401 ]]
    -- upvalues: l__Area__11 (copy)
    l__Area__11.Chances.Visible = true;
    l__Area__11.Timer.Visible = false;
    l__Area__11.Title.Visible = false;
    l__Area__11.Circle.Visible = false;
    l__Area__11.Buttons.Back.Visible = true;
    l__Area__11.Buttons.Chances.Visible = false;
    l__Area__11.Buttons.Spin.Visible = false;
    l__Area__11.ChancesDisclaimer.Visible = true;
end);
u41.PremiumSpin.OnClientEvent:Connect(function(p84, p85) --[[ Line: 412 ]]
    -- upvalues: u68 (copy), u45 (copy), l__ReplicatedConfig__10 (copy), u2 (copy), l__RewardGuiModule__16 (copy)
    u68(p85);
    u45();
    local v86 = l__ReplicatedConfig__10.DailySpinRewards[p85];
    script.Parent.Area.Visible = false;
    local v87 = {
        Text = p84,
        Image = v86.Image or "rbxassetid://17201344359"
    };
    local v88 = v86.Color and u2[v86.Color];
    if not v88 then
        local v89 = u2;
        local l__Chance__27 = v86.Chance;
        v88 = v89[l__Chance__27 < 3 and "Yellow" or (l__Chance__27 < 14 and "Purple" or (l__Chance__27 < 40 and "Blue" or "White"))];
    end;
    v87.Color = v88;
    l__RewardGuiModule__16.ShowReward(v87, function() --[[ Line: 427 ]]
        script.Parent.Area.Visible = true;
    end);
end);
script.Parent:GetPropertyChangedSignal("Enabled"):Connect(function() --[[ Line: 432 ]]
    -- upvalues: l__ShopModule__14 (copy)
    l__ShopModule__14.toggleLeftMenu(not script.Parent.Enabled);
    local v90 = game:GetService("Players").LocalPlayer.PlayerGui:FindFirstChild("CustomToolbar");
    if v90 then
        v90.Enabled = not script.Parent.Enabled;
    end;
end);