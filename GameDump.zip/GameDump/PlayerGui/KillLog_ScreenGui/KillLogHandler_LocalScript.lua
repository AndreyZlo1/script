-- Roblox: Players.SilverAce293026.PlayerGui.KillLog.KillLogHandler
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Players__2 = game:GetService("Players");
local l__TweenService__3 = game:GetService("TweenService");
local l__LocalPlayer__4 = l__Players__2.LocalPlayer;
local l__PlayerEvents__5 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents");
local l__Modules__6 = l__ReplicatedStorage__1:WaitForChild("Modules");
local l__ACS_Engine__7 = l__ReplicatedStorage__1:WaitForChild("ACS_Engine");
local l__Modules__8 = l__ACS_Engine__7:WaitForChild("Modules");
local l__GunModels__9 = l__ACS_Engine__7:WaitForChild("GunModels");
local l__AttachmentsUtil__10 = require(l__Modules__8:WaitForChild("AttachmentsUtil"));
local l__GuiModule__11 = require(l__Modules__6:WaitForChild("GuiModule"));
local l__Background__12 = script.Parent:WaitForChild("Background");
local l__Prototype__13 = l__Background__12:WaitForChild("Prototype");
local l__KillLog__14 = l__PlayerEvents__5:WaitForChild("KillLog");
local l__Size__15 = l__Prototype__13.Size;
local u1 = math.floor(1 / l__Size__15.Y.Scale);
local u2 = 0;
local u3 = TweenInfo.new(0.3, Enum.EasingStyle.Quint, Enum.EasingDirection.Out);
local function u8(p4, p5) --[[ Line: 40 ]]
    -- upvalues: l__LocalPlayer__4 (copy)
    local v6 = l__LocalPlayer__4:GetAttribute("MG_Team") ~= nil;
    for _, v7 in { p4, p5 } do
        if v7:GetAttribute("MG_Team") ~= nil ~= v6 then
            return false;
        end;
    end;
    return true;
end;
local function u20() --[[ Line: 52 ]]
    -- upvalues: l__Background__12 (copy), l__Prototype__13 (copy), u1 (ref), l__TweenService__3 (copy), u3 (copy)
    local v9 = {};
    local v10 = {};
    for _, v11 in l__Background__12:GetChildren() do
        if v11 ~= l__Prototype__13 and v11:IsA("CanvasGroup") then
            local l__LayoutOrder__16 = v11.LayoutOrder;
            v9[l__LayoutOrder__16] = v11;
            table.insert(v10, l__LayoutOrder__16);
        end;
    end;
    table.sort(v10, function(p12, p13) --[[ Line: 63 ]]
        return p12 < p13;
    end);
    local v14 = 1;
    for _, v15 in v10 do
        local v16 = (v14 - 1) / u1;
        local v17 = v9[v15];
        local v18 = { v17.Killer, v17.Victim, v17.GunFrame.Distance };
        local l__GunFrame__17 = v17.GunFrame;
        for _, v19 in v18 do
            l__TweenService__3:Create(v19, u3, {
                TextTransparency = v16
            }):Play();
        end;
        l__TweenService__3:Create(l__GunFrame__17, u3, {
            ImageTransparency = v16
        }):Play();
        v14 = v14 + 1;
    end;
end;
local function v44(p21, p22, p23, p24, u25) --[[ Line: 90 ]]
    -- upvalues: u8 (copy), l__Prototype__13 (copy), l__Background__12 (copy), u2 (ref), l__Size__15 (copy), l__TweenService__3 (copy), u3 (copy), l__GunModels__9 (copy), l__AttachmentsUtil__10 (copy), l__GuiModule__11 (copy), u20 (copy)
    if u8(p21, p22) then
        local v26 = p21:GetAttribute("MG_Team");
        local v27 = p22:GetAttribute("MG_Team");
        local v28 = v26 and (v26 == "Blue" and Color3.fromRGB(99, 141, 255) or Color3.fromRGB(234, 94, 76)) or Color3.fromRGB(255, 255, 255);
        local v29 = v27 and (v27 == "Blue" and Color3.fromRGB(99, 141, 255) or Color3.fromRGB(234, 94, 76)) or Color3.fromRGB(255, 255, 255);
        local u30 = l__Prototype__13:Clone();
        u30.Parent = l__Background__12;
        u30.LayoutOrder = -u2;
        u2 = u2 + 1;
        local v31 = l__Size__15;
        u30.Size = UDim2.new(1, 0, 0, 0);
        u30.GroupTransparency = 1;
        local v32 = l__TweenService__3:Create(u30, u3, {
            Size = v31
        });
        local u33 = l__TweenService__3:Create(u30, u3, {
            GroupTransparency = 0
        });
        v32.Completed:Connect(function() --[[ Line: 116 ]]
            -- upvalues: u33 (copy)
            u33:Play();
        end);
        u30.Killer.Text = p21.DisplayName;
        u30.Victim.Text = p22.DisplayName;
        u30.Killer.TextColor3 = v28;
        u30.Victim.TextColor3 = v29;
        u30.GunFrame.Distance.Text = string.format("%sm", (math.floor(p24 / 2.4)));
        local v34 = l__GunModels__9:FindFirstChild(p23);
        if v34 then
            local u35 = v34:Clone();
            u35.Parent = u30.GunFrame;
            (function() --[[ Name: processAttachments, Line 133 ]]
                -- upvalues: u25 (copy), l__AttachmentsUtil__10 (ref), u35 (copy)
                local v36 = {};
                for _, v37 in u25 do
                    local v38 = l__AttachmentsUtil__10.getAttDataFromHash(v37);
                    if v38 then
                        table.insert(v36, v38);
                    end;
                end;
                l__AttachmentsUtil__10.loadAttachments(u35, v36);
                local v39 = u35:FindFirstChild("SightMark", true);
                local v40 = v39 and v39:FindFirstChildOfClass("SurfaceGui");
                if v40 then
                    v40.Enabled = false;
                end;
                for _, v41 in u35:GetDescendants() do
                    if v41:IsA("Decal") then
                        v41:Destroy();
                    end;
                end;
            end)();
            local v42 = Instance.new("Camera");
            v42.Parent = u30;
            u30.GunFrame.CurrentCamera = v42;
            l__GuiModule__11.CameraZoom.zoomToExtents(v42, u35, 0, 0);
        end;
        u30.Visible = true;
        v32:Play();
        local u43 = l__TweenService__3:Create(u30, u3, {
            GroupTransparency = 1
        });
        u43.Completed:Connect(function() --[[ Line: 175 ]]
            -- upvalues: u30 (copy)
            u30:Destroy();
        end);
        task.delay(4, function() --[[ Line: 179 ]]
            -- upvalues: u43 (copy)
            u43:Play();
        end);
        u20();
    end;
end;
script:WaitForChild("Event").Event:Connect(v44);
l__KillLog__14.OnClientEvent:Connect(v44);