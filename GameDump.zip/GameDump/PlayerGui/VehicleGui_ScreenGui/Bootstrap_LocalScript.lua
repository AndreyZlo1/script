-- Roblox: Players.SilverAce293026.PlayerGui.VehicleGui.Bootstrap
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Players__2 = game:GetService("Players");
local l__Vehicles__3 = l__ReplicatedStorage__1:WaitForChild("Vehicles");
local l__Helicopters__4 = l__ReplicatedStorage__1:WaitForChild("Helicopters");
local l__LocalPlayer__5 = l__Players__2.LocalPlayer;
local v1 = l__LocalPlayer__5.Character or l__LocalPlayer__5.CharacterAdded:Wait();
local l__VehicleGuiModule__6 = require(script.Parent:WaitForChild("VehicleGuiModule"));
v1:WaitForChild("Humanoid").Seated:Connect(function(p2, p3) --[[ Line: 16 ]]
    -- upvalues: l__VehicleGuiModule__6 (copy), l__Vehicles__3 (copy), l__Helicopters__4 (copy)
    if p2 then
        local v4 = p3:FindFirstAncestorOfClass("Model");
        if v4 then
            if p3.Name == "TurretSeat" then
                while not v4:FindFirstChild("Required") do
                    v4 = v4.Parent;
                end;
            end;
            if l__Vehicles__3:FindFirstChild(v4.Name) or l__Helicopters__4:FindFirstChild(v4.Name) then
                l__VehicleGuiModule__6.Show(v4);
            else
                l__VehicleGuiModule__6.Clear();
            end;
        end;
    else
        l__VehicleGuiModule__6.Clear();
    end;
end);