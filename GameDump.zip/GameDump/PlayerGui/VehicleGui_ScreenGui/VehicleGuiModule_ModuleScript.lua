-- Roblox: Players.SilverAce293026.PlayerGui.VehicleGui.VehicleGuiModule
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
local l__Players__1 = game:GetService("Players");
local l__Occupants__2 = script.Parent:WaitForChild("Occupants");
local l__Prototype__3 = l__Occupants__2:WaitForChild("Prototype");
local u2 = {
    Driver = 18752623743,
    Gunner = 18752640470,
    Passenger = 18752643239
};
local u3 = {
    ApcSeat = "Driver",
    TankSeat = "Driver",
    VehicleSeat = "Driver",
    GunnerSeat = "Gunner",
    HeliSeat = "Driver",
    TurretSeat = "Gunner"
};
local u4 = {
    Blue = Color3.fromRGB(99, 141, 255),
    Red = Color3.fromRGB(234, 94, 76)
};
local u5 = {};
function u1.Show(p6) --[[ Line: 30 ]]
    -- upvalues: u1 (copy), u3 (copy), l__Prototype__3 (copy), u2 (copy), l__Occupants__2 (copy), l__Players__1 (copy), u4 (copy), u5 (ref)
    u1.Clear();
    local v7 = {};
    for _, v8 in p6:GetDescendants() do
        if v8:IsA("Seat") or v8:IsA("VehicleSeat") then
            table.insert(v7, v8);
        end;
    end;
    local v9 = table.clone(v7);
    local v10 = {};
    for _, v11 in v9 do
        if (u3[v11.Name] or "Passenger") == "Driver" then
            table.insert(v10, v11);
            break;
        end;
    end;
    for _, v12 in v9 do
        if (u3[v12.Name] or "Passenger") == "Gunner" then
            table.insert(v10, v12);
        end;
    end;
    for _, v13 in v9 do
        if (u3[v13.Name] or "Passenger") == "Passenger" then
            table.insert(v10, v13);
        end;
    end;
    local v14 = {};
    for _, u15 in v10 do
        local u16 = l__Prototype__3:Clone();
        v14[u15] = u16;
        u16.Image = string.format("rbxassetid://%s", u2[u3[u15.Name] or "Passenger"]);
        u16.Parent = l__Occupants__2;
        u16.Visible = true;
        local function v22() --[[ Line: 82 ]]
            -- upvalues: u15 (copy), u16 (copy), l__Players__1 (ref), u4 (ref)
            local l__Occupant__4 = u15.Occupant;
            if l__Occupant__4 then
                local v17 = l__Occupant__4:FindFirstAncestorOfClass("Model");
                if v17 then
                    local v18 = l__Players__1:GetPlayerFromCharacter(v17);
                    if v18 then
                        local v19 = v18:GetAttribute("MG_Team");
                        local v20 = Color3.fromRGB(255, 255, 255);
                        if v19 then
                            v20 = u4[v19];
                        end;
                        u16.ImageColor3 = v20;
                        u16.Label.TextColor3 = v20;
                        u16.Label.Text = v18.Name;
                    end;
                end;
            else
                u16.Label.Text = "Empty";
                local v21 = Color3.fromRGB(200, 200, 200);
                u16.ImageColor3 = v21;
                u16.Label.TextColor3 = v21;
            end;
        end;
        v22();
        local v23 = u15:GetPropertyChangedSignal("Occupant"):Connect(v22);
        table.insert(u5, v23);
    end;
end;
function u1.Clear() --[[ Line: 111 ]]
    -- upvalues: u5 (ref), l__Occupants__2 (copy), l__Prototype__3 (copy)
    for _, v24 in u5 do
        v24:Disconnect();
    end;
    for _, v25 in l__Occupants__2:GetChildren() do
        if v25:IsA("ImageLabel") and v25 ~= l__Prototype__3 then
            v25:Destroy();
        end;
    end;
    u5 = {};
end;
return u1;