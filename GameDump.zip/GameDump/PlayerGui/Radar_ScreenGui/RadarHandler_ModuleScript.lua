-- Roblox: Players.SilverAce293026.PlayerGui.Radar.RadarHandler
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__CollectionService__2 = game:GetService("CollectionService");
local l__RunService__3 = game:GetService("RunService");
local l__UserInputService__4 = game:GetService("UserInputService");
local l__Players__5 = game:GetService("Players");
local l__LocalPlayer__6 = l__Players__5.LocalPlayer;
local l__PlayerEvents__7 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents");
local l__RadarEvent__8 = l__PlayerEvents__7:WaitForChild("RadarEvent");
local l__RadarSubscription__9 = l__PlayerEvents__7:WaitForChild("RadarSubscription");
local l__Parent__10 = script.Parent;
local l__Canvas__11 = l__Parent__10:WaitForChild("Canvas");
local l__ProtoDot__12 = l__Canvas__11:WaitForChild("ProtoDot");
local u2 = {};
local function v17() --[[ Line: 33 ]]
    -- upvalues: u2 (ref), l__LocalPlayer__6 (copy), l__CollectionService__2 (copy), l__Players__5 (copy), l__ProtoDot__12 (copy), l__Canvas__11 (copy)
    for _, v3 in u2 do
        v3:Destroy();
    end;
    u2 = {};
    local v4 = l__LocalPlayer__6.Character:FindFirstChild("Humanoid");
    if v4 then
        local l__SeatPart__13 = v4.SeatPart;
        if l__SeatPart__13 then
            local v5 = {};
            for _, v6 in l__CollectionService__2:GetTagged("Aircraft") do
                if v6:IsDescendantOf(workspace) then
                    local l__PrimaryPart__14 = v6.PrimaryPart;
                    if l__PrimaryPart__14 then
                        local l__Occupant__15 = l__PrimaryPart__14.Occupant;
                        local v7;
                        if l__Occupant__15 then
                            v7 = l__Players__5:GetPlayerFromCharacter(l__Occupant__15.Parent):GetAttribute("SquadIndex");
                        else
                            v7 = nil;
                        end;
                        table.insert(v5, {
                            Model = v6,
                            Position = v6.PrimaryPart.Position,
                            SquadIndex = v7
                        });
                    end;
                end;
            end;
            for _, v8 in v5 do
                local _, v9, _ = l__SeatPart__13.CFrame:ToEulerAnglesYXZ();
                local l__Position__16 = (CFrame.new(l__SeatPart__13.Position) * CFrame.Angles(0, v9, 0)):ToObjectSpace(CFrame.new(v8.Position)).Position;
                local v10 = Vector3.new(l__Position__16.X, 0, l__Position__16.Z);
                if v10.Magnitude > 0 then
                    local l__Unit__17 = v10.Unit;
                    local v11 = math.min(v10.Magnitude, 1000) / 1000 * 0.5;
                    local v12 = Vector2.new(l__Unit__17.X, l__Unit__17.Z) * v11;
                    local v13 = 0.5 + v12.X;
                    local v14 = 0.5 + v12.Y;
                    local v15 = Color3.fromRGB(255, 255, 255);
                    if v8.SquadIndex == l__LocalPlayer__6:GetAttribute("SquadIndex") then
                        v15 = Color3.fromRGB(85, 170, 255);
                    elseif v8.SquadIndex then
                        v15 = Color3.fromRGB(255, 0, 0);
                    end;
                    local v16 = l__ProtoDot__12:Clone();
                    v16.Parent = l__Canvas__11;
                    v16.Position = UDim2.new(v13, 0, v14, 0);
                    v16.Visible = true;
                    v16.ImageColor3 = v15;
                    table.insert(u2, v16);
                end;
            end;
        end;
    end;
end;
local function v29(p18) --[[ Line: 101 ]]
    -- upvalues: u2 (ref), l__LocalPlayer__6 (copy), l__ProtoDot__12 (copy), l__Canvas__11 (copy)
    for _, v19 in u2 do
        v19:Destroy();
    end;
    u2 = {};
    local v20 = l__LocalPlayer__6.Character:FindFirstChild("Humanoid");
    if v20 then
        local l__SeatPart__18 = v20.SeatPart;
        if l__SeatPart__18 then
            for _, v21 in p18 do
                if not v21.Model then
                    local l__Position__19 = l__SeatPart__18.CFrame:ToObjectSpace(CFrame.new(v21.Position)).Position;
                    local v22 = Vector3.new(l__Position__19.X, 0, l__Position__19.Z);
                    if v22.Magnitude > 0 then
                        local l__Unit__20 = v22.Unit;
                        local v23 = math.min(v22.Magnitude, 1000) / 1000 * 0.5;
                        local v24 = Vector2.new(l__Unit__20.X, l__Unit__20.Z) * v23;
                        local v25 = 0.5 + v24.X;
                        local v26 = 0.5 + v24.Y;
                        local v27 = Color3.fromRGB(255, 255, 255);
                        if v21.SquadIndex == l__LocalPlayer__6:GetAttribute("SquadIndex") then
                            v27 = Color3.fromRGB(85, 170, 255);
                        elseif v21.SquadIndex then
                            v27 = Color3.fromRGB(255, 0, 0);
                        end;
                        local v28 = l__ProtoDot__12:Clone();
                        v28.Parent = l__Canvas__11;
                        v28.Position = UDim2.new(v25, 0, v26, 0);
                        v28.Visible = true;
                        v28.ImageColor3 = v27;
                        table.insert(u2, v28);
                    end;
                end;
            end;
        end;
    end;
end;
function v1.Show() --[[ Line: 151 ]]
    -- upvalues: l__Parent__10 (copy), l__RadarSubscription__9 (copy)
    l__Parent__10.Enabled = true;
    l__RadarSubscription__9:FireServer(true);
end;
function v1.Hide() --[[ Line: 156 ]]
    -- upvalues: l__Parent__10 (copy), l__RadarSubscription__9 (copy), u2 (ref)
    l__Parent__10.Enabled = false;
    l__RadarSubscription__9:FireServer(false);
    for _, v30 in u2 do
        v30:Destroy();
    end;
    u2 = {};
end;
l__RadarEvent__8.OnClientEvent:Connect(v29);
l__RunService__3.Heartbeat:Connect(v17);
l__UserInputService__4.InputEnded:Connect(function(p31, _) --[[ Line: 167 ]]
    -- upvalues: l__Canvas__11 (copy)
    if p31.UserInputType == Enum.UserInputType.Touch then
        l__Canvas__11.AnchorPoint = Vector2.new(1, 0);
        l__Canvas__11.Position = UDim2.new(0.98, 0, 0.04, 0);
    else
        l__Canvas__11.AnchorPoint = Vector2.new(0, 1);
        l__Canvas__11.Position = UDim2.new(0.02, 0, 0.96, 0);
    end;
end);
return v1;