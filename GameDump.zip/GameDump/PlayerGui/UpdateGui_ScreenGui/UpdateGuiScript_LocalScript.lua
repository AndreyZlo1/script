-- Roblox: Players.SilverAce293026.PlayerGui.UpdateGui.UpdateGuiScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Modules__2 = l__ReplicatedStorage__1:WaitForChild("Modules");
local l__GuiModule__3 = require(l__Modules__2:WaitForChild("GuiModule"));
local l__GameUpdateNotification__4 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents"):WaitForChild("GameUpdateNotification");
local l__Parent__5 = script.Parent;
local l__NewBaseFrame__6 = l__Parent__5:WaitForChild("NewBaseFrame");
l__Parent__5:WaitForChild("TeamsExperimentalFrame");
l__GameUpdateNotification__4.OnClientEvent:Connect(function(p1) --[[ Line: 11 ]]
    -- upvalues: l__NewBaseFrame__6 (copy), l__GuiModule__3 (copy)
    l__NewBaseFrame__6.Visible = true;
    l__NewBaseFrame__6:WaitForChild("Header"):WaitForChild("RefundLabel").Text = "Money added: " .. l__GuiModule__3.format(p1.refunded);
end);