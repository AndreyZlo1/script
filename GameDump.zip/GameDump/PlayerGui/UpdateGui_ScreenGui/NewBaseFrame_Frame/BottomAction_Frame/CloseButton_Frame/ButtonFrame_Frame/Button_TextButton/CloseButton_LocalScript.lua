-- Roblox: Players.SilverAce293026.PlayerGui.UpdateGui.NewBaseFrame.BottomAction.CloseButton.ButtonFrame.Button.CloseButton
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Modules__1 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local l__GuiModule__2 = require(l__Modules__1:WaitForChild("GuiModule"));
local l__Parent__3 = script.Parent.Parent;
local l__Parent__4 = l__Parent__3.Parent;
repeat
    l__Parent__4 = l__Parent__4.Parent;
until l__Parent__4.Name == "NewBaseFrame";
local u1 = false;
script.Parent.MouseButton1Click:connect(function() --[[ Line: 11 ]]
    -- upvalues: u1 (ref), l__GuiModule__2 (copy), l__Parent__3 (copy), l__Parent__4 (ref)
    if u1 == true then
    else
        u1 = true;
        l__GuiModule__2.buttonPress(l__Parent__3);
        l__GuiModule__2.setModal(l__Parent__4, 1.5, nil, function() --[[ Line: 17 ]]
            -- upvalues: l__Parent__4 (ref)
            l__Parent__4.Visible = false;
        end);
        task.wait(0.3);
        l__GuiModule__2.buttonLift(l__Parent__3);
        u1 = false;
    end;
end);