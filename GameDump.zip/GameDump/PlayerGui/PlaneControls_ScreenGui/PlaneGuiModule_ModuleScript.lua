-- Roblox: Players.SilverAce293026.PlayerGui.PlaneControls.PlaneGuiModule
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__TweenService__1 = game:GetService("TweenService");
local l__Parent__2 = script.Parent;
local l__MainFrame__3 = l__Parent__2:WaitForChild("MainFrame");
local l__ReloadBar__4 = l__MainFrame__3:WaitForChild("ReloadBar");
local l__Percent__5 = l__ReloadBar__4:WaitForChild("Percent");
local l__GunName__6 = l__MainFrame__3:WaitForChild("GunName");
function v1.setVisible(p2) --[[ Line: 13 ]]
    -- upvalues: l__Parent__2 (copy)
    l__Parent__2.Enabled = p2;
end;
local u3 = 0;
function v1.reload(p4, p5) --[[ Line: 19 ]]
    -- upvalues: u3 (ref), l__ReloadBar__4 (copy), l__Percent__5 (copy)
    u3 = u3 + 1;
    local u6 = u3;
    local v7 = p5 or 0;
    local function v9(p8) --[[ Line: 23 ]]
        -- upvalues: u6 (copy), u3 (ref), l__ReloadBar__4 (ref)
        if p8 then
            if u6 == u3 then
                l__ReloadBar__4.Visible = false;
            end;
        end;
    end;
    local v10 = v7 / p4;
    l__ReloadBar__4.Visible = true;
    l__Percent__5.Size = UDim2.new(v10, 0, 1, 0);
    l__Percent__5:TweenSize(UDim2.new(1, 0, 1, 0), nil, Enum.EasingStyle.Linear, p4 - v7, true, v9);
end;
function v1.switchGun(p11) --[[ Line: 35 ]]
    -- upvalues: l__ReloadBar__4 (copy), l__GunName__6 (copy), l__TweenService__1 (copy)
    l__ReloadBar__4.Visible = false;
    l__GunName__6.Text = p11;
    l__GunName__6.TextTransparency = 0;
    l__TweenService__1:Create(l__GunName__6, TweenInfo.new(3, Enum.EasingStyle.Cubic), {
        TextTransparency = 1
    }):Play();
end;
return v1;