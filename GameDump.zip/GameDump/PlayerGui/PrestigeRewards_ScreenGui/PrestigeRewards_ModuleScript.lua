-- Roblox: Players.SilverAce293026.PlayerGui.PrestigeRewards.PrestigeRewards
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
local l__Players__1 = game:GetService("Players");
local l__ReplicatedStorage__2 = game:GetService("ReplicatedStorage");
local l__Modules__3 = l__ReplicatedStorage__2:WaitForChild("Modules");
require(l__Modules__3:WaitForChild("GuiModule"));
game:GetService("StarterGui");
local l__LocalPlayer__4 = l__Players__1.LocalPlayer;
local l__PlayerGui__5 = l__LocalPlayer__4:WaitForChild("PlayerGui");
local l__FadeGui__6 = l__PlayerGui__5:WaitForChild("FadeGui");
local l__FadeModule__7 = require(l__FadeGui__6:WaitForChild("FadeModule"));
local l__PrestigeRewardArea__8 = workspace:WaitForChild("PrestigeRewardArea");
local l__PrestigeRewardMesh__9 = l__ReplicatedStorage__2:WaitForChild("PrestigeRewardMesh");
local l__RunService__10 = game:GetService("RunService");
local u2 = {};
local l__Vehicles__11 = l__ReplicatedStorage__2:WaitForChild("Vehicles");
local l__Helicopters__12 = l__ReplicatedStorage__2:WaitForChild("Helicopters");
local l__Planes__13 = l__ReplicatedStorage__2:WaitForChild("Planes");
local l__GunModels__14 = l__ReplicatedStorage__2:WaitForChild("ACS_Engine"):WaitForChild("GunModels");
local u3 = Vector3.new();
local function u6(p4) --[[ Line: 28 ]]
    -- upvalues: l__PrestigeRewardArea__8 (copy), l__ReplicatedStorage__2 (copy)
    if p4 then
        if l__PrestigeRewardArea__8:FindFirstChild("Helipad") then
        else
            local v5 = l__ReplicatedStorage__2:WaitForChild("Helipad"):Clone();
            v5.Parent = l__PrestigeRewardArea__8;
            v5:PivotTo(l__PrestigeRewardArea__8.SpawnPart.CFrame * CFrame.Angles(1.5707963267948966, 0, 0));
        end;
    elseif l__PrestigeRewardArea__8:FindFirstChild("Helipad") then
        l__PrestigeRewardArea__8.Helipad:Destroy();
    end;
end;
function u1.DisplayVehicle(p7, p8) --[[ Line: 40 ]]
    -- upvalues: l__FadeModule__7 (copy), l__Vehicles__11 (copy), l__Helicopters__12 (copy), l__Planes__13 (copy), u6 (copy), l__PrestigeRewardArea__8 (copy), l__LocalPlayer__4 (copy)
    if not p8 then
        l__FadeModule__7.FadeYield(true, 0.2);
    end;
    local v9 = l__Vehicles__11:FindFirstChild(p7) or (l__Helicopters__12:FindFirstChild(p7) or l__Planes__13:FindFirstChild(p7));
    local v10 = v9.Parent == l__Helicopters__12 and true or v9.Parent == l__Planes__13;
    u6(v10);
    for _, v11 in l__PrestigeRewardArea__8:GetChildren() do
        if v11.Name ~= "Helipad" and v11:IsA("Model") then
            v11:Destroy();
        end;
    end;
    local v12 = v9:Clone();
    v12.Parent = l__PrestigeRewardArea__8;
    local v13 = v12:GetAttribute("SpawnOffset") or Vector3.new(0, -2, 0);
    v12:PivotTo((v10 and l__PrestigeRewardArea__8.Helipad.HeliPadFloor or l__PrestigeRewardArea__8.SpawnPart).CFrame * CFrame.new(-v13 + Vector3.new(0, 10, 0)) * CFrame.Angles(0, v10 and 3.141592653589793, 0));
    l__LocalPlayer__4.Character:PivotTo(l__PrestigeRewardArea__8.CamPart.CFrame * CFrame.new(0, 0, 5));
    if not p8 then
        task.wait(0.6);
        l__FadeModule__7.FadeYield(false, 0.2);
    end;
end;
function u1.DisplayGun(p14, p15) --[[ Line: 72 ]]
    -- upvalues: l__FadeModule__7 (copy), l__PrestigeRewardArea__8 (copy), l__GunModels__14 (copy)
    if not p15 then
        l__FadeModule__7.FadeYield(true, 0.2);
    end;
    if l__PrestigeRewardArea__8:FindFirstChild("Helipad") then
        l__PrestigeRewardArea__8.Helipad:Destroy();
    end;
    for _, v16 in l__PrestigeRewardArea__8:GetChildren() do
        if v16.Name ~= "Helipad" and v16:IsA("Model") then
            v16:Destroy();
        end;
    end;
    local v17 = l__GunModels__14:FindFirstChild(p14):Clone();
    v17.Parent = l__PrestigeRewardArea__8;
    for _, v18 in v17:GetDescendants() do
        if v18:IsA("BasePart") then
            v18.Anchored = true;
        end;
    end;
    v17:PivotTo(workspace.CurrentCamera.CFrame * CFrame.new(0, 0, -5) * CFrame.Angles(0, 1.5707963267948966, 0));
    if not p15 then
        task.wait(0.6);
        l__FadeModule__7.FadeYield(false, 0.2);
    end;
end;
function u1.Hide() --[[ Line: 99 ]]
    -- upvalues: l__FadeModule__7 (copy), l__PrestigeRewardMesh__9 (copy), l__ReplicatedStorage__2 (copy), u2 (ref), l__LocalPlayer__4 (copy), u3 (ref), l__PrestigeRewardArea__8 (copy), l__PlayerGui__5 (copy), l__Players__1 (copy)
    l__FadeModule__7.FadeYield(true, 0.5);
    l__PrestigeRewardMesh__9.Parent = l__ReplicatedStorage__2;
    for _, v19 in u2 do
        v19:Disconnect();
    end;
    u2 = {};
    l__LocalPlayer__4.Character:PivotTo(u3);
    for _, v20 in l__PrestigeRewardArea__8:GetChildren() do
        if v20:IsA("Model") then
            v20:Destroy();
        end;
    end;
    l__PlayerGui__5.ShopGui.Enabled = true;
    local v21 = l__Players__1.LocalPlayer.PlayerGui:FindFirstChild("CustomToolbar");
    if v21 then
        v21.Enabled = true;
    end;
    workspace.CurrentCamera.CameraType = Enum.CameraType.Custom;
    workspace.CurrentCamera.CameraSubject = l__LocalPlayer__4.Character.Humanoid;
    script.Parent.Enabled = false;
    l__FadeModule__7.FadeYield(false, 0.5);
end;
function u1.Show() --[[ Line: 124 ]]
    -- upvalues: l__Players__1 (copy), l__PlayerGui__5 (copy), l__LocalPlayer__4 (copy), l__RunService__10 (copy), l__FadeModule__7 (copy), l__PrestigeRewardMesh__9 (copy), u2 (ref), l__PrestigeRewardArea__8 (copy), u1 (copy), u3 (ref)
    local v22 = l__Players__1.LocalPlayer.PlayerGui:FindFirstChild("CustomToolbar");
    if v22 then
        v22.Enabled = false;
    end;
    l__PlayerGui__5.ShopGui.Enabled = false;
    l__LocalPlayer__4.Character:FindFirstChildOfClass("Humanoid"):UnequipTools();
    l__RunService__10.RenderStepped:Wait();
    l__FadeModule__7.FadeYield(true);
    l__PrestigeRewardMesh__9.Parent = workspace;
    table.insert(u2, l__RunService__10.RenderStepped:Connect(function() --[[ Line: 137 ]]
        -- upvalues: l__PrestigeRewardArea__8 (ref)
        local l__CurrentCamera__15 = workspace.CurrentCamera;
        l__CurrentCamera__15.CameraType = Enum.CameraType.Scriptable;
        l__CurrentCamera__15.CameraSubject = nil;
        l__CurrentCamera__15.CFrame = l__PrestigeRewardArea__8.CamPart.CFrame;
    end));
    table.insert(u2, l__LocalPlayer__4.Character.Humanoid.Died:Connect(function() --[[ Line: 144 ]]
        -- upvalues: u1 (ref)
        u1.Hide();
    end));
    u3 = l__LocalPlayer__4.Character.PrimaryPart.CFrame;
    task.wait(0.3);
    script.Parent.Enabled = true;
    l__FadeModule__7.FadeYield(false);
end;
return u1;