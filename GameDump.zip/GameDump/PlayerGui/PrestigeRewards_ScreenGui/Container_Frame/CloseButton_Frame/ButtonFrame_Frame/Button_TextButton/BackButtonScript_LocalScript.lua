-- Roblox: Players.SilverAce293026.PlayerGui.PrestigeRewards.Container.CloseButton.ButtonFrame.Button.BackButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__PrestigeRewards__1 = require(script.Parent.Parent.Parent.Parent.Parent:WaitForChild("PrestigeRewards"));
local u1 = false;
script.Parent.Activated:Connect(function() --[[ Line: 3 ]]
    -- upvalues: u1 (ref), l__PrestigeRewards__1 (copy)
    if u1 then
    else
        u1 = true;
        l__PrestigeRewards__1.Hide();
        u1 = false;
    end;
end);