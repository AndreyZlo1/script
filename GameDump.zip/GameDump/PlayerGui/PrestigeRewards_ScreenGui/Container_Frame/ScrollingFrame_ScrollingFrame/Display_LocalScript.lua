-- Roblox: Players.SilverAce293026.PlayerGui.PrestigeRewards.Container.ScrollingFrame.Display
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Modules__2 = l__ReplicatedStorage__1:WaitForChild("Modules");
local l__RunService__3 = game:GetService("RunService");
local l__Vehicles__4 = l__ReplicatedStorage__1:WaitForChild("Vehicles");
local l__Helicopters__5 = l__ReplicatedStorage__1:WaitForChild("Helicopters");
local l__Planes__6 = l__ReplicatedStorage__1:WaitForChild("Planes");
local l__PrestigeModule__7 = require(l__Modules__2:WaitForChild("PrestigeModule"));
local l__PrestigeRewards__8 = require(script.Parent.Parent.Parent:WaitForChild("PrestigeRewards"));
local l__Prototype__9 = script.Parent:WaitForChild("Prototype");
local l__GuiModule__10 = require(l__Modules__2:WaitForChild("GuiModule"));
local u1 = {};
local u2 = {
    "Grapple Hook",
    ".44 Magnum",
    "Tanks",
    "Mil-24 Hind",
    "A-10 Warthog"
};
for v3, v4 in l__PrestigeModule__7.Rewards do
    for v5, v6 in v4 do
        if not u1[v5] then
            u1[v5] = {};
        end;
        for _, v7 in v6 do
            table.insert(u1[v5], {
                Name = v7,
                Type = v3
            });
        end;
    end;
end;
local u8 = false;
local function u20(p9) --[[ Line: 40 ]]
    -- upvalues: u1 (copy), l__Prototype__9 (copy), u2 (copy), l__Vehicles__4 (copy), l__Helicopters__5 (copy), l__Planes__6 (copy), l__ReplicatedStorage__1 (copy), u8 (ref), l__PrestigeRewards__8 (copy), l__GuiModule__10 (copy), l__RunService__3 (copy)
    local v10 = u1[p9];
    local v11 = (#v10 - 1) * 0.13 + 0.14;
    local v12 = l__Prototype__9:Clone();
    v12.Name = p9;
    v12.Size = UDim2.new(v11, -15, 1, -15);
    v12.Title.Text = string.format("Prestige %s", p9);
    if p9 > 4 then
        v12.Title.Text = "";
    end;
    v12.Sub.Text = u2[p9];
    v12.Parent = script.Parent;
    v12.Visible = true;
    for _, u13 in v10 do
        local v14;
        if u13.Type == "Vehicles" then
            v14 = l__Vehicles__4:FindFirstChild(u13.Name) and l__Vehicles__4 or (l__Helicopters__5:FindFirstChild(u13.Name) and l__Helicopters__5 or l__Planes__6);
        else
            v14 = l__ReplicatedStorage__1:WaitForChild("ACS_Engine"):WaitForChild("GunModels");
        end;
        local u15 = v12.Inner.Prototype:Clone();
        u15.Parent = v12.Inner;
        u15.Name = u13.Name;
        u15.Action.Activated:Connect(function() --[[ Line: 68 ]]
            -- upvalues: u8 (ref), u13 (copy), l__PrestigeRewards__8 (ref), u15 (copy)
            if u8 then
            else
                u8 = true;
                task.spawn(function() --[[ Line: 71 ]]
                    -- upvalues: u13 (ref), l__PrestigeRewards__8 (ref), u8 (ref)
                    if u13.Type == "Vehicles" then
                        l__PrestigeRewards__8.DisplayVehicle(u13.Name);
                    else
                        l__PrestigeRewards__8.DisplayGun(u13.Name);
                    end;
                    u8 = false;
                end);
                task.wait(0.25);
                u15.UIGradient.Enabled = true;
                u15.BackgroundColor3 = Color3.fromRGB(255, 255, 255);
                for _, v16 in script.Parent:GetChildren() do
                    if v16:IsA("Frame") then
                        for _, v17 in v16.Inner:GetChildren() do
                            if v17 ~= u15 and v17:IsA("Frame") then
                                v17.UIGradient.Enabled = false;
                                v17.BackgroundColor3 = Color3.fromRGB();
                            end;
                        end;
                    end;
                end;
            end;
        end);
        local v18 = v14:FindFirstChild(u13.Name):Clone();
        v18.Parent = u15.Action.ViewportFrame;
        local v19 = Instance.new("Camera");
        v19.Parent = script;
        u15.Action.ViewportFrame.CurrentCamera = v19;
        l__GuiModule__10.CameraZoom.setupWorldModel(u15.Action.ViewportFrame, v18);
        l__RunService__3.Heartbeat:Wait();
        l__GuiModule__10.CameraZoom.zoomToExtents(v19, v18, 135, -30);
        u15.Visible = true;
    end;
end;
script.Parent.Parent.Parent:GetPropertyChangedSignal("Enabled"):Once(function() --[[ Line: 111 ]]
    -- upvalues: u2 (copy), u1 (copy), u20 (copy)
    if game.Players.LocalPlayer:GetAttribute("PopulationType") == 0 then
        u2[3] = "T-72";
    end;
    if game.Players.LocalPlayer:GetAttribute("PopulationType") == 2 then
        u2[4] = "Helicopters";
    end;
    for v21, _ in u1 do
        u20(v21);
    end;
end);
script.Parent.Parent.Parent:GetPropertyChangedSignal("Enabled"):Connect(function() --[[ Line: 123 ]]
    -- upvalues: u1 (copy), l__PrestigeRewards__8 (copy)
    -- block 19
    if not script.Parent.Parent.Parent.Enabled then
        for _, v22 in script.Parent:GetChildren() do
            if v22:IsA("Frame") then
                for _, v23 in v22.Inner:GetChildren() do
                    if v23:IsA("Frame") then
                        v23.UIGradient.Enabled = false;
                        v23.BackgroundColor3 = Color3.fromRGB();
                    end;
                end;
            end;
        end;
        return;
    end;
    local v24 = game.Players.LocalPlayer.leaderstats.Prestige.Value + 1;
    local v25 = u1[v24];
    if not v25 then
        return;
    end;
    local v26, v27, v28;
    v26, v27, v28 = v25, nil, nil;
    local v29, v30, v31;
    if type(v26) == "function" then
        v29, v30 = v26(v27, v31);
    else
        v29, v30 = next(v26, v31);
    end;
    v31 = v29;
    -- block 1
    if v30.Type == "Vehicles" then
        l__PrestigeRewards__8.DisplayVehicle(v30.Name, true);
    else
        l__PrestigeRewards__8.DisplayGun(v30.Name, true);
    end;
    local v32 = script.Parent:WaitForChild((tostring(v24))).Inner[v30.Name];
    v32.BackgroundColor3 = Color3.fromRGB(255, 255, 255);
    v32.UIGradient.Enabled = true;
    return;
    if v30.Type == "Vehicles" then
        l__PrestigeRewards__8.DisplayVehicle(v30.Name, true);
    else
        l__PrestigeRewards__8.DisplayGun(v30.Name, true);
    end;
    v32 = script.Parent:WaitForChild((tostring(v24))).Inner[v30.Name];
    v32.BackgroundColor3 = Color3.fromRGB(255, 255, 255);
    v32.UIGradient.Enabled = true;
end);