-- Roblox: Players.SilverAce293026.PlayerGui.QuestProgressGui.ProgressModule
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__TweenService__1 = game:GetService("TweenService");
local l__Background__2 = script.Parent:WaitForChild("Background");
local l__PartList__3 = l__Background__2:WaitForChild("PartList");
local l__UQTitle__4 = l__Background__2:WaitForChild("UQTitle");
local l__UnlockLabel__5 = l__Background__2:WaitForChild("UnlockLabel");
local l__PartLabel__6 = l__Background__2:WaitForChild("PartLabel");
local l__PartProto__7 = l__PartList__3:WaitForChild("PartProto");
local u2 = TweenInfo.new(0.3, Enum.EasingStyle.Quint, Enum.EasingDirection.Out);
local u3 = TweenInfo.new(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out);
local l__Parent__8 = script.Parent;
local function u9(p4) --[[ Line: 20 ]]
    -- upvalues: l__PartList__3 (copy), l__PartProto__7 (copy)
    for _, v5 in l__PartList__3:GetChildren() do
        if not v5:IsA("UIGridLayout") and v5 ~= l__PartProto__7 then
            v5:Destroy();
        end;
    end;
    for v6, v7 in p4 do
        local v8 = l__PartProto__7:Clone();
        v8.Name = v6;
        v8.Parent = l__PartList__3;
        v8.Visible = true;
        v8.Text = v6;
        v8.TextTransparency = v7 and 0 or 0.5;
        v8.TextColor3 = v7 and Color3.fromRGB(85, 255, 127) or Color3.fromRGB(255, 255, 255);
    end;
end;
function v1.ShowUI(p10, p11, p12) --[[ Line: 38 ]]
    -- upvalues: l__Parent__8 (copy), l__UnlockLabel__5 (copy), l__PartLabel__6 (copy), l__TweenService__1 (copy), u2 (copy), u3 (copy), l__UQTitle__4 (copy), u9 (copy), l__PartList__3 (copy), l__PartProto__7 (copy)
    l__Parent__8.Enabled = true;
    l__UnlockLabel__5.Text = p10;
    l__PartLabel__6.Text = `Found <b>{p11}</b> Part`;
    l__UnlockLabel__5.MaxVisibleGraphemes = 0;
    l__UnlockLabel__5.Size = UDim2.new(0, 0, 0.2, 0);
    local v13 = { l__TweenService__1:Create(l__UnlockLabel__5, u2, {
            Size = UDim2.new(1, 0, 0.2, 0)
        }), l__TweenService__1:Create(l__UnlockLabel__5, u3, {
            MaxVisibleGraphemes = #l__UnlockLabel__5.Text
        }) };
    l__PartLabel__6.TextTransparency = 1;
    local v14 = l__TweenService__1:Create(l__PartLabel__6, u2, {
        TextTransparency = 0
    });
    for v15 = 0, 7 do
        task.wait(0.1);
        l__UQTitle__4.TextTransparency = v15 % 2 == 0 and 1 or 0;
    end;
    for _, v16 in ipairs(v13) do
        v16:Play();
        v16.Completed:Wait();
    end;
    v14:Play();
    u9(p12);
    local v17 = {};
    for _, v18 in l__PartList__3:GetChildren() do
        if not v18:IsA("UIGridLayout") and v18 ~= l__PartProto__7 then
            local l__TextTransparency__9 = v18.TextTransparency;
            v18.TextTransparency = 1;
            local v19 = l__TweenService__1:Create(v18, u2, {
                TextTransparency = l__TextTransparency__9
            });
            table.insert(v17, v19);
        end;
    end;
    for _, v20 in v17 do
        v20:Play();
        task.wait(u2.Time * 0.8);
    end;
    local v21 = l__PartList__3[p11];
    v21.TextColor3 = Color3.fromRGB(255, 255, 255);
    for v22 = 1, 9 do
        task.wait(0.1);
        local v23 = v22 % 2 == 0;
        v21.TextTransparency = v23 and 0.5 or 0;
        v21.TextColor3 = v23 and Color3.fromRGB(255, 255, 255) or Color3.fromRGB(85, 255, 127);
    end;
    task.wait(2);
    l__Parent__8.Enabled = false;
    for _, v24 in l__PartList__3:GetChildren() do
        if not v24:IsA("UIGridLayout") and v24 ~= l__PartProto__7 then
            v24:Destroy();
        end;
    end;
end;
return v1;