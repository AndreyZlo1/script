-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.GroundVehiclesMenu.BottomAction.RobuxPurchaseButton.ButtonFrame.Button.RobuxPurchaseButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__MarketplaceService__1 = game:GetService("MarketplaceService");
local l__Modules__2 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local l__GuiModule__3 = require(l__Modules__2:WaitForChild("GuiModule"));
local l__LocalPlayer__4 = game:GetService("Players").LocalPlayer;
local l__Parent__5 = script.Parent;
local l__Parent__6 = l__Parent__5.Parent;
repeat
    l__Parent__6 = l__Parent__6.Parent;
until l__Parent__6.Name == "GroundVehiclesMenu";
local l__CurrentPassId__7 = l__Parent__6:WaitForChild("CurrentPassId");
local u1 = false;
l__GuiModule__3.setupButtonSounds(l__Parent__5);
l__Parent__5.MouseButton1Click:connect(function() --[[ Line: 17 ]]
    -- upvalues: u1 (ref), l__CurrentPassId__7 (copy), l__MarketplaceService__1 (copy), l__LocalPlayer__4 (copy), l__GuiModule__3 (copy), l__Parent__5 (copy)
    if u1 == true or l__CurrentPassId__7.Value < 1 then
    else
        u1 = true;
        l__MarketplaceService__1:PromptGamePassPurchase(l__LocalPlayer__4, l__CurrentPassId__7.Value);
        l__GuiModule__3.buttonPress(l__Parent__5.Parent);
        task.wait(0.2);
        l__GuiModule__3.buttonLift(l__Parent__5.Parent);
        task.wait(1);
        u1 = false;
    end;
end);