-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.GroundVehiclesMenu.BottomAction.SpawnButton.ButtonFrame.Button.SpawnButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Modules__2 = l__ReplicatedStorage__1:WaitForChild("Modules");
local l__RequestGroundVehicleEvent__3 = l__ReplicatedStorage__1:WaitForChild("RequestGroundVehicleEvent");
local l__RequestHelicopterEvent__4 = l__ReplicatedStorage__1:WaitForChild("RequestHelicopterEvent");
local l__GuiModule__5 = require(l__Modules__2:WaitForChild("GuiModule"));
local _ = game:GetService("Players").LocalPlayer;
local l__Parent__6 = script.Parent;
repeat
    l__Parent__6 = l__Parent__6.Parent;
until l__Parent__6.Name == "ShopGui";
local l__ShopModule__7 = require(l__Parent__6:WaitForChild("ShopModule"));
local l__Parent__8 = script.Parent;
local l__Parent__9 = l__Parent__8.Parent;
repeat
    l__Parent__9 = l__Parent__9.Parent;
until l__Parent__9.Name == "GroundVehiclesMenu";
local l__CurrentVehicle__10 = l__Parent__9:WaitForChild("CurrentVehicle");
local l__Mode__11 = l__Parent__9:WaitForChild("Mode");
local u1 = false;
l__GuiModule__5.setupButtonSounds(l__Parent__8);
l__Parent__8.MouseButton1Click:connect(function() --[[ Line: 25 ]]
    -- upvalues: u1 (ref), l__Mode__11 (copy), l__RequestGroundVehicleEvent__3 (copy), l__RequestHelicopterEvent__4 (copy), l__CurrentVehicle__10 (copy), l__GuiModule__5 (copy), l__Parent__8 (copy), l__ShopModule__7 (copy)
    if u1 == true then
    else
        u1 = true;
        (l__Mode__11.Value == "GroundVehicles" and l__RequestGroundVehicleEvent__3 or l__RequestHelicopterEvent__4):FireServer(l__CurrentVehicle__10.Value);
        l__GuiModule__5.buttonPress(l__Parent__8.Parent);
        task.wait(0.2);
        l__GuiModule__5.Sounds.modalOut(true);
        l__GuiModule__5.Sounds.stopHangarAmbient();
        l__ShopModule__7.resetVehicleMenuState();
        task.wait(7);
        u1 = false;
    end;
end);