-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.GroundVehiclesMenu.BottomAction.PurchaseButton.ButtonFrame.Button.PurchaseButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Modules__2 = l__ReplicatedStorage__1:WaitForChild("Modules");
local l__GuiModule__3 = require(l__Modules__2:WaitForChild("GuiModule"));
local l__RequestVehiclePurchaseEvent__4 = l__ReplicatedStorage__1:WaitForChild("RequestVehiclePurchaseEvent");
local l__RequestHeliPurchaseEvent__5 = l__ReplicatedStorage__1:WaitForChild("RequestHeliPurchaseEvent");
local _ = game:GetService("Players").LocalPlayer;
local l__Parent__6 = script.Parent;
local l__Parent__7 = l__Parent__6.Parent;
repeat
    l__Parent__7 = l__Parent__7.Parent;
until l__Parent__7.Name == "GroundVehiclesMenu";
local l__CurrentVehicle__8 = l__Parent__7:WaitForChild("CurrentVehicle");
local l__Mode__9 = l__Parent__7:WaitForChild("Mode");
local u1 = false;
l__GuiModule__3.setupButtonSounds(l__Parent__6);
l__Parent__6.MouseButton1Click:connect(function() --[[ Line: 20 ]]
    -- upvalues: u1 (ref), l__Mode__9 (copy), l__RequestVehiclePurchaseEvent__4 (copy), l__RequestHeliPurchaseEvent__5 (copy), l__CurrentVehicle__8 (copy), l__GuiModule__3 (copy), l__Parent__6 (copy)
    if u1 == true then
    else
        u1 = true;
        (l__Mode__9.Value == "GroundVehicles" and l__RequestVehiclePurchaseEvent__4 or l__RequestHeliPurchaseEvent__5):FireServer(l__CurrentVehicle__8.Value);
        task.wait(0.2);
        l__GuiModule__3.buttonLift(l__Parent__6.Parent);
        task.wait(1);
        u1 = false;
    end;
end);