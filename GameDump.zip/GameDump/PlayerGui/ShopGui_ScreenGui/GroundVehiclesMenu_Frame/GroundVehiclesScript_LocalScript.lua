-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.GroundVehiclesMenu.GroundVehiclesScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Players__1 = game:GetService("Players");
local l__ReplicatedStorage__2 = game:GetService("ReplicatedStorage");
local l__MarketplaceService__3 = game:GetService("MarketplaceService");
game:GetService("TweenService");
local l__Modules__4 = l__ReplicatedStorage__2:WaitForChild("Modules");
local l__RunService__5 = game:GetService("RunService");
local l__GuiModule__6 = require(l__Modules__4:WaitForChild("GuiModule"));
local l__Tanks__7 = require(l__Modules__4:WaitForChild("PopulationType"):WaitForChild("Tanks"));
local l__Helicopters__8 = require(l__Modules__4.PopulationType:WaitForChild("Helicopters"));
local l__LocalPlayer__9 = l__Players__1.LocalPlayer;
if require(l__ReplicatedStorage__2:WaitForChild("ReplicatedConfig")).Mode == "Tycoon" then
    local l__AssociatedTycoon__10 = l__LocalPlayer__9:WaitForChild("AssociatedTycoon");
    local u1 = workspace:WaitForChild(l__AssociatedTycoon__10.Value);
    local l__Vehicles__11 = u1:WaitForChild("Vehicles");
    local l__Helicopters__12 = u1:WaitForChild("Helicopters");
    local l__leaderstats__13 = l__LocalPlayer__9:WaitForChild("leaderstats");
    local l__Money__14 = l__leaderstats__13:WaitForChild("Money");
    local l__CurrentVehicle__15 = script.Parent:WaitForChild("CurrentVehicle");
    local l__CurrentPassId__16 = script.Parent:WaitForChild("CurrentPassId");
    local l__Mode__17 = script.Parent:WaitForChild("Mode");
    local u2 = {
        "ATV",
        "Dune Buggy",
        "L-ATV",
        "Humvee",
        "BTR-80",
        "M142 HIMARS",
        "Leopard Evo",
        "Tank",
        "M4 Sherman",
        "T-72"
    };
    local u3 = {
        "MH-6 Little Bird",
        "UH-60 Black Hawk",
        "RAH-66 Comanche",
        "AH-1Z Viper",
        "Mil-24 Hind"
    };
    local l__ViewportFrame__18 = script.Parent:WaitForChild("ViewportFrame");
    local u4 = nil;
    local l__Vehicles__19 = l__ReplicatedStorage__2:WaitForChild("Vehicles");
    local l__Helicopters__20 = l__ReplicatedStorage__2:WaitForChild("Helicopters");
    local v5 = Instance.new("Camera");
    l__ViewportFrame__18.CurrentCamera = v5;
    v5.Parent = l__ViewportFrame__18;
    v5.CFrame = CFrame.new(Vector3.new(-17, 11, -17), Vector3.new(0, 0, 0));
    local l__VehicleInfo__21 = script.Parent:WaitForChild("VehicleInfo");
    local l__Name__22 = l__VehicleInfo__21:WaitForChild("Name");
    local l__Cost__23 = l__VehicleInfo__21:WaitForChild("Cost");
    local u6 = Color3.new(0, 1, 0.5);
    local u7 = Color3.new(0.662745, 0.662745, 0.662745);
    local u8 = Color3.new(1, 0.81181, 0.394903);
    local l__BottomAction__24 = script.Parent:WaitForChild("BottomAction");
    local l__PurchaseButton__25 = l__BottomAction__24:WaitForChild("PurchaseButton");
    local l__RobuxPurchaseButton__26 = l__BottomAction__24:WaitForChild("RobuxPurchaseButton");
    local l__SpawnButton__27 = l__BottomAction__24:WaitForChild("SpawnButton");
    local l__NotEnoughLabel__28 = l__BottomAction__24:WaitForChild("NotEnoughLabel");
    local l__RightButton__29 = script.Parent:WaitForChild("RightButton");
    local l__LeftButton__30 = script.Parent:WaitForChild("LeftButton");
    script.Parent:WaitForChild("EvoGradient");
    local u9 = nil;
    local u10 = nil;
    local u11 = true;
    local v12 = l__Mode__17.Value == "GroundVehicles";
    u10 = v12 and u2 and u2 or u3;
    u9 = v12 and l__Vehicles__19 and l__Vehicles__19 or l__Helicopters__20;
    l__CurrentVehicle__15.Value = u10[1];
    l__LeftButton__30.Visible = false;
    l__RightButton__29.Visible = true;
    local function u15(p13) --[[ Line: 112 ]]
        -- upvalues: l__RobuxPurchaseButton__26 (copy), l__PurchaseButton__25 (copy), l__NotEnoughLabel__28 (copy), l__SpawnButton__27 (copy), l__Cost__23 (copy), u7 (copy), u8 (copy), u6 (copy)
        for _, v14 in {
            l__RobuxPurchaseButton__26,
            l__PurchaseButton__25,
            l__NotEnoughLabel__28,
            l__SpawnButton__27
        } do
            v14.Visible = false;
        end;
        l__Cost__23.TextColor3 = u7;
        l__Cost__23.Visible = true;
        if p13 then
            if p13.Type == "BuyPass" then
                l__RobuxPurchaseButton__26.Visible = true;
                l__Cost__23.TextColor3 = u8;
            elseif p13.Type == "BuyVehicle" then
                l__PurchaseButton__25.Visible = true;
            else
                if p13.Type == "Spawn" then
                    l__SpawnButton__27.Visible = true;
                    l__Cost__23.TextColor3 = u6;
                end;
            end;
        else
            l__Cost__23.Text = "";
        end;
    end;
    local function u31() --[[ Line: 133 ]]
        -- upvalues: l__CurrentVehicle__15 (copy), l__Name__22 (copy), l__Cost__23 (copy), u7 (copy), l__PurchaseButton__25 (copy), l__SpawnButton__27 (copy), l__NotEnoughLabel__28 (copy), u4 (ref), u9 (ref), l__ViewportFrame__18 (copy), l__GuiModule__6 (copy), l__RunService__5 (copy), l__Vehicles__11 (copy), l__Helicopters__12 (copy), l__LocalPlayer__9 (copy), l__CurrentPassId__16 (copy), l__MarketplaceService__3 (copy), l__leaderstats__13 (copy), u8 (copy), u6 (copy), l__RobuxPurchaseButton__26 (copy), l__Money__14 (copy), l__Helicopters__8 (copy), l__Tanks__7 (copy), u1 (copy), u15 (copy)
        if l__CurrentVehicle__15.Value == "Coming Soon" then
            l__Name__22.Text = "More to come";
            l__Cost__23.Text = "Soon :)";
            l__Cost__23.TextColor3 = u7;
            l__PurchaseButton__25.Visible = false;
            l__SpawnButton__27.Visible = false;
            l__NotEnoughLabel__28.Visible = false;
            if u4 then
                u4:Destroy();
                u4 = nil;
            end;
        else
            if not u4 or u4.Name ~= l__CurrentVehicle__15.Value then
                if u4 then
                    u4:Destroy();
                    u4 = nil;
                end;
                local v16 = u9:FindFirstChild(l__CurrentVehicle__15.Value);
                if v16 then
                    u4 = v16:Clone();
                    u4.Parent = l__ViewportFrame__18;
                    if u9.Name == "Helicopters" then
                        l__GuiModule__6.CameraZoom.setupWorldModel(l__ViewportFrame__18, u4);
                        l__RunService__5.Heartbeat:Wait();
                    end;
                    l__GuiModule__6.CameraZoom.zoomToExtents(l__ViewportFrame__18.CurrentCamera, u4, 135, -30);
                end;
            end;
            local v17 = l__Vehicles__11:FindFirstChild(l__CurrentVehicle__15.Value) or l__Helicopters__12:FindFirstChild(l__CurrentVehicle__15.Value);
            local v18 = l__LocalPlayer__9:GetAttribute("PopulationType") or 0;
            local v19 = u4:GetAttribute("IsTank") or v17.Parent.Name == "Helicopters";
            local v20;
            if v17 then
                v20 = v17:FindFirstChild("PassId");
            else
                v20 = v17;
            end;
            l__CurrentPassId__16.Value = v20 and (v20.Value or 0) or 0;
            local v21;
            if v20 then
                v21 = l__MarketplaceService__3:GetProductInfo(v20.Value, Enum.InfoType.GamePass);
            else
                v21 = v20;
            end;
            local v22 = v17:FindFirstChild("Cost");
            local _ = v22 and v22.Value;
            local v23 = l__Name__22;
            local l__Value__31 = l__CurrentVehicle__15.Value;
            v23.Text = l__Value__31 == "RAH-66 Comanche" and "Comanche" or (l__Value__31 == "Tank" and "M1A2 Abrams" or l__Value__31);
            local v24;
            if v17 then
                v24 = v17:FindFirstChild("Prestige");
            else
                v24 = v17;
            end;
            local v25 = v24 and (v24.Value or 0) or 0;
            if v19 then
                local v26 = (v17.Parent.Name == "Helicopters" and l__Helicopters__8 or l__Tanks__7).PopTypeDelegateMap[v18].GetVehicleOwnershipState(l__LocalPlayer__9, u1, v17.Name);
                u15(v26.Button);
                l__Cost__23.Text = v26.Message;
            else
                if v24 and (v17 and l__leaderstats__13.Prestige.Value < v25) then
                    local v27 = l__Name__22;
                    local l__Value__32 = l__CurrentVehicle__15.Value;
                    v27.Text = l__Value__32 == "RAH-66 Comanche" and "Comanche" or (l__Value__32 == "Tank" and "M1A2 Abrams" or l__Value__32);
                    l__Cost__23.Text = string.format("Unlocked at Prestige %s", v25);
                    l__PurchaseButton__25.Visible = false;
                    l__SpawnButton__27.Visible = false;
                    l__NotEnoughLabel__28.Visible = false;
                elseif not (v17 and (v17:FindFirstChild("Cost") or v20 and (v21 and v21.IsForSale) or v24)) then
                    l__Name__22.Text = "Oopsie, error";
                    l__Cost__23.Text = "Please report this to StaySpy and sorry :(";
                    l__PurchaseButton__25.Visible = false;
                    l__SpawnButton__27.Visible = false;
                    l__NotEnoughLabel__28.Visible = false;
                    return;
                end;
                l__Cost__23.Visible = not v17.Value;
                local v28;
                if v21 then
                    v28 = v21.PriceInRobux;
                else
                    v28 = v24 and 0 or v17.Cost.Value;
                end;
                local v29 = v20 ~= nil;
                if v17.Value then
                    l__Cost__23.Text = "Owned";
                    l__Cost__23.TextColor3 = u6;
                else
                    l__Cost__23.Text = not v24 and l__GuiModule__6.format(v28, v29) or string.format("Unlocked at Prestige %s", v25);
                    l__Cost__23.TextColor3 = v29 and u8 or u7;
                end;
                local l__Value__33 = v17.Value;
                local v30 = v24 ~= nil;
                l__RobuxPurchaseButton__26.Visible = false;
                l__PurchaseButton__25.Visible = false;
                l__NotEnoughLabel__28.Visible = false;
                l__SpawnButton__27.Visible = false;
                if l__Value__33 then
                    l__SpawnButton__27.Visible = true;
                elseif v29 then
                    l__RobuxPurchaseButton__26.Visible = true;
                elseif v30 then
                    l__Cost__23.Visible = true;
                elseif v28 <= l__Money__14.Value then
                    l__PurchaseButton__25.Visible = true;
                else
                    l__NotEnoughLabel__28.Visible = true;
                end;
                l__Cost__23.Visible = true;
            end;
        end;
    end;
    local function u42(p32, p33) --[[ Line: 238 ]]
        -- upvalues: u11 (ref), u4 (ref), l__VehicleInfo__21 (copy), l__BottomAction__24 (copy), l__CurrentVehicle__15 (copy)
        if u11 then
            u11 = false;
            if u4 then
                u4:Destroy();
                u4 = nil;
            end;
            local v34 = UDim2.new(0, 0, 0, 0);
            local v35 = UDim2.new(0, 0, 0.75, 0);
            local v36 = UDim2.new(-1, 0, 0, 0);
            local v37 = UDim2.new(1, 0, 0, 0);
            local v38 = UDim2.new(-1, 0, 0.75, 0);
            local v39 = UDim2.new(1, 0, 0.75, 0);
            TweenInfo.new(0.15, Enum.EasingStyle.Circular, Enum.EasingDirection.Out);
            ({}).Offset = Vector2.new(2, 0);
            ({}).Offset = Vector2.new(0, 0);
            l__VehicleInfo__21:TweenPosition(p33 and v37 and v37 or v36, nil, nil, 0.15, true);
            l__BottomAction__24:TweenPosition(p33 and v39 and v39 or v38, nil, nil, 0.15, true);
            task.wait(0.15);
            l__CurrentVehicle__15.Value = p32;
            local v40 = l__VehicleInfo__21;
            if p33 then
                v37 = v36 or v37;
            end;
            v40.Position = v37;
            local v41 = l__BottomAction__24;
            if p33 then
                v39 = v38 or v39;
            end;
            v41.Position = v39;
            l__VehicleInfo__21:TweenPosition(v34, nil, nil, 0.15, true);
            l__BottomAction__24:TweenPosition(v35, nil, nil, 0.15, true);
            task.wait(0.15);
            u11 = true;
        end;
    end;
    local function u46(p43) --[[ Line: 278 ]]
        -- upvalues: u11 (ref), u10 (ref), l__CurrentVehicle__15 (copy), l__LeftButton__30 (copy), l__RightButton__29 (copy), u42 (copy)
        if u11 then
            local v44 = table.find(u10, l__CurrentVehicle__15.Value);
            if v44 == 1 and p43 or v44 == #u10 and not p43 then
            elseif v44 == nil then
                warn("What the...");
            else
                local v45 = v44 + (p43 and -1 or 1);
                local _ = #u10;
                if v45 == #u10 then
                    l__LeftButton__30.Visible = true;
                    l__RightButton__29.Visible = false;
                elseif v45 == 1 then
                    l__LeftButton__30.Visible = false;
                    l__RightButton__29.Visible = true;
                else
                    l__LeftButton__30.Visible = true;
                    l__RightButton__29.Visible = true;
                end;
                u42(u10[v45], p43);
            end;
        end;
    end;
    local u47 = u10;
    local u48 = u9;
    for _, v49 in ipairs({ l__RightButton__29, l__LeftButton__30 }) do
        l__GuiModule__6.setupCategorySwitchSounds(v49);
    end;
    l__RightButton__29.MouseButton1Click:Connect(function() --[[ Line: 308 ]]
        -- upvalues: u46 (copy)
        u46();
    end);
    l__LeftButton__30.MouseButton1Click:Connect(function() --[[ Line: 312 ]]
        -- upvalues: u46 (copy)
        u46(true);
    end);
    l__CurrentVehicle__15.Changed:Connect(u31);
    l__Mode__17.Changed:Connect(function(_) --[[ Line: 317 ]]
        -- upvalues: l__Mode__17 (copy), u47 (ref), u2 (copy), u3 (copy), u48 (ref), l__Vehicles__19 (copy), l__Helicopters__20 (copy), l__CurrentVehicle__15 (copy), l__LeftButton__30 (copy), l__RightButton__29 (copy), u31 (copy)
        local v50 = l__Mode__17.Value == "GroundVehicles";
        u47 = v50 and u2 or u3;
        u48 = v50 and l__Vehicles__19 or l__Helicopters__20;
        l__CurrentVehicle__15.Value = u47[1];
        l__LeftButton__30.Visible = false;
        l__RightButton__29.Visible = true;
        u31();
    end);
    script.Parent:GetPropertyChangedSignal("Visible"):Connect(u31);
    for _, u51 in ipairs(l__Vehicles__11:GetChildren()) do
        u51.Changed:Connect(function() --[[ Line: 325 ]]
            -- upvalues: u51 (copy), u3 (copy), l__GuiModule__6 (copy), u31 (copy)
            local l__Name__34 = u51.Name;
            local v52 = l__Name__34 == "Tank" and true or l__Name__34 == "BTR-80";
            local v53 = table.find(u3, l__Name__34);
            if script.Parent.Visible then
                if v52 then
                    l__GuiModule__6.Sounds.purchaseTank();
                elseif v53 then
                    l__GuiModule__6.Sounds.purchaseHeli();
                else
                    l__GuiModule__6.Sounds.purchaseCar();
                end;
            end;
            u31();
        end);
    end;
    for _, u54 in ipairs(l__Helicopters__12:GetChildren()) do
        u54.Changed:Connect(function() --[[ Line: 325 ]]
            -- upvalues: u54 (copy), u3 (copy), l__GuiModule__6 (copy), u31 (copy)
            local l__Name__35 = u54.Name;
            local v55 = l__Name__35 == "Tank" and true or l__Name__35 == "BTR-80";
            local v56 = table.find(u3, l__Name__35);
            if script.Parent.Visible then
                if v55 then
                    l__GuiModule__6.Sounds.purchaseTank();
                elseif v56 then
                    l__GuiModule__6.Sounds.purchaseHeli();
                else
                    l__GuiModule__6.Sounds.purchaseCar();
                end;
            end;
            u31();
        end);
    end;
end;