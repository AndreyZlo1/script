-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.Onboarding
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Modules__2 = l__ReplicatedStorage__1:WaitForChild("Modules");
local l__GuiModule__3 = require(l__Modules__2:WaitForChild("GuiModule"));
local l__ShopModule__4 = require(script.Parent:WaitForChild("ShopModule"));
local l__ReplicatedConfig__5 = require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig"));
local l__PlayerEvents__6 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents");
local l__CompleteTutorial__7 = l__PlayerEvents__6:WaitForChild("CompleteTutorial");
local l__BindableEvents__8 = l__ReplicatedStorage__1:WaitForChild("BindableEvents");
local l__StartTutorial__9 = l__BindableEvents__8:WaitForChild("StartTutorial");
l__BindableEvents__8:WaitForChild("TutorialAlreadyDone");
local l__Parent__10 = script.Parent;
l__Parent__10.Parent:WaitForChild("TutorialGui");
local l__DailySpin__11 = game.Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("DailySpin");
local u1 = l__PlayerEvents__6.GetTimeTillNextSpin:InvokeServer();
l__ShopModule__4.update();
(function() --[[ Name: launchTutorialIfNeeded, Line 25 ]]
    -- upvalues: l__GuiModule__3 (copy), l__ReplicatedConfig__5 (copy), l__BindableEvents__8 (copy), l__Parent__10 (copy), l__ShopModule__4 (copy), l__StartTutorial__9 (copy), u1 (copy), l__DailySpin__11 (copy), l__CompleteTutorial__7 (copy)
    local v2 = l__GuiModule__3.getParams();
    if not v2 then
        warn("Params not returned!");
    end;
    print(v2);
    if v2.isTutorialCompleted or not l__ReplicatedConfig__5.IsTutorialEnabled then
        l__BindableEvents__8.TutorialAlreadyDone:Fire();
    else
        while not l__Parent__10.Enabled do
            task.wait(1);
        end;
        spawn(function() --[[ Line: 42 ]]
            -- upvalues: l__ShopModule__4 (ref), l__StartTutorial__9 (ref), u1 (ref), l__Parent__10 (ref), l__DailySpin__11 (ref), l__CompleteTutorial__7 (ref)
            l__ShopModule__4.toggleLeftMenu(false);
            l__StartTutorial__9:Fire();
            local v3 = true;
            local v4;
            if u1 == 0 then
                v4 = true;
            else
                v4 = false;
            end;
            while v3 do
                v3 = l__Parent__10.Parent:FindFirstChild("TutorialGui");
                l__ShopModule__4.toggleLeftMenu(not v3);
                l__DailySpin__11.Enabled = not v3 and v4;
                task.wait();
            end;
            l__CompleteTutorial__7:FireServer();
        end);
    end;
end)();