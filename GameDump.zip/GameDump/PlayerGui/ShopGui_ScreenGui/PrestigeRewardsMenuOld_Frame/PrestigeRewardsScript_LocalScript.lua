-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.PrestigeRewardsMenuOld.PrestigeRewardsScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Players__1 = game:GetService("Players");
local l__ReplicatedStorage__2 = game:GetService("ReplicatedStorage");
local l__Modules__3 = l__ReplicatedStorage__2:WaitForChild("Modules");
local l__GuiModule__4 = require(l__Modules__3:WaitForChild("GuiModule"));
local l__Prestige__5 = l__Players__1.LocalPlayer:WaitForChild("leaderstats"):WaitForChild("Prestige");
local l__CurrentReward__6 = script.Parent:WaitForChild("CurrentReward");
local u1 = {
    "Grapple Hook",
    ".44 Magnum",
    "T-72",
    "Mil-24 Hind"
};
local l__ViewportFrame__7 = script.Parent:WaitForChild("ViewportFrame");
local u2 = nil;
local l__GunModels__8 = l__ReplicatedStorage__2:WaitForChild("ACS_Engine"):WaitForChild("GunModels");
local l__Vehicles__9 = l__ReplicatedStorage__2:WaitForChild("Vehicles");
local l__Helicopters__10 = l__ReplicatedStorage__2:WaitForChild("Helicopters");
local v3 = Instance.new("Camera");
l__ViewportFrame__7.CurrentCamera = v3;
v3.Parent = l__ViewportFrame__7;
v3.CFrame = CFrame.new(Vector3.new(-3, 2, -3), Vector3.new(0, 0, 0));
local l__RewardInfo__11 = script.Parent:WaitForChild("RewardInfo");
local l__Name__12 = l__RewardInfo__11:WaitForChild("Name");
local l__Cost__13 = l__RewardInfo__11:WaitForChild("Cost");
local u4 = Color3.new(0, 0, 0);
local u5 = Color3.new(0.270588, 0.270588, 0.270588);
script.Parent:WaitForChild("BottomAction"):WaitForChild("BackButton");
local l__RightButton__14 = script.Parent:WaitForChild("RightButton");
local l__LeftButton__15 = script.Parent:WaitForChild("LeftButton");
local u6 = true;
local function v9() --[[ Line: 48 ]]
    -- upvalues: l__CurrentReward__6 (copy), l__Name__12 (copy), l__Cost__13 (copy), u5 (copy), u2 (ref), l__GunModels__8 (copy), l__Vehicles__9 (copy), l__Helicopters__10 (copy), l__ViewportFrame__7 (copy), l__GuiModule__4 (copy), u1 (copy), l__Prestige__5 (copy), u4 (copy)
    if l__CurrentReward__6.Value == "Coming Soon" then
        l__Name__12.Text = "More to come";
        l__Cost__13.Text = "Soon :)";
        l__Cost__13.TextColor3 = u5;
        if u2 then
            u2:Destroy();
            u2 = nil;
        end;
    else
        if not u2 or u2.Name ~= l__CurrentReward__6.Value then
            if u2 then
                u2:Destroy();
                u2 = nil;
            end;
            local l__Value__16 = l__CurrentReward__6.Value;
            local v7 = l__GunModels__8:FindFirstChild(l__Value__16) or (l__Vehicles__9:FindFirstChild(l__Value__16) or l__Helicopters__10:FindFirstChild(l__Value__16));
            if v7 then
                u2 = v7:Clone();
                if u2:FindFirstChild("AimPart") then
                    u2.AimPart:Destroy();
                    if u2:FindFirstChild("Animated") and u2.Animated:FindFirstChild("Speedloader") then
                        u2.Animated.Speedloader:Destroy();
                    end;
                end;
                u2.Parent = l__ViewportFrame__7;
                l__GuiModule__4.CameraZoom.zoomToExtents(l__ViewportFrame__7.CurrentCamera, u2, 135, -30);
            end;
        end;
        l__Name__12.Text = l__CurrentReward__6.Value;
        local v8 = table.find(u1, l__CurrentReward__6.Value);
        if v8 and v8 <= l__Prestige__5.Value then
            l__Cost__13.Text = "Owned";
            l__Cost__13.TextColor3 = u4;
        elseif v8 then
            l__Cost__13.Text = "Prestige " .. v8;
            l__Cost__13.TextColor3 = u5;
        else
            l__Cost__13.Text = "Unknown";
            l__Cost__13.TextColor3 = u5;
        end;
    end;
end;
local function u16(p10, p11) --[[ Line: 98 ]]
    -- upvalues: u6 (ref), u2 (ref), l__RewardInfo__11 (copy), l__CurrentReward__6 (copy)
    if u6 then
        u6 = false;
        if u2 then
            u2:Destroy();
            u2 = nil;
        end;
        local v12 = UDim2.new(0, 0, 0, 0);
        local v13 = UDim2.new(-1, 0, 0, 0);
        local v14 = UDim2.new(1, 0, 0, 0);
        l__RewardInfo__11:TweenPosition(p11 and v14 and v14 or v13, nil, nil, 0.15, true);
        task.wait(0.15);
        l__CurrentReward__6.Value = p10;
        local v15 = l__RewardInfo__11;
        if p11 then
            v14 = v13 or v14;
        end;
        v15.Position = v14;
        l__RewardInfo__11:TweenPosition(v12, nil, nil, 0.15, true);
        task.wait(0.15);
        u6 = true;
    end;
end;
local function u20(p17) --[[ Line: 121 ]]
    -- upvalues: u6 (ref), u1 (copy), l__CurrentReward__6 (copy), l__LeftButton__15 (copy), l__RightButton__14 (copy), u16 (copy)
    if u6 then
        local v18 = table.find(u1, l__CurrentReward__6.Value);
        if v18 == 1 and p17 or v18 == #u1 and not p17 then
        elseif v18 == nil then
            warn("What the...");
        else
            local v19 = v18 + (p17 and -1 or 1);
            if v19 == #u1 then
                l__LeftButton__15.Visible = true;
                l__RightButton__14.Visible = false;
            elseif v19 == 1 then
                l__LeftButton__15.Visible = false;
                l__RightButton__14.Visible = true;
            else
                l__LeftButton__15.Visible = true;
                l__RightButton__14.Visible = true;
            end;
            u16(u1[v19], p17);
        end;
    end;
end;
for _, v21 in ipairs({ l__RightButton__14, l__LeftButton__15 }) do
    l__GuiModule__4.setupButtonSounds(v21);
end;
l__RightButton__14.MouseButton1Click:Connect(function() --[[ Line: 150 ]]
    -- upvalues: u20 (copy)
    u20();
end);
l__LeftButton__15.MouseButton1Click:Connect(function() --[[ Line: 154 ]]
    -- upvalues: u20 (copy)
    u20(true);
end);
l__CurrentReward__6.Changed:Connect(v9);
l__Prestige__5.Changed:Connect(v9);
script.Parent:GetPropertyChangedSignal("Visible"):Connect(v9);