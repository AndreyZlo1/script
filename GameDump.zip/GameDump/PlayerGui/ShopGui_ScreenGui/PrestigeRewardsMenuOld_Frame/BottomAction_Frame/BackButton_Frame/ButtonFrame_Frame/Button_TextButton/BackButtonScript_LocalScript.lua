-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.PrestigeRewardsMenuOld.BottomAction.BackButton.ButtonFrame.Button.BackButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Modules__1 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local l__GuiModule__2 = require(l__Modules__1:WaitForChild("GuiModule"));
local l__Parent__3 = script.Parent.Parent;
local l__Parent__4 = l__Parent__3.Parent;
repeat
    l__Parent__4 = l__Parent__4.Parent;
until l__Parent__4.Name == "PrestigeRewardsMenu";
local l__PrestigeMenu__5 = l__Parent__4.Parent:WaitForChild("PrestigeMenu");
l__Parent__4.Parent:WaitForChild("PrestigeFrame");
local u1 = false;
script.Parent.MouseButton1Click:connect(function() --[[ Line: 14 ]]
    -- upvalues: u1 (ref), l__GuiModule__2 (copy), l__Parent__3 (copy), l__Parent__4 (ref), l__PrestigeMenu__5 (copy)
    if u1 == true then
    else
        u1 = true;
        l__GuiModule__2.buttonPress(l__Parent__3);
        l__GuiModule__2.setModal(l__Parent__4, 1, nil, function() --[[ Line: 20 ]]
            -- upvalues: l__Parent__4 (ref)
            l__Parent__4.Visible = false;
        end);
        task.wait(0.3);
        l__PrestigeMenu__5.Visible = true;
        l__GuiModule__2.setModal(l__PrestigeMenu__5, 0.25);
        l__GuiModule__2.buttonLift(l__Parent__3);
        u1 = false;
    end;
end);