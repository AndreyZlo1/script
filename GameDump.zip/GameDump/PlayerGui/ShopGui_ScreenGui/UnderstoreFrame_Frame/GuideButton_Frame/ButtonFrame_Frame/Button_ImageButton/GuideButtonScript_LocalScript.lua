-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.UnderstoreFrame.GuideButton.ButtonFrame.Button.GuideButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Modules__1 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local l__GuiModule__2 = require(l__Modules__1:WaitForChild("GuiModule"));
local l__Parent__3 = script.Parent;
local u1 = true;
local function u5(p2, p3) --[[ Line: 12 ]]
    -- upvalues: u1 (ref), l__GuiModule__2 (copy), l__Parent__3 (copy)
    if p2 == nil then
        p2 = not u1;
    end;
    u1 = p2;
    game.Players.LocalPlayer:SetAttribute("GuideOn", u1);
    print(u1);
    l__GuiModule__2.setGuideParam(u1);
    l__Parent__3.TextLabel.TextTransparency = u1 and 0 or 0.5;
    local v4 = p3 and 0.2 or 0;
    if u1 then
        l__GuiModule__2.buttonLift(l__Parent__3.Parent, v4);
    else
        l__GuiModule__2.buttonPress(l__Parent__3.Parent, v4);
    end;
    l__GuiModule__2.Sounds.musicButtonClick();
end;
l__Parent__3.MouseButton1Down:Connect(function() --[[ Name: onClick, Line 28 ]]
    -- upvalues: u5 (copy), u1 (ref)
    u5(not u1, true);
end);
l__Parent__3.MouseEnter:Connect(function() --[[ Name: onHover, Line 29 ]]
    -- upvalues: l__GuiModule__2 (copy)
    l__GuiModule__2.Sounds.buttonHover();
end);
u5(l__GuiModule__2.getParams().guideOn, false);