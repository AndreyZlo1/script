-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.UnderstoreFrame.SpinButton.ButtonFrame.Button.LocalScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__DailySpin__1 = game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("DailySpin");
script.Parent.Activated:Connect(function() --[[ Line: 6 ]]
    -- upvalues: l__DailySpin__1 (copy)
    l__DailySpin__1.Enabled = true;
end);