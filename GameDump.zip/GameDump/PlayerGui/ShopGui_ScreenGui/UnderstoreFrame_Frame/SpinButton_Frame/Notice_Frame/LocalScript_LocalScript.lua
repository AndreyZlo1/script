-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.UnderstoreFrame.SpinButton.Notice.LocalScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = game:GetService("ReplicatedStorage"):WaitForChild("PlayerEvents"):WaitForChild("GetTimeTillNextSpin"):InvokeServer();
script.Parent.Visible = v1 == 0;