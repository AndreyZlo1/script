-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.UnderstoreFrame.Buttons
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Parent__1 = script.Parent;
local l__ShopModule__2 = require(l__Parent__1.Parent:WaitForChild("ShopModule"));
local l__ChallengesButton__3 = l__Parent__1:WaitForChild("ChallengesButton");
local l__CodeButton__4 = l__Parent__1:WaitForChild("CodeButton");
local l__SettingsButton__5 = l__Parent__1:WaitForChild("SettingsButton");
local l__AdButton__6 = l__Parent__1:WaitForChild("AdButton");
local l__MedalButton__7 = l__Parent__1.Parent:WaitForChild("MedalButton");
local l__Modals__8 = l__Parent__1.Parent:WaitForChild("Modals");
local l__ChallengesFrame__9 = l__Modals__8:WaitForChild("ChallengesFrame");
local l__CodeFrame__10 = l__Modals__8:WaitForChild("CodeFrame");
local l__SettingsFrame__11 = l__Modals__8:WaitForChild("SettingsFrame");
local l__RewardedAds__12 = l__Modals__8:WaitForChild("RewardedAds");
local l__Medal__13 = l__Modals__8:WaitForChild("Medal");
l__ShopModule__2.configureModalButton(l__ChallengesButton__3, l__ChallengesFrame__9, 0.15, true);
l__ShopModule__2.configureModalButton(l__CodeButton__4, l__CodeFrame__10);
l__ShopModule__2.configureModalButton(l__SettingsButton__5, l__SettingsFrame__11);
l__ShopModule__2.configureModalButton(l__AdButton__6, l__RewardedAds__12, 0.25, true);
l__ShopModule__2.configureModalButton(l__MedalButton__7, l__Medal__13, 0.3, true);
local l__CloseButton__14 = l__RewardedAds__12:WaitForChild("CloseButton");
l__ShopModule__2.configureCloseButton(l__CloseButton__14, l__AdButton__6);
local l__CloseButton__15 = l__Medal__13:WaitForChild("CloseButton");
l__ShopModule__2.configureCloseButton(l__CloseButton__15, l__MedalButton__7);