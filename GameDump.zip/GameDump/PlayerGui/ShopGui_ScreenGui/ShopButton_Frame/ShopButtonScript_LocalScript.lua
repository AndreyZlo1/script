-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.ShopButton.ShopButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Parent__1 = script.Parent;
repeat
    l__Parent__1 = l__Parent__1.Parent;
until l__Parent__1.Name == "ShopGui";
local l__ShopModule__2 = require(l__Parent__1:WaitForChild("ShopModule"));
local l__NewStore__3 = l__Parent__1:WaitForChild("NewStore");
l__ShopModule__2.configureModalButton(script.Parent, l__NewStore__3, 0.15, true);