-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.Shop (deprecated).UpgradesFrame.LocalScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__MarketplaceService__1 = game:GetService("MarketplaceService");
local l__Players__2 = game:GetService("Players");
local v1 = script.Parent:WaitForChild("ScrollingFrame"):GetChildren();
local u2 = script.Parent:WaitForChild("InfoFrame"):GetChildren();
for _, u3 in ipairs(v1) do
    u3:WaitForChild("PassImageButton").MouseButton1Click:connect(function() --[[ Line: 8 ]]
        -- upvalues: u3 (copy), u2 (copy)
        local v4 = u3:FindFirstChild("AssociatedInfoFrame");
        if v4 ~= nil then
            for _, v5 in ipairs(u2) do
                v5.Visible = v5.Name == v4.Value;
            end;
        end;
    end);
end;
for _, v6 in ipairs(u2) do
    local u7 = v6:FindFirstChild("GamePassId");
    local l__PurchaseButton__3 = v6:WaitForChild("PurchaseButton");
    local l__PurchaseButtonDisabled__4 = v6:WaitForChild("PurchaseButtonDisabled");
    if u7 ~= nil then
        local l__LocalPlayer__5 = l__Players__2.LocalPlayer;
        local u8 = false;
        local _, _ = pcall(function() --[[ Line: 27 ]]
            -- upvalues: u8 (ref), l__MarketplaceService__1 (copy), l__Players__2 (copy), u7 (copy)
            u8 = l__MarketplaceService__1:UserOwnsGamePassAsync(l__Players__2.LocalPlayer.UserId, u7.Value);
        end);
        if u8 then
            l__PurchaseButton__3.Visible = false;
            l__PurchaseButtonDisabled__4.Visible = true;
        end;
        l__PurchaseButton__3.MouseButton1Click:connect(function() --[[ Line: 36 ]]
            -- upvalues: l__MarketplaceService__1 (copy), l__LocalPlayer__5 (copy), u7 (copy)
            l__MarketplaceService__1:PromptGamePassPurchase(l__LocalPlayer__5, u7.Value);
        end);
    end;
end;