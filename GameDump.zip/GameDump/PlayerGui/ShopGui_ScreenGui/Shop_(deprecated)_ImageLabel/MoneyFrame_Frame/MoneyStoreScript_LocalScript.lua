-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.Shop (deprecated).MoneyFrame.MoneyStoreScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__MarketplaceService__1 = game:GetService("MarketplaceService");
local l__Players__2 = game:GetService("Players");
local v1 = script.Parent:WaitForChild("CashFrame"):GetChildren();
local v2 = script.Parent:WaitForChild("IncomeFrame"):GetChildren();
for _, u3 in ipairs(v1) do
    if u3.Name:match("PurchaseButton") then
        u3.MouseButton1Click:connect(function() --[[ Line: 9 ]]
            -- upvalues: l__Players__2 (copy), u3 (copy), l__MarketplaceService__1 (copy)
            local l__LocalPlayer__3 = l__Players__2.LocalPlayer;
            local v4 = u3:FindFirstChild("ProductId");
            if v4 ~= nil then
                l__MarketplaceService__1:PromptProductPurchase(l__LocalPlayer__3, v4.Value);
            end;
        end);
    end;
end;
for _, u5 in ipairs(v2) do
    if u5.Name:match("PurchaseButton") then
        u5.MouseButton1Click:connect(function() --[[ Line: 9 ]]
            -- upvalues: l__Players__2 (copy), u5 (copy), l__MarketplaceService__1 (copy)
            local l__LocalPlayer__4 = l__Players__2.LocalPlayer;
            local v6 = u5:FindFirstChild("ProductId");
            if v6 ~= nil then
                l__MarketplaceService__1:PromptProductPurchase(l__LocalPlayer__4, v6.Value);
            end;
        end);
    end;
end;