-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.Shop (deprecated).LocalScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Money__1 = script.Parent:WaitForChild("Money");
local l__Upgrades__2 = script.Parent:WaitForChild("Upgrades");
local l__MoneyFrame__3 = script.Parent:WaitForChild("MoneyFrame");
local l__UpgradesFrame__4 = script.Parent:WaitForChild("UpgradesFrame");
l__Money__1.MouseButton1Click:connect(function() --[[ Line: 7 ]]
    -- upvalues: l__MoneyFrame__3 (copy), l__UpgradesFrame__4 (copy)
    l__MoneyFrame__3.Visible = true;
    l__UpgradesFrame__4.Visible = false;
end);
l__Upgrades__2.MouseButton1Click:connect(function() --[[ Line: 12 ]]
    -- upvalues: l__MoneyFrame__3 (copy), l__UpgradesFrame__4 (copy)
    l__MoneyFrame__3.Visible = false;
    l__UpgradesFrame__4.Visible = true;
end);