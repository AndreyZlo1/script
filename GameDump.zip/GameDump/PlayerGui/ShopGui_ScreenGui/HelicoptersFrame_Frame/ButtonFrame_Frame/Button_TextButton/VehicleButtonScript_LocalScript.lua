-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.HelicoptersFrame.ButtonFrame.Button.VehicleButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Modules__1 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local l__GuiModule__2 = require(l__Modules__1:WaitForChild("GuiModule"));
local l__Parent__3 = script.Parent;
repeat
    l__Parent__3 = l__Parent__3.Parent;
until l__Parent__3.Name == "ShopGui";
require(l__Parent__3:WaitForChild("ShopModule"));
local l__GroundVehiclesMenu__4 = l__Parent__3:WaitForChild("GroundVehiclesMenu");
local l__Parent__5 = script.Parent;
local l__Parent__6 = l__Parent__5.Parent.Parent;
local l__VehicleMenuNew__7 = script:FindFirstAncestorOfClass("ScreenGui").Parent:WaitForChild("VehicleMenuNew");
local l__VehicleMenuSchema__8 = require(l__VehicleMenuNew__7:WaitForChild("VehicleMenuSchema"));
local l__MenuManager__9 = require(l__VehicleMenuNew__7:WaitForChild("MenuManager"));
l__MenuManager__9.Bind(l__VehicleMenuSchema__8);
l__GroundVehiclesMenu__4:WaitForChild("Mode");
local u1 = true;
l__GuiModule__2.setupButtonSounds(l__Parent__5);
l__Parent__5.MouseButton1Click:connect(function() --[[ Line: 26 ]]
    -- upvalues: u1 (ref), l__GroundVehiclesMenu__4 (copy), l__MenuManager__9 (copy), l__GuiModule__2 (copy), l__Parent__5 (copy)
    if u1 then
        u1 = false;
        if l__GroundVehiclesMenu__4.Visible == false then
            l__MenuManager__9.Open("Helicopters");
            l__GuiModule__2.Sounds.modalIn(true);
            l__GuiModule__2.Sounds.startHangarAmbient();
            l__GuiModule__2.buttonPress(l__Parent__5.Parent);
            task.wait(0.3);
        else
            l__GuiModule__2.Sounds.modalOut(true);
            l__GuiModule__2.Sounds.stopHangarAmbient();
            l__MenuManager__9.Close();
            l__GuiModule__2.buttonLift(l__Parent__5.Parent);
            task.wait(0.3);
        end;
        u1 = true;
    end;
end);
l__Parent__6:GetPropertyChangedSignal("Visible"):Connect(function() --[[ Line: 50 ]]
    -- upvalues: l__GuiModule__2 (copy), u1 (ref), l__MenuManager__9 (copy)
    l__GuiModule__2.Sounds.stopHangarAmbient();
    u1 = false;
    l__MenuManager__9.Close();
    task.wait(0.3);
    u1 = true;
end);