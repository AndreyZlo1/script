-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.MutatorFrame.HardpointBonus
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

game:GetService("RunService");
local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Players__2 = game:GetService("Players");
local l__ReplicatedConfig__3 = require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig"));
local l__LocalPlayer__4 = l__Players__2.LocalPlayer;
local l__HPBonus__5 = script.Parent:WaitForChild("HPBonus");
l__HPBonus__5.Visible = false;
if l__ReplicatedConfig__3.Mode == "Tycoon" then
    local function v4() --[[ Line: 16 ]]
        -- upvalues: l__LocalPlayer__4 (copy), l__HPBonus__5 (copy)
        local v1 = l__LocalPlayer__4:GetAttribute("SquadIndex");
        local v2 = 0;
        for _, v3 in workspace.Hardpoints:GetChildren() do
            if v3:GetAttribute("OwningSquad") == v1 then
                v2 = v2 + 1;
            end;
        end;
        l__HPBonus__5.Visible = v2 > 0;
        l__HPBonus__5.Text = string.format("Hardpoint income bonus: %s%%", (math.floor(v2 * 10)));
    end;
    while true do
        v4();
        task.wait(1);
    end;
end;