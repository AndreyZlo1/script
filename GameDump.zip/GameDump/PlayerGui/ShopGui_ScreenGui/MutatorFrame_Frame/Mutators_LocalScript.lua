-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.MutatorFrame.Mutators
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__LocalPlayer__1 = game:GetService("Players").LocalPlayer;
local function u5(p1) --[[ Line: 12 ]]
    local v2 = math.floor(p1 / 60 / 60);
    local v3 = math.floor(p1 / 60 % 60);
    local v4 = p1 % 60;
    if v2 > 0 then
        return string.format("%02d:%02d:%02d", v2, v3, v4);
    else
        return string.format("%02d:%02d", v3, v4);
    end;
end;
script.Parent:WaitForChild("DoubleXP");
script.Parent:WaitForChild("DoubleCash");
local function v14() --[[ Line: 24 ]]
    -- upvalues: l__LocalPlayer__1 (copy), u5 (copy)
    local v6 = {};
    local v7 = (l__LocalPlayer__1:GetAttribute("DoubleXPEnd") or 0) - os.time();
    v6.XP = math.max(v7, 0);
    local v8 = (l__LocalPlayer__1:GetAttribute("DoubleMoneyEnd") or 0) - os.time();
    v6.Cash = math.max(v8, 0);
    local v9 = {
        XP = false,
        Cash = false
    };
    for v10, v11 in v6 do
        if v11 > 0 then
            v9[v10] = true;
            script.Parent["Double" .. v10].Text = "2X " .. v10 .. ": " .. u5(v11);
        end;
    end;
    for v12, v13 in v9 do
        script.Parent["Double" .. v12].Visible = v13;
    end;
end;
while true do
    task.wait(0.2);
    v14();
end;