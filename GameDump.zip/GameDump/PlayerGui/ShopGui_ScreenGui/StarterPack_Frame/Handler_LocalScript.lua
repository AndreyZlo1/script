-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.StarterPack.Handler
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Players__2 = game:GetService("Players");
local l__MarketplaceService__3 = game:GetService("MarketplaceService");
local l__PlayerEvents__4 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents");
local l__GetStarterPackExpiry__5 = l__PlayerEvents__4:WaitForChild("GetStarterPackExpiry");
local l__InvalidateStarterPack__6 = l__PlayerEvents__4:WaitForChild("InvalidateStarterPack");
local v1 = l__PlayerEvents__4:WaitForChild("CanGetStarterPackFree"):InvokeServer();
l__PlayerEvents__4:WaitForChild("ClaimFreeStarterPack");
local l__LocalPlayer__7 = l__Players__2.LocalPlayer;
local l__Button__8 = script.Parent:WaitForChild("CloseButton"):WaitForChild("ButtonFrame"):WaitForChild("Button");
local l__Button__9 = script.Parent:WaitForChild("PurchaseButton"):WaitForChild("Button");
local l__Discount__10 = script.Parent:WaitForChild("Discount");
local u2 = l__GetStarterPackExpiry__5:InvokeServer() or 0;
local l__Expiry__11 = script.Parent:WaitForChild("Expiry");
local l__Frame__12 = l__Expiry__11:WaitForChild("Frame");
local l__Title__13 = l__Expiry__11:WaitForChild("Title");
local l__StarterButton__14 = script.Parent.Parent:WaitForChild("StarterButton");
local l__ShopModule__15 = require(script.Parent.Parent:WaitForChild("ShopModule"));
l__ShopModule__15.configureCloseButton(l__Button__8.Parent.Parent, l__StarterButton__14);
l__ShopModule__15.configureModalButton(l__StarterButton__14, script.Parent, 0.25, true, 0.5);
local v3 = {
    Carrack = 500
};
for v4, v5 in {
    BTR = {
        ID = 1156078137,
        Mult = 1
    },
    WepExp = {
        ID = 1811129231,
        Mult = 2
    },
    Cash = {
        ID = 1156077820,
        Mult = 1
    }
} do
    v3[v4] = l__MarketplaceService__3:GetProductInfo(v5.ID, Enum.InfoType.Product).PriceInRobux * v5.Mult;
end;
local l__ScrollingFrame__16 = script.Parent:WaitForChild("Content"):WaitForChild("ScrollingFrame");
local v6 = 0;
for v7, v8 in v3 do
    v6 = v6 + v8;
    l__ScrollingFrame__16:WaitForChild(v7):WaitForChild("PriceLabel").Text = ` {v8}`;
end;
local v9 = l__MarketplaceService__3:GetProductInfo(3455013565, Enum.InfoType.Product);
l__Button__9.Text = ` {v9.PriceInRobux} <font transparency="0.4"><s>{v6}</s></font>`;
l__Discount__10.Text = `Limited offer - <font color="rgb(0,255,0)">{math.round((1 - v9.PriceInRobux / v6) * 100)}%</font> Off`;
local function v10() --[[ Line: 58 ]] end;
if v1 then
    script.Parent:WaitForChild("Title").Text = "Small gift for you";
    l__Expiry__11.Visible = false;
    l__Discount__10.UIPadding.PaddingTop = UDim.new();
    l__Discount__10.UIPadding.PaddingBottom = UDim.new();
    l__Discount__10.TextXAlignment = Enum.TextXAlignment.Left;
    l__Discount__10.Text = "This pack costs Robux, but we decided to gift it to our most veteran players, and that includes you, for free. Thank you for playing :) - StaySpy";
    l__Button__9.Text = "Claim";
    script.Parent.CloseButton.Visible = false;
    l__Button__9.Activated:Connect(function() --[[ Line: 72 ]]
        -- upvalues: l__PlayerEvents__4 (copy)
        l__PlayerEvents__4.ClaimFreeStarterPack:FireServer();
        script.Parent.Visible = false;
    end);
else
    l__Button__9.Activated:Connect(function() --[[ Line: 80 ]]
        -- upvalues: l__MarketplaceService__3 (copy), l__LocalPlayer__7 (copy)
        l__MarketplaceService__3:PromptProductPurchase(l__LocalPlayer__7, 3455013565);
    end);
    l__Button__8.Activated:Connect(v10);
    local function u15() --[[ Line: 89 ]]
        -- upvalues: u2 (ref), l__Title__13 (copy), l__Button__9 (copy), l__Frame__12 (copy)
        local v11 = u2 - os.time();
        if v11 <= 0 then
            l__Title__13.Text = "Expired!";
            l__Button__9.Parent.Visible = false;
        else
            local v12 = math.floor(v11 / 86400);
            local v13 = math.floor(v11 / 3600 % 24);
            local v14 = math.floor(v11 / 60 % 60);
            l__Frame__12.Size = UDim2.new(1 - v11 / 172800, 0, 1, 0);
            l__Title__13.Text = `{v12}d {v13}h {v14}m left`;
        end;
    end;
    l__InvalidateStarterPack__6.OnClientEvent:Connect(function() --[[ Line: 107 ]]
        script.Parent.Visible = false;
        script:Destroy();
    end);
    l__LocalPlayer__7:GetAttributeChangedSignal("StarterPackPrompted"):Connect(function() --[[ Line: 112 ]]
        -- upvalues: u2 (ref), l__GetStarterPackExpiry__5 (copy), u15 (copy)
        u2 = l__GetStarterPackExpiry__5:InvokeServer() or 0;
        u15();
    end);
    while true do
        u15();
        task.wait(60);
    end;
end;