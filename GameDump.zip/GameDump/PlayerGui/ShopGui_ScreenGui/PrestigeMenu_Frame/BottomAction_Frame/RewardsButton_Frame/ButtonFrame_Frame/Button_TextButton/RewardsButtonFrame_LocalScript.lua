-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.PrestigeMenu.BottomAction.RewardsButton.ButtonFrame.Button.RewardsButtonFrame
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Players__1 = game:GetService("Players");
local l__Modules__2 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local l__GuiModule__3 = require(l__Modules__2:WaitForChild("GuiModule"));
local l__PlayerGui__4 = l__Players__1.LocalPlayer:WaitForChild("PlayerGui");
local l__FadeGui__5 = l__PlayerGui__4:WaitForChild("FadeGui");
require(l__FadeGui__5:WaitForChild("FadeModule"));
local l__PrestigeRewards__6 = require(l__PlayerGui__4:WaitForChild("PrestigeRewards"):WaitForChild("PrestigeRewards"));
local l__Parent__7 = script.Parent;
local l__Parent__8 = l__Parent__7.Parent;
repeat
    l__Parent__8 = l__Parent__8.Parent;
until l__Parent__8.Name == "PrestigeMenu";
local l__PrestigeRewardsMenu__9 = l__Parent__8.Parent:WaitForChild("PrestigeRewardsMenu");
l__Parent__8.Parent:WaitForChild("PrestigeFrame");
local u1 = false;
l__GuiModule__3.setupButtonSounds(l__Parent__7);
l__Parent__7.MouseButton1Click:Connect(function() --[[ Line: 23 ]]
    -- upvalues: u1 (ref), l__GuiModule__3 (copy), l__Parent__7 (copy), l__PrestigeRewardsMenu__9 (copy), l__Parent__8 (ref), l__PrestigeRewards__6 (copy)
    if u1 == true then
    else
        u1 = true;
        l__GuiModule__3.buttonPress(l__Parent__7.Parent);
        l__PrestigeRewardsMenu__9.Visible = true;
        l__GuiModule__3.setModal(l__Parent__8, 1, nil, function() --[[ Line: 28 ]]
            -- upvalues: l__Parent__8 (ref)
            l__Parent__8.Visible = false;
        end);
        task.spawn(l__PrestigeRewards__6.Show);
        task.wait(0.3);
        l__GuiModule__3.buttonLift(l__Parent__7.Parent);
        u1 = false;
    end;
end);