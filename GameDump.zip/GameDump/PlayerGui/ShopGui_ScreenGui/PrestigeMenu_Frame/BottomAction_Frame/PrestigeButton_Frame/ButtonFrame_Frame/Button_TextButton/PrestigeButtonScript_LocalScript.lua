-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.PrestigeMenu.BottomAction.PrestigeButton.ButtonFrame.Button.PrestigeButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Modules__1 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local l__GuiModule__2 = require(l__Modules__1:WaitForChild("GuiModule"));
local l__Parent__3 = script.Parent;
local l__Parent__4 = l__Parent__3.Parent;
repeat
    l__Parent__4 = l__Parent__4.Parent;
until l__Parent__4.Name == "PrestigeMenu";
local l__PrestigeConfirmFrame__5 = l__Parent__4.Parent:WaitForChild("PrestigeConfirmFrame");
local u1 = false;
l__GuiModule__2.setupButtonSounds(l__Parent__3);
l__Parent__3.MouseButton1Click:connect(function() --[[ Line: 14 ]]
    -- upvalues: u1 (ref), l__GuiModule__2 (copy), l__Parent__3 (copy), l__Parent__4 (ref), l__PrestigeConfirmFrame__5 (copy)
    if u1 == true then
    else
        u1 = true;
        l__GuiModule__2.buttonPress(l__Parent__3.Parent);
        l__Parent__4.Visible = false;
        l__PrestigeConfirmFrame__5.Visible = true;
        l__GuiModule__2.buttonLift(l__Parent__3.Parent);
        u1 = false;
    end;
end);