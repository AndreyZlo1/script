-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.PrestigeMenu.PrestigeMenuScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Players__1 = game:GetService("Players");
local l__ReplicatedStorage__2 = game:GetService("ReplicatedStorage");
local l__LocalPlayer__3 = l__Players__1.LocalPlayer;
local l__Prestige__4 = l__LocalPlayer__3:WaitForChild("leaderstats"):WaitForChild("Prestige");
if require(l__ReplicatedStorage__2:WaitForChild("ReplicatedConfig")).Mode == "Tycoon" then
    local l__AssociatedTycoon__5 = l__LocalPlayer__3:WaitForChild("AssociatedTycoon");
    local u1 = workspace:WaitForChild(l__AssociatedTycoon__5.Value);
    local l__Modules__6 = l__ReplicatedStorage__2:WaitForChild("Modules");
    local l__TycoonProgressModule__7 = require(l__Modules__6:WaitForChild("TycoonProgressModule"));
    local l__Parent__8 = script.Parent;
    local l__BottomAction__9 = l__Parent__8:WaitForChild("BottomAction");
    local l__PrestigeButton__10 = l__BottomAction__9:WaitForChild("PrestigeButton");
    local l__RewardsButton__11 = l__BottomAction__9:WaitForChild("RewardsButton");
    local l__CurrentPrestige__12 = l__Parent__8:WaitForChild("PrestigeInfo"):WaitForChild("CurrentPrestige");
    local l__ProgressBars__13 = l__Parent__8:WaitForChild("ProgressBars");
    local u2 = {
        Constructions = l__ProgressBars__13:WaitForChild("Constructions"),
        Guns = l__ProgressBars__13:WaitForChild("Guns"),
        Vehicles = l__ProgressBars__13:WaitForChild("Vehicles")
    };
    local u3 = UDim2.new(0.5, 0, 0.22, 0);
    local u4 = UDim2.new(0.75, 0, 0.22, 0);
    l__Parent__8:GetPropertyChangedSignal("Visible"):Connect(function() --[[ Name: updateMenu, Line 35 ]]
        -- upvalues: l__TycoonProgressModule__7 (copy), u1 (copy), l__PrestigeButton__10 (copy), l__RewardsButton__11 (copy), u4 (copy), u3 (copy), l__CurrentPrestige__12 (copy), l__Prestige__4 (copy), u2 (copy)
        local v5, v6 = l__TycoonProgressModule__7.GetConstructionsCompletionData(u1);
        local v7, v8 = l__TycoonProgressModule__7.GetGunsCompletionData(u1);
        local v9, v10 = l__TycoonProgressModule__7.GetVehiclesCompletionData(u1);
        if v5 + v7 + v9 <= v6 + v8 + v10 then
            l__PrestigeButton__10.Visible = true;
            l__RewardsButton__11.Position = u4;
        else
            l__PrestigeButton__10.Visible = false;
            l__RewardsButton__11.Position = u3;
        end;
        l__CurrentPrestige__12.Text = "Prestige " .. l__Prestige__4.Value;
        for v11, v12 in u2 do
            local v13, v14 = l__TycoonProgressModule__7["Get" .. v11 .. "CompletionData"](u1);
            v12.Bar.Value.Text = ("%s/%s"):format(v14, v13);
            v12.Bar.Fill.Size = UDim2.new(v14 / v13, 0, 1, 0);
        end;
    end);
end;