-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.StatsFrame.LocalScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__LocalPlayer__1 = game:GetService("Players").LocalPlayer;
local l__KillsLabel__2 = script.Parent:WaitForChild("KillsLabel");
local l__MoneyLabel__3 = script.Parent:WaitForChild("MoneyLabel");
local l__leaderstats__4 = l__LocalPlayer__1:WaitForChild("leaderstats");
local l__Money__5 = l__leaderstats__4:WaitForChild("Money");
local l__Kills__6 = l__leaderstats__4:WaitForChild("Kills");
script.Parent.Visible = true;
local function u7(p1) --[[ Line: 12 ]]
    if p1 == 0 then
        return "0$";
    end;
    local v2 = math.floor(p1);
    local v3 = tostring(v2);
    local v4 = string.split(v3, ".")[1];
    local v5 = string.split(v4, "");
    if string.len(v4) <= 3 then
        return v4 .. "$";
    end;
    for v6 = string.len(v4) - 2, 2, -3 do
        table.insert(v5, v6, ",");
    end;
    return table.concat(v5, "") .. "$";
end;
l__MoneyLabel__3.Text = "Money: " .. u7(l__Money__5.Value);
l__KillsLabel__2.Text = "Kills: " .. tostring(l__Kills__6.Value);
l__Money__5.Changed:Connect(function(p8) --[[ Name: displayMoney, Line 37 ]]
    -- upvalues: l__MoneyLabel__3 (copy), u7 (copy)
    l__MoneyLabel__3.Text = "Money: " .. u7(p8);
end);
l__Kills__6.Changed:Connect(function(p9) --[[ Name: displayKills, Line 41 ]]
    -- upvalues: l__KillsLabel__2 (copy)
    l__KillsLabel__2.Text = "Kills: " .. tostring(p9);
end);