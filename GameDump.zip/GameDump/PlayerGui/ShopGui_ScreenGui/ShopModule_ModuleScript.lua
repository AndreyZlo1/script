-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.ShopModule
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
local l__TweenService__1 = game:GetService("TweenService");
local l__ReplicatedStorage__2 = game:GetService("ReplicatedStorage");
local l__GetPlayerParams__3 = l__ReplicatedStorage__2:WaitForChild("PlayerEvents"):WaitForChild("GetPlayerParams");
local l__Modules__4 = l__ReplicatedStorage__2:WaitForChild("Modules");
local l__GuiModule__5 = require(l__Modules__4:WaitForChild("GuiModule"));
local l__Parent__6 = script.Parent;
local l__GroundVehiclesMenu__7 = l__Parent__6:WaitForChild("GroundVehiclesMenu");
local l__GroundVehiclesFrame__8 = l__Parent__6:WaitForChild("GroundVehiclesFrame");
local l__ButtonFrame__9 = l__GroundVehiclesFrame__8:WaitForChild("ButtonFrame");
l__Parent__6:WaitForChild("HelicoptersFrame");
l__GroundVehiclesFrame__8:WaitForChild("ButtonFrame");
local l__PrestigeMenu__10 = l__Parent__6:WaitForChild("PrestigeMenu");
local l__PrestigeRewardsMenu__11 = l__Parent__6:WaitForChild("PrestigeRewardsMenu");
local l__PrestigeConfirmFrame__12 = l__Parent__6:WaitForChild("PrestigeConfirmFrame");
local l__StatsFrame__13 = l__Parent__6:WaitForChild("StatsFrame");
local l__ShopButton__14 = l__Parent__6:WaitForChild("ShopButton");
l__Parent__6:WaitForChild("ModesSquadFrame"):WaitForChild("ModesButton");
l__Parent__6:WaitForChild("ModesSquadFrame"):WaitForChild("SquadButton");
local l__MutatorFrame__15 = l__Parent__6:WaitForChild("MutatorFrame");
local l__UnderstoreFrame__16 = l__Parent__6:WaitForChild("UnderstoreFrame");
local l__StarterButton__17 = l__Parent__6:WaitForChild("StarterButton");
local l__MedalButton__18 = l__Parent__6:WaitForChild("MedalButton");
local l__UIController__19 = require(l__Modules__4:WaitForChild("UIController"));
local l__NewBadge__20 = l__UnderstoreFrame__16:WaitForChild("ChallengesButton"):WaitForChild("ButtonFrame"):WaitForChild("NewBadge");
local l__LoadoutGuiModule__21 = require(l__Parent__6.Parent:WaitForChild("LoadoutGui"):WaitForChild("LoadoutGuiModule"));
function u1.configureModalButton(u2, u3, u4, u5, u6, u7) --[[ Line: 42 ]]
    -- upvalues: l__GuiModule__5 (copy), l__UIController__19 (copy)
    local l__Button__22 = u2:WaitForChild("ButtonFrame"):WaitForChild("Button");
    l__GuiModule__5.setupButtonSounds(l__Button__22);
    l__Button__22.MouseButton1Down:Connect(function() --[[ Line: 45 ]]
        -- upvalues: u3 (copy), l__UIController__19 (ref), u2 (copy)
        if u3.Name == "SettingsFrame" then
            l__UIController__19:ToggleUI("SettingsUI");
        end;
        if u3.Name == "NewStore" then
            l__UIController__19:ToggleUI("ShopUI");
        end;
        if u2:GetAttribute("Stun") then
        else
            u2:SetAttribute("IsPressed", not u2:GetAttribute("IsPressed"));
        end;
    end);
    u2:GetAttributeChangedSignal("IsPressed"):Connect(function() --[[ Line: 58 ]]
        -- upvalues: u7 (copy), u2 (copy), u3 (copy), l__GuiModule__5 (ref), u5 (copy), u4 (copy), u6 (copy)
        if u7 then
            u7();
        end;
        local v8 = u2:GetAttribute("IsPressed");
        u2:SetAttribute("Stun", true);
        if v8 then
            if u3.Name ~= "SettingsFrame" and u3.Name ~= "NewStore" then
                u3.Visible = true;
            end;
            l__GuiModule__5.Sounds.modalIn(u5);
            l__GuiModule__5.setModal(u3, u4 or 0.25, nil, function() --[[ Line: 74 ]]
                -- upvalues: u2 (ref)
                u2:SetAttribute("Stun", false);
            end, u6);
            l__GuiModule__5.buttonPress(u2.ButtonFrame);
        else
            l__GuiModule__5.Sounds.modalOut(u5);
            l__GuiModule__5.setModal(u3, 1, nil, function() --[[ Line: 79 ]]
                -- upvalues: u3 (ref), u2 (ref)
                u3.Visible = false;
                u2:SetAttribute("Stun", false);
            end, u6);
            l__GuiModule__5.buttonLift(u2.ButtonFrame);
        end;
    end);
end;
function u1.configureCloseButton(u9, u10) --[[ Line: 88 ]]
    -- upvalues: l__GuiModule__5 (copy)
    local l__Button__23 = u9:WaitForChild("ButtonFrame"):WaitForChild("Button");
    local u11 = l__GuiModule__5.setupCloseButtonSounds(l__Button__23);
    table.insert(u11, l__Button__23.MouseButton1Down:Connect(function() --[[ Line: 91 ]]
        -- upvalues: u9 (copy), u10 (copy), l__GuiModule__5 (ref)
        if u9:GetAttribute("Stun") or u10:GetAttribute("Stun") then
        else
            u10:SetAttribute("IsPressed", false);
            l__GuiModule__5.buttonPress(u9.ButtonFrame, nil, function() --[[ Line: 96 ]]
                -- upvalues: l__GuiModule__5 (ref), u9 (ref)
                l__GuiModule__5.buttonLift(u9.ButtonFrame, nil, function() --[[ Line: 98 ]]
                    -- upvalues: u9 (ref)
                    u9:SetAttribute("Stun", false);
                end);
            end);
        end;
    end));
    return function() --[[ Line: 102 ]]
        -- upvalues: u11 (copy)
        for _, v12 in u11 do
            v12:Disconnect();
        end;
    end;
end;
function u1.toggleLeftMenu(p13) --[[ Line: 109 ]]
    -- upvalues: u1 (copy), l__Parent__6 (copy), l__StatsFrame__13 (copy), l__StarterButton__17 (copy), l__ShopButton__14 (copy), l__MedalButton__18 (copy), l__UnderstoreFrame__16 (copy), l__MutatorFrame__15 (copy), l__TweenService__1 (copy)
    if not p13 then
        u1.closeAll();
    end;
    l__Parent__6:SetAttribute("IsHidden", not p13);
    local v14 = TweenInfo.new(0.2);
    local v15 = p13 and 0.015 or -0.24;
    for _, v16 in ipairs({
        l__StatsFrame__13,
        l__StarterButton__17,
        l__ShopButton__14,
        script.Parent:WaitForChild("ModesSquadFrame"),
        l__MedalButton__18,
        l__UnderstoreFrame__16,
        l__MutatorFrame__15
    }) do
        l__TweenService__1:Create(v16, v14, {
            Position = UDim2.new(v15, v16.Position.X.Offset, v16.Position.Y.Scale, v16.Position.Y.Offset)
        }):Play();
    end;
    for _, v17 in ipairs({ l__StatsFrame__13:WaitForChild("KillsLabel"), l__StatsFrame__13:WaitForChild("MoneyLabel") }) do
        l__TweenService__1:Create(v17, v14, {
            TextTransparency = p13 and 0 or 1
        }):Play();
    end;
end;
function u1.closeAll() --[[ Line: 131 ]]
    -- upvalues: l__UnderstoreFrame__16 (copy), l__ShopButton__14 (copy)
    for _, v18 in ipairs(l__UnderstoreFrame__16:GetChildren()) do
        if v18:GetAttribute("IsPressed") then
            v18:SetAttribute("IsPressed", false);
        end;
    end;
    l__ShopButton__14:SetAttribute("IsPressed", false);
end;
function u1.toggleLoadoutMenuShow(p19) --[[ Line: 140 ]]
    -- upvalues: l__LoadoutGuiModule__21 (copy)
    l__LoadoutGuiModule__21.toggleShow(p19);
end;
function u1.resetVehicleMenuState() --[[ Line: 144 ]]
    -- upvalues: l__GuiModule__5 (copy), l__GroundVehiclesMenu__7 (copy), l__ButtonFrame__9 (copy)
    l__GuiModule__5.setModal(l__GroundVehiclesMenu__7, 1, nil, function() --[[ Line: 146 ]]
        -- upvalues: l__GroundVehiclesMenu__7 (ref)
        l__GroundVehiclesMenu__7.Visible = false;
    end);
    l__GuiModule__5.buttonLift(l__ButtonFrame__9);
end;
function u1.resetPrestigeMenuState() --[[ Line: 154 ]]
    -- upvalues: l__PrestigeConfirmFrame__12 (copy), l__GuiModule__5 (copy), l__PrestigeMenu__10 (copy), l__PrestigeRewardsMenu__11 (copy)
    l__PrestigeConfirmFrame__12.Visible = false;
    l__GuiModule__5.setModal(l__PrestigeMenu__10, 1, nil, function() --[[ Line: 157 ]]
        -- upvalues: l__PrestigeMenu__10 (ref)
        l__PrestigeMenu__10.Visible = false;
    end);
    l__GuiModule__5.setModal(l__PrestigeRewardsMenu__11, 1, nil, function() --[[ Line: 161 ]]
        -- upvalues: l__PrestigeRewardsMenu__11 (ref)
        l__PrestigeRewardsMenu__11.Visible = false;
    end);
end;
function u1.update() --[[ Line: 167 ]]
    -- upvalues: l__GetPlayerParams__3 (copy), l__NewBadge__20 (copy)
    local v20 = l__GetPlayerParams__3:InvokeServer();
    if v20 then
        if v20.challenges.lastUpdate < v20.challenges.lastSeen then
            l__NewBadge__20.Visible = true;
        end;
    end;
end;
return u1;