-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.AddMoneyFrame.ButtonFrame.Button.AddMoneyScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__MarketplaceService__1 = game:GetService("MarketplaceService");
local l__Modules__2 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local l__GuiModule__3 = require(l__Modules__2:WaitForChild("GuiModule"));
local l__LocalPlayer__4 = game:GetService("Players").LocalPlayer;
local l__Parent__5 = script.Parent;
local l__ProductId__6 = script.Parent:WaitForChild("ProductId");
local u1 = false;
l__GuiModule__3.setupButtonSounds(l__Parent__5);
l__Parent__5.MouseButton1Click:connect(function() --[[ Line: 15 ]]
    -- upvalues: u1 (ref), l__MarketplaceService__1 (copy), l__LocalPlayer__4 (copy), l__ProductId__6 (copy), l__GuiModule__3 (copy), l__Parent__5 (copy)
    u1 = true;
    l__MarketplaceService__1:PromptProductPurchase(l__LocalPlayer__4, l__ProductId__6.Value);
    l__GuiModule__3.buttonPress(l__Parent__5.Parent);
    task.wait(0.2);
    l__GuiModule__3.buttonLift(l__Parent__5.Parent);
    task.wait(0.2);
    u1 = false;
end);