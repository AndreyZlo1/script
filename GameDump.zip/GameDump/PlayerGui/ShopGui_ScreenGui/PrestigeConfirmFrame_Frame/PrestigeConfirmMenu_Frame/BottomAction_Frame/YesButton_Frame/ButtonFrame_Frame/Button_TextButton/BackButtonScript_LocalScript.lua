-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.PrestigeConfirmFrame.PrestigeConfirmMenu.BottomAction.YesButton.ButtonFrame.Button.BackButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Modules__2 = l__ReplicatedStorage__1:WaitForChild("Modules");
local l__GuiModule__3 = require(l__Modules__2:WaitForChild("GuiModule"));
local l__RequestPrestigeEvent__4 = l__ReplicatedStorage__1:WaitForChild("RequestPrestigeEvent");
local l__Parent__5 = script.Parent;
local l__Parent__6 = l__Parent__5.Parent;
repeat
    l__Parent__6 = l__Parent__6.Parent;
until l__Parent__6.Name == "PrestigeConfirmFrame";
local u1 = false;
l__GuiModule__3.setupButtonSounds(l__Parent__5);
l__Parent__5.MouseButton1Click:connect(function() --[[ Line: 13 ]]
    -- upvalues: u1 (ref), l__GuiModule__3 (copy), l__Parent__5 (copy), l__Parent__6 (ref), l__RequestPrestigeEvent__4 (copy)
    if u1 == true then
    else
        u1 = true;
        l__GuiModule__3.buttonPress(l__Parent__5.Parent);
        l__Parent__6.Visible = false;
        l__RequestPrestigeEvent__4:FireServer();
        l__GuiModule__3.buttonLift(l__Parent__5.Parent);
        u1 = false;
    end;
end);