-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.SquadMessageBox.MessageBox
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__Parent__1 = script.Parent;
local l__TextLabel__2 = l__Parent__1:WaitForChild("Details"):WaitForChild("TextLabel");
local l__Title__3 = l__Parent__1:WaitForChild("BoxInfo"):WaitForChild("Title");
local u2 = nil;
l__Parent__1:WaitForChild("BottomAction"):WaitForChild("OKButton"):WaitForChild("ButtonFrame"):WaitForChild("Button").Activated:Connect(function() --[[ Line: 16 ]]
    -- upvalues: l__Parent__1 (copy), u2 (ref)
    l__Parent__1.Visible = false;
    if u2 then
        u2.Visible = true;
    end;
end);
function v1.Show(p3, p4, p5) --[[ Line: 23 ]]
    -- upvalues: u2 (ref), l__Title__3 (copy), l__TextLabel__2 (copy), l__Parent__1 (copy)
    if p5 then
        p5.Visible = false;
    end;
    u2 = p5;
    l__Title__3.Text = p3;
    l__TextLabel__2.TextSize = math.ceil(14 * (l__TextLabel__2.AbsoluteSize.Y / 58));
    l__TextLabel__2.Text = p4;
    l__Parent__1.Visible = true;
end;
return v1;