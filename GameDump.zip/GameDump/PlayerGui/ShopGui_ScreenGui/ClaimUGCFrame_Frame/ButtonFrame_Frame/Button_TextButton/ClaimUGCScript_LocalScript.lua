-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.ClaimUGCFrame.ButtonFrame.Button.ClaimUGCScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__MarketplaceService__1 = game:GetService("MarketplaceService");
local l__ReplicatedStorage__2 = game:GetService("ReplicatedStorage");
local l__ClaimUGC__3 = l__ReplicatedStorage__2:WaitForChild("PlayerEvents"):WaitForChild("ClaimUGC");
local l__Modules__4 = l__ReplicatedStorage__2:WaitForChild("Modules");
local l__GuiModule__5 = require(l__Modules__4:WaitForChild("GuiModule"));
local l__LocalPlayer__6 = game:GetService("Players").LocalPlayer;
local l__Parent__7 = script.Parent;
local l__Parent__8 = l__Parent__7.Parent.Parent;
local u1 = false;
local function v3() --[[ Line: 18 ]]
    -- upvalues: l__LocalPlayer__6 (copy), l__MarketplaceService__1 (copy), l__Parent__8 (copy)
    local v2 = l__LocalPlayer__6:GetAttribute("UGCRewardID");
    if v2 then
        if v2 == 0 then
            v2 = false;
        else
            v2 = not l__MarketplaceService__1:PlayerOwnsAsset(l__LocalPlayer__6, v2);
        end;
    end;
    l__Parent__8.Visible = v2;
end;
l__GuiModule__5.setupButtonSounds(l__Parent__7);
local v4 = l__LocalPlayer__6:GetAttribute("UGCRewardID");
if v4 then
    if v4 == 0 then
        v4 = false;
    else
        v4 = not l__MarketplaceService__1:PlayerOwnsAsset(l__LocalPlayer__6, v4);
    end;
end;
l__Parent__8.Visible = v4;
l__LocalPlayer__6:GetAttributeChangedSignal("UGCRewardID"):Connect(v3);
l__Parent__7.MouseButton1Click:connect(function() --[[ Line: 28 ]]
    -- upvalues: u1 (ref), l__ClaimUGC__3 (copy), l__LocalPlayer__6 (copy), l__GuiModule__5 (copy), l__Parent__7 (copy)
    u1 = true;
    l__ClaimUGC__3:FireServer(l__LocalPlayer__6:GetAttribute("UGCRewardID"));
    l__GuiModule__5.buttonPress(l__Parent__7.Parent);
    task.wait(0.2);
    l__GuiModule__5.buttonLift(l__Parent__7.Parent);
    task.wait(0.2);
    u1 = false;
end);