-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.Modals.CodeFrame.CodeMenu.BottomAction.ConfirmButton.ButtonFrame.Button.RedeemButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Modules__2 = l__ReplicatedStorage__1:WaitForChild("Modules");
local l__GuiModule__3 = require(l__Modules__2:WaitForChild("GuiModule"));
local l__RequestCodeRedeem__4 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents"):WaitForChild("RequestCodeRedeem");
local l__Parent__5 = script.Parent;
local l__Parent__6 = l__Parent__5.Parent;
repeat
    l__Parent__6 = l__Parent__6.Parent;
until l__Parent__6.Name == "CodeFrame";
local l__TextBox__7 = l__Parent__6:WaitForChild("CodeMenu"):WaitForChild("InfoFrame"):WaitForChild("TextBox");
local l__NotificationLabel__8 = l__Parent__6:WaitForChild("NotificationLabel");
local l__WinNotification__9 = script:WaitForChild("WinNotification");
local u1 = false;
l__GuiModule__3.setupButtonSounds(l__Parent__5);
l__Parent__5.MouseButton1Click:connect(function() --[[ Line: 26 ]]
    -- upvalues: u1 (ref), l__TextBox__7 (copy), l__GuiModule__3 (copy), l__Parent__5 (copy), l__RequestCodeRedeem__4 (copy), l__WinNotification__9 (copy), l__NotificationLabel__8 (copy)
    if u1 == true or l__TextBox__7.Text == nil then
    else
        u1 = true;
        l__GuiModule__3.buttonPress(l__Parent__5.Parent);
        local u2, u3 = l__RequestCodeRedeem__4:InvokeServer(l__TextBox__7.Text:lower());
        spawn(function() --[[ Line: 34 ]]
            -- upvalues: u2 (copy), l__WinNotification__9 (ref), u3 (copy), l__NotificationLabel__8 (ref)
            if u2 then
                l__WinNotification__9:Play();
                local v4 = u3 or "Yipee! Code successfully redeemed!";
                l__NotificationLabel__8.Visible = true;
                l__NotificationLabel__8.Text = v4;
                task.wait(3);
                l__NotificationLabel__8.Visible = false;
            else
                l__NotificationLabel__8.Visible = true;
                l__NotificationLabel__8.Text = "Code already redeemed or invalid";
                task.wait(3);
                l__NotificationLabel__8.Visible = false;
            end;
        end);
        l__GuiModule__3.buttonLift(l__Parent__5.Parent);
        u1 = false;
    end;
end);