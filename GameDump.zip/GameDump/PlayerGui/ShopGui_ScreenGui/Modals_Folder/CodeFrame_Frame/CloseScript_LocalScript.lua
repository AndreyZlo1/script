-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.Modals.CodeFrame.CloseScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Modules__1 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
require(l__Modules__1:WaitForChild("GuiModule"));
local l__Parent__2 = script.Parent.Parent.Parent;
local l__ShopModule__3 = require(l__Parent__2:WaitForChild("ShopModule"));
local l__CodeButton__4 = l__Parent__2:WaitForChild("UnderstoreFrame"):WaitForChild("CodeButton");
local l__CloseButton__5 = script.Parent:WaitForChild("CloseButton");
l__ShopModule__3.configureCloseButton(l__CloseButton__5, l__CodeButton__4);