-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.Modals.RewardedAds.Handler
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__AdService__2 = game:GetService("AdService");
local l__Parent__3 = script.Parent;
local l__WatchButton__4 = l__Parent__3:WaitForChild("WatchButton");
local l__Button__5 = l__WatchButton__4:WaitForChild("Button");
local l__Unavailable__6 = l__Parent__3:WaitForChild("Unavailable");
local l__RewardedAdEvent__7 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents"):WaitForChild("RewardedAdEvent");
local u1 = {
    Enum.AdAvailabilityResult.PlayerIneligible,
    Enum.AdAvailabilityResult.DeviceIneligible,
    Enum.AdAvailabilityResult.PublisherIneligible,
    Enum.AdAvailabilityResult.ExperienceIneligible
};
function checkForAds()
    -- upvalues: l__AdService__2 (copy), l__WatchButton__4 (copy), l__Unavailable__6 (copy), u1 (copy)
    local v2, v3 = pcall(function() --[[ Line: 34 ]]
        -- upvalues: l__AdService__2 (ref)
        return l__AdService__2:GetAdAvailabilityNowAsync(Enum.AdFormat.RewardedVideo);
    end);
    if v2 and v3.AdAvailabilityResult == Enum.AdAvailabilityResult.IsAvailable then
        l__WatchButton__4.Visible = true;
        l__Unavailable__6.Visible = false;
        return;
    end;
    local l__AdAvailabilityResult__8 = v3.AdAvailabilityResult;
    local v4;
    for _, v5 in ipairs(u1) do
        if l__AdAvailabilityResult__8 == v5 then
            v4 = true;
            if v4 then
                l__WatchButton__4.Visible = false;
                l__Unavailable__6.Visible = true;
                return;
            else
                return;
            end;
        end;
    end;
    v4 = false;
    if v4 then
        l__WatchButton__4.Visible = false;
        l__Unavailable__6.Visible = true;
    end;
end;
l__RewardedAdEvent__7.OnClientEvent:Connect(function(_, p6) --[[ Line: 52 ]]
    if p6 == Enum.ShowAdResult.ShowCompleted then
        checkForAds();
    end;
end);
l__Parent__3.Changed:Connect(function() --[[ Line: 58 ]]
    -- upvalues: l__Parent__3 (copy)
    if l__Parent__3.Visible then
        checkForAds();
    end;
end);
l__Button__5.MouseButton1Click:Connect(function() --[[ Line: 64 ]]
    -- upvalues: l__WatchButton__4 (copy), l__RewardedAdEvent__7 (copy)
    l__WatchButton__4.Visible = false;
    l__RewardedAdEvent__7:FireServer();
end);