-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.Modals.SettingsFrame.SettingsScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
game:GetService("Lighting");
local l__Modules__2 = l__ReplicatedStorage__1:WaitForChild("Modules");
local l__GuiModule__3 = require(l__Modules__2:WaitForChild("GuiModule"));
local l__Parent__4 = script.Parent.Parent.Parent;
local l__ShopModule__5 = require(l__Parent__4:WaitForChild("ShopModule"));
local l__SettingsButton__6 = l__Parent__4:WaitForChild("UnderstoreFrame"):WaitForChild("SettingsButton");
local l__Parent__7 = script.Parent;
local l__SettingsFrame__8 = l__Parent__7:WaitForChild("SettingsFrame");
local l__CloseButton__9 = l__Parent__7:WaitForChild("CloseButton");
l__ShopModule__5.configureCloseButton(l__CloseButton__9, l__SettingsButton__6);
local u1 = {
    On = Color3.new(0.09803921568627451, 0.6980392156862745, 0.36470588235294116),
    Off = Color3.new(0, 0, 0)
};
local u2 = {
    On = UDim2.new(0.9, 0, 0.5, 0),
    Off = UDim2.new(0.1, 0, 0.5, 0)
};
local u3 = {
    aimAssist = l__SettingsFrame__8:WaitForChild("MobileAimAssistCell"),
    shadows = l__SettingsFrame__8:WaitForChild("ShadowSettingCell"),
    sunrays = l__SettingsFrame__8:WaitForChild("SunraysSettingCell"),
    blur = l__SettingsFrame__8:WaitForChild("BlurSettingCell")
};
local function u8(p4, p5, _, p6) --[[ Line: 36 ]]
    -- upvalues: u1 (copy), u2 (copy), l__GuiModule__3 (copy)
    p4:SetAttribute("Enabled", p5);
    local l__Background__10 = p4:WaitForChild("SwitchButton"):WaitForChild("Background");
    local l__Pin__11 = l__Background__10:WaitForChild("Pin");
    local v7 = p5 and "On" or "Off";
    l__Background__10.BackgroundColor3 = u1[v7];
    l__Pin__11.Position = u2[v7];
    l__GuiModule__3.setGraphicsParam(p4:GetAttribute("Param"), p5, p6);
    l__GuiModule__3.setMobileParam(p4:GetAttribute("Param"), p5, p6);
end;
(function() --[[ Name: setup, Line 50 ]]
    -- upvalues: l__GuiModule__3 (copy), u3 (copy), u8 (copy)
    local v9 = l__GuiModule__3.getParams();
    local l__graphics__12 = v9.userSettings.graphics;
    local l__mobile__13 = v9.userSettings.mobile;
    for v10, u11 in pairs(u3) do
        u8(u11, l__graphics__12[v10] or l__mobile__13[v10], false, true);
        local l__Button__14 = u11:WaitForChild("SwitchButton"):WaitForChild("Button");
        l__GuiModule__3.setupToggleSwitchSounds(l__Button__14);
        l__Button__14.MouseButton1Down:Connect(function() --[[ Line: 59 ]]
            -- upvalues: u8 (ref), u11 (copy)
            u8(u11, not u11:GetAttribute("Enabled"), true);
        end);
    end;
end)();