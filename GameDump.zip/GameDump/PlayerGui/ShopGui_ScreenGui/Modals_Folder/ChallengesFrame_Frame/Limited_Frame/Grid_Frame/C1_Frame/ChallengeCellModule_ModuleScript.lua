-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.Modals.ChallengesFrame.Limited.Grid.C1.ChallengeCellModule
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__Modules__1 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local l__GuiModule__2 = require(l__Modules__1:WaitForChild("GuiModule"));
local l__ChallengeFrame__3 = script.Parent:WaitForChild("ChallengeFrame");
local l__RightFrame__4 = l__ChallengeFrame__3:WaitForChild("RightFrame");
local l__ProgressBar__5 = l__RightFrame__4:WaitForChild("ProgressBar");
local l__Percent__6 = l__ProgressBar__5:WaitForChild("Percent");
local l__Reward__7 = l__RightFrame__4:WaitForChild("Reward");
local l__Objective__8 = l__RightFrame__4:WaitForChild("Objective");
local l__Active__9 = l__ChallengeFrame__3:WaitForChild("Active");
local l__Complete__10 = l__ChallengeFrame__3:WaitForChild("Complete");
function v1.update(p2, p3) --[[ Line: 18 ]]
    -- upvalues: l__GuiModule__2 (copy), l__Reward__7 (copy), l__Objective__8 (copy), l__ProgressBar__5 (copy), l__Percent__6 (copy), l__Active__9 (copy), l__Complete__10 (copy)
    local l__reward__11 = p2.reward;
    if typeof(l__reward__11) == "number" then
        l__reward__11 = l__GuiModule__2.format(p2.reward);
    end;
    l__Reward__7.Text = l__reward__11;
    l__Objective__8.Text = p2.name;
    l__ProgressBar__5.Visible = not p3;
    if typeof(p2.progress) == "number" then
        l__Percent__6.Size = UDim2.new(p2.progress / p2.target, 0, 1, 0);
        l__Active__9.Enabled = true;
        l__Complete__10.Enabled = false;
    else
        l__Percent__6.Size = UDim2.new(1, 0, 1, 0);
        l__Active__9.Enabled = false;
        l__Complete__10.Enabled = true;
    end;
end;
return v1;