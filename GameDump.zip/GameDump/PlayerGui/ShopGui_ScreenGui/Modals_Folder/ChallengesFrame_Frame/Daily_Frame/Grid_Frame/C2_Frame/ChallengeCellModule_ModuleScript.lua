-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.Modals.ChallengesFrame.Daily.Grid.C2.ChallengeCellModule
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__Modules__1 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local l__GuiModule__2 = require(l__Modules__1:WaitForChild("GuiModule"));
local l__ChallengeFrame__3 = script.Parent:WaitForChild("ChallengeFrame");
local l__Percent__4 = l__ChallengeFrame__3:WaitForChild("ProgressBar"):WaitForChild("Percent");
local l__Reward__5 = l__ChallengeFrame__3:WaitForChild("Reward");
local l__Objective__6 = l__ChallengeFrame__3:WaitForChild("Objective");
local l__Active__7 = l__ChallengeFrame__3:WaitForChild("Active");
local l__Complete__8 = l__ChallengeFrame__3:WaitForChild("Complete");
function v1.update(p2) --[[ Line: 17 ]]
    -- upvalues: l__GuiModule__2 (copy), l__Reward__5 (copy), l__Objective__6 (copy), l__Percent__4 (copy), l__Active__7 (copy), l__Complete__8 (copy)
    local l__reward__9 = p2.reward;
    if typeof(l__reward__9) == "number" then
        l__reward__9 = l__GuiModule__2.format(p2.reward);
    end;
    l__Reward__5.Text = l__reward__9;
    l__Objective__6.Text = p2.name;
    if typeof(p2.progress) == "number" then
        l__Percent__4.Size = UDim2.new(p2.progress / p2.target, 0, 1, 0);
        l__Active__7.Enabled = true;
        l__Complete__8.Enabled = false;
    else
        l__Percent__4.Size = UDim2.new(1, 0, 1, 0);
        l__Active__7.Enabled = false;
        l__Complete__8.Enabled = true;
    end;
end;
return v1;