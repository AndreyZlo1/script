-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.Modals.ChallengesFrame.CloseScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Modules__1 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
require(l__Modules__1:WaitForChild("GuiModule"));
local l__Parent__2 = script.Parent.Parent.Parent;
local l__ShopModule__3 = require(l__Parent__2:WaitForChild("ShopModule"));
local l__ChallengesButton__4 = l__Parent__2:WaitForChild("UnderstoreFrame"):WaitForChild("ChallengesButton");
local l__CloseButton__5 = script.Parent:WaitForChild("Daily"):WaitForChild("CloseButton");
l__ShopModule__3.configureCloseButton(l__CloseButton__5, l__ChallengesButton__4);