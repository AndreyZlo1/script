-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.Modals.ChallengesFrame.ChallengesScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Modules__2 = l__ReplicatedStorage__1:WaitForChild("Modules");
local v1 = script;
repeat
    v1 = v1.Parent;
until v1.Name == "ShopGui";
local l__GuiModule__3 = require(l__Modules__2:WaitForChild("GuiModule"));
local l__ShopModule__4 = require(v1:WaitForChild("ShopModule"));
local l__SetChallengesSeen__5 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents"):WaitForChild("SetChallengesSeen");
local l__Parent__6 = script.Parent;
local l__Daily__7 = l__Parent__6:WaitForChild("Daily");
local l__Grid__8 = l__Daily__7:WaitForChild("Grid");
local l__Limited__9 = l__Parent__6:WaitForChild("Limited");
local l__Grid__10 = l__Limited__9:WaitForChild("Grid");
local l__TimeRemaining__11 = l__Daily__7:WaitForChild("TimeRemaining");
local l__TimeRemaining__12 = l__Limited__9:WaitForChild("TimeRemaining");
local function u7(p2, p3, p4) --[[ Line: 25 ]]
    local v5 = 1;
    for _, v6 in ipairs(p2:GetChildren()) do
        if v6.Name ~= "UIGridLayout" then
            require(v6:WaitForChild("ChallengeCellModule")).update(p3[v5], p4);
            v5 = v5 + 1;
        end;
    end;
end;
local function u11() --[[ Line: 44 ]]
    -- upvalues: l__GuiModule__3 (copy), l__TimeRemaining__11 (copy), l__TimeRemaining__12 (copy), u7 (copy), l__Grid__8 (copy), l__Grid__10 (copy), l__ShopModule__4 (copy)
    local v8 = l__GuiModule__3.getParams();
    if v8 then
        local v9 = v8.challenges.daily[1].expiresOn - os.time();
        if v9 >= 0 then
            l__TimeRemaining__11.Text = "Time remaining: " .. string.format("%02ih %02im %02is", v9 / 3600 % 24, v9 / 60 % 60, v9 % 60);
        else
            l__TimeRemaining__11.Text = "Expired";
        end;
        local v10 = v8.challenges.limited[1].expiresOn - os.time();
        if v10 >= 0 then
            l__TimeRemaining__12.Text = "Time remaining: " .. string.format("%02id %02ih %02im %02is", v10 / 3600 / 24, v10 / 3600 % 24, v10 / 60 % 60, v10 % 60);
        else
            l__TimeRemaining__12.Text = "Expired";
        end;
        u7(l__Grid__8, v8.challenges.daily);
        u7(l__Grid__10, v8.challenges.limited, v10 < 0);
        l__ShopModule__4.update();
    end;
end;
l__Parent__6:GetPropertyChangedSignal("Visible"):Connect(function() --[[ Line: 68 ]]
    -- upvalues: l__Parent__6 (copy), l__SetChallengesSeen__5 (copy)
    if l__Parent__6.Visible then
        l__SetChallengesSeen__5:FireServer();
    end;
end);
spawn(function() --[[ Line: 74 ]]
    -- upvalues: u11 (copy)
    while true do
        task.wait(1);
        pcall(u11);
    end;
end);