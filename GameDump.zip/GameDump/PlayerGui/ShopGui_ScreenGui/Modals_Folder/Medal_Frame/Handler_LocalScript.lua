-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.Modals.Medal.Handler
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Parent__1 = script.Parent;
local l__Check__2 = l__Parent__1:WaitForChild("Check");
local l__Button__3 = l__Check__2:WaitForChild("Button");
local l__CheckModule__4 = require(l__Parent__1:WaitForChild("CheckModule"));
local l__ResultModule__5 = require(l__Parent__1:WaitForChild("ResultModule"));
local l__CheckMedalCompletion__6 = game:GetService("ReplicatedStorage"):WaitForChild("PlayerEvents"):WaitForChild("CheckMedalCompletion");
game:GetService("GuiService"):IsTenFootInterface();
local u1 = false;
local u2 = {
    [-1] = function() --[[ Line: 26 ]]
        -- upvalues: l__ResultModule__5 (copy)
        l__ResultModule__5.ShowError("Server error - please contact us");
    end,
    [0] = function() --[[ Line: 30 ]]
        -- upvalues: l__ResultModule__5 (copy), l__Check__2 (copy)
        l__ResultModule__5.ShowError("Account not connected to Medal");
        l__Check__2.Visible = true;
    end,
    [1] = function() --[[ Line: 35 ]]
        -- upvalues: l__ResultModule__5 (copy), l__Check__2 (copy)
        l__ResultModule__5.ShowError("Step 2 incomplete");
        l__Check__2.Visible = true;
    end,
    [2] = function() --[[ Line: 40 ]]
        -- upvalues: l__ResultModule__5 (copy)
        l__ResultModule__5.ShowClaimed();
    end
};
u2[3] = u2[2];
l__Button__3.Activated:Connect(function() --[[ Line: 46 ]]
    -- upvalues: u1 (ref), l__CheckModule__4 (copy), l__CheckMedalCompletion__6 (copy), u2 (copy)
    if u1 then
    else
        u1 = true;
        l__CheckModule__4.ShowProgress();
        local v3 = l__CheckMedalCompletion__6:InvokeServer();
        l__CheckModule__4.HideProgress();
        u2[v3]();
        u1 = false;
        l__CheckModule__4.HideProgress();
    end;
end);