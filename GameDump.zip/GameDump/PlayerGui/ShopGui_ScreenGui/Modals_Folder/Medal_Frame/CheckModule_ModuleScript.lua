-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.Modals.Medal.CheckModule
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__RunService__1 = game:GetService("RunService");
local l__ProgressFrame__2 = script.Parent:WaitForChild("ProgressFrame");
local l__Spinner__3 = l__ProgressFrame__2:WaitForChild("Spinner");
local l__Check__4 = script.Parent:WaitForChild("Check");
local u2 = nil;
function v1.ShowProgress() --[[ Line: 12 ]]
    -- upvalues: u2 (ref), l__Check__4 (copy), l__Spinner__3 (copy), l__ProgressFrame__2 (copy), l__RunService__1 (copy)
    if u2 then
        u2:Disconnect();
        u2 = nil;
    end;
    l__Check__4.Visible = false;
    l__Spinner__3.Rotation = 0;
    l__ProgressFrame__2.Visible = true;
    u2 = l__RunService__1.RenderStepped:Connect(function(p3) --[[ Line: 22 ]]
        -- upvalues: l__Spinner__3 (ref)
        local v4 = l__Spinner__3;
        v4.Rotation = v4.Rotation - 180 * p3;
    end);
end;
function v1.HideProgress() --[[ Line: 27 ]]
    -- upvalues: u2 (ref), l__ProgressFrame__2 (copy)
    if u2 then
        u2:Disconnect();
        u2 = nil;
    end;
    l__ProgressFrame__2.Visible = false;
end;
return v1;