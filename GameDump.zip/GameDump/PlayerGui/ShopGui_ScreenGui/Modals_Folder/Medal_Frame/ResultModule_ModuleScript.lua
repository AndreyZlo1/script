-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.Modals.Medal.ResultModule
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__Result__1 = script.Parent:WaitForChild("Result");
local l__Button__2 = l__Result__1:WaitForChild("Button");
function v1.ShowClaimed() --[[ Line: 6 ]]
    -- upvalues: l__Result__1 (copy), l__Button__2 (copy)
    l__Result__1.BackgroundColor3 = Color3.fromRGB(70, 200, 70);
    l__Button__2.Text = "Rewards claimed!";
    l__Result__1.Visible = true;
end;
function v1.ShowError(p2) --[[ Line: 12 ]]
    -- upvalues: l__Result__1 (copy), l__Button__2 (copy)
    l__Result__1.BackgroundColor3 = Color3.fromRGB(255, 70, 70);
    l__Button__2.Text = p2;
    l__Result__1.Visible = true;
    task.wait(3);
    l__Result__1.Visible = false;
end;
function v1.ShowUnavailable() --[[ Line: 21 ]]
    -- upvalues: l__Result__1 (copy), l__Button__2 (copy)
    l__Result__1.BackgroundColor3 = Color3.fromRGB(255, 70, 70);
    l__Button__2.Text = "Unavailable on Console";
    l__Result__1.Visible = true;
end;
function v1.Hide() --[[ Line: 27 ]]
    -- upvalues: l__Result__1 (copy)
    l__Result__1.Visible = false;
end;
return v1;