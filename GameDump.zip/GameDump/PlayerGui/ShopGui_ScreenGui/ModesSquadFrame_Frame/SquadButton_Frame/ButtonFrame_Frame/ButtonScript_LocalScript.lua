-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.ModesSquadFrame.SquadButton.ButtonFrame.ButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Parent__1 = script.Parent.Parent;
local l__Parent__2 = l__Parent__1.Parent.Parent;
local l__ShopModule__3 = require(l__Parent__2:WaitForChild("ShopModule"));
script.Parent:WaitForChild("Button");
local l__SquadMenu__4 = l__Parent__2:WaitForChild("SquadMenu");
l__ShopModule__3.configureModalButton(l__Parent__1, l__SquadMenu__4, 0.25);