-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.ModesSquadFrame.ModesButton.ModesButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

game.Lighting:WaitForChild("Blur");
local l__LoadingGui__1 = game.Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("LoadingGui");
local l__Frame__2 = l__LoadingGui__1:WaitForChild("Frame");
local l__Parent__3 = script.Parent;
repeat
    l__Parent__3 = l__Parent__3.Parent;
until l__Parent__3.Name == "ShopGui";
local l__ShopModule__4 = require(l__Parent__3:WaitForChild("ShopModule"));
local l__Parent__5 = script.Parent;
local l__ModesBack__6 = require(l__Frame__2.Parent:WaitForChild("ModesBack"));
local u1 = true;
local u2 = nil;
l__ShopModule__4.configureModalButton(l__Parent__5, l__Frame__2.ModesFrame, 0.15, true, 0.5, function() --[[ Line: 15 ]]
    -- upvalues: l__LoadingGui__1 (copy), l__Frame__2 (copy), u1 (ref), l__ModesBack__6 (copy), u2 (ref), l__ShopModule__4 (copy)
    l__LoadingGui__1.Enabled = true;
    for _, v3 in l__Frame__2:GetChildren() do
        v3.Visible = false;
    end;
    l__Frame__2.ModesFrame.Visible = true;
    if u1 then
        l__Frame__2.ModesFrame.Position = UDim2.new(0.5, 0, 1.15, 0);
        u1 = false;
    end;
    l__ModesBack__6.isModalMode = true;
    u2 = l__ShopModule__4.configureCloseButton(l__Frame__2:WaitForChild("ModesFrame"):WaitForChild("BackBtn"), script.Parent);
end);
l__LoadingGui__1.Changed:Connect(function() --[[ Line: 34 ]]
    -- upvalues: l__LoadingGui__1 (copy), l__ModesBack__6 (copy), u2 (ref)
    if l__LoadingGui__1.Enabled == false then
        l__ModesBack__6.isModalMode = false;
        if u2 then
            task.delay(1, function() --[[ Line: 38 ]]
                -- upvalues: u2 (ref)
                if u2 then
                    u2();
                    u2 = nil;
                end;
            end);
        end;
    end;
end);
l__Frame__2:WaitForChild("ModesFrame"):WaitForChild("BackBtn"):WaitForChild("ButtonFrame"):WaitForChild("Button").Activated:Connect(function() --[[ Line: 47 ]]
    -- upvalues: u2 (ref)
    task.delay(1, function() --[[ Line: 48 ]]
        -- upvalues: u2 (ref)
        if u2 then
            u2();
            u2 = nil;
        end;
    end);
end);