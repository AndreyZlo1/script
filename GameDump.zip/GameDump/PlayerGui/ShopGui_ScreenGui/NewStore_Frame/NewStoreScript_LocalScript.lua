-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.NewStore.NewStoreScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__MarketplaceService__1 = game:GetService("MarketplaceService");
local l__ReplicatedStorage__2 = game:GetService("ReplicatedStorage");
local l__RunService__3 = game:GetService("RunService");
local l__Players__4 = game:GetService("Players");
local l__LocalPlayer__5 = l__Players__4.LocalPlayer;
local l__Modules__6 = l__ReplicatedStorage__2:WaitForChild("Modules");
local l__GuiModule__7 = require(l__Modules__6:WaitForChild("GuiModule"));
local l__Parent__8 = script.Parent;
local _ = l__Parent__8.Parent;
local l__Upgrades__9 = l__Parent__8:WaitForChild("Upgrades");
local l__Cash__10 = l__Parent__8:WaitForChild("Cash");
local u1 = l__RunService__3:IsStudio();
local function u5(p2) --[[ Line: 21 ]]
    -- upvalues: l__GuiModule__7 (copy), l__MarketplaceService__1 (copy), l__Players__4 (copy), u1 (copy), l__LocalPlayer__5 (copy)
    if p2:IsA("Frame") then
        local l__PassId__11 = p2:WaitForChild("PassId");
        local l__BuyButton__12 = p2:WaitForChild("BuyButton");
        local l__Button__13 = l__BuyButton__12:WaitForChild("ButtonFrame"):WaitForChild("Button");
        l__GuiModule__7.setupButtonSounds(l__Button__13);
        local u3 = false;
        local _, _ = pcall(function() --[[ Line: 28 ]]
            -- upvalues: u3 (ref), l__MarketplaceService__1 (ref), l__Players__4 (ref), l__PassId__11 (copy)
            u3 = l__MarketplaceService__1:UserOwnsGamePassAsync(l__Players__4.LocalPlayer.UserId, l__PassId__11.Value);
        end);
        local v4 = l__MarketplaceService__1:GetProductInfo(l__PassId__11.Value, Enum.InfoType.GamePass);
        if u3 and not u1 or not (v4 and v4.PriceInRobux) then
            l__BuyButton__12.Visible = false;
        end;
        l__Button__13.Text = l__GuiModule__7.format(v4.PriceInRobux, true);
        l__Button__13.MouseButton1Click:Connect(function() --[[ Line: 37 ]]
            -- upvalues: l__MarketplaceService__1 (ref), l__LocalPlayer__5 (ref), l__PassId__11 (copy)
            l__MarketplaceService__1:PromptGamePassPurchase(l__LocalPlayer__5, l__PassId__11.Value);
        end);
    end;
end;
local function v9(p6) --[[ Line: 42 ]]
    -- upvalues: u5 (copy)
    local v7 = p6:WaitForChild("ScrollingFrame"):GetChildren();
    for _, v8 in ipairs(v7) do
        u5(v8);
    end;
end;
for _, v10 in ipairs({ l__Upgrades__9:WaitForChild("GunPacks"), l__Upgrades__9:WaitForChild("Vehicles") }) do
    v9(v10);
end;
local function v13(p11) --[[ Line: 57 ]]
    -- upvalues: l__GuiModule__7 (copy), l__MarketplaceService__1 (copy), l__LocalPlayer__5 (copy)
    if p11.Name:match("Button") then
        local l__Button__14 = p11:WaitForChild("ButtonFrame"):WaitForChild("Button");
        l__GuiModule__7.setupButtonSounds(l__Button__14);
        l__Button__14.MouseButton1Click:Connect(function() --[[ Line: 61 ]]
            -- upvalues: l__Button__14 (copy), l__MarketplaceService__1 (ref), l__LocalPlayer__5 (ref), l__GuiModule__7 (ref)
            local v12 = l__Button__14:FindFirstChild("ProductId");
            if v12 ~= nil then
                l__MarketplaceService__1:PromptProductPurchase(l__LocalPlayer__5, v12.Value);
            end;
            l__GuiModule__7.buttonPress(l__Button__14.Parent);
            task.wait(0.2);
            l__GuiModule__7.buttonLift(l__Button__14.Parent);
        end);
    end;
end;
for _, v14 in ipairs(l__Cash__10:WaitForChild("SectionFrame"):GetChildren()) do
    v13(v14);
end;