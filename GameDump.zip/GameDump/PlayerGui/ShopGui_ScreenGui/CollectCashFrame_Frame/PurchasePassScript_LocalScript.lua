-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.CollectCashFrame.PurchasePassScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__MarketplaceService__1 = game:GetService("MarketplaceService");
local l__RunService__2 = game:GetService("RunService");
local l__Modules__3 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local l__GuiModule__4 = require(l__Modules__3:WaitForChild("GuiModule"));
local l__LocalPlayer__5 = game:GetService("Players").LocalPlayer;
local l__DoubleAndVipWrapper__6 = script.Parent:WaitForChild("DoubleAndVipWrapper");
local l__VipFrame__7 = l__DoubleAndVipWrapper__6:WaitForChild("VipFrame");
local l__DoubleCashFrame__8 = l__DoubleAndVipWrapper__6:WaitForChild("DoubleCashFrame");
local l__ZAutoCollectFrame__9 = script.Parent:WaitForChild("ZAutoCollectFrame");
local l__Button__10 = l__VipFrame__7:WaitForChild("ButtonFrame"):WaitForChild("Button");
local l__Button__11 = l__DoubleCashFrame__8:WaitForChild("ButtonFrame"):WaitForChild("Button");
local l__Button__12 = l__ZAutoCollectFrame__9:WaitForChild("ButtonFrame"):WaitForChild("Button");
local v1 = { l__Button__10:WaitForChild("PassId"), l__Button__11:WaitForChild("PassId"), (l__Button__12:WaitForChild("PassId")) };
local v2 = l__RunService__2:IsStudio();
local v3 = { "VIP", "X2 Cash", "Auto Collect" };
local u4 = false;
local v5 = { l__VipFrame__7, l__DoubleCashFrame__8, l__ZAutoCollectFrame__9 };
for v6, u7 in ipairs({ l__Button__10, l__Button__11, l__Button__12 }) do
    local u8 = v1[v6];
    local v9 = v5[v6];
    local u10 = false;
    local v11 = l__MarketplaceService__1:GetProductInfo(u8.Value, Enum.InfoType.GamePass);
    local _, _ = pcall(function() --[[ Line: 43 ]]
        -- upvalues: u10 (ref), l__MarketplaceService__1 (copy), l__LocalPlayer__5 (copy), u8 (copy)
        u10 = l__MarketplaceService__1:UserOwnsGamePassAsync(l__LocalPlayer__5.UserId, u8.Value);
    end);
    if v11 then
        v11 = v11.PriceInRobux;
    end;
    if u10 and not v2 or not v11 then
        v9.Visible = false;
    else
        u7.Text = v3[v6] .. " <font weight=\"100\" color=\"rgb(255,200,169)\">" .. l__GuiModule__4.format(v11, true) .. "</font>";
        l__GuiModule__4.setupButtonSounds(u7);
        u7.MouseButton1Click:connect(function() --[[ Line: 57 ]]
            -- upvalues: u4 (ref), l__MarketplaceService__1 (copy), l__LocalPlayer__5 (copy), u8 (copy), l__GuiModule__4 (copy), u7 (copy)
            u4 = true;
            l__MarketplaceService__1:PromptGamePassPurchase(l__LocalPlayer__5, u8.Value);
            l__GuiModule__4.buttonPress(u7.Parent);
            task.wait(0.2);
            l__GuiModule__4.buttonLift(u7.Parent);
            task.wait(0.2);
            u4 = false;
        end);
    end;
end;