-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.CollectCashFrame.DoubleAndVipWrapper.VipFrame.HintButton.HintButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__HintFrame__1 = script.Parent.Parent:WaitForChild("HintFrame");
local _ = script.Parent;
local function v1() --[[ Line: 5 ]]
    -- upvalues: l__HintFrame__1 (copy)
    l__HintFrame__1.Visible = true;
end;
local function v2() --[[ Line: 9 ]]
    -- upvalues: l__HintFrame__1 (copy)
    l__HintFrame__1.Visible = false;
end;
script.Parent.SelectionGained:Connect(v1);
script.Parent.MouseEnter:Connect(v1);
script.Parent.SelectionLost:Connect(v2);
script.Parent.MouseLeave:Connect(v2);