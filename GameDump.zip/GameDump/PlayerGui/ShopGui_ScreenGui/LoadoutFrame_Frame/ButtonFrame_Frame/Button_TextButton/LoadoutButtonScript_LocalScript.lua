-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.LoadoutFrame.ButtonFrame.Button.LoadoutButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Modules__1 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local l__GuiModule__2 = require(l__Modules__1:WaitForChild("GuiModule"));
local l__Parent__3 = script.Parent;
repeat
    l__Parent__3 = l__Parent__3.Parent;
until l__Parent__3.Name == "ShopGui";
require(l__Parent__3:WaitForChild("ShopModule"));
local l__Parent__4 = script.Parent;
local l__Parent__5 = l__Parent__4.Parent.Parent;
local u1 = true;
local l__UIController__6 = require(l__Modules__1:WaitForChild("UIController"));
l__GuiModule__2.setupButtonSounds(l__Parent__4);
l__Parent__4.MouseButton1Click:Connect(function() --[[ Line: 18 ]]
    -- upvalues: u1 (ref), l__GuiModule__2 (copy), l__Parent__4 (copy), l__UIController__6 (copy)
    if u1 then
        u1 = false;
        l__GuiModule__2.buttonPress(l__Parent__4.Parent);
        l__UIController__6:OpenUI("LoadoutUI");
        task.wait(0.3);
        l__GuiModule__2.buttonLift(l__Parent__4.Parent);
        u1 = true;
    end;
end);
l__Parent__5:GetPropertyChangedSignal("Visible"):Connect(function() --[[ Line: 34 ]]
    -- upvalues: u1 (ref), l__GuiModule__2 (copy), l__Parent__4 (copy), l__UIController__6 (copy)
    u1 = false;
    l__GuiModule__2.buttonPress(l__Parent__4.Parent);
    l__UIController__6:OpenUI("MenuUI");
    task.wait(0.3);
    u1 = true;
end);