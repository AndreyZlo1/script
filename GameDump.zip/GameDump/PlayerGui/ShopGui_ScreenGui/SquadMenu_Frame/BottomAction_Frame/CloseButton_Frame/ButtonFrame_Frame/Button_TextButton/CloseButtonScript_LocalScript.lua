-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.SquadMenu.BottomAction.CloseButton.ButtonFrame.Button.CloseButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Parent__1 = script.Parent.Parent.Parent;
local l__Parent__2 = l__Parent__1.Parent.Parent.Parent;
local l__SquadButton__3 = l__Parent__2:WaitForChild("ModesSquadFrame"):WaitForChild("SquadButton");
require(l__Parent__2:WaitForChild("ShopModule")).configureCloseButton(l__Parent__1, l__SquadButton__3);