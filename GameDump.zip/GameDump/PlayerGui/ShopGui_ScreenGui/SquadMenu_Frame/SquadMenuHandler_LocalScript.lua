-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.SquadMenu.SquadMenuHandler
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Players__2 = game:GetService("Players");
game:GetService("RunService");
local l__ReplicatedConfig__3 = require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig"));
local l__LocalPlayer__4 = l__Players__2.LocalPlayer;
local l__PlayerEvents__5 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents");
local l__SquadGetState__6 = l__PlayerEvents__5:WaitForChild("SquadGetState");
local l__SquadUpdate__7 = l__PlayerEvents__5:WaitForChild("SquadUpdate");
local l__SquadLeave__8 = l__PlayerEvents__5:WaitForChild("SquadLeave");
local l__SquadKickPlayer__9 = l__PlayerEvents__5:WaitForChild("SquadKickPlayer");
local l__SquadInvites__10 = script.Parent.Parent:WaitForChild("SquadInvites");
local l__Count__11 = script.Parent:WaitForChild("SquadInfo"):WaitForChild("Count");
local l__ScrollVisible__12 = script.Parent:WaitForChild("ScrollBacking"):WaitForChild("ScrollVisible");
local l__Prototype__13 = l__ScrollVisible__12:WaitForChild("Prototype");
local l__InvitePrototype__14 = l__ScrollVisible__12:WaitForChild("InvitePrototype");
local l__SquadMessageBox__15 = script.Parent.Parent:WaitForChild("SquadMessageBox");
local l__MessageBox__16 = require(l__SquadMessageBox__15:WaitForChild("MessageBox"));
local u1 = nil;
local function u9(u2) --[[ Line: 28 ]]
    -- upvalues: u1 (ref), l__LocalPlayer__4 (copy), l__Prototype__13 (copy), l__SquadLeave__8 (copy), l__MessageBox__16 (copy), l__SquadKickPlayer__9 (copy), l__Players__2 (copy), l__ScrollVisible__12 (copy)
    local v3 = u1.Leader == l__LocalPlayer__4;
    local v4 = u2 == l__LocalPlayer__4;
    local v5 = u1.Leader == u2;
    local v6 = l__Prototype__13:Clone();
    v6.Name = "PlayerFrame";
    v6.DName.Text = u2.DisplayName;
    v6.LeaderLabel.Visible = v5;
    if v4 then
        v6.LeaveButton.Visible = #u1.Members > 1;
        v6.LeaveButton.ButtonFrame.Button.Activated:Connect(function() --[[ Line: 41 ]]
            -- upvalues: l__SquadLeave__8 (ref), l__MessageBox__16 (ref)
            local v7, v8 = l__SquadLeave__8:InvokeServer();
            if not v7 then
                l__MessageBox__16.Show("Error", v8 or "Unknown error", script.Parent);
            end;
        end);
    elseif v3 then
        v6.KickButton.Visible = true;
        v6.KickButton.ButtonFrame.Button.Activated:Connect(function() --[[ Line: 49 ]]
            -- upvalues: l__SquadKickPlayer__9 (ref), u2 (copy)
            l__SquadKickPlayer__9:FireServer(u2);
        end);
    end;
    v6.LayoutOrder = -(50 + (v5 and 1000 or 0) + (v4 and 500 or 0));
    v6.Icon.Image = l__Players__2:GetUserThumbnailAsync(u2.UserId, Enum.ThumbnailType.AvatarThumbnail, Enum.ThumbnailSize.Size352x352);
    v6.Parent = l__ScrollVisible__12;
    v6.Visible = true;
    return v6;
end;
local function u14() --[[ Line: 81 ]]
    -- upvalues: l__ScrollVisible__12 (copy), l__Prototype__13 (copy), l__InvitePrototype__14 (copy), u1 (ref), l__ReplicatedConfig__3 (copy), l__SquadInvites__10 (copy), u9 (copy), l__Count__11 (copy)
    print("ScrollFrame children at time of clear =======");
    for _, v10 in l__ScrollVisible__12:GetChildren() do
        print(v10.Name, v10.ClassName);
        if v10:IsA("Frame") and (v10 ~= l__Prototype__13 and v10 ~= l__InvitePrototype__14) then
            v10:Destroy();
        end;
    end;
    print("=============================================");
    local v11 = #u1.Members;
    for _ = 1, l__ReplicatedConfig__3.MaxSquadSize - v11 do
        local v12 = l__InvitePrototype__14:Clone();
        v12.Button.Activated:Connect(function() --[[ Line: 70 ]]
            -- upvalues: l__SquadInvites__10 (ref)
            script.Parent.Visible = false;
            l__SquadInvites__10.Visible = true;
        end);
        v12.Parent = l__ScrollVisible__12;
        v12.Visible = true;
    end;
    for _, v13 in u1.Members do
        u9(v13);
    end;
    l__Count__11.Text = string.format("%s/%s members", v11, l__ReplicatedConfig__3.MaxSquadSize);
end;
l__SquadUpdate__7.OnClientEvent:Connect(function(p15) --[[ Line: 105 ]]
    -- upvalues: u1 (ref), u14 (copy)
    print("SquadMenu Update");
    print("Client State printout============");
    for _, v16 in p15.Members do
        print(v16.Name);
    end;
    print("=================================");
    u1 = p15;
    u14();
end);
while true do
    task.wait(4);
    if u1 then
        break;
    end;
    u1 = l__SquadGetState__6:InvokeServer();
    if u1 then
        u14();
        break;
    end;
    if u1 then
        break;
    end;
end;