-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.SquadInvites.SquadInfo.InviteFriendList.ButtonFrame.Button.InviteButton
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__SocialService__1 = game:GetService("SocialService");
local l__LocalPlayer__2 = game:GetService("Players").LocalPlayer;
local l__Parent__3 = script.Parent;
local l__Parent__4 = l__Parent__3.Parent.Parent.Parent.Parent;
local l__SquadMessageBox__5 = l__Parent__4.Parent:WaitForChild("SquadMessageBox");
local l__MessageBox__6 = require(l__SquadMessageBox__5:WaitForChild("MessageBox"));
l__Parent__3.Activated:Connect(function() --[[ Line: 12 ]]
    -- upvalues: l__LocalPlayer__2 (copy), l__SocialService__1 (copy), l__MessageBox__6 (copy), l__Parent__4 (copy)
    local v1 = Instance.new("ExperienceInviteOptions");
    v1.PromptMessage = "Ask your friends to join your squad!";
    v1.InviteMessageId = "4d15173b-42ab-2a48-9669-0262e54db310";
    v1.LaunchData = "JoinSquad:" .. l__LocalPlayer__2:GetAttribute("SquadIndex");
    local v2, v3 = pcall(function() --[[ Line: 18 ]]
        -- upvalues: l__SocialService__1 (ref), l__LocalPlayer__2 (ref)
        return l__SocialService__1:CanSendGameInviteAsync(l__LocalPlayer__2);
    end);
    if v2 and v3 then
        l__SocialService__1:PromptGameInvite(l__LocalPlayer__2, v1);
    else
        l__MessageBox__6.Show("Error", "Cannot invite friends", l__Parent__4);
    end;
end);