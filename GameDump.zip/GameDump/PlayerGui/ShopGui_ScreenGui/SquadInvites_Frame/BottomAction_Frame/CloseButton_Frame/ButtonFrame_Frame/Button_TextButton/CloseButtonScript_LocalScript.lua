-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.SquadInvites.BottomAction.CloseButton.ButtonFrame.Button.CloseButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Parent__1 = script.Parent;
local l__Parent__2 = l__Parent__1.Parent.Parent.Parent.Parent;
local l__SquadMenu__3 = l__Parent__2.Parent:WaitForChild("SquadMenu");
l__Parent__1.Activated:Connect(function() --[[ Line: 9 ]]
    -- upvalues: l__Parent__2 (copy), l__SquadMenu__3 (copy)
    l__Parent__2.Visible = false;
    l__SquadMenu__3.Visible = true;
end);