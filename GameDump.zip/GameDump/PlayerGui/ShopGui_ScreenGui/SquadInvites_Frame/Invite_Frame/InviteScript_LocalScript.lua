-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.SquadInvites.Invite.InviteScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Players__1 = game:GetService("Players");
local l__ReplicatedStorage__2 = game:GetService("ReplicatedStorage");
local l__LocalPlayer__3 = l__Players__1.LocalPlayer;
local l__SquadCreateInvite__4 = l__ReplicatedStorage__2:WaitForChild("PlayerEvents"):WaitForChild("SquadCreateInvite");
local l__ScrollVisible__5 = script.Parent:WaitForChild("ScrollVisible");
local l__Prototype__6 = l__ScrollVisible__5:WaitForChild("Prototype");
local l__SquadMessageBox__7 = script.Parent.Parent.Parent:WaitForChild("SquadMessageBox");
local l__MessageBox__8 = require(l__SquadMessageBox__7:WaitForChild("MessageBox"));
local u1 = {};
local function u8(u2) --[[ Line: 19 ]]
    -- upvalues: l__Prototype__6 (copy), l__Players__1 (copy), l__LocalPlayer__3 (copy), l__SquadCreateInvite__4 (copy), l__MessageBox__8 (copy), l__ScrollVisible__5 (copy)
    local u3 = l__Prototype__6:Clone();
    u3.Name = u2.Name;
    u3.Main.DName.Text = u2.DisplayName;
    u3.Icon.Image = l__Players__1:GetUserThumbnailAsync(u2.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size100x100);
    local v4, v5 = pcall(function() --[[ Line: 29 ]]
        -- upvalues: u2 (copy), l__LocalPlayer__3 (ref)
        return u2:IsFriendsWith(l__LocalPlayer__3);
    end);
    if v4 and v5 then
        u3.Main.FriendLabel.Visible = true;
        u3.LayoutOrder = -500;
    end;
    u3.InviteButton.ButtonFrame.Button.Activated:Connect(function() --[[ Line: 38 ]]
        -- upvalues: u2 (copy), l__SquadCreateInvite__4 (ref), l__MessageBox__8 (ref), u3 (copy)
        print("Inviting", u2.Name);
        local v6, v7 = l__SquadCreateInvite__4:InvokeServer(u2);
        if v6 then
            u3.InviteButton.Visible = false;
            task.delay(16, function() --[[ Line: 45 ]]
                -- upvalues: u3 (ref)
                u3.InviteButton.Visible = true;
            end);
        else
            l__MessageBox__8.Show("Error", v7 or "Unknown error", script.Parent.Parent);
        end;
    end);
    u3.Parent = l__ScrollVisible__5;
    u3.Visible = true;
    return u3;
end;
local u9 = {};
local function v13(u10) --[[ Line: 60 ]]
    -- upvalues: l__LocalPlayer__3 (copy), u1 (copy), u9 (copy), l__Players__1 (copy), u8 (copy)
    if u10 == l__LocalPlayer__3 then
    else
        u1[u10] = {};
        local function v11() --[[ Line: 64 ]]
            -- upvalues: u9 (ref), u10 (copy), l__Players__1 (ref), u8 (ref)
            if u9[u10] then
                u9[u10]:Destroy();
                u9[u10] = nil;
            end;
            if u10.Team == l__Players__1.LocalPlayer.Team then
                u9[u10] = u8(u10);
            end;
        end;
        if u9[u10] then
            u9[u10]:Destroy();
            u9[u10] = nil;
        end;
        if u10.Team == l__Players__1.LocalPlayer.Team then
            u9[u10] = u8(u10);
        end;
        for _, v12 in { u10:GetPropertyChangedSignal("Team"):Connect(v11), l__LocalPlayer__3:GetPropertyChangedSignal("Team"):Connect(v11) } do
            table.insert(u1[u10], v12);
        end;
    end;
end;
l__Players__1.PlayerAdded:Connect(v13);
for _, v14 in l__Players__1:GetChildren() do
    v13(v14);
end;
l__Players__1.PlayerRemoving:Connect(function(p15) --[[ Line: 92 ]]
    -- upvalues: u1 (copy), u9 (copy)
    if u1[p15] then
        for _, v16 in u1[p15] do
            v16:Disconnect();
        end;
        u1[p15] = nil;
    end;
    if u9[p15] then
        u9[p15]:Destroy();
        u9[p15] = nil;
    end;
end);