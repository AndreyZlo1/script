-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.StarterProduct
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__LocalPlayer__2 = game:GetService("Players").LocalPlayer;
local l__PlayerEvents__3 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents");
local l__GetStarterPackExpiry__4 = l__PlayerEvents__3:WaitForChild("GetStarterPackExpiry");
local v1 = l__PlayerEvents__3:WaitForChild("CanGetStarterPackFree"):InvokeServer();
l__PlayerEvents__3:WaitForChild("ClaimFreeStarterPack");
local l__StarterButton__5 = script.Parent:WaitForChild("StarterButton");
local l__Timer__6 = l__StarterButton__5:WaitForChild("ButtonFrame"):WaitForChild("Timer");
local l__InvalidateStarterPack__7 = l__PlayerEvents__3:WaitForChild("InvalidateStarterPack");
local u2 = l__GetStarterPackExpiry__4:InvokeServer() or 0;
local u3 = {
    ShopButton = {
        PackShown = 0.575,
        PackHidden = 0.425
    },
    ModesSquadFrame = {
        PackShown = 0.655,
        PackHidden = 0.505
    },
    UnderstoreFrame = {
        PackShown = 0.735,
        PackHidden = 0.585
    },
    MedalButton = {
        PackShown = 0.495,
        PackHidden = 0.345
    }
};
local function u8(p4) --[[ Line: 53 ]]
    -- upvalues: l__StarterButton__5 (copy), u3 (copy)
    l__StarterButton__5.Visible = p4;
    for v5, v6 in u3 do
        local v7 = script.Parent:WaitForChild(v5);
        v7.Position = UDim2.new(v7.Position.X.Scale, 0, v6[p4 and "PackShown" or "PackHidden"], 0);
    end;
end;
l__InvalidateStarterPack__7.OnClientEvent:Connect(function() --[[ Line: 62 ]]
    -- upvalues: u8 (copy)
    u8(false);
    script:Destroy();
end);
local function v10() --[[ Line: 67 ]]
    -- upvalues: l__LocalPlayer__2 (copy), u2 (ref), l__GetStarterPackExpiry__4 (copy), l__Timer__6 (copy), u8 (copy)
    if l__LocalPlayer__2:GetAttribute("StarterPackPrompted") then
        u2 = l__GetStarterPackExpiry__4:InvokeServer() or 0;
        local v9 = u2 - os.time();
        if v9 > 0 then
            l__Timer__6.Text = `{math.floor(v9 / 86400)}d {math.floor(v9 / 3600 % 24)}h {math.floor(v9 / 60 % 60)}m`;
        end;
        u8(true);
    end;
end;
u8(false);
if v1 then
else
    l__LocalPlayer__2:GetAttributeChangedSignal("StarterPackPrompted"):Connect(v10);
    if l__LocalPlayer__2:GetAttribute("StarterPackPrompted") then
        u2 = l__GetStarterPackExpiry__4:InvokeServer() or 0;
        local v11 = u2 - os.time();
        if v11 > 0 then
            l__Timer__6.Text = `{math.floor(v11 / 86400)}d {math.floor(v11 / 3600 % 24)}h {math.floor(v11 / 60 % 60)}m`;
        end;
        u8(true);
    end;
    while u2 - os.time() > 0 do
        local v12 = u2 - os.time();
        if v12 > 0 then
            l__Timer__6.Text = `{math.floor(v12 / 86400)}d {math.floor(v12 / 3600 % 24)}h {math.floor(v12 / 60 % 60)}m`;
        end;
        task.wait(60);
    end;
    u8(false);
    script:Destroy();
end;