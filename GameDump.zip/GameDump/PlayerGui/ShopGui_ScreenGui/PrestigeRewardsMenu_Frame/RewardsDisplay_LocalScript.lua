-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.PrestigeRewardsMenu.RewardsDisplay
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__ACS_Engine__2 = l__ReplicatedStorage__1:WaitForChild("ACS_Engine");
local l__Modules__3 = l__ReplicatedStorage__1:WaitForChild("Modules");
l__ACS_Engine__2:WaitForChild("GunModels");
l__ReplicatedStorage__1:WaitForChild("Vehicles");
local l__PrestigeModule__4 = require(l__Modules__3:WaitForChild("PrestigeModule"));
local l__LeftButton__5 = script.Parent:WaitForChild("LeftButton");
local l__RightButton__6 = script.Parent:WaitForChild("RightButton");
local l__RewardInfo__7 = script.Parent:WaitForChild("RewardInfo");
local l__ScrollBacking__8 = script.Parent:WaitForChild("ScrollBacking");
local l__Prototype__9 = script:WaitForChild("Prototype");
l__RewardInfo__7:WaitForChild("Name");
local l__Cost__10 = l__RewardInfo__7:WaitForChild("Cost");
local u1 = {
    Visible = l__ScrollBacking__8:WaitForChild("ScrollVisible"),
    Hidden = l__ScrollBacking__8:WaitForChild("ScrollHidden")
};
local u2 = {};
local u3 = false;
for v4, v5 in l__PrestigeModule__4.Rewards do
    for v6, v7 in v5 do
        if not u2[v6] then
            u2[v6] = {};
        end;
        for _, v8 in v7 do
            table.insert(u2[v6], {
                Name = v8,
                Type = v4
            });
        end;
    end;
end;
local function u14(p9, p10) --[[ Line: 43 ]]
    -- upvalues: u2 (copy), l__Prototype__9 (copy)
    for _, v11 in p9:GetChildren() do
        if v11:IsA("Frame") then
            v11:Destroy();
        end;
    end;
    for _, v12 in u2[p10] do
        local v13 = l__Prototype__9:Clone();
        v13.Parent = p9;
        v13.Info.Title.Text = v12.Name;
        v13.Info.Description.Text = "";
    end;
end;
local function u16(p15) --[[ Line: 63 ]]
    -- upvalues: u3 (ref), u1 (copy)
    if u3 then
    else
        u3 = true;
        u1.Hidden.Position = UDim2.new(p15 and 1 or -1, 0, 0, 0);
        u1.Visible:TweenPosition(UDim2.new(p15 and -1 or 1, 0, 0, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Quint, 0.2);
        u1.Hidden:TweenPosition(UDim2.new(0, 0, 0, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Quint, 0.2);
        local l__Visible__11 = u1.Visible;
        u1.Visible = u1.Hidden;
        u1.Hidden = l__Visible__11;
        task.wait(0.22);
        u3 = false;
    end;
end;
local u17 = 1;
l__LeftButton__5.Activated:Connect(function() --[[ Line: 89 ]]
    -- upvalues: u17 (ref), u3 (ref), u14 (copy), u1 (copy), l__Cost__10 (copy), u16 (copy)
    if u17 == 1 or u3 then
    else
        u17 = u17 - 1;
        u14(u1.Hidden, u17);
        l__Cost__10.Text = string.format("Prestige %s", u17);
        u16(false);
    end;
end);
l__RightButton__6.Activated:Connect(function() --[[ Line: 98 ]]
    -- upvalues: u17 (ref), u2 (copy), u3 (ref), u14 (copy), u1 (copy), l__Cost__10 (copy), u16 (copy)
    if u17 >= #u2 or u3 then
    else
        u17 = u17 + 1;
        u14(u1.Hidden, u17);
        l__Cost__10.Text = string.format("Prestige %s", u17);
        u16(true);
    end;
end);
script.Parent:GetPropertyChangedSignal("Visible"):Once(function() --[[ Line: 107 ]]
    -- upvalues: u14 (copy), u1 (copy), l__Cost__10 (copy), u17 (ref)
    u14(u1.Visible, 1);
    u14(u1.Hidden, 2);
    l__Cost__10.Text = string.format("Prestige %s", u17);
end);