-- Roblox: Players.SilverAce293026.PlayerGui.ShopGui.PrestigeFrame.ButtonFrame.Button.PrestigeButtonScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Modules__1 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local l__GuiModule__2 = require(l__Modules__1:WaitForChild("GuiModule"));
local l__Parent__3 = script.Parent;
repeat
    l__Parent__3 = l__Parent__3.Parent;
until l__Parent__3.Name == "ShopGui";
local l__ShopModule__4 = require(l__Parent__3:WaitForChild("ShopModule"));
local l__PrestigeMenu__5 = l__Parent__3:WaitForChild("PrestigeMenu");
local l__PrestigeRewardsMenu__6 = l__Parent__3:WaitForChild("PrestigeRewardsMenu");
local l__Parent__7 = script.Parent;
local l__Parent__8 = l__Parent__7.Parent;
local u1 = true;
l__GuiModule__2.setupButtonSounds(l__Parent__7);
l__Parent__7.MouseButton1Click:connect(function() --[[ Line: 16 ]]
    -- upvalues: u1 (ref), l__PrestigeMenu__5 (copy), l__PrestigeRewardsMenu__6 (copy), l__GuiModule__2 (copy), l__Parent__7 (copy), l__ShopModule__4 (copy)
    if u1 then
        u1 = false;
        if l__PrestigeMenu__5.Visible == false and l__PrestigeRewardsMenu__6.Visible == false then
            l__PrestigeMenu__5.Visible = true;
            l__GuiModule__2.Sounds.modalIn();
            l__GuiModule__2.setModal(l__PrestigeMenu__5, 0.25);
            l__GuiModule__2.buttonPress(l__Parent__7.Parent);
            task.wait(0.3);
        else
            l__ShopModule__4.resetPrestigeMenuState();
            task.wait(0.3);
        end;
        u1 = true;
    end;
end);
l__Parent__8:GetPropertyChangedSignal("Visible"):Connect(function() --[[ Line: 32 ]]
    -- upvalues: u1 (ref), l__ShopModule__4 (copy)
    u1 = false;
    l__ShopModule__4.resetPrestigeMenuState();
    task.wait(0.3);
    u1 = true;
end);