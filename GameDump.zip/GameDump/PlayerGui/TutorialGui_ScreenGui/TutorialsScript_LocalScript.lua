-- Roblox: Players.SilverAce293026.PlayerGui.TutorialGui.TutorialsScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Players__1 = game:GetService("Players");
game:GetService("RunService");
local l__ReplicatedStorage__2 = game:GetService("ReplicatedStorage");
local l__LocalPlayer__3 = l__Players__1.LocalPlayer;
local l__Modules__4 = l__ReplicatedStorage__2:WaitForChild("Modules");
local l__GuiModule__5 = require(l__Modules__4:WaitForChild("GuiModule"));
local l__ContextArrowModule__6 = require(l__Modules__4:WaitForChild("ContextArrowModule"));
local l__BindableEvents__7 = l__ReplicatedStorage__2:WaitForChild("BindableEvents");
local l__StartTutorial__8 = l__BindableEvents__7:WaitForChild("StartTutorial");
local l__ProgressTutorial__9 = l__BindableEvents__7:WaitForChild("ProgressTutorial");
local l__TutorialAlreadyDone__10 = l__BindableEvents__7:WaitForChild("TutorialAlreadyDone");
local l__PlayClicked__11 = l__BindableEvents__7:WaitForChild("PlayClicked");
local l__StartTutorial__12 = l__ReplicatedStorage__2:WaitForChild("PlayerEvents"):WaitForChild("StartTutorial");
if require(l__ReplicatedStorage__2:WaitForChild("ReplicatedConfig")).Mode == "Tycoon" then
    local l__AssociatedTycoon__13 = l__LocalPlayer__3:WaitForChild("AssociatedTycoon", (1 / 0));
    local u1 = workspace:WaitForChild(l__AssociatedTycoon__13.Value);
    local l__Parent__14 = script.Parent;
    l__Parent__14:WaitForChild("ObjectFrame");
    local l__TextFrame__15 = l__Parent__14:WaitForChild("TextFrame");
    local l__TextLabel__16 = l__TextFrame__15:WaitForChild("TextLabel");
    local l__ConfirmButton__17 = l__TextFrame__15:WaitForChild("ConfirmButton");
    local l__Button__18 = l__ConfirmButton__17:WaitForChild("ButtonFrame"):WaitForChild("Button");
    local u2 = {
        {
            IsCompleted = false,
            Name = "buildExtractor",
            Text = "Hello, Commander ${displayName}. Build an oil extractor to start making money so you can build your base. Follow the arrow."
        },
        {
            IsCompleted = false,
            Name = "collectCash",
            Text = "Nicely done! You can build more oil extractors and upgrade existing ones to increase profits. Go collect your earnings. Follow the arrow."
        },
        {
            IsCompleted = false,
            Name = "finalInstruction",
            Text = "Well done! Keep in mind there are ways to earn money outside of your base. Hardpoints boost your oil rig income and minigames give huge rewards. Good luck, Commander!"
        }
    };
    local function u5(p3, _) --[[ Line: 53 ]]
        -- upvalues: l__TextLabel__16 (copy), l__LocalPlayer__3 (copy), l__ConfirmButton__17 (copy), l__Button__18 (copy), u1 (copy), l__ContextArrowModule__6 (copy)
        l__TextLabel__16.Text = string.gsub(p3.Text, "${displayName}", l__LocalPlayer__3.DisplayName);
        l__ConfirmButton__17.Visible = p3.Name == "finalInstruction";
        l__Button__18:SetAttribute("TaskName", p3.Name);
        if p3.Name == "buildExtractor" then
            local v4 = u1.BuyButtons.Extractor1:FindFirstChild("ButtonPart");
            l__ContextArrowModule__6.SetTarget(v4);
        elseif p3.Name == "collectCash" then
            l__ContextArrowModule__6.SetTarget(u1.CashGiver.CashCollectButton);
        else
            l__ContextArrowModule__6.Clear();
        end;
    end;
    local function v6() --[[ Line: 68 ]]
        -- upvalues: l__ContextArrowModule__6 (copy), l__Parent__14 (copy)
        l__ContextArrowModule__6.Clear();
        spawn(function() --[[ Line: 70 ]]
            -- upvalues: l__Parent__14 (ref)
            l__Parent__14:Destroy();
        end);
    end;
    local function u7() --[[ Line: 76 ]]
        -- upvalues: u1 (copy), u2 (copy), u5 (copy), l__ContextArrowModule__6 (copy), l__Parent__14 (copy)
        if u1.BuyButtons:FindFirstChild("Extractor1") and not u2[1].IsCompleted then
            u5(u2[1]);
        elseif u2[2].IsCompleted then
            if u2[3].IsCompleted then
                l__ContextArrowModule__6.Clear();
                spawn(function() --[[ Line: 70 ]]
                    -- upvalues: l__Parent__14 (ref)
                    l__Parent__14:Destroy();
                end);
            else
                u5(u2[3]);
            end;
        else
            u5(u2[2]);
        end;
    end;
    l__GuiModule__5.setupButtonSounds(l__Button__18);
    l__Button__18.MouseButton1Click:Connect(function() --[[ Line: 90 ]]
        -- upvalues: l__Button__18 (copy), u2 (copy), u7 (copy)
        local v8 = l__Button__18:GetAttribute("TaskName");
        if v8 then
            for _, v9 in ipairs(u2) do
                if v9.Name == v8 then
                    v9.IsCompleted = true;
                    u7();
                    return;
                end;
            end;
        end;
    end);
    if require(game.ReplicatedStorage:WaitForChild("ReplicatedConfig")).Mode == "Tycoon" then
        local u10 = false;
        l__PlayClicked__11.Event:Connect(function() --[[ Line: 108 ]]
            -- upvalues: u10 (ref)
            u10 = true;
        end);
        l__StartTutorial__8.Event:Connect(function() --[[ Name: startTutorial, Line 112 ]]
            -- upvalues: u10 (ref), l__StartTutorial__12 (copy), l__TextFrame__15 (copy), l__GuiModule__5 (copy), u7 (copy), l__ProgressTutorial__9 (copy), u2 (copy)
            repeat
                task.wait();
            until u10;
            l__StartTutorial__12:FireServer();
            l__TextFrame__15.Visible = true;
            l__GuiModule__5.setModal(l__TextFrame__15, 0.65);
            u7();
            l__ProgressTutorial__9.Event:Connect(function(p11) --[[ Line: 122 ]]
                -- upvalues: u2 (ref), u7 (ref)
                for _, v12 in ipairs(u2) do
                    if v12.Name == p11 then
                        v12.IsCompleted = true;
                    end;
                end;
                u7();
            end);
        end);
        l__TutorialAlreadyDone__10.Event:Connect(v6);
    end;
end;