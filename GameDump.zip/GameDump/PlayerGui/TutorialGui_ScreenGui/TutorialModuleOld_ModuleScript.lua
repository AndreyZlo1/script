-- Roblox: Players.SilverAce293026.PlayerGui.TutorialGui.TutorialModuleOld
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__Players__1 = game:GetService("Players");
local l__TweenService__2 = game:GetService("TweenService");
local l__RunService__3 = game:GetService("RunService");
local l__ReplicatedStorage__4 = game:GetService("ReplicatedStorage");
local l__LocalPlayer__5 = l__Players__1.LocalPlayer;
local l__Modules__6 = l__ReplicatedStorage__4:WaitForChild("Modules");
local l__GuiModule__7 = require(l__Modules__6:WaitForChild("GuiModule"));
local l__TutorialTaskCompleted__8 = l__ReplicatedStorage__4:WaitForChild("BindableEvents"):WaitForChild("TutorialTaskCompleted");
local l__AssociatedTycoon__9 = l__LocalPlayer__5:WaitForChild("AssociatedTycoon", (1 / 0));
local u2 = workspace:WaitForChild(l__AssociatedTycoon__9.Value);
local l__Parent__10 = script.Parent;
local l__ObjectFrame__11 = l__Parent__10:WaitForChild("ObjectFrame");
local l__ConfirmButton__12 = l__Parent__10:WaitForChild("TextFrame"):WaitForChild("ConfirmButton");
local l__Button__13 = l__ConfirmButton__12:WaitForChild("ButtonFrame"):WaitForChild("Button");
local l__Scale__14 = l__ObjectFrame__11.Size.X.Scale;
local u3 = l__TweenService__2:Create(l__ObjectFrame__11, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, (1 / 0), true, 0.2), {
    Size = UDim2.new(l__Scale__14 * 0.7, 0, l__Scale__14 * 0.7, 0)
});
local u4 = {
    {
        IsCompleted = false,
        Name = "buildExtractor",
        Text = "Hello, Commander ${displayName}! I\'ll walk you through the mission objectives. Your main goal is to build a forward operating base in this area. Let\'s build an oil extractor to start making money. Follow the arrow to the extractor site."
    },
    {
        IsCompleted = false,
        Name = "collectCash",
        Text = "Great! You\'ve started earning money. Remember to build new oil extractors and upgrade existing ones to increase profits. Let\'s go collect your earnings! Follow the arrow to your money collector."
    },
    {
        IsCompleted = false,
        Name = "finalInstruction",
        Text = "There are many ways to earn more money here. Capture Hardpoints for a 50% profits boost or win Deathmatches for huge prizes! I know the base will prosper under your leadership. Good luck, Commander."
    }
};
function v1.animate() --[[ Line: 65 ]]
    -- upvalues: u3 (copy)
    u3:Play();
end;
function v1.stopAnimating() --[[ Line: 69 ]]
    -- upvalues: u3 (copy)
    u3:Cancel();
end;
local function u11(p5) --[[ Line: 91 ]]
    -- upvalues: l__LocalPlayer__5 (copy)
    if p5 == nil then
    else
        local v6 = l__LocalPlayer__5.Character or l__LocalPlayer__5.CharacterAdded:Wait();
        if v6 then
            v6 = v6:WaitForChild("HumanoidRootPart", 5);
        end;
        if v6 then
            local v7 = l__LocalPlayer__5.Character or l__LocalPlayer__5.CharacterAdded:Wait();
            if v7 then
                v7 = v7:WaitForChild("HumanoidRootPart", 5);
            end;
            if v7 and v7:FindFirstChild("HRPBeamAtt") then
                v7.HRPBeamAtt:Destroy();
            end;
            if v7 and v7:FindFirstChild("TutorialBeam") then
                v7.TutorialBeam:Destroy();
            end;
            local v8 = Instance.new("Beam", v6);
            v8.Name = "TutorialBeam";
            v8.Color = ColorSequence.new(Color3.fromRGB(0, 0, 0));
            local v9 = Instance.new("Attachment", p5);
            v9.Name = "BeamAtt";
            local v10 = Instance.new("Attachment", v6);
            v10.Name = "HRPBeamAtt";
            v8.Attachment0 = v9;
            v8.Attachment1 = v10;
        end;
    end;
end;
local function u14(p12, _) --[[ Line: 120 ]]
    -- upvalues: l__ConfirmButton__12 (copy), u2 (copy), u11 (copy), l__LocalPlayer__5 (copy)
    l__ConfirmButton__12.Visible = p12.Name == "finalInstruction";
    l__ConfirmButton__12:SetAttribute("TaskName", p12.Name);
    if p12.Name == "buildExtractor" then
        u11((u2.BuyButtons.Extractor1:FindFirstChild("ButtonPart")));
    elseif p12.Name == "collectCash" then
        u11(u2.CashGiver.CashCollectButton);
    else
        local v13 = l__LocalPlayer__5.Character or l__LocalPlayer__5.CharacterAdded:Wait();
        if v13 then
            v13 = v13:WaitForChild("HumanoidRootPart", 5);
        end;
        if v13 and v13:FindFirstChild("HRPBeamAtt") then
            v13.HRPBeamAtt:Destroy();
        end;
        if v13 and v13:FindFirstChild("TutorialBeam") then
            v13.TutorialBeam:Destroy();
        end;
    end;
end;
local function u16() --[[ Line: 139 ]]
    -- upvalues: u2 (copy), u4 (copy), u14 (copy), l__LocalPlayer__5 (copy), l__Parent__10 (copy)
    if u2.BuyButtons:FindFirstChild("Extractor1") and not u4[1].IsCompleted then
        u14(u4[1]);
    elseif u4[2].IsCompleted then
        if u4[3].IsCompleted then
            local v15 = l__LocalPlayer__5.Character or l__LocalPlayer__5.CharacterAdded:Wait();
            if v15 then
                v15 = v15:WaitForChild("HumanoidRootPart", 5);
            end;
            if v15 and v15:FindFirstChild("HRPBeamAtt") then
                v15.HRPBeamAtt:Destroy();
            end;
            if v15 and v15:FindFirstChild("TutorialBeam") then
                v15.TutorialBeam:Destroy();
            end;
            l__Parent__10:Destroy();
        else
            u14(u4[3]);
        end;
    else
        u14(u4[2]);
    end;
end;
l__GuiModule__7.setupButtonSounds(l__Button__13);
l__Button__13.MouseButton1Click:Connect(function() --[[ Line: 153 ]]
    -- upvalues: l__Button__13 (copy), u4 (copy), u16 (copy)
    local v17 = l__Button__13:GetAttribute("TaskName");
    if v17 then
        for _, v18 in ipairs(u4) do
            if v18.Name == v17 then
                v18.IsCompleted = true;
                u16();
                return;
            end;
        end;
    end;
end);
function v1.startTutorial() --[[ Line: 165 ]]
    -- upvalues: u16 (copy), l__RunService__3 (copy), l__TutorialTaskCompleted__8 (copy), u4 (copy)
    u16();
    l__RunService__3.RenderStepped:Connect(function() --[[ Line: 167 ]] end);
    l__TutorialTaskCompleted__8.Event:Connect(function(p19) --[[ Line: 170 ]]
        -- upvalues: u4 (ref), u16 (ref)
        for _, v20 in ipairs(u4) do
            if v20.Name == p19 then
                v20.IsCompleted = true;
            end;
        end;
        u16();
    end);
end;
return v1;