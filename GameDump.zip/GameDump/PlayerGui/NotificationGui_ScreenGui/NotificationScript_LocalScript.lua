-- Roblox: Players.SilverAce293026.PlayerGui.NotificationGui.NotificationScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

game:GetService("ServerScriptService");
local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__RunService__2 = game:GetService("RunService");
local l__LocalPlayer__3 = game:GetService("Players").LocalPlayer;
local l__TycoonModule__4 = require(l__ReplicatedStorage__1:WaitForChild("Modules"):WaitForChild("TycoonModule"));
local l__MinigameEvents__5 = l__ReplicatedStorage__1:WaitForChild("MinigameEvents");
local l__SignupNotification__6 = l__MinigameEvents__5:WaitForChild("SignupNotification");
local l__ErrorNotification__7 = l__MinigameEvents__5:WaitForChild("ErrorNotification");
local l__WinnerNotification__8 = l__MinigameEvents__5:WaitForChild("WinnerNotification");
local l__Notification__9 = l__MinigameEvents__5:WaitForChild("Notification");
local l__StartCountdown__10 = l__MinigameEvents__5:WaitForChild("StartCountdown");
local l__ActivePlayersChanged__11 = l__MinigameEvents__5:WaitForChild("ActivePlayersChanged");
local l__TeamStatsChanged__12 = l__MinigameEvents__5:WaitForChild("TeamStatsChanged");
l__MinigameEvents__5:WaitForChild("TeleportTo");
local l__MinigameEnded__13 = l__MinigameEvents__5:WaitForChild("MinigameEnded");
local l__MinigameEvent__14 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents"):WaitForChild("MinigameEvent");
local l__NotificationFrame__15 = script.Parent:WaitForChild("NotificationFrame");
local l__NotificationLabel__16 = l__NotificationFrame__15:WaitForChild("NotificationLabel");
local l__CountdownLabel__17 = l__NotificationFrame__15:WaitForChild("CountdownLabel");
local l__ButtonsFrame__18 = l__NotificationFrame__15:WaitForChild("ButtonsFrame");
local l__Button__19 = l__ButtonsFrame__18:WaitForChild("Accept"):WaitForChild("ButtonFrame"):WaitForChild("Button");
local l__Button__20 = l__ButtonsFrame__18:WaitForChild("Decline"):WaitForChild("ButtonFrame"):WaitForChild("Button");
local l__TeamsFrame__21 = l__NotificationFrame__15:WaitForChild("TeamsFrame");
local l__Progress__22 = l__TeamsFrame__21:WaitForChild("Blue"):WaitForChild("Progress");
local l__ProgressLabel__23 = l__Progress__22:WaitForChild("ProgressLabel");
local l__NameLabel__24 = l__TeamsFrame__21.Blue:WaitForChild("NameLabel");
local l__Progress__25 = l__TeamsFrame__21:WaitForChild("Red"):WaitForChild("Progress");
local l__ProgressLabel__26 = l__Progress__25:WaitForChild("ProgressLabel");
local l__NameLabel__27 = l__TeamsFrame__21.Red:WaitForChild("NameLabel");
local l__NameLabel__28 = l__TeamsFrame__21:WaitForChild("Target"):WaitForChild("NameLabel");
local l__WinNotification__29 = script:WaitForChild("WinNotification");
local u1 = nil;
local u2 = nil;
local u3 = 0;
local l__DailySpin__30 = l__LocalPlayer__3:WaitForChild("PlayerGui"):WaitForChild("DailySpin");
local function v6(p4, p5) --[[ Line: 64 ]]
    -- upvalues: u1 (ref), u2 (ref)
    u1 = p5;
    u2 = p4;
end;
local function v9(p7, p8) --[[ Line: 69 ]]
    -- upvalues: l__ButtonsFrame__18 (copy), l__NotificationLabel__16 (copy), u3 (ref)
    l__ButtonsFrame__18.Visible = false;
    l__NotificationLabel__16.Text = p7;
    u3 = workspace:GetServerTimeNow() + (p8 or 3);
end;
local function v11(p10) --[[ Line: 75 ]]
    -- upvalues: u3 (ref), l__ButtonsFrame__18 (copy), l__TeamsFrame__21 (copy), u1 (ref), l__NotificationLabel__16 (copy)
    if u3 == nil then
        u3 = 0;
    end;
    l__ButtonsFrame__18.Visible = false;
    l__TeamsFrame__21.Visible = false;
    u1 = nil;
    if p10 then
        l__NotificationLabel__16.Text = p10;
        u3 = workspace:GetServerTimeNow() + 3;
    end;
end;
function convertToMS(p12)
    local v13 = (p12 - p12 % 60) / 60;
    local v14 = p12 - v13 * 60;
    return string.format("%02i", v13) .. ":" .. string.format("%02i", v14);
end;
l__StartCountdown__10.OnClientEvent:Connect(v6);
l__Notification__9.OnClientEvent:Connect(v9);
l__ErrorNotification__7.OnClientEvent:Connect(v9);
l__MinigameEnded__13.OnClientEvent:Connect(v11);
l__SignupNotification__6.OnClientEvent:Connect(function(p15, p16, p17) --[[ Line: 97 ]]
    -- upvalues: l__TycoonModule__4 (copy), l__LocalPlayer__3 (copy), l__DailySpin__30 (copy), u3 (ref), l__ButtonsFrame__18 (copy), l__TeamsFrame__21 (copy), u1 (ref), u2 (ref), l__NotificationLabel__16 (copy)
    if l__TycoonModule__4.isBaseShieldEnabled(l__TycoonModule__4.tycoonNameForPlayer(l__LocalPlayer__3)) then
    elseif l__DailySpin__30.Enabled then
    else
        if u3 == nil then
            u3 = 0;
        end;
        l__ButtonsFrame__18.Visible = false;
        l__TeamsFrame__21.Visible = false;
        u1 = nil;
        u1 = p16;
        u2 = nil;
        u3 = nil;
        if p17 then
            p15 = "<font color=\"" .. p17 .. "\">" .. p15 .. "</font>";
        end;
        l__NotificationLabel__16.Text = p15 .. " is starting";
        l__ButtonsFrame__18.Visible = true;
    end;
end);
l__WinnerNotification__8.OnClientEvent:Connect(function(p18) --[[ Line: 110 ]]
    -- upvalues: l__WinNotification__29 (copy), u3 (ref), l__ButtonsFrame__18 (copy), l__TeamsFrame__21 (copy), u1 (ref), l__NotificationLabel__16 (copy)
    l__WinNotification__29:Play();
    if u3 == nil then
        u3 = 0;
    end;
    l__ButtonsFrame__18.Visible = false;
    l__TeamsFrame__21.Visible = false;
    u1 = nil;
    if p18 then
        l__NotificationLabel__16.Text = p18;
        u3 = workspace:GetServerTimeNow() + 3;
    end;
end);
l__ActivePlayersChanged__11.OnClientEvent:Connect(function(p19) --[[ Line: 115 ]]
    -- upvalues: l__NotificationLabel__16 (copy)
    l__NotificationLabel__16.Text = "Players alive: " .. #p19;
    local _ = #p19 < 3;
end);
l__TeamStatsChanged__12.OnClientEvent:Connect(function(p20, p21, p22) --[[ Line: 124 ]]
    -- upvalues: l__TeamsFrame__21 (copy), l__Progress__22 (copy), l__Progress__25 (copy), l__ProgressLabel__23 (copy), l__ProgressLabel__26 (copy), l__NameLabel__24 (copy), l__NameLabel__27 (copy), l__NameLabel__28 (copy)
    l__TeamsFrame__21.Visible = true;
    l__Progress__22.Size = UDim2.new(p20.score / p22, 0, 1, 0);
    l__Progress__25.Size = UDim2.new(p21.score / p22, 0, 1, 0);
    l__ProgressLabel__23.Text = p20.score;
    l__ProgressLabel__26.Text = p21.score;
    l__NameLabel__24.Text = p20.name;
    l__NameLabel__27.Text = p21.name;
    l__NameLabel__28.Text = p22;
end);
l__Button__19.MouseButton1Click:connect(function() --[[ Line: 135 ]]
    -- upvalues: l__SignupNotification__6 (copy), l__ButtonsFrame__18 (copy)
    l__SignupNotification__6:FireServer();
    l__ButtonsFrame__18.Visible = false;
end);
l__MinigameEvent__14.OnClientEvent:Connect(function(p23) --[[ Line: 140 ]]
    -- upvalues: l__NotificationLabel__16 (copy)
    if p23 == "GameStarted" then
        l__NotificationLabel__16.Text = "";
    end;
end);
l__Button__20.MouseButton1Click:connect(function() --[[ Line: 146 ]]
    -- upvalues: u3 (ref), l__ButtonsFrame__18 (copy), l__TeamsFrame__21 (copy), u1 (ref)
    if u3 == nil then
        u3 = 0;
    end;
    l__ButtonsFrame__18.Visible = false;
    l__TeamsFrame__21.Visible = false;
    u1 = nil;
end);
l__RunService__2.RenderStepped:Connect(function() --[[ Line: 150 ]]
    -- upvalues: u3 (ref), l__NotificationLabel__16 (copy), u1 (ref), l__CountdownLabel__17 (copy), u2 (ref), l__ButtonsFrame__18 (copy), l__TeamsFrame__21 (copy)
    if u3 == nil or u3 >= workspace:GetServerTimeNow() then
        l__NotificationLabel__16.Visible = true;
    else
        l__NotificationLabel__16.Visible = false;
    end;
    if u1 and u1 >= workspace:GetServerTimeNow() then
        l__CountdownLabel__17.Visible = true;
        local v24 = convertToMS(u1 - workspace:GetServerTimeNow());
        local v25 = l__CountdownLabel__17;
        if u2 then
            v24 = u2 .. v24 or v24;
        end;
        v25.Text = v24;
    elseif l__ButtonsFrame__18.Visible then
        if u3 == nil then
            u3 = 0;
        end;
        l__ButtonsFrame__18.Visible = false;
        l__TeamsFrame__21.Visible = false;
        u1 = nil;
        l__CountdownLabel__17.Visible = false;
    else
        l__CountdownLabel__17.Visible = false;
    end;
end);