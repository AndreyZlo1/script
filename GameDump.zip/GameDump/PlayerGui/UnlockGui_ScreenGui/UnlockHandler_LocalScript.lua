-- Roblox: Players.SilverAce293026.PlayerGui.UnlockGui.UnlockHandler
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Attachments__2 = l__ReplicatedStorage__1:WaitForChild("ACS_Engine"):WaitForChild("Attachments");
local l__WeaponProgression__3 = l__ReplicatedStorage__1:WaitForChild("WeaponProgression");
local l__Attachments__4 = require(l__WeaponProgression__3:WaitForChild("Attachments"));
local l__WeaponLevelUp__5 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents"):WaitForChild("WeaponLevelUp");
local l__UnlockModule__6 = require(script.Parent:WaitForChild("UnlockModule"));
l__WeaponLevelUp__5.OnClientEvent:Connect(function(p1, p2, p3) --[[ Name: onLevelUp, Line 16 ]]
    -- upvalues: l__Attachments__4 (copy), l__Attachments__2 (copy), l__UnlockModule__6 (copy)
    local v4, v5;
    if p3 then
        local v6 = l__Attachments__4.attachments[p3];
        v4 = v6.name;
        v5 = l__Attachments__2:WaitForChild(v6.folder or "Universal").Models:FindFirstChild(v4);
    else
        v4 = nil;
        v5 = nil;
    end;
    l__UnlockModule__6.ShowReward(p1, p2, v4, v5);
end);