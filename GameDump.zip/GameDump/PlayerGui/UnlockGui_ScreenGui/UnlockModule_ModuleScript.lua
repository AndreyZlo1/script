-- Roblox: Players.SilverAce293026.PlayerGui.UnlockGui.UnlockModule
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
TweenInfo.new(0.7, Enum.EasingStyle.Quint, Enum.EasingDirection.Out);
local u2 = TweenInfo.new(0.5, Enum.EasingStyle.Quint, Enum.EasingDirection.Out);
TweenInfo.new(0.18, Enum.EasingStyle.Quint, Enum.EasingDirection.Out);
local l__TweenService__1 = game:GetService("TweenService");
local l__ReplicatedStorage__2 = game:GetService("ReplicatedStorage");
l__ReplicatedStorage__2:WaitForChild("PlayerEvents");
local l__Modules__3 = l__ReplicatedStorage__2:WaitForChild("Modules");
local l__GuiModule__4 = require(l__Modules__3:WaitForChild("GuiModule"));
local l__Container__5 = script.Parent:WaitForChild("Container");
local l__Title__6 = l__Container__5:WaitForChild("Title");
local l__TitleSub__7 = l__Container__5:WaitForChild("TitleSub");
local l__Unlock__8 = l__Container__5:WaitForChild("Unlock");
local l__UnlockSub__9 = l__Container__5:WaitForChild("UnlockSub");
local l__Viewport__10 = l__Container__5:WaitForChild("Viewport");
local u3 = false;
local u4 = Instance.new("Camera", script);
l__Viewport__10.CurrentCamera = u4;
local function u6() --[[ Line: 31 ]]
    -- upvalues: l__Container__5 (copy), l__Viewport__10 (copy), l__Title__6 (copy), l__TitleSub__7 (copy), l__UnlockSub__9 (copy), l__Unlock__8 (copy)
    l__Container__5.Visible = false;
    local v5 = l__Viewport__10:FindFirstChildOfClass("Model");
    if v5 then
        v5:Destroy();
    end;
    l__Title__6.UIGradient.Rotation = 180;
    l__Title__6.UIGradient.Offset = Vector2.new(-1, 0);
    l__TitleSub__7.UIGradient.Rotation = 180;
    l__TitleSub__7.UIGradient.Offset = Vector2.new(-1, 0);
    l__Viewport__10.UIGradient.Rotation = 0;
    l__Viewport__10.UIGradient.Offset = Vector2.new(-1, 0);
    l__UnlockSub__9.UIGradient.Rotation = 180;
    l__UnlockSub__9.UIGradient.Offset = Vector2.new(-1, 0);
    l__Unlock__8.UIGradient.Rotation = 0;
    l__Unlock__8.UIGradient.Offset = Vector2.new(0, 0);
    l__TitleSub__7.Visible = true;
    l__UnlockSub__9.Visible = false;
end;
function v1.ShowReward(p7, p8, u9, u10) --[[ Line: 56 ]]
    -- upvalues: u3 (ref), u6 (copy), l__Container__5 (copy), l__TitleSub__7 (copy), l__UnlockSub__9 (copy), l__Unlock__8 (copy), l__Viewport__10 (copy), l__GuiModule__4 (copy), u4 (copy), l__TweenService__1 (copy), l__Title__6 (copy), u2 (copy)
    if u3 then
    else
        u3 = true;
        u6();
        l__Container__5.Visible = true;
        l__TitleSub__7.Text = p7;
        l__UnlockSub__9.Text = string.format("LEVEL %s", p8);
        l__Unlock__8.Text = u9 or "";
        if u10 then
            local v11 = u10:Clone();
            v11.Parent = l__Viewport__10;
            l__GuiModule__4.CameraZoom.zoomToExtents(u4, v11, 0, 0);
        end;
        local u12 = l__TweenService__1:Create(l__Title__6.UIGradient, u2, {
            Offset = Vector2.new(0, 0)
        });
        local u13 = l__TweenService__1:Create(l__Viewport__10.UIGradient, u2, {
            Offset = Vector2.new(1, 0)
        });
        local u14 = l__TweenService__1:Create(l__Unlock__8.UIGradient, u2, {
            Offset = Vector2.new(1, 0)
        });
        local u15 = l__TweenService__1:Create(l__Unlock__8.UIGradient, u2, {
            Offset = Vector2.new(0, 0)
        });
        local u16 = l__TweenService__1:Create(l__TitleSub__7.UIGradient, u2, {
            Offset = Vector2.new(0, 0)
        });
        local u17 = l__TweenService__1:Create(l__Viewport__10.UIGradient, u2, {
            Offset = Vector2.new(1, 0)
        });
        local u18 = l__TweenService__1:Create(l__UnlockSub__9.UIGradient, u2, {
            Offset = Vector2.new(0, 0)
        });
        u12.Completed:Connect(function() --[[ Line: 104 ]]
            -- upvalues: u9 (copy), u10 (copy), u13 (copy), u16 (copy), u6 (ref), u3 (ref)
            if u9 and u10 then
                u13:Play();
            else
                task.wait(1.5);
                u16.Completed:Connect(function() --[[ Line: 110 ]]
                    -- upvalues: u6 (ref), u3 (ref)
                    u6();
                    u3 = false;
                end);
                u16:Play();
            end;
        end);
        u13.Completed:Connect(function() --[[ Line: 119 ]]
            -- upvalues: u14 (copy), l__Viewport__10 (ref)
            u14:Play();
            l__Viewport__10.UIGradient.Rotation = 180;
            l__Viewport__10.UIGradient.Offset = Vector2.new(-1, 0);
        end);
        u14.Completed:Connect(function() --[[ Line: 125 ]]
            -- upvalues: l__Unlock__8 (ref), l__UnlockSub__9 (ref), u15 (copy)
            l__Unlock__8.UIGradient.Rotation = 180;
            l__Unlock__8.UIGradient.Offset = Vector2.new(-1, 0);
            task.wait(1);
            l__UnlockSub__9.Visible = true;
            u15:Play();
        end);
        u15.Completed:Connect(function() --[[ Line: 133 ]]
            -- upvalues: u16 (copy)
            u16:Play();
        end);
        u16.Completed:Connect(function() --[[ Line: 137 ]]
            -- upvalues: u9 (copy), u10 (copy), u17 (copy)
            if u9 or not u10 then
                u17:Play();
            end;
        end);
        u17.Completed:Connect(function() --[[ Line: 142 ]]
            -- upvalues: u18 (copy)
            u18:Play();
        end);
        u18.Completed:Connect(function() --[[ Line: 146 ]]
            -- upvalues: u3 (ref)
            u3 = false;
        end);
        task.spawn(function() --[[ Line: 152 ]]
            -- upvalues: l__Title__6 (ref), u12 (copy)
            local v19 = Color3.fromRGB(255, 255, 255);
            local v20 = Color3.fromRGB();
            for _ = 1, 6 do
                local v21 = l__Title__6.BackgroundColor3 == v20;
                l__Title__6.BackgroundColor3 = v21 and v19 and v19 or v20;
                l__Title__6.TextColor3 = v21 and v20 and v20 or v19;
                task.wait(0.08);
            end;
            task.wait(0.3);
            u12:Play();
        end);
    end;
end;
u6();
return v1;