-- Roblox: Players.SilverAce293026.PlayerGui.KillNotifs.KillStack.StackArea.LogEvent
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__StackHandler__2 = require(script.Parent:WaitForChild("StackHandler"));
local l__GameplayEvents__3 = l__ReplicatedStorage__1:WaitForChild("GameplayEvents");
local l__KillEvent__4 = l__GameplayEvents__3:WaitForChild("KillEvent");
local l__MiscRewardEvent__5 = l__GameplayEvents__3:WaitForChild("MiscRewardEvent");
local function u9(p1, p2, p3, p4, p5) --[[ Line: 9 ]]
    -- upvalues: l__StackHandler__2 (copy)
    local v6 = {};
    for _, v7 in p5 do
        local v8 = {
            Cash = 0,
            Name = string.sub(v7.name, 1, 1):upper() .. string.sub(v7.name, 2),
            EXP = v7.exp
        };
        table.insert(v6, v8);
    end;
    l__StackHandler__2.PushToStack(p1, p2, {
        Cash = p3,
        EXP = p4
    }, v6);
end;
l__KillEvent__4.OnClientEvent:Connect(function(p10, p11, p12, p13) --[[ Line: 20 ]]
    -- upvalues: u9 (copy)
    u9("Killed Enemy", p10, p11, p12, p13);
    local v14 = script.KillSound:Clone();
    v14.Parent = script;
    v14.PlayOnRemove = true;
    v14:Destroy();
end);
l__MiscRewardEvent__5.OnClientEvent:Connect(u9);