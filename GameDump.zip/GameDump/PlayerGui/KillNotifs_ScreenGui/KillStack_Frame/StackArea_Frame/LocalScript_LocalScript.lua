-- Roblox: Players.SilverAce293026.PlayerGui.KillNotifs.KillStack.StackArea.LocalScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__StackHandler__1 = require(script.Parent:WaitForChild("StackHandler"));
task.wait(30);
for _, v1 in {
    {
        "Enemy Killed",
        "SkyVeldin",
        {
            Cash = 100,
            EXP = 300
        },
        {
            {
                Name = "Headshot",
                Cash = 25,
                EXP = 15
            },
            {
                Name = "Revenge kill",
                Cash = 75,
                EXP = 35
            }
        }
    },
    {
        "Transported ally",
        "Warehouse",
        {
            Cash = 45,
            EXP = 0
        }
    },
    {
        "Destroyed vehicle",
        "BTR-90",
        {
            Cash = 170,
            EXP = 100
        }
    }
} do
    task.wait(1);
    l__StackHandler__1.PushToStack(unpack(v1));
end;