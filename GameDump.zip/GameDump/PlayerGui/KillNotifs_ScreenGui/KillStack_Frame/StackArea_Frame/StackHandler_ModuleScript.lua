-- Roblox: Players.SilverAce293026.PlayerGui.KillNotifs.KillStack.StackArea.StackHandler
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__TweenService__1 = game:GetService("TweenService");
local l__RunService__2 = game:GetService("RunService");
local u2 = TweenInfo.new(0.5, Enum.EasingStyle.Quint, Enum.EasingDirection.Out);
local u3 = TweenInfo.new(0.35, Enum.EasingStyle.Quint, Enum.EasingDirection.Out);
local u4 = TweenInfo.new(0.18, Enum.EasingStyle.Quint, Enum.EasingDirection.Out);
local l__Parent__3 = script.Parent;
local l__Prototype__4 = l__Parent__3:WaitForChild("Prototype");
local l__Prototype__5 = l__Prototype__4:WaitForChild("Conditions"):WaitForChild("Prototype");
local u5 = 0;
local u6 = l__Prototype__4.Size.Y.Scale + 0.04;
local u7 = {};
local u8 = false;
local function u11() --[[ Line: 27 ]]
    -- upvalues: u8 (ref), u7 (copy), u6 (copy), u11 (copy)
    if u8 then
    elseif #u7 == 0 then
    else
        u8 = true;
        u7[1].FullTween();
        u7[1].Frame:Destroy();
        table.remove(u7, 1);
        for v9, v10 in u7 do
            v10.Frame.Position = UDim2.new(0, 0, 1 - (v9 - 2) * u6, 0);
        end;
        u8 = false;
        u11();
    end;
end;
function v1.PushToStack(p12, u13, u14, p15) --[[ Line: 57 ]]
    -- upvalues: u5 (ref), l__Prototype__4 (copy), l__Prototype__5 (copy), u7 (copy), u6 (copy), l__Parent__3 (copy), l__TweenService__1 (copy), u4 (copy), u2 (copy), u3 (copy), l__RunService__2 (copy), u11 (copy)
    u5 = u5 + 1;
    local u16 = {
        EXP = u14.EXP > 0,
        Cash = u14.Cash > 0
    };
    for v17, v18 in u16 do
        if not v18 then
            for _, v19 in p15 do
                if v19[v17] > 0 then
                    u16[v17] = true;
                    break;
                end;
            end;
        end;
    end;
    local u20 = l__Prototype__4:Clone();
    u20.Name = p12;
    u20.Main.Root.Text = p12:upper();
    u20.Main.Sub.Text = u13 or "";
    local u21 = p15 or {};
    local u22 = {};
    for _, v23 in u21 do
        local v24 = l__Prototype__5:Clone();
        v24.Name = v23.Name;
        v24.Parent = u20.Conditions;
        v24.Visible = true;
        v24.Top.Text = v23.Name;
        v24.Under.Text = v23.Name;
        table.insert(u22, v24);
    end;
    local v25 = {
        Frame = u20
    };
    local l__Frame__6 = v25.Frame;
    l__Frame__6.Position = UDim2.new(0, 0, 1 - (#u7 - 1) * u6, 0);
    l__Frame__6.Visible = true;
    l__Frame__6.Parent = l__Parent__3;
    function v25.FullTween() --[[ Line: 109 ]]
        -- upvalues: u20 (copy), u16 (copy), l__TweenService__1 (ref), u4 (ref), u2 (ref), u22 (copy), u3 (ref), l__RunService__2 (ref), u14 (copy), u13 (copy), u21 (ref)
        local l__Total__7 = u20.Total;
        local u26;
        if u16.Cash then
            u26 = l__Total__7.Cash or nil;
        else
            u26 = nil;
        end;
        local u27 = u16.EXP and l__Total__7.Exp or nil;
        if u27 and not u26 then
            u27.Position = UDim2.new();
        end;
        local u28 = {
            In = {},
            Out = {}
        };
        for _, v29 in { u26, u27 } do
            local v30 = l__TweenService__1:Create(v29.UIGradient, u4, {
                Offset = Vector2.new(1, 1)
            });
            table.insert(u28.In, v30);
        end;
        u28.In[1].Completed:Connect(function() --[[ Line: 133 ]]
            -- upvalues: u28 (copy)
            if u28.In[2] then
                u28.In[2]:Play();
            end;
        end);
        local v31 = l__TweenService__1:Create(u20.Main.Root.UIGradient, u2, {
            Offset = Vector2.new(0, 0)
        });
        local v32 = {};
        for v33, v34 in { u27, u26, u20.Main.Sub } do
            v32[v33] = l__TweenService__1:Create(v34.UIGradient, u4, {
                Offset = Vector2.new(0, 0)
            });
        end;
        local l__Conditions__8 = u20.Conditions;
        local v35 = {
            In = {},
            Out = {}
        };
        for _, u36 in u22 do
            local v37 = l__TweenService__1:Create(u36.Top.UIGradient, u3, {
                Offset = Vector2.new(1, 1)
            });
            v37.Completed:Connect(function() --[[ Line: 168 ]]
                -- upvalues: u36 (copy), l__TweenService__1 (ref), u3 (ref)
                u36.Top.UIGradient.Rotation = 180;
                u36.Top.UIGradient.Offset = Vector2.new(-1, -1);
                l__TweenService__1:Create(u36.Top.UIGradient, u3, {
                    Offset = Vector2.new(0, 0)
                }):Play();
                u36.Under.Visible = true;
            end);
            table.insert(v35.In, v37);
        end;
        for _, u38 in u22 do
            local v39 = l__TweenService__1:Create(u38.Top.UIGradient, u4, {
                Offset = Vector2.new(1, 1)
            });
            local u40 = l__TweenService__1:Create(u38.Top.UIGradient, u4, {
                Offset = Vector2.new(0, 0)
            });
            v39.Completed:Connect(function() --[[ Line: 190 ]]
                -- upvalues: u38 (copy), u40 (copy)
                u38.Under.Visible = false;
                u38.Top.UIGradient.Rotation = 180;
                u38.Top.UIGradient.Offset = Vector2.new(-1, -1);
                u40:Play();
            end);
            table.insert(v35.Out, v39);
        end;
        local u41 = {
            Cash = 0,
            EXP = 0
        };
        local u42 = {
            Cash = 0,
            EXP = 0
        };
        local u43 = {
            Cash = 0,
            EXP = 0
        };
        local l__Time__9 = u4.Time;
        local v53 = l__RunService__2.RenderStepped:Connect(function(p44) --[[ Line: 206 ]]
            -- upvalues: u20 (ref), u41 (copy), u26 (copy), u27 (copy), u42 (copy), u43 (copy), l__Time__9 (copy)
            if u20 then
                for v45, v46 in u41 do
                    local v47 = v45 == "Cash" and u26 or u27;
                    local v48 = v45 == "Cash" and "$%s" or "%s EXP";
                    local v49 = u42[v45];
                    if v46 == v49 then
                        u43[v45] = 0;
                    else
                        local v50 = u43;
                        v50[v45] = v50[v45] + p44 * 2;
                        local v51 = math.clamp(u43[v45] / l__Time__9, 0, 1);
                        local v52 = math.ceil(v49 * (1 - v51) + v46 * v51);
                        u42[v45] = v52;
                        v47.Text = string.format(v48, v52);
                    end;
                end;
            end;
        end);
        u28.In[1]:Play();
        if u28.In[2] then
            u28.In[2].Completed:Wait();
        else
            u28.In[1].Completed:Wait();
        end;
        u41.Cash = u14.Cash;
        u41.EXP = u14.EXP;
        l__Conditions__8.Visible = true;
        for _, v54 in v35.In do
            v54:Play();
            task.wait(0.2);
        end;
        task.wait(0.55);
        u20.Main.Sub.Visible = true;
        u20.Main.Root.UIGradient.Enabled = true;
        if u13 then
            v31:Play();
        end;
        for v55, v56 in v35.Out do
            local v57 = u21[v55];
            u41.Cash = u41.Cash + v57.Cash;
            u41.EXP = u41.EXP + v57.EXP;
            local v58 = u22[v55];
            v58.Top.Text = "";
            v58.Top.UIGradient.Rotation = 0;
            v58.Top.UIGradient.Offset = Vector2.new(0, 0);
            v56:Play();
            task.wait(u4.Time * 2);
        end;
        task.wait(0.25);
        local v59 = { u27, u26, u20.Main.Sub };
        if u13 then
            for v60, v61 in v32 do
                local v62 = v59[v60];
                if v62 then
                    v62.UIGradient.Rotation = 180;
                    v62.UIGradient.Offset = Vector2.new(-1, -1);
                    v61:Play();
                    task.wait(u4.Time);
                end;
            end;
        else
            for v63, v64 in v32 do
                if v63 == #v32 then
                    break;
                end;
                local v65 = v59[v63];
                if v65 then
                    v65.UIGradient.Rotation = 180;
                    v65.UIGradient.Offset = Vector2.new(-1, -1);
                    v64:Play();
                    task.wait(u4.Time);
                end;
            end;
            u20.Main.Sub.Visible = false;
            v31:Play();
            v31.Completed:Wait();
        end;
        v53:Disconnect();
    end;
    table.insert(u7, v25);
    task.spawn(function() --[[ Line: 308 ]]
        -- upvalues: u20 (copy), u11 (ref)
        local v66 = Color3.fromRGB(255, 255, 255);
        local v67 = Color3.fromRGB();
        local l__Root__10 = u20.Main.Root;
        for _ = 1, 6 do
            local v68 = l__Root__10.BackgroundColor3 == v67;
            l__Root__10.BackgroundColor3 = v68 and v66 and v66 or v67;
            l__Root__10.TextColor3 = v68 and v67 and v67 or v66;
            task.wait(0.08);
        end;
        u11();
    end);
end;
return v1;