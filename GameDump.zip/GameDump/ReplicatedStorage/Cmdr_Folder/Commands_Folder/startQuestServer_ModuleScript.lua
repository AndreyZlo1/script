-- Roblox: ReplicatedStorage.Cmdr.Commands.startQuestServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function(_, p1, p2) --[[ Line: 1 ]]
    game.ReplicatedStorage.PlayerEvents.StartQuest:FireClient(p1, p2);
end;