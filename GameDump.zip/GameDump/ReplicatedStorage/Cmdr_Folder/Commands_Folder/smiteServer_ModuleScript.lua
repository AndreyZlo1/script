-- Roblox: ReplicatedStorage.Cmdr.Commands.smiteServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function(p1, p2) --[[ Line: 1 ]]
    local l__Character__1 = p2.Character;
    if l__Character__1 then
        local l__PrimaryPart__2 = l__Character__1.PrimaryPart;
        if l__PrimaryPart__2 then
            local v3 = script.Bolt:Clone();
            v3.Parent = workspace;
            v3.CFrame = CFrame.new(l__PrimaryPart__2.CFrame.Position);
            l__Character__1.Humanoid.Health = 0;
            task.wait(0.1);
            v3:Destroy();
            p1.State.Success = true;
        end;
    end;
end;