-- Roblox: ReplicatedStorage.Cmdr.Commands.modviewServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

game:GetService("Players");
game:GetService("ServerScriptService");
game:GetService("MessagingService");
local l__PlayerEvents__1 = game:GetService("ReplicatedStorage"):WaitForChild("PlayerEvents");
l__PlayerEvents__1:WaitForChild("StartUnreliableSpy");
l__PlayerEvents__1:WaitForChild("UnreliableSpy");
return function(p1, p2) --[[ Line: 10 ]]
    if p1.Executor == p2 then
    else
        if not p2.Character then
            return "Target has no character - they\'re likely dead or mid-respawn";
        end;
        p1.Executor:RequestStreamAroundAsync(p2.Character.PrimaryPart.Position);
        p1.State.Success = true;
    end;
end;