-- Roblox: ReplicatedStorage.Cmdr.Commands.carpetServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local _ = game:GetService("ServerScriptService").DataStores.PlayerDataHandler;
local l__ServerStorage__1 = game:GetService("ServerStorage");
local l__Players__2 = game:GetService("Players");
return function(p1, p2) --[[ Line: 6 ]]
    -- upvalues: l__Players__2 (copy), l__ServerStorage__1 (copy)
    if not p2 or p2.Parent ~= l__Players__2 then
        return "Invalid player";
    end;
    local v3 = l__ServerStorage__1.CmdrTools:FindFirstChild("F-C4RP3T");
    if not v3 then
        return "Gun not found";
    end;
    p1.State.Success = true;
    local v4 = p2:FindFirstChild("Backpack");
    v3:Clone().Parent = v4;
end;