-- Roblox: ReplicatedStorage.Cmdr.Commands.spawnVehicleServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Players__1 = game:GetService("Players");
local l__ReplicatedStorage__2 = game:GetService("ReplicatedStorage");
local l__Vehicles__3 = l__ReplicatedStorage__2:WaitForChild("Vehicles");
local l__Helicopters__4 = l__ReplicatedStorage__2:WaitForChild("Helicopters");
local l__Planes__5 = l__ReplicatedStorage__2:WaitForChild("Planes");
return function(p1, p2) --[[ Line: 8 ]]
    -- upvalues: l__Players__1 (copy), l__Vehicles__3 (copy), l__Helicopters__4 (copy), l__Planes__5 (copy)
    local l__Executor__6 = p1.Executor;
    if l__Executor__6 and l__Executor__6.Parent == l__Players__1 then
        local l__Character__7 = l__Executor__6.Character;
        if l__Character__7 then
            local l__PrimaryPart__8 = l__Character__7.PrimaryPart;
            if l__PrimaryPart__8 then
                local v3 = l__Vehicles__3:FindFirstChild(p2) or (l__Helicopters__4:FindFirstChild(p2) or l__Planes__5:FindFirstChild(p2));
                if not v3 then
                    return "Invalid vehicle";
                end;
                local v4 = v3:Clone();
                v4.Parent = workspace;
                v4:PivotTo(l__PrimaryPart__8.CFrame * CFrame.new(0, 7, -28));
                p1.State.Success = true;
            end;
        end;
    else
        return "Invalid player";
    end;
end;