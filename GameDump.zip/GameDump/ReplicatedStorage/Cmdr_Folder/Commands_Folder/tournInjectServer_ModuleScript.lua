-- Roblox: ReplicatedStorage.Cmdr.Commands.tournInjectServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

game:GetService("Players");
local l__ServerScriptService__1 = game:GetService("ServerScriptService");
local _ = l__ServerScriptService__1.DataStores.PlayerDataHandler;
require(script.Parent.Parent.Util.RolePowers);
require(script.Parent.Parent.Util.BanStructParser);
require(game:GetService("ReplicatedStorage").ReplicatedConfig);
return function(p1, p2, p3, p4, p5) --[[ Line: 8 ]]
    -- upvalues: l__ServerScriptService__1 (copy)
    local v6 = {};
    local v7 = {};
    for _, v8 in p4:split(",") do
        local v9 = tonumber(v8);
        table.insert(v6, v9);
    end;
    for _, v10 in p5:split(",") do
        local v11 = tonumber(v10);
        table.insert(v7, v11);
    end;
    l__ServerScriptService__1.Gameplay.Minigames.TournamentInject:Invoke(p2, p3, {
        Red = v7,
        Blue = v6
    });
    p1.State.Success = true;
end;