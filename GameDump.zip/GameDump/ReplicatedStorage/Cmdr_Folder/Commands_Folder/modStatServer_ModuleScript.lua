-- Roblox: ReplicatedStorage.Cmdr.Commands.modStatServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local _ = game:GetService("ServerScriptService").DataStores.PlayerDataHandler;
local l__Players__1 = game:GetService("Players");
local u10 = {
    Set = function(_, p1) --[[ Name: Set, Line 8 ]]
        return p1;
    end,
    Add = function(p2, p3) --[[ Name: Add, Line 12 ]]
        return p2 + p3;
    end,
    Subtract = function(p4, p5) --[[ Name: Subtract, Line 16 ]]
        return p4 - p5;
    end,
    Multiply = function(p6, p7) --[[ Name: Multiply, Line 20 ]]
        return p6 * p7;
    end,
    Divide = function(p8, p9) --[[ Name: Divide, Line 24 ]]
        return p8 / p9;
    end
};
return function(p11, p12, p13, p14, p15) --[[ Line: 29 ]]
    -- upvalues: l__Players__1 (copy), u10 (copy)
    if not p12 or p12.Parent ~= l__Players__1 then
        return "Player no longer exists";
    end;
    if not u10[p14] then
        return "Error with stat modif type, contact khls";
    end;
    local v16 = p12:FindFirstChild("leaderstats");
    if not v16 then
        return "Couldn\'t find players leaderstat";
    end;
    local v17 = v16:FindFirstChild(p13);
    if not v17 then
        return string.format("Couldn\'t find stat of type %s, contact khls", p13);
    end;
    local v18 = u10[p14](v17.Value, p15);
    if not (v18 and tonumber(v18)) then
        return "Failed to modify stat. Contact khls";
    end;
    v17.Value = v18;
    p11.State.Success = true;
    return "Stat changed";
end;