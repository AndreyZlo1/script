-- Roblox: ReplicatedStorage.Cmdr.Commands.watchlistAddServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Cmdr__1 = game:GetService("ServerScriptService").Cmdr;
local l__WatchlistHelper__2 = require(l__Cmdr__1.Watchlist.WatchlistHelper);
return function(p1, p2) --[[ Line: 5 ]]
    -- upvalues: l__WatchlistHelper__2 (copy)
    l__WatchlistHelper__2.AddUser(p2);
    p1.State.Success = true;
end;