-- Roblox: ReplicatedStorage.Cmdr.Commands.unbanServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Players__1 = game:GetService("Players");
local _ = game:GetService("ServerScriptService").DataStores.PlayerDataHandler;
require(script.Parent.Parent.Util.RolePowers);
require(script.Parent.Parent.Util.BanStructParser);
require(game:GetService("ReplicatedStorage").ReplicatedConfig);
return function(p1, u2) --[[ Line: 8 ]]
    -- upvalues: l__Players__1 (copy)
    local v3, v4 = pcall(function() --[[ Line: 10 ]]
        -- upvalues: l__Players__1 (ref), u2 (copy)
        l__Players__1:UnbanAsync({
            ApplyToUniverse = true,
            UserIds = { u2 }
        });
    end);
    if not v3 then
        error(v4);
    end;
    p1.State.Success = true;
end;