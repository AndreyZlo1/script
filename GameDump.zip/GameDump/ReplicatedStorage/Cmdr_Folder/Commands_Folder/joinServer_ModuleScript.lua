-- Roblox: ReplicatedStorage.Cmdr.Commands.joinServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

game:GetService("Players");
game:GetService("ServerScriptService");
local l__MessagingService__1 = game:GetService("MessagingService");
local l__TeleportService__2 = game:GetService("TeleportService");
require(script.Parent:WaitForChild("checkonlineServer"));
return function(p1, p2, p3) --[[ Line: 8 ]]
    -- upvalues: l__MessagingService__1 (copy), l__TeleportService__2 (copy)
    local v4 = "CmdrCheckOnline" .. math.random(1, 999999);
    local u5 = false;
    local u6 = nil;
    local v8 = l__MessagingService__1:SubscribeAsync(v4, function(p7) --[[ Line: 13 ]]
        -- upvalues: u6 (ref), u5 (ref)
        u6 = p7.Data;
        u5 = true;
    end);
    l__MessagingService__1:PublishAsync("CmdrCheckOnline", {
        UserId = p2,
        ReturnTopic = v4
    });
    local v9 = u6;
    local v10 = u5;
    local v11 = 0;
    while true do
        task.wait(0.2);
        v11 = v11 + 0.2;
        if v11 >= 10 then
            break;
        end;
        if v10 and v9 then
            v8:Disconnect();
            local v12 = Instance.new("TeleportOptions");
            v12.ServerInstanceId = v9.ServerId;
            if p3 then
                return;
            else
                l__TeleportService__2:TeleportAsync(v9.PlaceId, { p1.Executor }, v12);
                p1.State.Success = true;
                return;
            end;
        end;
    end;
    v8:Disconnect();
    return "Not found";
end;