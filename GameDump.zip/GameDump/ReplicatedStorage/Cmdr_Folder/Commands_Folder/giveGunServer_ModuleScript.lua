-- Roblox: ReplicatedStorage.Cmdr.Commands.giveGunServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local _ = game:GetService("ServerScriptService").DataStores.PlayerDataHandler;
local l__ServerStorage__1 = game:GetService("ServerStorage");
local l__Players__2 = game:GetService("Players");
local l__Guns__3 = l__ServerStorage__1:WaitForChild("Guns");
return function(p1, p2, p3) --[[ Line: 8 ]]
    -- upvalues: l__Players__2 (copy), l__Guns__3 (copy)
    if not p2 or p2.Parent ~= l__Players__2 then
        return "Invalid player";
    end;
    local v4 = l__Guns__3:FindFirstChild(p3);
    if not v4 then
        return "Gun not found";
    end;
    p1.State.Success = true;
    local v5 = p2:FindFirstChild("Backpack");
    v4:Clone().Parent = v5;
end;