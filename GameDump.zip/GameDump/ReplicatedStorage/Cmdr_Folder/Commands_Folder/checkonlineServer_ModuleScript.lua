-- Roblox: ReplicatedStorage.Cmdr.Commands.checkonlineServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

game:GetService("Players");
game:GetService("ServerScriptService");
local l__MessagingService__1 = game:GetService("MessagingService");
return function(_, p1) --[[ Line: 5 ]]
    -- upvalues: l__MessagingService__1 (copy)
    local v2 = "CmdrCheckOnline" .. math.random(1, 999999);
    local u3 = false;
    local u4 = nil;
    local v6 = l__MessagingService__1:SubscribeAsync(v2, function(p5) --[[ Line: 10 ]]
        -- upvalues: u4 (ref), u3 (ref)
        u4 = p5.Data;
        u3 = true;
    end);
    l__MessagingService__1:PublishAsync("CmdrCheckOnline", {
        UserId = p1,
        ReturnTopic = v2
    });
    local v7 = u4;
    local v8 = u3;
    local v9 = 0;
    while true do
        task.wait(0.2);
        v9 = v9 + 0.2;
        if v9 >= 10 then
            break;
        end;
        if v8 and v7 then
            v6:Disconnect();
            return "Player found, Server ID: " .. v7.ServerId .. " | Place ID: " .. v7.PlaceId;
        end;
    end;
    v6:Disconnect();
    return "Not found";
end;