-- Roblox: ReplicatedStorage.Cmdr.Commands.banServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Players__1 = game:GetService("Players");
local _ = game:GetService("ServerScriptService").DataStores.PlayerDataHandler;
local l__RolePowers__2 = require(script.Parent.Parent.Util.RolePowers);
require(script.Parent.Parent.Util.BanStructParser);
require(game:GetService("ReplicatedStorage").ReplicatedConfig);
return function(u1, u2, u3, u4) --[[ Line: 13 ]]
    -- upvalues: l__RolePowers__2 (copy), l__Players__1 (copy)
    if not l__RolePowers__2.canExecutorTargetPlayer(u1.Executor, u2) then
        return "Cannot ban a user of higher or equivalent rank";
    end;
    if u3 ~= "perma" and u3 <= 0 then
        return "Days to ban for must be higher than 0";
    end;
    local v5, v6 = pcall(function() --[[ Line: 22 ]]
        -- upvalues: l__Players__1 (ref), u2 (copy), u3 (copy), u4 (copy), u1 (copy)
        l__Players__1:BanAsync({
            ExcludeAltAccounts = false,
            ApplyToUniverse = true,
            UserIds = { u2.UserId },
            Duration = u3 == "perma" and -1 or u3,
            DisplayReason = u4,
            PrivateReason = "Banned by " .. u1.Executor.UserId
        });
    end);
    if not v5 then
        error(v6);
    end;
    u1.State.Success = true;
end;