-- Roblox: ReplicatedStorage.Cmdr.Commands.rewardGunServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ServerScriptService__1 = game:GetService("ServerScriptService");
local _ = l__ServerScriptService__1.DataStores.PlayerDataHandler;
local l__ServerStorage__2 = game:GetService("ServerStorage");
local l__Players__3 = game:GetService("Players");
local l__Guns__4 = l__ServerStorage__2:WaitForChild("Guns");
return function(p1, p2, p3) --[[ Line: 8 ]]
    -- upvalues: l__Players__3 (copy), l__Guns__4 (copy), l__ServerScriptService__1 (copy)
    if not p2 or p2.Parent ~= l__Players__3 then
        return "Invalid player";
    end;
    if not l__Guns__4:FindFirstChild(p3) then
        return "Gun not found";
    end;
    p1.State.Success = true;
    require(l__ServerScriptService__1.DataStores.PlayerParamsModule).rewardGun(p2, p3);
end;