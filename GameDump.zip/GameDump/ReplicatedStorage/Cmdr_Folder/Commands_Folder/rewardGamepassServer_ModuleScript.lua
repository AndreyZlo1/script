-- Roblox: ReplicatedStorage.Cmdr.Commands.rewardGamepassServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ServerScriptService__1 = game:GetService("ServerScriptService");
local _ = l__ServerScriptService__1.DataStores.PlayerDataHandler;
local l__ServerStorage__2 = game:GetService("ServerStorage");
local l__Players__3 = game:GetService("Players");
l__ServerStorage__2:WaitForChild("Guns");
return function(p1, p2, p3) --[[ Line: 8 ]]
    -- upvalues: l__Players__3 (copy), l__ServerScriptService__1 (copy)
    if not p2 or p2.Parent ~= l__Players__3 then
        return "Invalid player";
    end;
    local l__PlayerParamsModule__4 = require(l__ServerScriptService__1.DataStores.PlayerParamsModule);
    local v4 = game:GetService("MarketplaceService"):GetProductInfo(p3, Enum.InfoType.GamePass);
    l__PlayerParamsModule__4.giftGamepass("Developer", v4.Name, p2, p3);
    p1.State.Success = true;
end;