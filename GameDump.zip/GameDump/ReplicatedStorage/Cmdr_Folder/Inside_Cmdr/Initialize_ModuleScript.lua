-- Roblox: ReplicatedStorage.Cmdr.Cmdr.Initialize
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__StarterGui__2 = game:GetService("StarterGui");
local l__CreateGui__3 = require(script.Parent.CreateGui);
return function(p1) --[[ Line: 6 ]]
    -- upvalues: l__ReplicatedStorage__1 (copy), l__StarterGui__2 (copy), l__CreateGui__3 (copy)
    local v2 = nil;
    v2 = script.Parent.CmdrClient;
    v2.Parent = l__ReplicatedStorage__1;
    local v3 = Instance.new("RemoteFunction");
    v3.Name = "CmdrFunction";
    v3.Parent = v2;
    local v4 = Instance.new("RemoteEvent");
    v4.Name = "CmdrEvent";
    v4.Parent = v2;
    local v5 = Instance.new("Folder");
    v5.Name = "Commands";
    v5.Parent = v2;
    local v6 = Instance.new("Folder");
    v6.Name = "Types";
    v6.Parent = v2;
    script.Parent.Shared.Parent = v2;
    p1.ReplicatedRoot = v2;
    p1.RemoteFunction = v3;
    p1.RemoteEvent = v4;
    p1:RegisterTypesIn(script.Parent.BuiltInTypes);
    script.Parent.BuiltInTypes:Destroy();
    script.Parent.BuiltInCommands.Name = "Server commands";
    if l__StarterGui__2:FindFirstChild("Cmdr") == nil then
        l__CreateGui__3();
    end;
end;