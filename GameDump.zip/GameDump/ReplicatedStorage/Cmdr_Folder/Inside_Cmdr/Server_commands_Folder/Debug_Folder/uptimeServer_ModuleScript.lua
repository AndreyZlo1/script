-- Roblox: ReplicatedStorage.Cmdr.Cmdr.Server commands.Debug.uptimeServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = os.time();
return function() --[[ Line: 3 ]]
    -- upvalues: u1 (copy)
    local v2 = os.time() - u1;
    return ("%dd %dh %dm %ds"):format(math.floor(v2 / 86400), math.floor(v2 / 3600) % 24, math.floor(v2 / 60) % 60, math.floor(v2) % 60);
end;