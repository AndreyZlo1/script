-- Roblox: ReplicatedStorage.Cmdr.Cmdr.Server commands.Debug.fetchServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__HttpService__1 = game:GetService("HttpService");
return function(_, p1) --[[ Line: 3 ]]
    -- upvalues: l__HttpService__1 (copy)
    return l__HttpService__1:GetAsync(p1);
end;