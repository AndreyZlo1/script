-- Roblox: ReplicatedStorage.Cmdr.Cmdr.Server commands.Debug.getPlayerPlaceInstanceServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__TeleportService__1 = game:GetService("TeleportService");
return function(_, u1, p2) --[[ Line: 3 ]]
    -- upvalues: l__TeleportService__1 (copy)
    local v3 = p2 or "PlaceIdJobId";
    local v4, _, v5, v6, v7 = pcall(function() --[[ Line: 6 ]]
        -- upvalues: l__TeleportService__1 (ref), u1 (copy)
        return l__TeleportService__1:GetPlayerPlaceInstanceAsync(u1);
    end);
    if not v4 or v5 and #v5 > 0 then
        if v3 == "PlaceIdJobId" then
            return "0 -";
        end;
        if v3 == "PlaceId" then
            return "0";
        end;
        if v3 == "JobId" then
            return "-";
        end;
    end;
    if v3 == "PlaceIdJobId" then
        return v6 .. " " .. v7;
    end;
    if v3 == "PlaceId" then
        return tostring(v6);
    end;
    if v3 == "JobId" then
        return tostring(v7);
    end;
end;