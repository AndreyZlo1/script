-- Roblox: ReplicatedStorage.Cmdr.Cmdr.Server commands.Utility.varSetServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__DataStoreService__1 = game:GetService("DataStoreService");
local u1 = {};
local u2 = nil;
local u3 = nil;
task.spawn(function() --[[ Line: 5 ]]
    -- upvalues: u2 (ref), u3 (ref), l__DataStoreService__1 (copy), u1 (copy)
    local v5, v6 = pcall(function() --[[ Line: 6 ]]
        -- upvalues: l__DataStoreService__1 (ref)
        local v4 = l__DataStoreService__1:GetDataStore("_package/eryn.io/Cmdr");
        v4:GetAsync("test_key");
        return v4;
    end);
    u2 = v5;
    u3 = v6;
    while #u1 > 0 do
        coroutine.resume(table.remove(u1, 1));
    end;
end);
return function(p7, p8, p9) --[[ Line: 17 ]]
    -- upvalues: u2 (ref), u1 (copy), u3 (ref)
    if u2 == nil then
        table.insert(u1, coroutine.running());
        coroutine.yield();
    end;
    local v10 = true;
    local v11;
    if p8:sub(1, 1) == "$" then
        p8 = p8:sub(2);
        v11 = true;
    else
        v11 = false;
    end;
    if p8:sub(1, 1) == "." then
        p8 = p8:sub(2);
        v10 = false;
    end;
    if v10 and not u2 then
        return "# You must publish this place to the web to use saved keys.";
    else
        local v12 = "var_" .. (v11 and "global" or tostring(p7.Executor.UserId));
        if v10 then
            u3:SetAsync(v12 .. "_" .. p8, p9);
            return type(p9) == "table" and (table.concat(p9, ",") or "") or p9;
        else
            p7:GetStore(v12)[p8] = p9;
            return type(p9) == "table" and (table.concat(p9, ",") or "") or p9;
        end;
    end;
end;