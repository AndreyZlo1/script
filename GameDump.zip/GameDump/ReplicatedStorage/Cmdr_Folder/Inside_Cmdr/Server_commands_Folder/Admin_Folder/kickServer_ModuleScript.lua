-- Roblox: ReplicatedStorage.Cmdr.Cmdr.Server commands.Admin.kickServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function(_, p1) --[[ Line: 1 ]]
    for _, v2 in pairs(p1) do
        v2:Kick("Kicked by admin.");
    end;
    return ("Kicked %d players."):format(#p1);
end;