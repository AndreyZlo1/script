-- Roblox: ReplicatedStorage.Cmdr.Cmdr.Server commands.Admin.announceServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__TextService__1 = game:GetService("TextService");
local l__Players__2 = game:GetService("Players");
local l__Chat__3 = game:GetService("Chat");
return function(p1, p2) --[[ Line: 5 ]]
    -- upvalues: l__TextService__1 (copy), l__Players__2 (copy), l__Chat__3 (copy)
    local v3 = l__TextService__1:FilterStringAsync(p2, p1.Executor.UserId, Enum.TextFilterContext.PublicChat);
    for _, v4 in ipairs(l__Players__2:GetPlayers()) do
        if l__Chat__3:CanUsersChatAsync(p1.Executor.UserId, v4.UserId) then
            p1:SendEvent(v4, "Message", v3:GetChatForUserAsync(v4.UserId), p1.Executor);
        end;
    end;
    return "Created announcement.";
end;