-- Roblox: ReplicatedStorage.Cmdr.Cmdr.Server commands.Admin.respawnServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return function(_, p1) --[[ Line: 1 ]]
    for _, v2 in pairs(p1) do
        if v2.Character then
            v2:LoadCharacter();
        end;
    end;
    return ("Respawned %d players."):format(#p1);
end;