-- Roblox: ReplicatedStorage.Cmdr.Cmdr.Server commands.Admin.gotoPlaceServer
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__TeleportService__1 = game:GetService("TeleportService");
return function(p1, p2, p3, p4) --[[ Line: 3 ]]
    -- upvalues: l__TeleportService__1 (copy)
    local v5 = p2 or { p1.Executor };
    if p3 <= 0 then
        return "Invalid place ID";
    end;
    if p4 == "-" then
        return "Invalid job ID";
    end;
    p1:Reply("Commencing teleport...");
    if p4 then
        for _, v6 in ipairs(v5) do
            l__TeleportService__1:TeleportToPlaceInstance(p3, p4, v6);
        end;
    else
        l__TeleportService__1:TeleportAsync(p3, v5);
    end;
    return "Teleported.";
end;