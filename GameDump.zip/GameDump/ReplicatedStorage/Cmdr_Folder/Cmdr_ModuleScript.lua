-- Roblox: ReplicatedStorage.Cmdr.Cmdr
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__RunService__1 = game:GetService("RunService");
local l__Util__2 = require(script.Shared:WaitForChild("Util"));
if l__RunService__1:IsServer() == false then
    error("Cmdr server module is somehow running on a client!");
end;
local u4 = setmetatable({
    ReplicatedRoot = nil,
    RemoteFunction = nil,
    RemoteEvent = nil,
    Util = l__Util__2,
    DefaultCommandsFolder = script.BuiltInCommands
}, {
    __index = function(u1, p2) --[[ Name: __index, Line 16 ]]
        local u3 = u1.Registry[p2];
        if u3 and type(u3) == "function" then
            return function(_, ...) --[[ Line: 19 ]]
                -- upvalues: u3 (copy), u1 (copy)
                return u3(u1.Registry, ...);
            end;
        end;
    end
});
u4.Registry = require(script.Shared.Registry)(u4);
u4.Dispatcher = require(script.Shared.Dispatcher)(u4);
require(script.Initialize)(u4);
function u4.RemoteFunction.OnServerInvoke(p5, p6, p7) --[[ Line: 33 ]]
    -- upvalues: u4 (ref)
    return #p6 > 100000 and "Input too long" or u4.Dispatcher:EvaluateAndRun(p6, p5, p7);
end;
return u4;