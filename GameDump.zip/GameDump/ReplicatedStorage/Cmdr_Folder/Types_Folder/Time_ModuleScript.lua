-- Roblox: ReplicatedStorage.Cmdr.Types.Time
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local u2 = {
    "s",
    "m",
    "h",
    "d",
    "w",
    "M",
    "y"
};
local u3 = {
    s = 1,
    m = 60,
    h = 3600,
    d = 86400,
    w = 604800,
    M = 2419200,
    y = 31536000
};
function v1.Validate(p4) --[[ Line: 23 ]]
    -- upvalues: u2 (copy)
    if p4 == "perma" then
        return true;
    else
        local v5 = tostring(p4);
        if v5 and string.len(p4) >= 2 then
            local v6 = string.sub(v5, 1, #v5 - 1);
            local v7 = tonumber(v6);
            if v7 and v7 >= 0 then
                local v8 = string.sub(v5, #v5);
                if v8 and tostring(v8) then
                    local v9 = tostring(v8);
                    if tonumber(v9) then
                        return false, "Invalid suffix";
                    elseif table.find(u2, v9) then
                        return true;
                    else
                        return false, "Suffix must be one of: " .. table.concat(u2, ", ");
                    end;
                else
                    return false, "Invalid suffix";
                end;
            else
                return false, "Invalid number";
            end;
        else
            return false, "Invalid duration";
        end;
    end;
end;
function v1.Parse(p10) --[[ Line: 51 ]]
    -- upvalues: u3 (copy)
    if p10 == "perma" then
        return "perma";
    end;
    local v11 = tostring(p10);
    local v12 = string.sub(v11, #v11);
    local v13 = string.sub(v11, 1, #v11 - 1);
    return tonumber(v13) * (u3[v12] or 1);
end;
return v1;