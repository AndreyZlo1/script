-- Roblox: ReplicatedStorage.Cmdr.Enums.Vehicle
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local v1 = {};
for _, v2 in { l__ReplicatedStorage__1:WaitForChild("Vehicles"), l__ReplicatedStorage__1:WaitForChild("Helicopters"), l__ReplicatedStorage__1:WaitForChild("Planes") } do
    for _, v3 in v2:GetChildren() do
        table.insert(v1, v3.Name);
    end;
end;
return v1;