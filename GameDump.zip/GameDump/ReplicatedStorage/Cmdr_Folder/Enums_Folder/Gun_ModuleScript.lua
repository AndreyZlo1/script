-- Roblox: ReplicatedStorage.Cmdr.Enums.Gun
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
for _, v2 in game:GetService("ServerStorage").Guns:GetChildren() do
    if v2:IsA("Tool") then
        table.insert(v1, v2.Name);
    end;
end;
return v1;