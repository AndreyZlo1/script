-- Roblox: ReplicatedStorage.Cmdr.Enums.StatType
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    "Money",
    "Prestige",
    "Kills",
    "Deaths"
};