-- Roblox: ReplicatedStorage.Cmdr.Enums.StatModifType
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    "Set",
    "Add",
    "Subtract",
    "Multiply",
    "Divide"
};