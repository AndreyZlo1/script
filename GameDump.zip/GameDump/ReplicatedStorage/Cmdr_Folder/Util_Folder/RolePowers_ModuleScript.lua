-- Roblox: ReplicatedStorage.Cmdr.Util.RolePowers
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
local u2 = {
    Moderator = 50,
    Developer = 100,
    ["Stealth Developer"] = 200,
    ["The Main Guy"] = 1000
};
function u1.playerHasPerms(p3, p4) --[[ Line: 11 ]]
    -- upvalues: u2 (copy), u1 (copy)
    local v5 = u2[p4 == "DefaultAdmin" and "Developer" or p4];
    if v5 then
        return v5 <= u1.getPlayerPower(p3);
    else
        return false;
    end;
end;
function u1.getPlayerPower(p6) --[[ Line: 25 ]]
    -- upvalues: u2 (copy)
    return p6.UserId == 10601162154 and 1000 or (u2[p6:GetRoleInGroup(12266404)] or 0);
end;
function u1.canExecutorTargetPlayer(p7, p8) --[[ Line: 34 ]]
    -- upvalues: u1 (copy)
    return u1.getPlayerPower(p7) > u1.getPlayerPower(p8);
end;
return u1;