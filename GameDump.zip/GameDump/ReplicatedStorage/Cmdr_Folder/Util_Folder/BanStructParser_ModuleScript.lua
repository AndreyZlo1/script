-- Roblox: ReplicatedStorage.Cmdr.Util.BanStructParser
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__Players__1 = game:GetService("Players");
function v1.GetKickReason(p2) --[[ Line: 5 ]]
    -- upvalues: l__Players__1 (copy)
    local v3 = "You are banned. You were banned by " .. l__Players__1:GetNameFromUserIdAsync(p2.bannerId) .. ".\n";
    local v4 = os.time();
    local v5 = p2.unbanTimestamp - v4;
    return (v3 .. "You will be unbanned in " .. math.floor(v5 / 86400) .. " days, " .. math.floor(v5 % 86400 / 3600) .. " hours.\n") .. "Ban reason: " .. p2.reason;
end;
return v1;