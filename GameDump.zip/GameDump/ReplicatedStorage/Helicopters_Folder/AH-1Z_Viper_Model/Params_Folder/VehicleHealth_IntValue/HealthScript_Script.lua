-- Roblox: ReplicatedStorage.Helicopters.AH-1Z Viper.Params.VehicleHealth.HealthScript
-- Class: Script
-- Method: decompile

-- Empty bytecode