-- Roblox: ReplicatedStorage.Helicopters.AH-1Z Viper.Params.Config
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    DriverWeapons = {
        {
            Name = "Hydra Rockets",
            Abbreviation = "HYDRA",
            ShellType = "Explosive",
            ShellName = "HeliRocketShell",
            MuzzleVelocity = 600,
            Ammo = 14,
            ReloadTime = 15,
            ShootRate = 500,
            FireMode = "Auto",
            Explosive = true,
            DamageFallOf = 0,
            HardpointData = {
                Name = "Rockets",
                Mode = "Sequential"
            },
            Explosion = {
                Radius = 20,
                Damage = 120
            },
            TorsoDamage = { 90, 90 },
            LimbDamage = { 90, 90 },
            HeadDamage = { 90, 90 }
        },
        {
            Name = "Heatseekers",
            Abbreviation = "HEAT",
            ShellType = "Explosive",
            ShellName = "HeliRocketShell",
            MuzzleVelocity = 300,
            Ammo = 2,
            ReloadTime = 15,
            SpecialType = "Heatseeker",
            ShootRate = 400,
            FireMode = "Semi",
            Explosive = true,
            DamageFallOf = 0,
            MinDamage = 60,
            HardpointData = {
                Name = "Heatseekers",
                Mode = "Sequential"
            },
            LimbDamage = { 279, 279 },
            TorsoDamage = { 279, 279 },
            HeadDamage = { 279, 279 },
            Explosion = {
                Radius = 14,
                Damage = 70
            }
        }
    },
    GunnerWeapons = {
        {
            Name = "20mm Gatling Gun",
            ShellType = "Bullet",
            ShellName = "DefaultBullet",
            FireSound = "SecondaryFire",
            FXAttName = "SecondaryFireFX",
            MuzzleVelocity = 1400,
            DamageFallOf = 1,
            MinDamage = 5,
            Ammo = 30,
            ReloadTime = 7,
            ShootRate = 500,
            FireMode = "Auto",
            CameraPart = "GunnerCameraPart",
            AllowZoom = true,
            FOV = 60,
            AimFOV = 30,
            LimbDamage = { 35, 36 },
            TorsoDamage = { 35, 35 },
            HeadDamage = { 51, 52 },
            HardpointData = {
                Name = "Turret",
                Mode = "Sequential"
            },
            Turret = {
                FirstPerson = true
            }
        }
    }
};