-- Roblox: ReplicatedStorage.AI.Undead2.ZombieScript
-- Class: Script
-- Method: decompile

-- Empty bytecode