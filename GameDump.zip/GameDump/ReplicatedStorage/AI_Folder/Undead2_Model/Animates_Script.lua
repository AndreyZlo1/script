-- Roblox: ReplicatedStorage.AI.Undead2.Animates
-- Class: Script
-- Method: decompile

-- Empty bytecode