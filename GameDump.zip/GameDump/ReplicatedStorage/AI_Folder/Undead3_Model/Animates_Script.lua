-- Roblox: ReplicatedStorage.AI.Undead3.Animates
-- Class: Script
-- Method: decompile

-- Empty bytecode