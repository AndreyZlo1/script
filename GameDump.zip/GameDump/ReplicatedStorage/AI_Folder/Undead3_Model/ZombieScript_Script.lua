-- Roblox: ReplicatedStorage.AI.Undead3.ZombieScript
-- Class: Script
-- Method: decompile

-- Empty bytecode