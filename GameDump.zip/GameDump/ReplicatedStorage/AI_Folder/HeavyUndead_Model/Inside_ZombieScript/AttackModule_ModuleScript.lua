-- Roblox: ReplicatedStorage.AI.HeavyUndead.ZombieScript.AttackModule
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__Animator__1 = script.Parent.Parent.Humanoid.Animator;
local l__AttackAnimation1__2 = script.AttackAnimation1;
local l__AttackAnimation2__3 = script.AttackAnimation2;
function v1.attack(p2, p3, _) --[[ Line: 7 ]]
    -- upvalues: l__Animator__1 (copy), l__AttackAnimation1__2 (copy), l__AttackAnimation2__3 (copy)
    if p2 and p2:FindFirstChild("Humanoid") then
        p2.Humanoid:TakeDamage(math.random(p3[1], p3[2]));
        l__Animator__1:LoadAnimation(math.random() >= 0.5 and l__AttackAnimation1__2 or l__AttackAnimation2__3):Play(0.1);
    end;
end;
return v1;