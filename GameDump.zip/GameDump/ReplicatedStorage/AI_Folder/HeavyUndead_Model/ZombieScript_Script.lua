-- Roblox: ReplicatedStorage.AI.HeavyUndead.ZombieScript
-- Class: Script
-- Method: decompile

-- Empty bytecode