-- Roblox: ReplicatedStorage.AI.Undead1.ZombieScript
-- Class: Script
-- Method: decompile

-- Empty bytecode