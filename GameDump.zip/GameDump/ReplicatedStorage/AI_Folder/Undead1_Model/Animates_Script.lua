-- Roblox: ReplicatedStorage.AI.Undead1.Animates
-- Class: Script
-- Method: decompile

-- Empty bytecode