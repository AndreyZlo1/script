-- Roblox: ReplicatedStorage.AI.HostileStaySpy.ZombieScript
-- Class: Script
-- Method: decompile

-- Empty bytecode