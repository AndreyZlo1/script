-- Roblox: ReplicatedStorage.AI.HostileStaySpy.Animates
-- Class: Script
-- Method: decompile

-- Empty bytecode