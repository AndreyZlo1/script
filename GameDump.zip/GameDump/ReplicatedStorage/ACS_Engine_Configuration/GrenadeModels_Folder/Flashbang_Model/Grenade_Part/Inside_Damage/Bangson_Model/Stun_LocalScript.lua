-- Roblox: ReplicatedStorage.ACS_Engine.GrenadeModels.Flashbang.Grenade.Damage.Bangson.Stun
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__TweenService__1 = game:GetService("TweenService");
if script.Parent.Parent.Parent.CurrentCamera:FindFirstChild("Stun") ~= nil then
    script.Parent.Parent.Parent.CurrentCamera:FindFirstChild("Stun"):Destroy();
end;
local v1 = Instance.new("ColorCorrectionEffect");
v1.Parent = script.Parent.Parent.Parent.CurrentCamera;
v1.Brightness = script.Parent.Brightness.Value;
v1.Name = "Stun";
l__TweenService__1:Create(v1, TweenInfo.new(script.Parent.Time.Value, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut, 0, false, 0), {
    Brightness = 0
}):Play();
task.wait(script.Parent.Time.Value + 0.5);
v1:Destroy();
script.Parent:Destroy();