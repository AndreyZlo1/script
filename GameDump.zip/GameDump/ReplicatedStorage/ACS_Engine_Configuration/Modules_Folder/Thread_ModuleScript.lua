-- Roblox: ReplicatedStorage.ACS_Engine.Modules.Thread
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__RunService__1 = game:GetService("RunService");
function v1.Wait(_, p2) --[[ Line: 5 ]]
    -- upvalues: l__RunService__1 (copy)
    if p2 == nil then
        l__RunService__1.Heartbeat:Wait();
    else
        local v3 = 0 + l__RunService__1.Heartbeat:Wait();
        while v3 < p2 do
            v3 = v3 + l__RunService__1.Heartbeat:Wait();
        end;
    end;
end;
function v1.Spawn(_, p4) --[[ Line: 17 ]]
    local v5 = Instance.new("BindableEvent");
    v5.Event:connect(p4);
    v5:Fire();
    v5:Destroy();
end;
function v1.Delay(u6, u7, u8) --[[ Line: 24 ]]
    u6:Spawn(function() --[[ Line: 25 ]]
        -- upvalues: u6 (copy), u7 (copy), u8 (copy)
        u6:Wait(u7);
        u8();
    end);
end;
return v1;