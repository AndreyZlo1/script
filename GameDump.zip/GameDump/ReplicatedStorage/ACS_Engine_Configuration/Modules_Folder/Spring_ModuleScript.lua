-- Roblox: ReplicatedStorage.ACS_Engine.Modules.Spring
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    new = function(p1) --[[ Name: new, Line 3 ]]
        local u2 = tick();
        local u3 = p1 or 0;
        local u4 = p1 and (0 * p1 or 0) or 0;
        local u5 = p1 or 0;
        local u6 = 1;
        local u7 = 1;
        local function u18(p8) --[[ Line: 11 ]]
            -- upvalues: u2 (ref), u3 (ref), u5 (ref), u7 (ref), u6 (ref), u4 (ref)
            local v9 = p8 - u2;
            local v10 = u3 - u5;
            if u7 == 0 then
                return u3, 0;
            end;
            if u6 >= 1 then
                local v11 = u4 / u7 + v10;
                local v12 = math.exp(u7 * v9);
                return u5 + (v10 + v11 * u7 * v9) / v12, u7 * (v11 - v10 - v11 * u7 * v9) / v12;
            end;
            local v13 = math.sqrt(1 - u6 ^ 2);
            local v14 = (u4 / u7 + u6 * v10) / v13;
            local v15 = math.cos(v13 * u7 * v9);
            local v16 = math.sin(v13 * u7 * v9);
            local v17 = math.exp(u6 * u7 * v9);
            return u5 + (v10 * v15 + v14 * v16) / v17, u7 * ((v13 * v14 - u6 * v10) * v15 - (v13 * v10 + u6 * v14) * v16) / v17;
        end;
        return setmetatable({
            accelerate = function(_, p19) --[[ Name: accelerate, Line 34 ]]
                -- upvalues: u18 (copy), u3 (ref), u4 (ref), u2 (ref)
                local v20 = tick();
                local v21, v22 = u18(v20);
                u3 = v21;
                u4 = v22 + p19;
                u2 = v20;
            end
        }, {
            __index = function(_, p23) --[[ Name: __index, Line 43 ]]
                -- upvalues: u18 (copy), u2 (ref), u3 (ref), u5 (ref), u7 (ref), u6 (ref), u4 (ref)
                if p23 == "value" or (p23 == "position" or p23 == "p") then
                    local v24, _ = u18(tick());
                    return v24;
                end;
                if p23 == "velocity" or p23 == "v" then
                    local _, v25 = u18(tick());
                    return v25;
                end;
                if p23 == "acceleration" or p23 == "a" then
                    local v26 = tick() - u2;
                    local v27 = u3 - u5;
                    if u7 == 0 then
                        return 0;
                    end;
                    if u6 >= 1 then
                        local v28 = u4 / u7 + v27;
                        return u7 ^ 2 * (v27 - 2 * v28 + v28 * u7 * v26) / math.exp(u7 * v26);
                    end;
                    local v29 = math.sqrt(1 - u6 ^ 2);
                    local v30 = (u4 / u7 + u6 * v27) / v29;
                    local v31 = (v27 * u6 ^ 2 - v29 * 2 * u6 * v30 - v27 * v29 ^ 2) * math.cos(v29 * u7 * v26);
                    local v32 = (v30 * u6 ^ 2 + v29 * 2 * u6 * v27 - v30 * v29 ^ 2) * math.sin(v29 * u7 * v26);
                    return u7 ^ 2 * (v31 + v32) / math.exp(u6 * u7 * v26);
                end;
                if p23 == "target" or p23 == "t" then
                    return u5;
                end;
                if p23 == "damper" or p23 == "d" then
                    return u6;
                end;
                if p23 == "speed" or p23 == "s" then
                    return u7;
                end;
                if p23 == "magnitude" or p23 == "m" then
                    local v33, _ = u18(tick());
                    return v33.magnitude;
                end;
                error(p23 .. " is not a valid member of spring", 0);
            end,
            __newindex = function(_, p34, p35) --[[ Name: __newindex, Line 79 ]]
                -- upvalues: u18 (copy), u3 (ref), u4 (ref), u5 (ref), u6 (ref), u7 (ref), u2 (ref)
                local v36 = tick();
                if p34 == "value" or (p34 == "position" or p34 == "p") then
                    local _, v37 = u18(v36);
                    u3 = p35;
                    u4 = v37;
                elseif p34 == "velocity" or p34 == "v" then
                    local v38, _ = u18(v36);
                    u3 = v38;
                    u4 = p35;
                elseif p34 == "acceleration" or p34 == "a" then
                    local v39, v40 = u18(v36);
                    local v41 = v40 + p35;
                    u3 = v39;
                    u4 = v41;
                elseif p34 == "target" or p34 == "t" then
                    local v42, v43 = u18(v36);
                    u3 = v42;
                    u4 = v43;
                    u5 = p35;
                elseif p34 == "damper" or p34 == "d" then
                    local v44, v45 = u18(v36);
                    u3 = v44;
                    u4 = v45;
                    u6 = p35 < 0 and 0 or (p35 < 1 and p35 and p35 or 1);
                elseif p34 == "speed" or p34 == "s" then
                    local v46, v47 = u18(v36);
                    u3 = v46;
                    u4 = v47;
                    u7 = p35 < 0 and 0 or p35;
                else
                    error(p34 .. " is not a valid member of spring", 0);
                end;
                u2 = v36;
            end
        });
    end
};