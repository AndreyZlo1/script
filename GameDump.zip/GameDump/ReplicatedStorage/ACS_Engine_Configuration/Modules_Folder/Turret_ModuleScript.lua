-- Roblox: ReplicatedStorage.ACS_Engine.Modules.Turret
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local v1 = {};
local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__ACS_WorkSpace__2 = workspace:WaitForChild("ACS_WorkSpace");
local l__Events__3 = l__ReplicatedStorage__1:WaitForChild("ACS_Engine"):WaitForChild("Events");
local l__RunService__4 = game:GetService("RunService");
script:WaitForChild("Hitmarker");
script:WaitForChild("HeadshotHitmarker");
require(script.Parent:WaitForChild("Hitmarker"));
require(l__ReplicatedStorage__1:WaitForChild("Modules"):WaitForChild("VehicleModule"));
local _ = { l__ACS_WorkSpace__2.Client, l__ACS_WorkSpace__2.Server };
function CheckForHumanoid(p2)
    if p2 and p2.Parent then
        repeat
            p2 = p2.Parent;
        until p2:FindFirstChild("Humanoid") or p2 == workspace;
        if p2 ~= workspace and p2.Humanoid.Health > 0 then
            return p2.Humanoid;
        end;
    end;
end;
function v1.EnterTurretView(_, u3, u4) --[[ Line: 27 ]]
    -- upvalues: l__Events__3 (copy), l__ReplicatedStorage__1 (copy)
    local u5 = script.TurretView:Clone();
    u5.Parent = u3.Character;
    l__Events__3.Backpack:FireClient(u3, false);
    local l__Character__5 = u3.Character;
    if l__Character__5 then
        l__Character__5.Humanoid:EquipTool(u5);
        local l__Occupant__6 = u4.Occupant;
        local l__Parent__7 = u4.Parent.Parent;
        local u6 = Instance.new("ObjectValue");
        u6.Name = "TurretModel";
        u6.Parent = l__Character__5;
        u6.Value = l__Parent__7;
        u4:GetPropertyChangedSignal("Occupant"):Connect(function() --[[ Line: 41 ]]
            -- upvalues: u4 (copy), l__Occupant__6 (copy), u5 (copy), l__Events__3 (ref), u3 (copy), l__ReplicatedStorage__1 (ref), l__Character__5 (copy), u6 (copy)
            if u4.Occupant ~= l__Occupant__6 then
                u5:Destroy();
                l__Events__3.Backpack:FireClient(u3, true);
                if l__ReplicatedStorage__1:FindFirstChild(u3.Name .. "Turret") then
                    l__ReplicatedStorage__1:FindFirstChild(u3.Name .. "Turret"):Destroy();
                    if l__Character__5:FindFirstChild("Control") then
                        l__Character__5:FindFirstChild("Control"):Destroy();
                        u6:Destroy();
                    end;
                    u6:Destroy();
                end;
            end;
        end);
        local v7 = Instance.new("RemoteFunction");
        v7.Name = u3.Name .. "Turret";
        v7.Parent = game.ReplicatedStorage;
        local u8 = l__Parent__7.body:GetPrimaryPartCFrame();
        function v7.OnServerInvoke(p9, p10) --[[ Line: 63 ]]
            -- upvalues: u3 (copy), l__Events__3 (ref), l__Parent__7 (copy), u8 (copy)
            if p9 == u3 then
                for _, v11 in pairs(game.Players:GetChildren()) do
                    if v11.Name ~= p9.Name then
                        l__Events__3.ShowTurretPos:FireClient(v11, p10, l__Parent__7, u8);
                    end;
                end;
            end;
        end;
        local v12 = Instance.new("ObjectValue");
        v12.Name = "TurretModel";
        v12.Parent = u5;
        v12.Value = l__Parent__7;
        local v13 = script.Control:Clone();
        v13.Parent = l__Character__5;
        v13.Disabled = false;
    else
        u5:Destroy();
        l__Events__3.Backpack:FireClient(u3, true);
        warn("Failed getting Character // Turret");
    end;
end;
function v1.EnterTurretShooting(_, u14, p15) --[[ Line: 89 ]]
    -- upvalues: l__Events__3 (copy), l__RunService__4 (copy)
    local l__Character__8 = u14.Character;
    if l__Character__8 then
        local u16 = script.Turret:Clone();
        u16.Parent = l__Character__8;
        l__Events__3.Backpack:FireClient(u14, false);
        l__Character__8.Humanoid:EquipTool(u16);
        local _ = p15.Occupant;
        local _ = p15.Parent.Parent;
        l__RunService__4.Heartbeat:Wait();
        l__Character__8.Humanoid.Seated:Once(function(_, _) --[[ Name: onSeated, Line 106 ]]
            -- upvalues: u16 (copy), u14 (copy), l__Character__8 (copy)
            if u16 then
                u16:Destroy();
            end;
            if u14.Backpack:FindFirstChild("Turret") then
                u14.Backpack.Turret:Destroy();
            end;
            if game.ReplicatedStorage:FindFirstChild(u14.Name .. "Turret") then
                game.ReplicatedStorage:FindFirstChild(u14.Name .. "Turret"):Destroy();
                if l__Character__8:FindFirstChild("Control") then
                    l__Character__8:FindFirstChild("Control"):Destroy();
                end;
            end;
        end);
    else
        l__Events__3.Backpack:FireClient(u14, true);
        warn("Failed getting Character // Turret");
    end;
end;
function v1.LeaveTurret(_, p17) --[[ Line: 153 ]]
    local l__Character__9 = p17.Character;
    if l__Character__9 then
        l__Character__9.Humanoid.Jump = true;
    end;
end;
return v1;