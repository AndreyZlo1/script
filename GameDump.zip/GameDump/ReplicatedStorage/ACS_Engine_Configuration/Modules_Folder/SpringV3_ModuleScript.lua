-- Roblox: ReplicatedStorage.ACS_Engine.Modules.SpringV3
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    create = function(_, p1, p2, p3, p4) --[[ Name: create, Line 11 ]]
        return {
            Target = Vector3.new(),
            Position = Vector3.new(),
            Velocity = Vector3.new(),
            Mass = p1 or 5,
            Force = p2 or 50,
            Damping = p3 or 4,
            Speed = p4 or 4,
            shove = function(p5, p6) --[[ Name: shove, Line 24 ]]
                local l__X__1 = p6.X;
                local l__Y__2 = p6.Y;
                local l__Z__3 = p6.Z;
                p5.Velocity = p5.Velocity + Vector3.new((l__X__1 ~= l__X__1 or (l__X__1 == (1 / 0) or l__X__1 == (-1 / 0))) and 0 or l__X__1, (l__Y__2 ~= l__Y__2 or (l__Y__2 == (1 / 0) or l__Y__2 == (-1 / 0))) and 0 or l__Y__2, (l__Z__3 ~= l__Z__3 or (l__Z__3 == (1 / 0) or l__Z__3 == (-1 / 0))) and 0 or l__Z__3);
            end,
            update = function(p7, p8) --[[ Name: update, Line 38 ]]
                local v9 = math.min(p8, 1) * p7.Speed / 8;
                for _ = 1, 8 do
                    p7.Velocity = p7.Velocity + ((p7.Target - p7.Position) * p7.Force / p7.Mass - p7.Velocity * p7.Damping) * v9;
                    p7.Position = p7.Position + p7.Velocity * v9;
                end;
                return p7.Position;
            end
        };
    end
};