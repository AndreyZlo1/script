-- Roblox: ReplicatedStorage.ACS_Engine.Modules.AttachmentsUtil
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
local l__RunService__1 = game:GetService("RunService");
local l__Attachments__2 = script.Parent.Parent:WaitForChild("Attachments");
local l__WeaponProgression__3 = game:GetService("ReplicatedStorage"):WaitForChild("WeaponProgression");
local l__Attachments__4 = require(l__WeaponProgression__3:WaitForChild("Attachments"));
local u2 = l__RunService__1:IsStudio();
local function u6(p3) --[[ Line: 19 ]]
    for _, v4 in pairs(p3:GetDescendants()) do
        if v4:IsA("BasePart") then
            v4.Anchored = false;
            v4.CanCollide = false;
            if p3.PrimaryPart ~= v4 then
                local v5 = Instance.new("Motor6D", p3.PrimaryPart);
                v5.Part0 = p3.PrimaryPart;
                v5.Part1 = v4;
                v5.Name = v4.Name .. "AttWeld";
                v5.C0 = p3.PrimaryPart.CFrame:inverse() * v4.CFrame;
            end;
        end;
    end;
end;
local function u8(p7) --[[ Line: 36 ]]
    return { p7:FindFirstChild("Muzzle"), p7:FindFirstChild("Other"), p7:FindFirstChild("Underbarrel") };
end;
local u9 = {
    o = "Optic",
    f = "Foregrip",
    m = "Muzzle",
    l = "Laser",
    a = "Ammo",
    b = "Barrel",
    s = "Stock",
    g = "Grip",
    t = "Trigger"
};
function u1.getAttachmentCategoryFromIndex(p10) --[[ Line: 56 ]]
    -- upvalues: u9 (copy)
    return u9[string.sub(p10, 1, 1)] or "Misc";
end;
function u1.getAttDataFromHash(p11) --[[ Line: 60 ]]
    -- upvalues: l__Attachments__4 (copy), u9 (copy)
    for v12, v13 in l__Attachments__4.attachments do
        if v12 == p11 then
            local v14 = u9[string.sub(p11, 1, 1)];
            return {
                Name = v13.name,
                Folder = v13.folder,
                Category = v14
            };
        end;
    end;
end;
u1.attachmentChangedCallbacks = {
    Optic = function(p15, p16, p17) --[[ Name: Optic, Line 78 ]]
        for _, v18 in pairs(p15:GetDescendants()) do
            if v18:IsA("BasePart") then
                if v18.Name == "IS" then
                    v18.Transparency = p17 and 1 or 0;
                end;
                if v18.Name == "IM" then
                    v18.Transparency = p17 and 0 or 1;
                end;
            end;
        end;
        local v19 = p16:FindFirstChild("AimPos");
        if v19 then
            if p17 then
                p15.AimPart.Position = v19.Position;
            end;
        end;
    end,
    Barrel = function(p20, p21, _) --[[ Name: Barrel, Line 96 ]]
        -- upvalues: u8 (copy)
        local l__Nodes__5 = p20.Nodes;
        local l__Nodes__6 = p21.Nodes;
        local v22 = u8(l__Nodes__5);
        local v23 = u8(l__Nodes__6);
        for v24, v25 in ipairs(v23) do
            if v25 then
                if v22[v24] then
                    local v26 = v22[v24]:FindFirstChild("WeldsToBolt") or v22[v24]:FindFirstChild("WeldsToSlide");
                    if v26 then
                        v26.Parent = v25;
                    end;
                    v22[v24]:Destroy();
                end;
                v25.Parent = l__Nodes__5;
            end;
        end;
    end,
    Ammo = function(p27, _, p28) --[[ Name: Ammo, Line 113 ]]
        local v29 = p27:FindFirstChild("Mag");
        if v29 then
            if p28 then
                local v30 = v29:FindFirstChild("Mag");
                if v30 then
                    v30.Transparency = 1;
                    v30.Name = "OriginalMag";
                end;
            else
                local v31 = v29:FindFirstChild("OriginalMag");
                if v31 then
                    v31.Transparency = 0;
                    v31.Name = "Mag";
                end;
            end;
        end;
    end
};
function u1.sectionToNodeName(p32) --[[ Line: 134 ]]
    return ({
        Optic = "Sight",
        Muzzle = "Muzzle",
        Foregrip = "Underbarrel",
        Laser = "Other"
    })[p32] or "RootNode";
end;
function u1.getAttachmentModule(p33) --[[ Line: 144 ]]
    -- upvalues: l__Attachments__2 (copy), u2 (copy)
    local v34 = l__Attachments__2:FindFirstChild(p33.Folder or "Universal");
    if v34 then
        local v35 = v34.Modules:FindFirstChild(p33.Name);
        if v35 then
            return v35;
        else
            local v36 = p33.Name .. " module not found";
            if u2 then
                print(v36 .. " | AttachmentsUtil");
            end;
        end;
    else
        local v37 = p33.Folder .. " folder not found";
        if u2 then
            print(v37 .. " | AttachmentsUtil");
        end;
    end;
end;
function u1.loadAttachments(u38, p39) --[[ Line: 159 ]]
    -- upvalues: u2 (copy), u8 (copy), l__Attachments__2 (copy), u1 (copy), u6 (copy)
    if u38 then
        local u40 = u38:FindFirstChild("Nodes");
        if u40 then
            local v41 = u38:FindFirstChild("Barrel");
            if v41 and v41:FindFirstChild("Nodes") then
                local v42 = u8(v41.Nodes);
                for _, v43 in ipairs(v42) do
                    if v43 then
                        v43.Parent = u40;
                    elseif u2 then
                        print("One of barrel nodes is missing: Muzzle, Other, or Underbarrel | AttachmentsUtil");
                    end;
                end;
            end;
            local u44 = {};
            local function v55(p45) --[[ Line: 186 ]]
                -- upvalues: l__Attachments__2 (ref), u2 (ref), u1 (ref), u40 (copy), u6 (ref), u38 (copy), u44 (copy)
                local v46 = l__Attachments__2:FindFirstChild(p45.Folder or "Universal");
                if v46 then
                    local v47 = v46.Models:FindFirstChild(p45.Name);
                    if v47 then
                        if not v47.PrimaryPart then
                            v47.PrimaryPart = v47:FindFirstChild("RootNode");
                        end;
                        local v48 = u1.sectionToNodeName(p45.Category);
                        if v48 then
                            local v49 = u40:FindFirstChild(v48);
                            if v49 then
                                local v50 = v47:Clone();
                                u6(v50);
                                v50:SetPrimaryPartCFrame(v49.CFrame);
                                v50:SetAttribute("Category", p45.Category or "Attachment");
                                v50.Parent = u38;
                                local v51 = Instance.new("Motor6D");
                                v51.Name = p45.Category .. "Weld";
                                v51.Parent = v49;
                                v51.Part0 = v50.PrimaryPart;
                                v51.Part1 = v49;
                                v51.C0 = CFrame.new();
                                u44[p45.Category] = v50;
                                local v52 = u1.attachmentChangedCallbacks[p45.Category];
                                if v52 then
                                    v52(u38, v50, true);
                                end;
                            end;
                        end;
                    else
                        local v53 = p45.Name .. " model not found";
                        if u2 then
                            print(v53 .. " | AttachmentsUtil");
                        end;
                    end;
                else
                    local v54 = p45.Folder .. " folder not found";
                    if u2 then
                        print(v54 .. " | AttachmentsUtil");
                    end;
                end;
            end;
            local v56 = nil;
            for _, v57 in ipairs(p39) do
                if v57.Category == "Barrel" then
                    v56 = v57;
                end;
            end;
            if v56 then
                v55(v56);
            end;
            for _, v58 in ipairs(p39) do
                v55(v58);
            end;
            return u44;
        elseif u2 then
            print("No nodes found | AttachmentsUtil");
        end;
    elseif u2 then
        print("No weapon passed | AttachmentsUtil");
    end;
end;
return u1;