-- Roblox: ReplicatedStorage.ACS_Engine.Modules.CamosUtil
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Camos__2 = require(l__ReplicatedStorage__1:WaitForChild("WeaponProgression"):WaitForChild("Camos"));
local u2 = {
    f = "Biome",
    l = "Limited"
};
function u1.getCategoryFromIndex(p3) --[[ Line: 11 ]]
    -- upvalues: u2 (copy)
    return u2[string.sub(p3, 1, 1)] or "Misc";
end;
function u1.getNameFromIndex(p4) --[[ Line: 15 ]]
    -- upvalues: l__Camos__2 (copy)
    if p4 == nil then
        return nil;
    else
        return not l__Camos__2.camos[p4] and "Unknown" or l__Camos__2.camos[p4].name;
    end;
end;
function u1.getCamoFromIndex(p5) --[[ Line: 21 ]]
    -- upvalues: l__Camos__2 (copy)
    if p5 == nil then
        return nil;
    elseif l__Camos__2.camos[p5] then
        return l__Camos__2.camos[p5];
    else
        return nil;
    end;
end;
function u1.applyCamoToGun(p6, p7) --[[ Line: 27 ]]
    -- upvalues: u1 (copy)
    if p6 then
        local v8 = u1.getCamoFromIndex(p7);
        for _, v9 in p6:GetDescendants() do
            if v9.Name == "PrimaryPart" then
                for _, v10 in v9:GetChildren() do
                    if v10:IsA("Texture") then
                        v10:Destroy();
                    end;
                end;
                if v8 and v8.primaryTexture then
                    for _, v11 in Enum.NormalId:GetEnumItems() do
                        local v12 = Instance.new("Texture", v9);
                        v12.Face = v11;
                        v12.Texture = v8.primaryTexture;
                    end;
                end;
            elseif v9.Name == "SecondaryPart" then
                for _, v13 in v9:GetChildren() do
                    if v13:IsA("Texture") then
                        v13:Destroy();
                    end;
                end;
                if v8 and v8.secondaryTexture then
                    for _, v14 in Enum.NormalId:GetEnumItems() do
                        local v15 = Instance.new("Texture", v9);
                        v15.Face = v14;
                        v15.Texture = v8.secondaryTexture;
                    end;
                end;
            end;
        end;
    end;
end;
return u1;