-- Roblox: ReplicatedStorage.ACS_Engine.Modules.Hitmarker
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

workspace:WaitForChild("ACS_WorkSpace");
local l__Debris__1 = game:GetService("Debris");
local l__TweenService__2 = game:GetService("TweenService");
local l__ReplicatedStorage__3 = game:GetService("ReplicatedStorage");
local u1 = {
    "4668969235",
    "1565825075",
    "1565824613",
    "4668969774",
    "4668969602",
    "4668970218",
    "4668970412"
};
local u2 = {
    "282954522",
    "282954538",
    "282954576",
    "1565756607",
    "1565756818"
};
local u3 = {
    "1565830611",
    "1565831129",
    "1565831468",
    "1565832329"
};
local u4 = {
    "287772625",
    "287772674",
    "287772718",
    "287772829",
    "287772902"
};
local u5 = {
    "287769261",
    "287769348",
    "287769415",
    "287769483",
    "287769538"
};
local u6 = {
    "287390459",
    "287390954",
    "287391087",
    "287391197",
    "287391361",
    "287391499",
    "287391567"
};
local u7 = {
    "342190504",
    "342190495",
    "342190488",
    "342190510"
};
local u8 = {
    "3744371091",
    "3744371584",
    "1565837588",
    "1565836522",
    "1565734495",
    "3744371864",
    "1565734259",
    "3744371342"
};
local u9 = {
    "342190005",
    "342190012",
    "342190017",
    "342190024"
};
local u10 = { "9120009535", "9120006514", "9120010568" };
local v11 = {};
local l__MLGHitmarker__4 = script:WaitForChild("MLGHitmarker");
local l__HeadshotHitmarker__5 = script:WaitForChild("HeadshotHitmarker");
script:WaitForChild("MetalPipe");
script:WaitForChild("ArmorBreak");
local l__ArmorHitmarker__6 = script:WaitForChild("ArmorHitmarker");
local l__Players__7 = game:GetService("Players");
local l__VehicleModule__8 = require(l__ReplicatedStorage__3:WaitForChild("Modules"):WaitForChild("VehicleModule"));
local l__VFX__9 = l__ReplicatedStorage__3:WaitForChild("VFX");
local l__BulletImpact__10 = l__VFX__9:WaitForChild("BulletImpact");
local l__SwaggyExplosion__11 = l__VFX__9:WaitForChild("SwaggyExplosion");
local u12 = {
    Default = nil,
    Armor = nil,
    Vehicle = nil
};
local function u18(p13, p14, p15, p16) --[[ Line: 42 ]]
    local v17 = Instance.new("Sound");
    v17.Parent = p14;
    v17.Volume = math.random(20, 30) / 10;
    v17.MaxDistance = 100 * (p15 or 5) / 5;
    v17.EmitterSize = p15 or 5;
    v17.PlaybackSpeed = p16 or 1;
    v17.SoundId = "rbxassetid://" .. p13[math.random(1, #p13)];
    v17:Play();
end;
local function u26(p19, p20, p21) --[[ Line: 54 ]]
    -- upvalues: l__Debris__1 (copy)
    local v22 = p19:Clone();
    v22.Parent = workspace;
    v22.Position = p20;
    for _, u23 in ipairs(v22.Attachment:GetChildren()) do
        if u23:IsA("ParticleEmitter") then
            u23.Enabled = false;
            local u24 = u23:GetAttribute("EmitCount") or 1;
            local v25 = u23:GetAttribute("EmitDelay") or 0;
            if p21 then
                u23.Color = ColorSequence.new(p21);
            end;
            delay(v25, function() --[[ Line: 66 ]]
                -- upvalues: u23 (copy), u24 (copy)
                u23:Emit(u24);
            end);
        end;
    end;
    l__Debris__1:AddItem(v22, 5);
end;
function v11.playArmorBreak() --[[ Line: 80 ]]
    -- upvalues: l__ArmorHitmarker__6 (copy)
    local v27 = l__ArmorHitmarker__6;
    v27.PlayOnRemove = true;
    v27.Parent = nil;
    v27.Parent = script;
    v27.PlayOnRemove = false;
end;
function v11.playMLGHitmarker(p28, p29, p30, p31) --[[ Line: 84 ]]
    -- upvalues: l__Players__7 (copy), u12 (copy), l__TweenService__2 (copy), l__MLGHitmarker__4 (copy), l__HeadshotHitmarker__5 (copy), l__ArmorHitmarker__6 (copy)
    local l__HitmarkerImage__12 = l__Players__7.LocalPlayer.PlayerGui:WaitForChild("TopGui"):WaitForChild("HitmarkerImage");
    local l__ArmorHitmarkerImage__13 = l__Players__7.LocalPlayer.PlayerGui.TopGui:WaitForChild("ArmorHitmarkerImage");
    local l__VehicleHitmarkerImage__14 = l__Players__7.LocalPlayer.PlayerGui.TopGui:WaitForChild("VehicleHitmarkerImage");
    local u32 = p28 == "Vehicle" and Color3.new(0.9725490196078431, 0.6745098039215687, 0.3176470588235294) or p30 and Color3.new(1, 0, 0) or (p28 == "Armor" and Color3.new(0, 0.5490196078431373, 1) or Color3.new(1, 1, 1));
    if p31 then
        l__HitmarkerImage__12.ImageColor3 = u32;
    else
        local function v35(u33, p34, _) --[[ Line: 96 ]]
            -- upvalues: u12 (ref), l__TweenService__2 (ref), u32 (copy)
            if u12[u33] then
                u12[u33]:Cancel();
            end;
            u12[u33] = l__TweenService__2:Create(p34, TweenInfo.new(1), {
                ImageTransparency = 1
            });
            p34.ImageColor3 = u32;
            p34.ImageTransparency = 0;
            spawn(function() --[[ Line: 101 ]]
                -- upvalues: u12 (ref), u33 (copy)
                u12[u33]:Play();
            end);
        end;
        local v36 = l__MLGHitmarker__4;
        v36.PlayOnRemove = true;
        v36.Parent = nil;
        v36.Parent = script;
        v36.PlayOnRemove = false;
        if p29 then
            local v37 = l__HeadshotHitmarker__5;
            v37.PlayOnRemove = true;
            v37.Parent = nil;
            v37.Parent = script;
            v37.PlayOnRemove = false;
        end;
        if p28 == "Armor" then
            local v38 = l__ArmorHitmarker__6;
            v38.PlayOnRemove = true;
            v38.Parent = nil;
            v38.Parent = script;
            v38.PlayOnRemove = false;
            v35(p28, l__ArmorHitmarkerImage__13, u32);
        elseif p28 == "ArmorBreak" then
            local v39 = l__ArmorHitmarker__6;
            v39.PlayOnRemove = true;
            v39.Parent = nil;
            v39.Parent = script;
            v39.PlayOnRemove = false;
            v35("Armor", l__ArmorHitmarkerImage__13, u32);
        elseif p28 == "Vehicle" then
            v35(p28, l__VehicleHitmarkerImage__14, u32);
        end;
        if p28 ~= "Vehicle" then
            v35("Default", l__HitmarkerImage__12, u32);
        end;
    end;
end;
function v11.HitEffect(p40, p41, p42, p43) --[[ Line: 125 ]]
    -- upvalues: l__Debris__1 (copy), u18 (copy), u8 (copy), u1 (copy), u5 (copy), u26 (copy), l__BulletImpact__10 (copy), u4 (copy), u3 (copy), u7 (copy), u9 (copy), u2 (copy)
    if p41 and p41.Parent then
        local v44 = Instance.new("Attachment", workspace.Terrain);
        v44.CFrame = CFrame.new(p40, p40 + p42);
        l__Debris__1:AddItem(v44, 3);
        if p41.Name == "Head" or p41.Parent.Name == "Top" then
            u18(u8, v44);
        elseif p41.Name == "HumanoidRootPart" or (p41.Name == "Torso" or (p41.Name == "UpperTorso" or (p41.Name == "LowerTorso" or (p41.Name == "Right Arm" or (p41.Name == "Left Arm" or (p41.Name == "Right Leg" or (p41.Name == "Left Leg" or (p41.Name == "RightUpperArm" or (p41.Name == "RightLowerArm" or (p41.Name == "RightHand" or (p41.Name == "LeftUpperArm" or (p41.Name == "LeftLowerArm" or (p41.Name == "LeftHand" or (p41.Name == "RightUpperLeg" or (p41.Name == "RightLowerLeg" or (p41.Name == "RightFoot" or (p41.Name == "LeftUpperLeg" or (p41.Name == "LeftLowerLeg" or (p41.Name == "LeftFoot" or (p41.Parent.Name == "Chest" or p41.Parent.Name == "Back")))))))))))))))))))) then
            u18(u8, v44);
        elseif p41.Parent:IsA("Accessory") then
            u18(u8, v44);
        elseif p41.Name == "Glass" then
            u18(u1, v44);
            local v45 = Instance.new("BillboardGui", v44);
            v45.Adornee = v44;
            local v46 = math.random(10, 15) / 10;
            v45.Size = UDim2.new(v46, 0, v46, 0);
            local v47 = Instance.new("ImageLabel", v45);
            v47.BackgroundTransparency = 1;
            v47.Size = UDim2.new(0.05, 0, 0.05, 0);
            v47.Position = UDim2.new(0.5, 0, 0.5, 0);
            v47.Image = "http://www.roblox.com/asset/?id=5984841909";
            v47.ImageTransparency = math.random(0, 0.5);
            v47.Rotation = math.random(0, 360);
            v47:TweenSizeAndPosition(UDim2.new(1, 0, 1, 0), UDim2.new(0, 0, 0, 0), "Out", "Quad", 0.1);
            l__Debris__1:AddItem(v45, 0.1);
        elseif p43 == Enum.Material.Concrete or (p43 == Enum.Material.Slate or (p43 == Enum.Material.Cobblestone or (p43 == Enum.Material.Brick or (p43 == Enum.Material.Granite or (p43 == Enum.Material.Basalt or (p43 == Enum.Material.Rock or (p43 == Enum.Material.CrackedLava or (p43 == Enum.Material.Limestone or (p43 == Enum.Material.Asphalt or p43 == Enum.Material.Sandstone))))))))) then
            u18(u5, v44);
            u26(l__BulletImpact__10.Concrete, p40);
        elseif p43 == Enum.Material.Wood or p43 == Enum.Material.WoodPlanks then
            u18(u4, v44);
            u26(l__BulletImpact__10.Wood, p40);
        elseif p43 == Enum.Material.Fabric then
            u18(u3, v44);
            u26(l__BulletImpact__10.Wood, p40, p41.Color);
        elseif p43 == Enum.Material.Grass or (p43 == Enum.Material.Sand or (p43 == Enum.Material.Ground or (p43 == Enum.Material.Snow or (p43 == Enum.Material.Mud or p43 == Enum.Material.LeafyGrass)))) then
            u18(u3, v44);
            u26(l__BulletImpact__10.Sand, p40);
        elseif p43 == Enum.Material.Plastic or p43 == Enum.Material.SmoothPlastic then
            u18(u7, v44);
            u26(l__BulletImpact__10.Wood, p40, p41.Color);
        elseif p43 == Enum.Material.ForceField then
            u18(u9, v44);
            u26(l__BulletImpact__10.Kinetic, p40);
        elseif p43 == Enum.Material.CorrodedMetal or (p43 == Enum.Material.Metal or p43 == Enum.Material.DiamondPlate) then
            u18(u2, v44);
            u26(l__BulletImpact__10.Metal, p40);
        elseif p43 == Enum.Material.Glass or (p43 == Enum.Material.Ice or p43 == Enum.Material.Glacier) then
            u18(u1, v44);
            local v48 = Instance.new("ParticleEmitter");
            v48.Enabled = false;
            v48.Color = ColorSequence.new(Color3.new(50, 50, 50));
            v48.LightEmission = 0;
            v48.LightInfluence = 1;
            v48.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1, 0.1), NumberSequenceKeypoint.new(1, 1) });
            v48.Texture = "http://www.roblox.com/asset/?id=5984841909";
            v48.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0, 0), NumberSequenceKeypoint.new(1, 1) });
            v48.Acceleration = Vector3.new(0, -50, 0);
            v48.Lifetime = NumberRange.new(0.5, 0.5);
            v48.Rate = 100;
            v48.Drag = 5;
            v48.RotSpeed = NumberRange.new(-360, 360);
            v48.Speed = NumberRange.new(25, 25);
            v48.VelocitySpread = 50;
            v48.Parent = v44;
            v48.EmissionDirection = "Front";
            v48:Emit(5);
            l__Debris__1:AddItem(v44, v48.Lifetime.Max);
            local v49 = Instance.new("BillboardGui", v44);
            v49.Adornee = v44;
            local v50 = math.random(10, 15) / 10;
            v49.Size = UDim2.new(v50, 0, v50, 0);
            local v51 = Instance.new("ImageLabel", v49);
            v51.BackgroundTransparency = 1;
            v51.Size = UDim2.new(0.05, 0, 0.05, 0);
            v51.Position = UDim2.new(0.5, 0, 0.5, 0);
            v51.Image = "http://www.roblox.com/asset/?id=476778304";
            v51.ImageTransparency = math.random(0, 0.5);
            v51.Rotation = math.random(0, 360);
            v51:TweenSizeAndPosition(UDim2.new(1, 0, 1, 0), UDim2.new(0, 0, 0, 0), "Out", "Quad", 0.1);
            l__Debris__1:AddItem(v49, 0.1);
        else
            u18(u7, v44);
            u26(l__BulletImpact__10.Wood, p40, p41.Color);
        end;
    end;
end;
function v11.Explosion(p52, p53, p54) --[[ Line: 227 ]]
    -- upvalues: l__SwaggyExplosion__11 (copy), u18 (copy), u6 (copy), l__TweenService__2 (copy), l__Debris__1 (copy)
    local v55 = p54 or {};
    v55.LightScale = v55.LightScale or 1;
    v55.DisabledFX = v55.DisabledFX or {};
    local v56 = l__SwaggyExplosion__11:Clone();
    v56.Position = p52;
    v56.Parent = workspace;
    local v57 = p53 / 30;
    local v58 = 1 - v57;
    local v59 = v56.Attachment:GetChildren();
    u18(u6, v56.Attachment, v57 * 25, 1 + 0.5 * v58);
    for _, u60 in ipairs(v59) do
        if not table.find(v55.DisabledFX, u60.Name) then
            if u60:IsA("PointLight") then
                l__TweenService__2:Create(u60, TweenInfo.new(0.3, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut, 0, true), {
                    Brightness = 9 * v55.LightScale,
                    Range = 20 * v55.LightScale
                }):Play();
            end;
            if u60:IsA("ParticleEmitter") then
                u60.Enabled = false;
                local v61 = u60:GetAttribute("EmitDelay");
                local u62 = u60:GetAttribute("EmitCount");
                local v63 = {};
                for _, v64 in u60.Size.Keypoints do
                    local v65 = NumberSequenceKeypoint.new(v64.Time, v64.Value * v57, v64.Envelope);
                    table.insert(v63, v65);
                end;
                u60.Size = NumberSequence.new(v63);
                delay(v61, function(_) --[[ Line: 282 ]]
                    -- upvalues: u60 (copy), u62 (copy)
                    u60:Emit(u62);
                end);
            end;
        end;
    end;
    l__Debris__1:AddItem(v56, 7);
end;
function v11.tankShot(p66, p67) --[[ Line: 290 ]]
    -- upvalues: l__VehicleModule__8 (copy), l__ReplicatedStorage__3 (copy)
    if p66 and (p66.Character and (p66.Character:FindFirstChild("Humanoid") and p66.Character.Humanoid.SeatPart)) then
        local v68 = l__VehicleModule__8.checkAndGetTank(p66.Character.Humanoid.SeatPart);
        if v68 then
            local l__FollowPart__15 = v68.Required.Dome.FollowPart;
            local l__Name__16 = p66.Character.Humanoid.SeatPart.Name;
            local v69 = (l__Name__16 == "TankSeat" or l__Name__16 == "ApcSeat") and "DriverWeapons" or (l__Name__16 == "GunnerSeat" and "GunnerWeapons" or nil);
            local v70;
            if p67 then
                if not (l__ReplicatedStorage__3.Vehicles[v68.Name] and l__ReplicatedStorage__3.Vehicles[v68.Name].Params.Config) then
                    return;
                end;
                local l__Config__17 = require(l__ReplicatedStorage__3.Vehicles[v68.Name].Params.Config);
                if not v69 or (not l__Config__17[v69] or #l__Config__17[v69] < p67) then
                    return;
                end;
                v70 = l__Config__17[v69][p67];
            else
                v70 = nil;
            end;
            local v71;
            if v70 and (v70.FireSound and l__FollowPart__15:FindFirstChild(v70.FireSound)) then
                v71 = l__FollowPart__15[v70.FireSound];
            else
                v71 = l__FollowPart__15.Fire;
            end;
            if v71 and (v70 and v70.OneShotSound) then
                local v72 = v71:Clone();
                v72.Parent = v71.Parent;
                v72.PlayOnRemove = true;
                v72:Destroy();
            elseif v71 then
                v71:Play();
            end;
            local function v76(u73) --[[ Line: 332 ]]
                if u73 and u73:IsA("ParticleEmitter") then
                    local v74 = u73:GetAttribute("EmitDelay") or 0;
                    local u75 = u73:GetAttribute("EmitCount") or 1;
                    delay(v74, function(_) --[[ Line: 336 ]]
                        -- upvalues: u73 (copy), u75 (copy)
                        u73:Emit(u75);
                    end);
                end;
            end;
            if v70 then
                local v77 = v68.Required:FindFirstChild(v70.FXAttName, true);
                if v77 then
                    for _, v78 in v77.Parent:GetChildren() do
                        if v78:IsA("Attachment") and v78.Name == v70.FXAttName then
                            for _, v79 in ipairs(v78:GetChildren()) do
                                v76(v79);
                            end;
                        end;
                    end;
                end;
            end;
        end;
    end;
end;
function v11.heliRocketShot(p80, p81, p82) --[[ Line: 352 ]]
    -- upvalues: l__VehicleModule__8 (copy), u18 (copy), u10 (copy)
    if p80 and (p80.Character and (p80.Character:FindFirstChild("Humanoid") and p80.Character.Humanoid.SeatPart)) then
        local v83 = l__VehicleModule__8.checkAndGetHeli(p80.Character.Humanoid.SeatPart);
        if v83 and v83:FindFirstChild("Weaponry") then
            u18(u10, p82[p81].Attachment);
        end;
    end;
end;
return v11;