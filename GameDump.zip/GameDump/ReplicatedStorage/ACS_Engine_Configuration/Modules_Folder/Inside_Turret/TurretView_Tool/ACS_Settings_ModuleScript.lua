-- Roblox: ReplicatedStorage.ACS_Engine.Modules.Turret.TurretView.ACS_Settings
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

game:GetService("TweenService");
return {
    SlideEx = CFrame.new(0, 0, 0),
    SlideLock = false,
    canAim = false,
    Zoom = 60,
    Zoom2 = 60,
    gunName = script.Parent.Name,
    Type = "Gun",
    EnableHUD = false,
    IncludeChamberedBullet = false,
    Ammo = 0,
    StoredAmmo = 0,
    AmmoInGun = 0,
    MaxStoredAmmo = 0,
    CanCheckMag = false,
    MagCount = false,
    ShellInsert = true,
    ShootRate = 0,
    Bullets = 0,
    BurstShot = 3,
    ShootType = 3,
    FireModes = {
        ChangeFiremode = true,
        Semi = false,
        Burst = false,
        Auto = true
    },
    LimbDamage = { 0, 0 },
    TorsoDamage = { 0, 0 },
    HeadDamage = { 0, 0 },
    DamageFallOf = 0,
    MinDamage = 0,
    IgnoreProtection = true,
    BulletPenetration = 0,
    CrossHair = true,
    CenterDot = true,
    CrosshairOffset = 0,
    CanBreachDoor = false,
    SightAtt = "",
    BarrelAtt = "",
    UnderBarrelAtt = "",
    OtherAtt = "",
    camRecoil = {
        camRecoilUp = { 10, 13 },
        camRecoilTilt = { 7, 12 },
        camRecoilLeft = { 5, 9 },
        camRecoilRight = { 4, 7 }
    },
    gunRecoil = {
        gunRecoilUp = { 3, 5 },
        gunRecoilTilt = { 3, 5 },
        gunRecoilLeft = { 3, 5 },
        gunRecoilRight = { 3, 5 }
    },
    AimRecoilReduction = 3,
    AimSpreadReduction = 1,
    MinRecoilPower = 0.5,
    MaxRecoilPower = 1,
    RecoilPowerStepAmount = 0.05,
    MinSpread = 0.85,
    MaxSpread = 30,
    AimInaccuracyStepAmount = 0.95,
    AimInaccuracyDecrease = 0.25,
    WalkMult = 0,
    EnableZeroing = true,
    MaxZero = 500,
    ZeroIncrement = 50,
    CurrentZero = 0,
    BulletType = "5.56x45mm",
    MuzzleVelocity = 1500,
    BulletDrop = 0.25,
    Tracer = true,
    BulletFlare = true,
    TracerColor = Color3.fromRGB(255, 255, 255),
    RandomTracer = {
        Enabled = false,
        Chance = 25
    },
    TracerEveryXShots = 3,
    RainbowMode = false,
    InfraRed = false,
    CanBreak = true,
    Jammed = false
};