-- Roblox: ReplicatedStorage.ACS_Engine.Modules.Turret.Turret.ACS_Settings
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

game:GetService("TweenService");
return {
    SlideEx = CFrame.new(0, 0, 0),
    SlideLock = false,
    canAim = true,
    Zoom = 40,
    Zoom2 = 40,
    gunName = script.Parent.Name,
    Type = "Gun",
    EnableHUD = false,
    IncludeChamberedBullet = false,
    Ammo = 1e16,
    StoredAmmo = 1e16,
    AmmoInGun = 1e16,
    MaxStoredAmmo = 1e16,
    CanCheckMag = false,
    MagCount = false,
    ShellInsert = true,
    ShootRate = 700,
    Bullets = 1,
    BurstShot = 3,
    ShootType = 3,
    FireModes = {
        ChangeFiremode = false,
        Semi = false,
        Burst = false,
        Auto = true
    },
    LimbDamage = { 50, 50 },
    TorsoDamage = { 50, 50 },
    HeadDamage = { 85, 85 },
    DamageFallOf = 0,
    MinDamage = 0,
    IgnoreProtection = true,
    BulletPenetration = 0,
    CrossHair = false,
    CenterDot = true,
    CrosshairOffset = 0,
    CanBreachDoor = false,
    SightAtt = "",
    BarrelAtt = "",
    UnderBarrelAtt = "",
    OtherAtt = "",
    camRecoil = {
        camRecoilUp = { 5, 9 },
        camRecoilTilt = { 7, 12 },
        camRecoilLeft = { 5, 9 },
        camRecoilRight = { 4, 7 }
    },
    gunRecoil = {
        gunRecoilUp = { 3, 5 },
        gunRecoilTilt = { 3, 5 },
        gunRecoilLeft = { 3, 5 },
        gunRecoilRight = { 3, 5 }
    },
    AimRecoilReduction = 3,
    AimSpreadReduction = 1,
    MinRecoilPower = 0.5,
    MaxRecoilPower = 1,
    RecoilPowerStepAmount = 0.05,
    MinSpread = 2,
    MaxSpread = 2,
    AimInaccuracyStepAmount = 1,
    AimInaccuracyDecrease = 0,
    WalkMult = 0,
    EnableZeroing = true,
    MaxZero = 500,
    ZeroIncrement = 50,
    CurrentZero = 0,
    BulletType = "5.56x45mm",
    MuzzleVelocity = 1500,
    BulletDrop = 0.25,
    Tracer = true,
    BulletFlare = true,
    TracerColor = Color3.fromRGB(255, 255, 255),
    RandomTracer = {
        Enabled = false,
        Chance = 25
    },
    TracerEveryXShots = 3,
    RainbowMode = false,
    InfraRed = false,
    CanBreak = false,
    Jammed = false
};