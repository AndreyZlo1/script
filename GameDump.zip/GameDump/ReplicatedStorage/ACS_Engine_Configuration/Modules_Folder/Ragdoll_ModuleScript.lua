-- Roblox: ReplicatedStorage.ACS_Engine.Modules.Ragdoll
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

game:GetService("PhysicsService");
local l__Players__1 = game.Players;
return function(u1) --[[ Line: 4 ]]
    -- upvalues: l__Players__1 (copy)
    pcall(function() --[[ Line: 8 ]]
        -- upvalues: u1 (copy), l__Players__1 (ref)
        if u1 ~= nil then
            l__Players__1:GetPlayerFromCharacter(u1);
            if u1.Humanoid.RigType == Enum.HumanoidRigType.R6 then
                local v2 = u1:FindFirstChild("Head");
                local v3 = u1:FindFirstChild("Humanoid");
                local v4 = u1:FindFirstChild("Left Arm");
                local v5 = u1:FindFirstChild("Left Leg");
                local v6 = u1:FindFirstChild("Right Leg");
                local v7 = u1:FindFirstChild("Right Arm");
                local v8 = u1:FindFirstChild("Torso");
                v3.PlatformStand = true;
                v3.AutoRotate = false;
                local v9 = Instance.new("Attachment");
                v9.Name = "HeadA";
                v9.Parent = v2;
                v9.Position = Vector3.new(0, -0.5, 0);
                v9.Rotation = Vector3.new(0, 0, -90);
                v9.Axis = Vector3.new(0, -1, 0);
                v9.SecondaryAxis = Vector3.new(1, 0, 0);
                local v10 = Instance.new("Attachment");
                v10.Name = "LeftArmA";
                v10.Parent = v4;
                v10.Position = Vector3.new(0.5, 0.6, 0);
                v10.Rotation = Vector3.new(0, 0, 0);
                v10.Axis = Vector3.new(1, 0, 0);
                v10.SecondaryAxis = Vector3.new(0, 1, 0);
                local v11 = Instance.new("Attachment");
                v11.Name = "LeftLegA";
                v11.Parent = v5;
                v11.Position = Vector3.new(0.1, 1, -0);
                v11.Rotation = Vector3.new(-0, -0, -90);
                v11.Axis = Vector3.new(-0, -1, 0);
                v11.SecondaryAxis = Vector3.new(1, 0, 0);
                local v12 = Instance.new("Attachment");
                v12.Name = "RightArmA";
                v12.Parent = v7;
                v12.Position = Vector3.new(-0.5, 0.6, 0);
                v12.Rotation = Vector3.new(-180, 0, -180);
                v12.Axis = Vector3.new(-1, 0, 0);
                v12.SecondaryAxis = Vector3.new(0, 1, 0);
                local v13 = Instance.new("Attachment");
                v13.Name = "RightLegA";
                v13.Parent = v6;
                v13.Position = Vector3.new(-0.1, 1, 0);
                v13.Rotation = Vector3.new(0, 0, -90);
                v13.Axis = Vector3.new(-0, -1, -0);
                v13.SecondaryAxis = Vector3.new(1, 0, -0);
                local v14 = Instance.new("Attachment");
                v14.Name = "TorsoA";
                v14.Parent = v8;
                v14.Position = Vector3.new(0.4, -1, 0);
                v14.Rotation = Vector3.new(0, 0, -90);
                v14.Axis = Vector3.new(0, -1, 0);
                v14.SecondaryAxis = Vector3.new(1, 0, 0);
                local v15 = Instance.new("Attachment");
                v15.Name = "TorsoA1";
                v15.Parent = v8;
                v15.Position = Vector3.new(-0.4, -1, 0);
                v15.Rotation = Vector3.new(0, 0, -90);
                v15.Axis = Vector3.new(0, -1, 0);
                v15.SecondaryAxis = Vector3.new(1, 0, 0);
                local v16 = Instance.new("Attachment");
                v16.Name = "TorsoA2";
                v16.Parent = v8;
                v16.Position = Vector3.new(-1, 0.8, 0);
                v16.Rotation = Vector3.new(-0, 0, -0);
                v16.Axis = Vector3.new(1, -0, 0);
                v16.SecondaryAxis = Vector3.new(0, 1, -0);
                local v17 = Instance.new("Attachment");
                v17.Name = "TorsoA3";
                v17.Parent = v8;
                v17.Position = Vector3.new(1, 0.8, 0);
                v17.Rotation = Vector3.new(180, 0, 180);
                v17.Axis = Vector3.new(-1, -0, 0);
                v17.SecondaryAxis = Vector3.new(-0, 1, -0);
                local v18 = Instance.new("Attachment");
                v18.Name = "TorsoA4";
                v18.Parent = v8;
                v18.Position = Vector3.new(-0, 1, 0);
                v18.Rotation = Vector3.new(0, 0, -90);
                v18.Axis = Vector3.new(0, -1, 0);
                v18.SecondaryAxis = Vector3.new(1, 0, 0);
                local v19 = Instance.new("BallSocketConstraint");
                v19.Parent = v2;
                v19.Attachment0 = v9;
                v19.Attachment1 = v18;
                v19.Enabled = true;
                local v20 = Instance.new("BallSocketConstraint");
                v20.Parent = v4;
                v20.Attachment0 = v10;
                v20.Attachment1 = v16;
                v20.Enabled = true;
                local v21 = Instance.new("BallSocketConstraint");
                v21.Parent = v7;
                v21.Attachment0 = v12;
                v21.Attachment1 = v17;
                v21.Enabled = true;
                local v22 = Instance.new("BallSocketConstraint");
                v22.Parent = v2;
                v22.Attachment0 = v9;
                v22.Attachment1 = v18;
                v22.Enabled = true;
                local v23 = Instance.new("BallSocketConstraint");
                v23.Parent = v8;
                v23.Attachment0 = v15;
                v23.Attachment1 = v11;
                v23.Enabled = true;
                local v24 = Instance.new("BallSocketConstraint");
                v24.Parent = v8;
                v24.Attachment0 = v14;
                v24.Attachment1 = v13;
                v24.Enabled = true;
            else
                local v25 = u1:FindFirstChild("Head");
                local v26 = u1:FindFirstChild("Humanoid");
                local v27 = u1:FindFirstChild("LeftUpperArm");
                local v28 = u1:FindFirstChild("LeftLowerArm");
                local v29 = u1:FindFirstChild("LeftHand");
                local v30 = u1:FindFirstChild("LeftUpperLeg");
                local v31 = u1:FindFirstChild("LeftLowerLeg");
                local v32 = u1:FindFirstChild("LeftFoot");
                local v33 = u1:FindFirstChild("RightUpperLeg");
                local v34 = u1:FindFirstChild("RightLowerLeg");
                local v35 = u1:FindFirstChild("RightFoot");
                local v36 = u1:FindFirstChild("RightUpperArm");
                local v37 = u1:FindFirstChild("RightLowerArm");
                local v38 = u1:FindFirstChild("RightHand");
                local v39 = u1:FindFirstChild("UpperTorso");
                local v40 = u1:FindFirstChild("LowerTorso");
                for _, v41 in {
                    v25,
                    v26,
                    v27,
                    v28,
                    v29,
                    v30,
                    v31,
                    v32,
                    v33,
                    v34,
                    v35,
                    v36,
                    v37,
                    v38,
                    v39,
                    v40
                } do
                    if not v41 then
                        return;
                    end;
                end;
                v26.PlatformStand = true;
                v26.AutoRotate = false;
                local v42 = Instance.new("BallSocketConstraint");
                v42.Parent = v25;
                v42.Attachment0 = v25.NeckRigAttachment;
                v42.Attachment1 = v39.NeckRigAttachment;
                v42.Enabled = true;
                v42.LimitsEnabled = true;
                v42.TwistLimitsEnabled = true;
                v42.UpperAngle = 90;
                v42.TwistLowerAngle = -60;
                v42.TwistUpperAngle = 60;
                local v43 = Instance.new("BallSocketConstraint");
                v43.Parent = v27;
                v43.Attachment0 = v27.LeftShoulderRigAttachment;
                v43.Attachment1 = v39.LeftShoulderRigAttachment;
                v43.Enabled = true;
                v43.LimitsEnabled = false;
                v43.TwistLimitsEnabled = false;
                v43.UpperAngle = 180;
                v43.TwistLowerAngle = -90;
                v43.TwistUpperAngle = 0;
                local v44 = Instance.new("BallSocketConstraint");
                v44.Parent = v27;
                v44.Attachment0 = v28.LeftElbowRigAttachment;
                v44.Attachment1 = v27.LeftElbowRigAttachment;
                v44.Enabled = true;
                v44.LimitsEnabled = true;
                v44.TwistLimitsEnabled = true;
                v44.UpperAngle = 0;
                v44.TwistLowerAngle = -160;
                v44.TwistUpperAngle = 0;
                local v45 = Instance.new("BallSocketConstraint");
                v45.Parent = v27;
                v45.Attachment0 = v28.LeftWristRigAttachment;
                v45.Attachment1 = v29.LeftWristRigAttachment;
                v45.Enabled = true;
                v45.LimitsEnabled = true;
                v45.TwistLimitsEnabled = true;
                v45.UpperAngle = 25;
                v45.TwistLowerAngle = -25;
                v45.TwistUpperAngle = 25;
                local v46 = Instance.new("BallSocketConstraint");
                v46.Parent = v36;
                v46.Attachment0 = v36.RightShoulderRigAttachment;
                v46.Attachment1 = v39.RightShoulderRigAttachment;
                v46.Enabled = true;
                v46.LimitsEnabled = false;
                v46.TwistLimitsEnabled = false;
                v46.UpperAngle = 90;
                v46.TwistLowerAngle = 0;
                v46.TwistUpperAngle = 0;
                local v47 = Instance.new("BallSocketConstraint");
                v47.Parent = v37;
                v47.Attachment0 = v37.RightElbowRigAttachment;
                v47.Attachment1 = v36.RightElbowRigAttachment;
                v47.Enabled = true;
                v47.LimitsEnabled = true;
                v47.TwistLimitsEnabled = true;
                v47.UpperAngle = 0;
                v47.TwistLowerAngle = -160;
                v47.TwistUpperAngle = 0;
                local v48 = Instance.new("BallSocketConstraint");
                v48.Parent = v38;
                v48.Attachment0 = v37.RightWristRigAttachment;
                v48.Attachment1 = v38.RightWristRigAttachment;
                v48.Enabled = true;
                v48.LimitsEnabled = true;
                v48.TwistLimitsEnabled = true;
                v48.UpperAngle = 25;
                v48.TwistLowerAngle = -25;
                v48.TwistUpperAngle = 25;
                local v49 = Instance.new("BallSocketConstraint");
                v49.Parent = v39;
                v49.Attachment0 = v39.WaistRigAttachment;
                v49.Attachment1 = v40.WaistRigAttachment;
                v49.Enabled = true;
                v49.LimitsEnabled = true;
                v49.TwistLimitsEnabled = true;
                v49.UpperAngle = 30;
                v49.TwistLowerAngle = -30;
                v49.TwistUpperAngle = 30;
                local v50 = Instance.new("BallSocketConstraint");
                v50.Parent = v33;
                v50.Attachment0 = v33.RightHipRigAttachment;
                v50.Attachment1 = v40.RightHipRigAttachment;
                v50.Enabled = true;
                v50.LimitsEnabled = true;
                v50.TwistLimitsEnabled = true;
                v50.UpperAngle = 20;
                v50.TwistLowerAngle = -75;
                v50.TwistUpperAngle = 75;
                local v51 = Instance.new("BallSocketConstraint");
                v51.Parent = v34;
                v51.Attachment0 = v34.RightKneeRigAttachment;
                v51.Attachment1 = v33.RightKneeRigAttachment;
                v51.Enabled = true;
                v51.LimitsEnabled = true;
                v51.TwistLimitsEnabled = true;
                v51.UpperAngle = 0;
                v51.TwistLowerAngle = 0;
                v51.TwistUpperAngle = 90;
                local v52 = Instance.new("BallSocketConstraint");
                v52.Parent = v35;
                v52.Attachment0 = v35.RightAnkleRigAttachment;
                v52.Attachment1 = v34.RightAnkleRigAttachment;
                v52.Enabled = true;
                v52.LimitsEnabled = true;
                v52.TwistLimitsEnabled = true;
                v52.UpperAngle = 25;
                v52.TwistLowerAngle = -25;
                v52.TwistUpperAngle = 25;
                local v53 = Instance.new("BallSocketConstraint");
                v53.Parent = v30;
                v53.Attachment0 = v30.LeftHipRigAttachment;
                v53.Attachment1 = v40.LeftHipRigAttachment;
                v53.Enabled = true;
                v53.LimitsEnabled = true;
                v53.TwistLimitsEnabled = true;
                v53.UpperAngle = 30;
                v53.TwistLowerAngle = -90;
                v53.TwistUpperAngle = 90;
                local v54 = Instance.new("BallSocketConstraint");
                v54.Parent = v31;
                v54.Attachment0 = v31.LeftKneeRigAttachment;
                v54.Attachment1 = v30.LeftKneeRigAttachment;
                v54.Enabled = true;
                v54.LimitsEnabled = true;
                v54.TwistLimitsEnabled = true;
                v54.UpperAngle = 0;
                v54.TwistLowerAngle = 0;
                v54.TwistUpperAngle = 90;
                local v55 = Instance.new("BallSocketConstraint");
                v55.Parent = v32;
                v55.Attachment0 = v32.LeftAnkleRigAttachment;
                v55.Attachment1 = v31.LeftAnkleRigAttachment;
                v55.Enabled = true;
                v55.LimitsEnabled = true;
                v55.TwistLimitsEnabled = true;
                v55.UpperAngle = 25;
                v55.TwistLowerAngle = -25;
                v55.TwistUpperAngle = 25;
            end;
            for _, v56 in pairs(u1:GetDescendants()) do
                if not v56:IsA("Accessory") and (not v56:IsA("Model") and v56:IsA("Motor6D")) then
                    v56:Destroy();
                end;
            end;
            if u1:FindFirstChild("HumanoidRootPart") ~= nil then
                u1.HumanoidRootPart:Destroy();
            end;
        end;
    end);
end;