-- Roblox: ReplicatedStorage.ACS_Engine.Modules.Utilities
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    Weld = function(p1, p2, p3, p4) --[[ Line: 3 ]]
        local v5 = Instance.new("Motor6D", p1);
        v5.Part0 = p1;
        v5.Part1 = p2;
        v5.Name = p2.Name;
        v5.C0 = p3 or p1.CFrame:inverse() * p2.CFrame;
        v5.C1 = p4 or CFrame.new();
        return v5;
    end,
    WeldKf = function(p6, p7, p8) --[[ Line: 13 ]]
        local v9 = Instance.new("Motor6D", p6);
        local v10, v11, v12 = p7.CFrame:ToObjectSpace(p6.CFrame):ToEulerAnglesYXZ();
        v9.Part0 = p6;
        v9.Part1 = p7;
        v9.Name = p7.Name;
        local v13 = p8 and 3.141592653589793 or 0;
        local v14 = CFrame.Angles(v10 + v13, v11, v12 + v13);
        v9.C0 = p6.CFrame:ToObjectSpace(p7.CFrame) * v14;
        v9.C1 = v14;
        return v9;
    end,
    WeldComplex = function(p15, p16, p17, p18) --[[ Line: 27 ]]
        local v19 = Instance.new("Motor6D");
        v19.Name = p17;
        v19.Part0 = p15;
        v19.Part1 = p16;
        local v20 = CFrame.new(p15.Position);
        local v21 = p15.CFrame:inverse() * v20;
        local v22 = p16.CFrame:inverse() * v20;
        v19.C0 = v21;
        v19.C1 = v22;
        if p18 then
            p15 = p16 or p15;
        end;
        v19.Parent = p15;
        return v19;
    end,
    CheckForHumanoid = function(p23) --[[ Line: 41 ]]
        local v24 = nil;
        local v25;
        if p23 and (p23.Parent:FindFirstChild("Humanoid") or p23.Parent.Parent:FindFirstChild("Humanoid")) then
            v25 = true;
            if p23.Parent:FindFirstChild("Humanoid") then
                return v25, p23.Parent.Humanoid;
            end;
            if p23.Parent.Parent:FindFirstChild("Humanoid") then
                return v25, p23.Parent.Parent.Humanoid;
            end;
        else
            v25 = false;
        end;
        return v25, v24;
    end
};