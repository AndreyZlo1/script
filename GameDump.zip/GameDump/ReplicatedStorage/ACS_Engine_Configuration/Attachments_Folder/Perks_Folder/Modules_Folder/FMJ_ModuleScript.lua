-- Roblox: ReplicatedStorage.ACS_Engine.Attachments.Perks.Modules.FMJ
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    SightZoom = 0,
    SightZoom2 = 0,
    IsSuppressor = false,
    IsFlashHider = false,
    IsBipod = false,
    EnableLaser = false,
    EnableFlashlight = false,
    InfraRed = false,
    UiStats = {
        Pros = { "15% Vehicle Damage" },
        Cons = {}
    },
    Mult = {
        Damage = 1,
        HeadDamage = 1,
        MinDamage = 1,
        VehicleDamage = 1.15,
        AdsTime = 1,
        VerticalRecoil = 1,
        HorizontalRecoil = 1,
        DamageFallOff = 1,
        MuzzleVelocity = 1,
        MoveSpeed = 1,
        AdsMoveSpeed = 1,
        HipSpread = 1,
        SprintToFire = 1,
        ReloadSpeed = 1
    }
};