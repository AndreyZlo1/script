-- Roblox: ReplicatedStorage.ACS_Engine.Attachments.CROSS.Modules.10 Round Mag
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    SightZoom = 0,
    SightZoom2 = 0,
    IsSuppressor = false,
    IsFlashHider = false,
    IsBipod = false,
    EnableLaser = false,
    EnableFlashlight = false,
    InfraRed = false,
    AmmoCountOverride = 10,
    UiStats = {
        Pros = { "Mag Size" },
        Cons = { "25% Reload Speed", "15% ADS Speed", "7% Movement Speed" }
    },
    Mult = {
        Damage = 1,
        HeadDamage = 1,
        MinDamage = 1,
        AdsTime = 0.85,
        VerticalRecoil = 1,
        HorizontalRecoil = 1,
        DamageFallOff = 1,
        MuzzleVelocity = 1,
        MoveSpeed = 0.93,
        AdsMoveSpeed = 1,
        HipSpread = 1,
        SprintToFire = 1,
        ReloadSpeed = 0.75
    }
};