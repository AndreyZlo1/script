-- Roblox: ReplicatedStorage.ACS_Engine.Attachments.Universal.Modules.Vertical Grip
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    SightZoom = 0,
    SightZoom2 = 0,
    IsSuppressor = false,
    IsFlashHider = false,
    IsBipod = false,
    EnableLaser = false,
    EnableFlashlight = false,
    InfraRed = false,
    UiStats = {
        Pros = { "15% Vertical Recoil", "5% Horizontal Recoil" },
        Cons = { "5% ADS Speed", "10% ADS Movement Speed" }
    },
    Mult = {
        Damage = 1,
        HeadDamage = 1,
        MinDamage = 1,
        AdsTime = 1.05,
        VerticalRecoil = 0.85,
        HorizontalRecoil = 0.95,
        DamageFallOff = 1,
        MuzzleVelocity = 1,
        MoveSpeed = 1,
        AdsMoveSpeed = 0.9,
        HipSpread = 1,
        SprintToFire = 1,
        ReloadSpeed = 1
    }
};