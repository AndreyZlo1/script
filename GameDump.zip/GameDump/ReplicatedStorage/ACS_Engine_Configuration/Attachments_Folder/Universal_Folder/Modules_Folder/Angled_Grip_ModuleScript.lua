-- Roblox: ReplicatedStorage.ACS_Engine.Attachments.Universal.Modules.Angled Grip
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    SightZoom = 0,
    SightZoom2 = 0,
    IsSuppressor = false,
    IsFlashHider = false,
    IsBipod = false,
    EnableLaser = false,
    EnableFlashlight = false,
    InfraRed = false,
    UiStats = {
        Pros = { "5% Horizontal Recoil", "7% ADS Movement Speed" },
        Cons = { "7% ADS Time" }
    },
    Mult = {
        Damage = 1,
        HeadDamage = 1,
        MinDamage = 1,
        AdsTime = 1.07,
        VerticalRecoil = 1,
        HorizontalRecoil = 0.95,
        DamageFallOff = 1,
        MuzzleVelocity = 1,
        MoveSpeed = 1,
        AdsMoveSpeed = 1.07,
        HipSpread = 1,
        SprintToFire = 1,
        ReloadSpeed = 1
    }
};