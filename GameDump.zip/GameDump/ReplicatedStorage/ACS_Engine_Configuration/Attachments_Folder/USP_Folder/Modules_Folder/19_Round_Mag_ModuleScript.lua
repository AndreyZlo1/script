-- Roblox: ReplicatedStorage.ACS_Engine.Attachments.USP.Modules.19 Round Mag
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    SightZoom = 0,
    SightZoom2 = 0,
    IsSuppressor = false,
    IsFlashHider = false,
    IsBipod = false,
    EnableLaser = false,
    EnableFlashlight = false,
    InfraRed = false,
    AmmoCountOverride = 19,
    UiStats = {
        Pros = { "Mag Size" },
        Cons = { "20% Reload Speed", "10% ADS Speed" }
    },
    Mult = {
        Damage = 1,
        HeadDamage = 1,
        MinDamage = 1,
        AdsTime = 0.9,
        VerticalRecoil = 1,
        HorizontalRecoil = 1,
        DamageFallOff = 1,
        MuzzleVelocity = 1,
        MoveSpeed = 1,
        AdsMoveSpeed = 1,
        HipSpread = 1,
        SprintToFire = 1,
        ReloadSpeed = 0.8
    }
};