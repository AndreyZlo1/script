-- Roblox: ReplicatedStorage.ACS_Engine.Attachments.Marksman.Modules.Legion Suppressor
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    SightZoom = 0,
    SightZoom2 = 0,
    IsSuppressor = true,
    IsFlashHider = true,
    IsBipod = false,
    EnableLaser = false,
    EnableFlashlight = false,
    InfraRed = false,
    UiStats = {
        Pros = { "Suppressed", "10% Damage Range", "10% Vertical Recoil" },
        Cons = { "7% ADS Speed" }
    },
    Mult = {
        Damage = 1,
        HeadDamage = 1,
        MinDamage = 1,
        AdsTime = 1,
        VerticalRecoil = 0.9,
        HorizontalRecoil = 1,
        DamageFallOff = 1,
        MuzzleVelocity = 1,
        MoveSpeed = 1,
        AdsMoveSpeed = 1,
        HipSpread = 1,
        SprintToFire = 1,
        ReloadSpeed = 1
    }
};