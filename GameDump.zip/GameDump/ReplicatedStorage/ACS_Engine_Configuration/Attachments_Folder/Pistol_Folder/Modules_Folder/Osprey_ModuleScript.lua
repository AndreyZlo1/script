-- Roblox: ReplicatedStorage.ACS_Engine.Attachments.Pistol.Modules.Osprey
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    SightZoom = 0,
    SightZoom2 = 0,
    IsSuppressor = true,
    IsFlashHider = true,
    IsBipod = false,
    EnableLaser = false,
    EnableFlashlight = false,
    InfraRed = false,
    UiStats = {
        Pros = { "Suppressed", "25% Range" },
        Cons = { "15% ADS Time" }
    },
    Mult = {
        Damage = 1,
        MinDamage = 1,
        AdsTime = 1.15,
        VerticalRecoil = 1,
        HorizontalRecoil = 1,
        DamageFallOff = 0.75,
        MuzzleVelocity = 1,
        MoveSpeed = 1,
        AdsMoveSpeed = 1,
        HipSpread = 1,
        SprintToFire = 1,
        ReloadSpeed = 1
    }
};