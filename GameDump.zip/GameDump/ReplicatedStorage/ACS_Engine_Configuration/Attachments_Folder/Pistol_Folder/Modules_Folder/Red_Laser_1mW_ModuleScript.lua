-- Roblox: ReplicatedStorage.ACS_Engine.Attachments.Pistol.Modules.Red Laser 1mW
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    SightZoom = 0,
    SightZoom2 = 0,
    IsSuppressor = false,
    IsFlashHider = false,
    IsBipod = false,
    EnableLaser = true,
    EnableFlashlight = false,
    InfraRed = false,
    UiStats = {
        Pros = { "15% Hipfire Spread" },
        Cons = {}
    },
    Mult = {
        Damage = 1,
        HeadDamage = 1,
        MinDamage = 1,
        AdsTime = 1,
        VerticalRecoil = 1,
        HorizontalRecoil = 1,
        DamageFallOff = 1,
        MuzzleVelocity = 1,
        MoveSpeed = 1,
        AdsMoveSpeed = 1,
        HipSpread = 0.85,
        SprintToFire = 1,
        ReloadSpeed = 1
    }
};