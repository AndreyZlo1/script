-- Roblox: ReplicatedStorage.ACS_Engine.HUD.NVGOverlay.NoiseScript
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = require(script:WaitForChild("pool")).new({
    12817152186,
    12817151943,
    12817151838,
    12817151684,
    12817151437,
    12817151256,
    12817151057,
    12817150900,
    12817150706,
    12817150567
});
local l__Noise__1 = script.Parent:WaitForChild("Noise");
game:GetService("RunService").RenderStepped:Connect(function() --[[ Line: 21 ]]
    -- upvalues: l__Noise__1 (copy), u1 (copy)
    l__Noise__1.Image = "rbxassetid://" .. tostring(u1.draw());
end);