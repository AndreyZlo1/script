-- Roblox: ReplicatedStorage.ACS_Engine.HUD.NVGOverlay.NoiseScript.pool
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    new = function(p1) --[[ Name: new, Line 11 ]]
        local u2 = {
            reference = p1,
            pool = {},
            seed = Random.new()
        };
        function u2.refill() --[[ Line: 19 ]]
            -- upvalues: u2 (copy)
            local v3 = u2;
            local v4 = {};
            for v5, v6 in u2.reference do
                v4[v5] = v6;
            end;
            v3.pool = v4;
        end;
        function u2.draw() --[[ Line: 23 ]]
            -- upvalues: u2 (copy)
            if #u2.pool < 1 then
                u2.refill();
            end;
            local v7 = u2.seed:NextInteger(1, #u2.pool);
            local v8 = u2.pool[v7];
            table.remove(u2.pool, v7);
            return v8;
        end;
        return u2;
    end
};