-- Roblox: ReplicatedStorage.ACS_Engine.HUD.GPShud.GPS
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

repeat
    wait();
until game.Players.LocalPlayer.Character;
local l__Parent__1 = script.Parent;
local l__LocalPlayer__2 = game.Players.LocalPlayer;
local l__Character__3 = l__LocalPlayer__2.Character;
local l__Saude__4 = l__Character__3:WaitForChild("Saude");
tick();
while l__Parent__1:FindFirstChild("Frame") == nil do
    wait();
end;
local l__Frame__5 = l__Parent__1.Frame;
local l__ACS_Engine__6 = game.ReplicatedStorage:WaitForChild("ACS_Engine");
local l__GPSdistance__7 = require(l__ACS_Engine__6.ServerConfigs:WaitForChild("Config")).GPSdistance;
tick();
while l__Frame__5:FindFirstChild("MinhaVisao") == nil do
    wait();
end;
local l__MinhaVisao__8 = l__Frame__5.MinhaVisao;
tick();
while l__Frame__5:FindFirstChild("RosaDosVentos") == nil do
    wait();
end;
local _ = l__Frame__5.RosaDosVentos;
tick();
while l__Frame__5:FindFirstChild("FoeBlip") == nil do
    wait();
end;
local l__FoeBlip__9 = l__Frame__5.FoeBlip;
tick();
while l__Frame__5:FindFirstChild("FriendBlip") == nil do
    wait();
end;
local l__FriendBlip__10 = l__Frame__5.FriendBlip;
tick();
while l__Frame__5:FindFirstChild("UIAspectRatioConstraint") == nil do
    wait();
end;
local _ = l__Frame__5.UIAspectRatioConstraint;
local l__CurrentCamera__11 = workspace.CurrentCamera;
local u1 = {
    MinhaVisao = 1,
    RosaDosVentos = 1,
    UIAspectRatioConstraint = 1,
    FoeBlip = 1,
    FriendBlip = 1
};
local u2 = {
    UIGridLayout = 1
};
l__Character__3.Humanoid.Died:Connect(function() --[[ Line: 40 ]]
    script.Parent.Enabled = false;
end);
game:GetService("RunService").RenderStepped:connect(function() --[[ Line: 44 ]]
    -- upvalues: l__CurrentCamera__11 (copy), l__Saude__4 (copy), l__MinhaVisao__8 (copy), l__LocalPlayer__2 (copy), u2 (copy), l__Frame__5 (copy), u1 (copy), l__FriendBlip__10 (copy), l__FoeBlip__9 (copy), l__GPSdistance__7 (copy)
    local l__unit__12 = (Vector2.new(l__CurrentCamera__11.Focus.x, l__CurrentCamera__11.Focus.z) - Vector2.new(l__CurrentCamera__11.CoordinateFrame.x, l__CurrentCamera__11.CoordinateFrame.z)).unit;
    local v3 = math.atan2(l__unit__12.y, l__unit__12.x) * -57.29577951308232 - 90;
    if l__Saude__4.FireTeam.SquadName.Value == "" then
        l__MinhaVisao__8.ImageColor3 = Color3.fromRGB(255, 255, 255);
    else
        l__MinhaVisao__8.ImageColor3 = l__Saude__4.FireTeam.SquadColor.Value;
    end;
    local v4 = Vector3.new(l__CurrentCamera__11.CoordinateFrame.x, 0, l__CurrentCamera__11.CoordinateFrame.z);
    local v5 = Vector3.new(l__CurrentCamera__11.Focus.x, 0, l__CurrentCamera__11.Focus.z);
    local v6 = CFrame.new(v5, v4);
    script.Parent.Frame.RosaDosVentos.Rotation = v3;
    local v7 = game.Players:GetChildren();
    if l__Saude__4.FireTeam.SquadName.Value == "" or not l__LocalPlayer__2 then
        script.Parent.Squad.Visible = false;
    else
        script.Parent.Squad.Visible = true;
        script.Parent.Squad.Esquadrao.Text = l__Saude__4.FireTeam.SquadName.Value;
    end;
    local v8 = script.Parent.Squad.Membros:GetChildren();
    for v9 = 1, #v8 do
        if not u2[v8[v9].Name] then
            v8[v9]:Destroy();
        end;
    end;
    for v10 = 1, #v7 do
        if v7[v10] ~= l__LocalPlayer__2 and (v7[v10].Character and (l__LocalPlayer__2 and (l__LocalPlayer__2.Character and (l__LocalPlayer__2.Character.Humanoid.Health > 0 and (not script.Parent.Squad.Membros:FindFirstChild(v7[v10].Name) and (v7[v10].TeamColor == l__LocalPlayer__2.TeamColor and (v7[v10].Character:FindFirstChild("Saude") and (v7[v10].Character.Saude:FindFirstChild("FireTeam") and (v7[v10].Character.Saude.FireTeam.SquadName.Value == l__LocalPlayer__2.Character.Saude.FireTeam.SquadName.Value and l__LocalPlayer__2.Character.Saude.FireTeam.SquadName.Value ~= ""))))))))) then
            local v11 = script.Parent.Squad.Exemplo:Clone();
            v11.Visible = true;
            v11.Text = v7[v10].Name;
            v11.Name = v7[v10].Name;
            v11.Parent = script.Parent.Squad.Membros;
        end;
    end;
    local v12 = l__Frame__5:GetChildren();
    for v13 = 1, #v12 do
        if not u1[v12[v13].Name] then
            v12[v13]:Destroy();
        end;
    end;
    for v14 = 1, #v7 do
        if v7[v14] ~= l__LocalPlayer__2 and (v7[v14].Character and (l__LocalPlayer__2 and l__LocalPlayer__2.Character)) then
            local v15 = l__Frame__5:FindFirstChild(v7[v14].Name);
            if not v15 then
                if v7[v14].TeamColor == l__LocalPlayer__2.TeamColor then
                    v15 = l__FriendBlip__10:Clone();
                else
                    v15 = l__FoeBlip__9:Clone();
                end;
                v15.Visible = false;
                v15.Name = v7[v14].Name;
                v15.Parent = l__Frame__5;
            end;
            if v7[v14].Character:FindFirstChild("Humanoid") and v7[v14].Character:FindFirstChild("HumanoidRootPart") then
                local v16 = CFrame.new(v7[v14].Character.HumanoidRootPart.Position.X, 0, v7[v14].Character.HumanoidRootPart.Position.Z);
                local v17 = v6:inverse() * v16;
                if v17.p.Magnitude / l__GPSdistance__7 < 0.9 then
                    v15.Position = UDim2.new(0.5 - v17.x / l__GPSdistance__7 / 2, 0, 0.5 - v17.z / l__GPSdistance__7 / 2, 0);
                    v15.Rotation = -v7[v14].Character.HumanoidRootPart.Orientation.Y + v3;
                    if v7[v14].TeamColor == l__LocalPlayer__2.TeamColor and v7[v14].Character then
                        if v7[v14].Character:FindFirstChild("Saude") and (v7[v14].Character.Saude:FindFirstChild("FireTeam") and v7[v14].Character.Saude.FireTeam.SquadName.Value ~= "") then
                            v15.ImageColor3 = v7[v14].Character.Saude.FireTeam.SquadColor.Value;
                        else
                            v15.ImageColor3 = l__FriendBlip__10.ImageColor3;
                        end;
                    else
                        v15.ImageColor3 = l__FoeBlip__9.ImageColor3;
                    end;
                    v15.Visible = true;
                else
                    v15.Visible = false;
                end;
            else
                v15.Visible = false;
            end;
        end;
    end;
end);