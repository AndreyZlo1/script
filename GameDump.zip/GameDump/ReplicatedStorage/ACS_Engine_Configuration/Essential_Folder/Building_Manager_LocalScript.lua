-- Roblox: ReplicatedStorage.ACS_Engine.Essential.Building_Manager
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

repeat
    wait();
until game.Players.LocalPlayer.Character;
local l__LocalPlayer__1 = game.Players.LocalPlayer;
local l__Character__2 = l__LocalPlayer__1.Character;
local _ = workspace.CurrentCamera;
local u1 = l__LocalPlayer__1:GetMouse();
local l__ACS_Engine__3 = game.ReplicatedStorage:WaitForChild("ACS_Engine");
local l__Eventos__4 = l__ACS_Engine__3:WaitForChild("Eventos");
local l__ServerConfigs__5 = l__ACS_Engine__3:WaitForChild("ServerConfigs");
local l__HUD__6 = l__ACS_Engine__3:WaitForChild("HUD");
local l__Assets__7 = l__ACS_Engine__3:WaitForChild("Assets");
local l__Humanoid__8 = l__Character__2:WaitForChild("Humanoid");
local l__UserInputService__9 = game:GetService("UserInputService");
game:GetService("TweenService");
local l__RenderStepped__10 = game:GetService("RunService").RenderStepped;
local l__Config__11 = require(l__ServerConfigs__5:WaitForChild("Config"));
local l__Config__12 = require(script:WaitForChild("Config"));
local u2 = false;
local u3 = nil;
local u4 = nil;
local u5 = CFrame.Angles(0, 0, 0);
local u6 = CFrame.new();
local u7 = "Rotate";
local u8 = nil;
local l__PlaceEvent__13 = l__Eventos__4:WaitForChild("PlaceEvent");
function placementVector(p9, p10, p11, p12)
    -- upvalues: u6 (ref), u5 (ref)
    if p10 then
        local v13 = Ray.new(p11 + Vector3.new(0, 0.1, 0), Vector3.new(0, -1, 0));
        local _, v14, v15 = workspace:FindPartOnRay(v13, p9);
        local v16 = (Vector3.new(0, 1, 0)):Cross(v15);
        local v17 = math.asin(v16.magnitude);
        p9:SetPrimaryPartCFrame(p9.PrimaryPart.CFrame:lerp(CFrame.new(v14 + v15 * p9.PrimaryPart.Size.y / 2) * CFrame.fromAxisAngle(v16.magnitude == 0 and Vector3.new(1) or v16.unit, v17) * u6 * u5, p12));
    end;
end;
l__Character__2.ChildAdded:connect(function(p18) --[[ Line: 59 ]]
    -- upvalues: l__Humanoid__8 (copy), l__Config__11 (copy), u3 (ref), u8 (ref), l__HUD__6 (copy), l__LocalPlayer__1 (copy), l__Assets__7 (copy), u2 (ref), l__Config__12 (copy), u4 (ref)
    if p18:IsA("Tool") and (p18:FindFirstChild("ACS_Setup") and (l__Humanoid__8.Health > 0 and (require(p18.ACS_Setup).Type == "Build" and l__Config__11.BuildingEnabled))) then
        u3 = p18;
        u8 = l__HUD__6:WaitForChild("PlacementUI"):clone();
        u8.Parent = l__LocalPlayer__1.PlayerGui;
        u8.Frame.Visible = true;
        for _, v19 in pairs(l__Assets__7:GetChildren()) do
            if v19:IsA("Model") and v19.PrimaryPart then
                local u20 = u8:WaitForChild("Template"):WaitForChild("TemplateButton"):clone();
                u20.Parent = u8:WaitForChild("Frame"):WaitForChild("AssetListFrame");
                u20.Visible = true;
                u20.Name = v19.Name;
                u20.Text = v19.Name;
                u20.MouseButton1Click:connect(function() --[[ Line: 75 ]]
                    -- upvalues: u2 (ref), l__Config__12 (ref), l__LocalPlayer__1 (ref), u4 (ref), l__Assets__7 (ref), u20 (copy)
                    if not u2 then
                        if l__Config__12.ResourcesEnabled then
                            if l__LocalPlayer__1.Team and (l__LocalPlayer__1.Team:FindFirstChild("Resources") and l__LocalPlayer__1.Team.Resources.Value > 0) then
                                u4 = l__Assets__7:WaitForChild(u20.Name):clone();
                                u4.Parent = workspace:FindFirstChild("Buildables") or workspace;
                                u2 = true;
                            end;
                        else
                            u4 = l__Assets__7:WaitForChild(u20.Name):clone();
                            u4.Parent = workspace:FindFirstChild("Buildables") or workspace;
                            u2 = true;
                        end;
                    end;
                end);
            end;
        end;
    end;
end);
l__Character__2.ChildRemoved:connect(function(p21) --[[ Line: 95 ]]
    -- upvalues: u3 (ref), l__Config__11 (copy), u8 (ref)
    if p21 == u3 and l__Config__11.BuildingEnabled then
        u8:Destroy();
    end;
end);
l__UserInputService__9.InputBegan:connect(function(p22, p23) --[[ Line: 102 ]]
    -- upvalues: l__Config__11 (copy), u7 (ref), u5 (ref), l__Config__12 (copy), u6 (ref), u4 (ref), u2 (ref), l__LocalPlayer__1 (copy), u1 (copy), l__Character__2 (copy), l__PlaceEvent__13 (copy)
    if not p23 and l__Config__11.BuildingEnabled then
        if p22.KeyCode == Enum.KeyCode.Q then
            if u7 == "Rotate" then
                u5 = u5 * CFrame.Angles(0, math.rad(l__Config__12.RotInc), 0);
            elseif u7 == "Move" then
                u6 = u6 * CFrame.new(0, l__Config__12.MoveInc, 0);
            end;
        end;
        if p22.KeyCode == Enum.KeyCode.E then
            if u7 == "Rotate" then
                u5 = u5 * CFrame.Angles(0, math.rad(-l__Config__12.RotInc), 0);
            elseif u7 == "Move" then
                u6 = u6 * CFrame.new(0, -l__Config__12.MoveInc, 0);
            end;
        end;
        if p22.KeyCode == Enum.KeyCode.G then
            if u7 == "Rotate" then
                u5 = u5 * CFrame.Angles(0, 0, (math.rad(l__Config__12.RotInc)));
            elseif u7 == "Move" then
                u6 = u6 * CFrame.new(0, 0, l__Config__12.MoveInc);
            end;
        end;
        if p22.KeyCode == Enum.KeyCode.H then
            if u7 == "Rotate" then
                u5 = u5 * CFrame.Angles(0, 0, (math.rad(-l__Config__12.RotInc)));
            elseif u7 == "Move" then
                u6 = u6 * CFrame.new(0, 0, -l__Config__12.MoveInc);
            end;
        end;
        if p22.KeyCode == Enum.KeyCode.V then
            if u7 == "Rotate" then
                u5 = u5 * CFrame.Angles(math.rad(l__Config__12.RotInc), 0, 0);
            elseif u7 == "Move" then
                u6 = u6 * CFrame.new(l__Config__12.MoveInc, 0, 0);
            end;
        end;
        if p22.KeyCode == Enum.KeyCode.B then
            if u7 == "Rotate" then
                u5 = u5 * CFrame.Angles(math.rad(-l__Config__12.RotInc), 0, 0);
            elseif u7 == "Move" then
                u6 = u6 * CFrame.new(-l__Config__12.MoveInc, 0, 0);
            end;
        end;
        if p22.KeyCode == Enum.KeyCode.F then
            if u7 == "Rotate" then
                u7 = "Move";
            elseif u7 == "Move" then
                u7 = "Rotate";
            end;
        end;
        if p22.UserInputType == Enum.UserInputType.MouseButton1 then
            if not (u4 or u2) then
                return;
            end;
            if u4 and u2 then
                local v24 = u4:GetDescendants();
                local u25 = "HalfRot";
                local v26 = false;
                for _, v27 in pairs(v24) do
                    if v27:IsA("Seat") and v27.Name == "WBTurretSeat" then
                        local l__OptionFrame__14 = l__LocalPlayer__1.PlayerGui:WaitForChild("PlacementUI"):WaitForChild("OptionFrame");
                        l__OptionFrame__14.Position = UDim2.new(0, u1.X - l__OptionFrame__14.AbsoluteSize.X, 0, u1.Y - l__OptionFrame__14.AbsoluteSize.Y);
                        l__OptionFrame__14.Visible = true;
                        v26 = true;
                        for _, u28 in pairs(l__OptionFrame__14:GetChildren()) do
                            if u28:IsA("TextButton") then
                                u28.MouseButton1Click:connect(function() --[[ Line: 176 ]]
                                    -- upvalues: u28 (copy), u25 (ref), l__OptionFrame__14 (copy)
                                    if u28.Name == "FRot" then
                                        u25 = "FullRot";
                                    elseif u28.Name == "HRot" then
                                        u25 = "HalfRot";
                                    end;
                                    l__OptionFrame__14.Visible = false;
                                    l__OptionFrame__14.Position = UDim2.new(0, 0, 0, 0);
                                end);
                            end;
                        end;
                    end;
                end;
                if (u1.Hit.p - l__Character__2:WaitForChild("HumanoidRootPart").Position).magnitude <= l__Config__12.MaxDist then
                    l__PlaceEvent__13:FireServer(u4.Name, u4.PrimaryPart.CFrame, u1.Target, v26, u25, "Place");
                    u4:Destroy();
                    u5 = CFrame.Angles(0, 0, 0);
                    u6 = CFrame.new();
                    u2 = false;
                end;
            end;
        end;
    end;
end);
l__RenderStepped__10:connect(function(p29) --[[ Line: 203 ]]
    -- upvalues: u2 (ref), l__Config__11 (copy), u1 (copy), u4 (ref), l__Config__12 (copy)
    if u2 and l__Config__11.BuildingEnabled then
        u1.TargetFilter = u4;
        placementVector(u4, u1.Target, u1.Hit.p, p29 * l__Config__12.SpeedMult);
    end;
end);