-- Roblox: ReplicatedStorage.ACS_Engine.Essential.TeamTag
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

repeat
    wait();
until game.Players.LocalPlayer.Character;
local l__LocalPlayer__1 = game.Players.LocalPlayer;
local _ = l__LocalPlayer__1.Character;
local l__ACS_Engine__2 = game.ReplicatedStorage:WaitForChild("ACS_Engine");
local l__GameRules__3 = l__ACS_Engine__2:WaitForChild("GameRules");
l__ACS_Engine__2:WaitForChild("HUD");
require(l__GameRules__3:WaitForChild("Config"));
function UpdateTag(p1)
    -- upvalues: l__LocalPlayer__1 (copy)
    if p1 ~= l__LocalPlayer__1 and (p1.Character and p1.Character:FindFirstChild("TeamTagUI")) then
        local v2 = p1.Character:FindFirstChild("TeamTagUI");
        if p1.Team == l__LocalPlayer__1.Team then
            v2.Enabled = true;
            if p1.Character:FindFirstChild("ACS_Client") and (p1.Character.ACS_Client:FindFirstChild("FireTeam") and p1.Character.ACS_Client.FireTeam.SquadName.Value ~= "") then
                v2.Frame.Icon.ImageColor3 = p1.Character.ACS_Client.FireTeam.SquadColor.Value;
                return;
            else
                v2.Frame.Icon.ImageColor3 = Color3.fromRGB(255, 255, 255);
                return;
            end;
        end;
        v2.Enabled = false;
    end;
end;
game:GetService("RunService").Heartbeat:connect(function() --[[ Line: 35 ]]
    for _, v3 in pairs(game.Players:GetChildren()) do
        UpdateTag(v3);
    end;
end);