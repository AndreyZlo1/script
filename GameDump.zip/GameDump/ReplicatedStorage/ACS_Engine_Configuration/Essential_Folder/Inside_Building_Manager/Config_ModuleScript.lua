-- Roblox: ReplicatedStorage.ACS_Engine.Essential.Building_Manager.Config
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

return {
    SpeedMult = 6,
    RotInc = 10,
    MoveInc = 0.1,
    MaxDist = 20,
    ResourcesEnabled = false,
    ModeKey = Enum.KeyCode.F
};