-- Roblox: Players.SilverAce293026.PlayerScripts.PickupClient
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

if require(game.ReplicatedStorage:WaitForChild("ReplicatedConfig")).FeatureToggles.DeathDropsEnabled then
    local l__Players__1 = game:GetService("Players");
    local l__ReplicatedStorage__2 = game:GetService("ReplicatedStorage");
    local l__Bezier__3 = require(l__ReplicatedStorage__2:WaitForChild("Modules"):WaitForChild("Bezier"));
    local l__NewDeathDrop__4 = l__ReplicatedStorage__2:WaitForChild("PlayerEvents"):WaitForChild("NewDeathDrop");
    l__ReplicatedStorage__2:WaitForChild("PlayerEvents"):WaitForChild("DropPickedUp");
    game:GetService("Players").LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("TopGui"):WaitForChild("PickupUpdater"):WaitForChild("Pickup");
    local l__Drops__5 = workspace:WaitForChild("Drops");
    l__NewDeathDrop__4.OnClientEvent:Connect(function(p1, p2, p3) --[[ Line: 17 ]]
        -- upvalues: l__Drops__5 (copy), l__Players__1 (copy), l__Bezier__3 (copy)
        local u4 = l__Drops__5:WaitForChild(p1, 10);
        if u4 then
            local u5;
            if u4:IsA("Model") then
                u5 = u4.PrimaryPart or (u4:WaitForChild("Handle", 5) or u4);
            else
                u5 = u4;
            end;
            if u5 then
                local v6 = u4:GetAttribute("DropType");
                local v7 = Vector3.new(p2.X, p3.Y, p2.Z);
                u5.CFrame = CFrame.new(p3, v7);
                if v6 == "ArmorPickup" then
                    u5.CFrame = u5.CFrame * CFrame.Angles(0, 4.71238898038469, 0);
                elseif v6 == "Gun" then
                    u4:PivotTo(u4.PrimaryPart.CFrame * CFrame.Angles(1.5707963267948966, 1.5707963267948966, 0));
                    if u4:GetAttribute("HideFrom") == l__Players__1.LocalPlayer.Name then
                        u4:Destroy();
                        return;
                    end;
                end;
                local v8 = (p3 + p2) * 0.5;
                local v9 = { p3, Vector3.new(v8.X, p3.Y + 1, v8.Z), p2 };
                local u10 = l__Bezier__3.new(v9);
                local u11 = nil;
                local u12 = 0;
                u11 = game:GetService("RunService").RenderStepped:Connect(function(p13) --[[ Line: 58 ]]
                    -- upvalues: u4 (copy), u11 (ref), u12 (ref), u10 (copy), u5 (copy)
                    if u4 then
                        u12 = u12 + p13 * 3;
                        u12 = math.clamp(u12, 0, 1);
                        local v14 = u10:GetPoint(u12);
                        if u4:IsA("Model") then
                            local v15 = CFrame.new(v14);
                            local l__CFrame__6 = u5.CFrame;
                            u4:PivotTo(v15 * (l__CFrame__6 - l__CFrame__6.Position));
                        else
                            u4.Position = v14;
                        end;
                        if u12 >= 1 then
                            u11:Disconnect();
                        end;
                    else
                        u11:Disconnect();
                    end;
                end);
                local v16 = script.Highlight:Clone();
                if v6 == "GiftPickup" then
                    v16.OutlineColor = Color3.fromRGB(255, 255, 0);
                elseif v6 == "BigGiftPickup" then
                    v16.OutlineColor = Color3.fromRGB(255, 0, 0);
                end;
                v16.Parent = u4;
            end;
        end;
    end);
end;