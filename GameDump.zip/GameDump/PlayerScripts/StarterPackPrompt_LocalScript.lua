-- Roblox: Players.SilverAce293026.PlayerScripts.StarterPackPrompt
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Players__2 = game:GetService("Players");
game:GetService("RunService");
require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig"));
local l__LocalPlayer__3 = l__Players__2.LocalPlayer;
local l__PlayerGui__4 = l__LocalPlayer__3:WaitForChild("PlayerGui");
local l__Modules__5 = l__ReplicatedStorage__1:WaitForChild("Modules");
local l__AreaModule__6 = require(l__Modules__5:WaitForChild("AreaModule"));
local l__PlayerEvents__7 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents");
local v1 = l__PlayerEvents__7:WaitForChild("GetStarterPackExpiry"):InvokeServer();
local l__InvalidateStarterPack__8 = l__PlayerEvents__7:WaitForChild("InvalidateStarterPack");
local v2 = l__PlayerEvents__7:WaitForChild("CanGetStarterPackFree"):InvokeServer();
l__PlayerEvents__7:WaitForChild("ClaimFreeStarterPack");
local l__GetHasPromptedStarterPack__9 = l__PlayerEvents__7:WaitForChild("GetHasPromptedStarterPack");
local l__SetHasPromptedStarterPack__10 = l__PlayerEvents__7:WaitForChild("SetHasPromptedStarterPack");
if v1 < 600 and not v2 then
    return;
end;
if l__GetHasPromptedStarterPack__9:InvokeServer() and not v2 then
    return;
end;
local l__Value__11 = l__LocalPlayer__3:WaitForChild("AssociatedTycoon").Value;
local l__RootPart__12 = workspace:WaitForChild(l__Value__11):WaitForChild("RootPart");
local u3 = false;
if v2 then
    repeat
        task.wait(0.2);
    until l__PlayerGui__4:WaitForChild("LoadingGui").Enabled == false;
    l__PlayerGui__4.ShopGui.StarterPack.Visible = true;
    script:Destroy();
    return;
end;
task.delay(300, function() --[[ Line: 46 ]]
    -- upvalues: l__LocalPlayer__3 (copy), u3 (ref), l__SetHasPromptedStarterPack__10 (copy), l__PlayerGui__4 (copy)
    local v4 = false;
    while true do
        task.wait(1);
        local l__Character__13 = l__LocalPlayer__3.Character;
        if l__Character__13 then
            local v5 = l__Character__13:FindFirstChild("Humanoid");
            if v5 then
                local v6 = l__Character__13:FindFirstChild("Head");
                if v6 then
                    v4 = u3 and not (v5.SeatPart or l__Character__13:FindFirstChildOfClass("Tool"));
                    if v4 then
                        v4 = v6.LocalTransparencyModifier < 0.95;
                    end;
                end;
            end;
        end;
        if v4 then
            l__SetHasPromptedStarterPack__10:FireServer(true);
            l__PlayerGui__4.ShopGui.StarterPack.Visible = true;
            script:Destroy();
            return;
        end;
    end;
end);
l__InvalidateStarterPack__8.OnClientEvent:Connect(function() --[[ Line: 69 ]]
    script:Destroy();
end);
while true do
    local v7;
    repeat
        task.wait(1);
        v7 = l__LocalPlayer__3.Character;
    until v7;
    local v8 = v7:FindFirstChild("HumanoidRootPart");
    if v8 then
        u3 = l__AreaModule__6(l__RootPart__12, v8);
    end;
end;