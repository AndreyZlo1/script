-- Roblox: Players.SilverAce293026.PlayerScripts.RbxCoreAdvertising
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__LocalPlayer__2 = game:GetService("Players").LocalPlayer;
local l__RobloxCoreAdvertising__3 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents"):WaitForChild("RobloxCoreAdvertising");
local function v4(p1) --[[ Line: 15 ]]
    -- upvalues: l__RobloxCoreAdvertising__3 (copy)
    local u2 = { "AlignPosition", "AlignOrientation", "BodyGyro" };
    p1.DescendantAdded:Connect(function(p3) --[[ Line: 22 ]]
        -- upvalues: u2 (copy), l__RobloxCoreAdvertising__3 (ref)
        if table.find(u2, p3.ClassName) then
            l__RobloxCoreAdvertising__3:FireServer("Floating");
        end;
    end);
    local l__Humanoid__4 = p1:WaitForChild("Humanoid");
    l__Humanoid__4.Changed:Connect(function() --[[ Line: 30 ]]
        -- upvalues: l__Humanoid__4 (copy), l__RobloxCoreAdvertising__3 (ref)
        if l__Humanoid__4.WalkSpeed >= 40 then
            l__RobloxCoreAdvertising__3:FireServer("Skip");
        end;
    end);
end;
l__LocalPlayer__2.CharacterAdded:Connect(v4);
if l__LocalPlayer__2.Character then
    v4(l__LocalPlayer__2.Character);
end;