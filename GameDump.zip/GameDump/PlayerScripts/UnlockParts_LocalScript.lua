-- Roblox: Players.SilverAce293026.PlayerScripts.UnlockParts
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Players__2 = game:GetService("Players");
local l__CollectionService__3 = game:GetService("CollectionService");
local l__QuestProgressGui__4 = l__Players__2.LocalPlayer.PlayerGui:WaitForChild("QuestProgressGui");
local l__ProgressModule__5 = require(l__QuestProgressGui__4:WaitForChild("ProgressModule"));
local l__PlayerEvents__6 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents");
local l__GetUnlockedParts__7 = l__PlayerEvents__6:WaitForChild("GetUnlockedParts");
local l__Modules__8 = l__ReplicatedStorage__1:WaitForChild("Modules");
local l__UnlockParts__9 = require(l__Modules__8:WaitForChild("UnlockParts"));
local u1 = {};
local l__ProxProto__10 = script:WaitForChild("ProxProto");
local function u8(p2) --[[ Line: 22 ]]
    -- upvalues: u1 (ref), l__UnlockParts__9 (copy), l__PlayerEvents__6 (copy), l__ProgressModule__5 (copy)
    local v3 = p2:GetAttribute("UnlockName");
    local v4 = p2:GetAttribute("PartIndex");
    local v5 = u1[v3];
    if not v5 then
        v5 = {};
        u1[v3] = v5;
    end;
    table.insert(v5, v4);
    p2.LocalTransparencyModifier = 1;
    if p2:FindFirstChild("ProxProto") then
        p2.ProxProto:Destroy();
    end;
    local v6 = {};
    for _, v7 in l__UnlockParts__9[v3] do
        v6[v7] = table.find(v5, v7) ~= nil;
    end;
    l__PlayerEvents__6.UnlockPartFound:FireServer(v3, v4);
    l__ProgressModule__5.ShowUI(v3, v4, v6);
end;
local function u13(u9) --[[ Line: 49 ]]
    -- upvalues: l__ProxProto__10 (copy), u8 (copy)
    if u9:FindFirstChild("UnlockProx") then
    else
        local v10 = u9:GetAttribute("UnlockName");
        local v11 = u9:GetAttribute("PartIndex");
        local v12 = l__ProxProto__10:Clone();
        v12.ObjectText = `{v10} - {v11} Part`;
        v12.ActionText = "Pick up";
        v12.HoldDuration = 3;
        v12.Parent = u9;
        v12.Triggered:Connect(function() --[[ Line: 60 ]]
            -- upvalues: u8 (ref), u9 (copy)
            u8(u9);
        end);
    end;
end;
local function u18(p14) --[[ Line: 65 ]]
    -- upvalues: u1 (ref), u13 (copy)
    local v15 = p14:GetAttribute("UnlockName");
    local v16 = p14:GetAttribute("PartIndex");
    local v17 = u1[v15];
    if v17 then
        if v17 == "Unlocked" or table.find(v17, v16) ~= nil then
            p14.LocalTransparencyModifier = 1;
            if p14:FindFirstChild("ProxProto") then
                p14.ProxProto.Enabled = false;
                p14.ProxProto:Destroy();
            end;
        else
            u13(p14);
        end;
    else
        u13(p14);
    end;
end;
local function v20() --[[ Line: 84 ]]
    -- upvalues: u1 (ref), l__GetUnlockedParts__7 (copy), l__CollectionService__3 (copy), u18 (copy)
    u1 = l__GetUnlockedParts__7:InvokeServer();
    print(u1);
    for _, v19 in l__CollectionService__3:GetTagged("UnlockPart") do
        u18(v19);
    end;
end;
l__CollectionService__3:GetInstanceAddedSignal("UnlockPart"):Connect(function(p21) --[[ Line: 93 ]]
    -- upvalues: u1 (ref), l__GetUnlockedParts__7 (copy), u18 (copy)
    if not u1 then
        u1 = l__GetUnlockedParts__7:InvokeServer();
    end;
    u18(p21);
end);
v20();