-- Roblox: Players.SilverAce293026.PlayerScripts.QuestClient.Construction
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
u1.__index = u1;
local l__StepTracker__1 = require(script.Parent:WaitForChild("StepTracker"));
setmetatable(u1, l__StepTracker__1);
game:GetService("Players");
local u2 = game:GetService("RunService"):IsServer();
function u1.new() --[[ Line: 10 ]]
    -- upvalues: l__StepTracker__1 (copy), u1 (copy)
    local v3 = l__StepTracker__1.new();
    setmetatable(v3, u1);
    return v3;
end;
function u1.Setup(u4, p5, p6) --[[ Line: 17 ]]
    -- upvalues: u2 (copy)
    local l__Value__2 = p6:WaitForChild("AssociatedTycoon").Value;
    local v7 = workspace:WaitForChild(l__Value__2);
    local l__Constructions__3 = v7:WaitForChild("Constructions");
    local l__Target__4 = p5.Goal.Target;
    local v8;
    if l__Constructions__3:FindFirstChild(l__Target__4) then
        u4:Complete();
        v8 = true;
    else
        v8 = false;
    end;
    if v8 then
    else
        local v10 = l__Constructions__3.ChildAdded:Connect(function(p9) --[[ Line: 37 ]]
            -- upvalues: l__Target__4 (copy), u4 (copy)
            if p9.Name == l__Target__4 then
                u4:Complete();
            end;
        end);
        table.insert(u4.Connections, v10);
        if not u2 then
            local v11 = v7.BuyButtons:FindFirstChild(l__Target__4);
            u4.ContextArrowModule.SetTarget(v11.ButtonPart);
        end;
    end;
end;
return u1;