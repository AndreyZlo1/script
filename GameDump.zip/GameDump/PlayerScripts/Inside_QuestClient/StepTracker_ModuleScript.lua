-- Roblox: Players.SilverAce293026.PlayerScripts.QuestClient.StepTracker
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
u1.__index = u1;
local l__Modules__1 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
local l__ContextArrowModule__2 = require(l__Modules__1:WaitForChild("ContextArrowModule"));
function u1.new() --[[ Line: 8 ]]
    -- upvalues: u1 (copy), l__ContextArrowModule__2 (copy)
    local v2 = {};
    setmetatable(v2, u1);
    function v2.OnStepComplete() --[[ Line: 12 ]] end;
    v2.Connections = {};
    v2.ContextArrowModule = l__ContextArrowModule__2;
    return v2;
end;
function u1.Dispose(p3) --[[ Line: 20 ]]
    for _, v4 in p3.Connections do
        v4:Disconnect();
    end;
    p3.Connections = {};
    p3.ContextArrowModule.Clear();
    if p3.OnCleanup then
        p3:OnCleanup();
    end;
end;
function u1.Setup(_, _) --[[ Line: 34 ]] end;
function u1.Complete(p5) --[[ Line: 38 ]]
    p5:Dispose();
    p5.OnStepComplete();
end;
return u1;