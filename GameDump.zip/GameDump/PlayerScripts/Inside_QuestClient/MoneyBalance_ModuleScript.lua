-- Roblox: Players.SilverAce293026.PlayerScripts.QuestClient.MoneyBalance
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local u1 = {};
u1.__index = u1;
local l__StepTracker__1 = require(script.Parent:WaitForChild("StepTracker"));
setmetatable(u1, l__StepTracker__1);
game:GetService("Players");
local u2 = game:GetService("RunService"):IsServer();
function u1.new() --[[ Line: 10 ]]
    -- upvalues: l__StepTracker__1 (copy), u1 (copy)
    local v3 = l__StepTracker__1.new();
    setmetatable(v3, u1);
    return v3;
end;
function u1.Setup(u4, p5, p6) --[[ Line: 17 ]]
    -- upvalues: u2 (copy)
    local l__Money__2 = p6.leaderstats.Money;
    local l__Target__3 = p5.Goal.Target;
    local function v7() --[[ Line: 22 ]]
        -- upvalues: l__Money__2 (copy), l__Target__3 (copy), u4 (copy)
        if l__Target__3 <= l__Money__2.Value then
            u4:Complete();
            return true;
        end;
    end;
    local v8;
    if l__Target__3 <= l__Money__2.Value then
        u4:Complete();
        v8 = true;
    else
        v8 = nil;
    end;
    if v8 then
    else
        local v9 = l__Money__2.Changed:Connect(v7);
        table.insert(u4.Connections, v9);
        if u2 then
        else
            if p5.Goal.ArrowToCollector then
                local l__Value__4 = p6:WaitForChild("AssociatedTycoon").Value;
                local l__CashCollectButton__5 = workspace:WaitForChild(l__Value__4):WaitForChild("CashGiver"):WaitForChild("CashCollectButton");
                u4.ContextArrowModule.SetTarget(l__CashCollectButton__5);
            end;
        end;
    end;
end;
return u1;