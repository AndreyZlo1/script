-- Roblox: Players.SilverAce293026.PlayerScripts.UIController_Local
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__UIController__2 = require(l__ReplicatedStorage__1:WaitForChild("Modules"):WaitForChild("UIController"));
l__UIController__2:InitializeUIModules();
l__UIController__2:OpenUI("MenuUI");