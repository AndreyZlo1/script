-- Roblox: Players.SilverAce293026.PlayerScripts.PromptPassPurchase
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__MarketplaceService__2 = game:GetService("MarketplaceService");
local l__Players__3 = game:GetService("Players");
local l__PromptPassPurchaseEvent__4 = l__ReplicatedStorage__1:WaitForChild("PromptPassPurchaseEvent");
function promptPassPurchase(p1)
    -- upvalues: l__MarketplaceService__2 (copy), l__Players__3 (copy)
    l__MarketplaceService__2:PromptGamePassPurchase(l__Players__3.LocalPlayer, p1);
end;
l__PromptPassPurchaseEvent__4.OnClientEvent:Connect(promptPassPurchase);