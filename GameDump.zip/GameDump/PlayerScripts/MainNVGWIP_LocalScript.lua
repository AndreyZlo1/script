-- Roblox: Players.SilverAce293026.PlayerScripts.MainNVGWIP
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__LocalPlayer__1 = game.Players.LocalPlayer;
local l__ContextActionService__2 = game:GetService("ContextActionService");
local l__TweenService__3 = game:GetService("TweenService");
local u1 = Instance.new("ColorCorrectionEffect");
u1.Parent = game.Lighting;
local l__ExposureCompensation__4 = game.Lighting.ExposureCompensation;
local u2 = nil;
local u3 = nil;
local u4 = nil;
local u5 = nil;
local u6 = nil;
local u7 = nil;
local u8 = nil;
local u9 = nil;
function removehelmet()
    -- upvalues: l__LocalPlayer__1 (copy), u7 (ref), l__ContextActionService__2 (copy), u4 (ref), u9 (ref)
    if l__LocalPlayer__1.Character then
        if u7 then
            u7:Disconnect();
        end;
        animating = false;
        togglenvg(false);
        l__ContextActionService__2:UnbindAction("nvgtoggle");
        if u4 then
            u4:Destroy();
        end;
        if u9 then
            u9:Destroy();
        end;
    end;
end;
function oncharadded(p10)
    -- upvalues: u9 (ref), u4 (ref), l__LocalPlayer__1 (copy), u7 (ref), u2 (ref), u6 (ref), u8 (ref), u3 (ref), u5 (ref), l__TweenService__3 (copy), u1 (copy), l__ExposureCompensation__4 (copy), l__ContextActionService__2 (copy)
    p10:WaitForChild("Humanoid").Died:connect(function() --[[ Line: 39 ]]
        removehelmet();
    end);
    p10.ChildAdded:connect(function(p11) --[[ Line: 42 ]]
        -- upvalues: u9 (ref), u4 (ref), l__LocalPlayer__1 (ref), u7 (ref), u2 (ref), u6 (ref), u8 (ref), u3 (ref), u5 (ref), l__TweenService__3 (ref), u1 (ref), l__ExposureCompensation__4 (ref), l__ContextActionService__2 (ref)
        local v12;
        if p11.Name == "Helmet" then
            u9 = p11;
            u4 = Instance.new("ScreenGui");
            u4.IgnoreGuiInset = true;
            v12 = Instance.new("TextButton");
            v12.Text = "Helmet";
            v12.Size = UDim2.new(0.05, 0, 0.035, 0);
            v12.TextColor3 = Color3.new(0.75, 0.75, 0.75);
            v12.Position = UDim2.new(0.1, 0, 0.3, 0);
            v12.BackgroundTransparency = 0.45;
            v12.BackgroundColor3 = Color3.fromRGB(124, 52, 38);
            v12.Font = Enum.Font.SourceSansBold;
            v12.TextScaled = true;
            v12.MouseButton1Down:connect(removehelmet);
            v12.Parent = u4;
            u4.Parent = l__LocalPlayer__1.PlayerGui;
            u7 = p11.AncestryChanged:Connect(function(_, p13) --[[ Line: 63 ]]
                if not p13 then
                    removehelmet();
                end;
            end);
        else
            v12 = nil;
        end;
        local l__Up__5 = p11:WaitForChild("Up", 0.5);
        if l__Up__5 then
            u2 = l__Up__5;
            u6 = require(u2:WaitForChild("AUTO_CONFIG"));
            u8 = u2:WaitForChild("NVG_Settings");
            local v14 = Instance.new("ImageLabel");
            v14.BackgroundTransparency = 1;
            v14.ImageTransparency = 1;
            local v15 = v14:Clone();
            v15.Image = "rbxassetid://" .. u8.OverlayImage.Value;
            v15.Size = UDim2.new(1, 0, 1, 0);
            v15.Name = "Overlay";
            local l__Value__6 = u8.RemoveButtonPosition.Value;
            v12.Position = UDim2.new(l__Value__6.X, 0, l__Value__6.Y, 0);
            v14.Name = "Noise";
            v14.AnchorPoint = Vector2.new(0.5, 0.5);
            v14.Position = UDim2.new(0.5, 0, 0.5, 0);
            v14.Size = UDim2.new(2, 0, 2, 0);
            v15.Parent = u4;
            v14.Parent = u4;
            local l__tweeninfo__7 = u6.tweeninfo;
            u3 = u6.onanim;
            u5 = u6.offanim;
            on_overlayanim = {
                l__TweenService__3:Create(game.Lighting, l__tweeninfo__7, {
                    ExposureCompensation = u8.Exposure.Value
                }),
                l__TweenService__3:Create(u1, l__tweeninfo__7, {
                    Contrast = 0.8,
                    Saturation = -1,
                    Brightness = u8.OverlayBrightness.Value,
                    TintColor = u8.OverlayColor.Value
                }),
                l__TweenService__3:Create(u4.Overlay, l__tweeninfo__7, {
                    ImageTransparency = 0
                }),
                l__TweenService__3:Create(u4.Noise, l__tweeninfo__7, {
                    ImageTransparency = 0
                })
            };
            off_overlayanim = {
                l__TweenService__3:Create(game.Lighting, l__tweeninfo__7, {
                    ExposureCompensation = l__ExposureCompensation__4
                }),
                l__TweenService__3:Create(u1, l__tweeninfo__7, {
                    Brightness = 0,
                    Contrast = 0,
                    Saturation = 0,
                    TintColor = Color3.fromRGB(255, 255, 255)
                }),
                l__TweenService__3:Create(u4.Overlay, l__tweeninfo__7, {
                    ImageTransparency = 1
                }),
                l__TweenService__3:Create(u4.Noise, l__tweeninfo__7, {
                    ImageTransparency = 1
                })
            };
            l__ContextActionService__2:BindAction("nvgtoggle", function() --[[ Line: 127 ]]
                togglenvg(not nvgactive);
                return Enum.ContextActionResult.Pass;
            end, true, Enum.KeyCode.N);
        end;
    end);
end;
l__LocalPlayer__1.CharacterAdded:connect(oncharadded);
local v16 = workspace:FindFirstChild(l__LocalPlayer__1.Name);
if v16 then
    oncharadded(v16);
end;
function playtween(u17)
    spawn(function() --[[ Line: 142 ]]
        -- upvalues: u17 (copy)
        for _, v18 in pairs(u17) do
            if typeof(v18) == "number" then
                wait(v18);
            else
                v18:Play();
            end;
        end;
    end);
end;
function applyprops(p19, p20)
    for v21, v22 in pairs(p20) do
        p19[v21] = v22;
    end;
end;
function cycle(p23)
    -- upvalues: u4 (ref)
    local l__Noise__8 = u4.Noise;
    local l__src__9 = p23.src;
    local v24;
    repeat
        v24 = l__src__9[math.random(1, #l__src__9)];
    until v24 ~= p23.last;
    l__Noise__8.Image = "rbxassetid://" .. v24;
    local v25 = math.random(230, 255);
    l__Noise__8.Position = UDim2.new(math.random(0.4, 0.6), 0, math.random(0.4, 0.6), 0);
    l__Noise__8.ImageColor3 = Color3.fromRGB(v25, v25, v25);
    p23.last = v24;
end;
function togglenvg(p26)
    -- upvalues: u2 (ref), u4 (ref), u6 (ref), u3 (ref), u5 (ref)
    print("Breakpoint 1");
    if not animating and u2 then
        u4.TextButton.Visible = not p26;
        animating = true;
        nvgactive = p26;
        if u6.lens then
            u6.lens.Material = p26 and "Neon" or "Glass";
        end;
        print("Breakpoint 2");
        if p26 then
            print("Breakpoint 3");
            playtween(u3);
            delay(0.75, function() --[[ Line: 189 ]]
                -- upvalues: u6 (ref)
                playtween(on_overlayanim);
                spawn(function() --[[ Line: 191 ]]
                    -- upvalues: u6 (ref)
                    while nvgactive do
                        cycle(u6.dark);
                        cycle(u6.light);
                        wait(0.05);
                    end;
                end);
                animating = false;
            end);
            return;
        end;
        print("Breakpoint off");
        playtween(u5);
        delay(0.5, function() --[[ Line: 203 ]]
            print("Breakpoint off 2");
            playtween(off_overlayanim);
            animating = false;
        end);
    end;
end;