-- Roblox: Players.SilverAce293026.PlayerScripts.RbxCharacterSounds
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Players__1 = game:GetService("Players");
local l__RunService__2 = game:GetService("RunService");
local l__Footsteps__3 = game:GetService("SoundService"):WaitForChild("Footsteps");
local _ = game.Players.LocalPlayer.Character;
local u1 = {
    Climbing = {
        SoundId = "rbxasset://sounds/action_footsteps_plastic.mp3",
        Looped = true
    },
    Died = {
        SoundId = "rbxasset://sounds/uuhhh.mp3"
    },
    FreeFalling = {
        SoundId = "rbxasset://sounds/action_falling.mp3",
        Looped = true
    },
    GettingUp = {
        SoundId = "rbxasset://sounds/action_get_up.mp3"
    },
    Jumping = {
        SoundId = "rbxasset://sounds/action_jump.mp3"
    },
    Landing = {
        SoundId = "rbxasset://sounds/action_jump_land.mp3"
    },
    Running = {
        SoundId = "",
        Looped = true,
        Playing = true,
        Pitch = 1
    },
    Splash = {
        SoundId = "rbxasset://sounds/impact_water.mp3"
    },
    Swimming = {
        SoundId = "rbxasset://sounds/action_swim.mp3",
        Looped = true,
        Pitch = 1.6
    }
};
local function u7(...) --[[ Line: 50 ]]
    local u2 = Instance.new("BindableEvent");
    local u3 = { ... };
    local function v5(...) --[[ Line: 54 ]]
        -- upvalues: u3 (copy), u2 (copy)
        for v4 = 1, #u3 do
            u3[v4]:Disconnect();
        end;
        return u2:Fire(...);
    end;
    for v6 = 1, #u3 do
        u3[v6] = u3[v6]:Connect(v5);
    end;
    return u2.Event:Wait();
end;
local function u61(p8, u9, u10) --[[ Line: 84 ]]
    -- upvalues: u1 (copy), l__Footsteps__3 (copy), l__Players__1 (copy), l__RunService__2 (copy)
    local u11 = {};
    local u12 = false;
    for v13, v14 in pairs(u1) do
        local v15 = Instance.new("Sound");
        v15.Name = v13;
        v15.Archivable = false;
        v15.EmitterSize = 5;
        v15.MaxDistance = 150;
        v15.Volume = 0.65;
        for v16, v17 in pairs(v14) do
            v15[v16] = v17;
        end;
        v15.Parent = u10;
        u11[v13] = v15;
    end;
    local u18 = {};
    local u22 = u9:WaitForChild("Animator").AnimationPlayed:Connect(function(p19) --[[ Name: checkForSlideTrack, Line 118 ]]
        -- upvalues: u12 (ref)
        if p19.Name == "SlideAnim" then
            u12 = true;
            local u20 = nil;
            local u21 = false;
            u20 = p19.Ended:Connect(function() --[[ Line: 132 ]]
                -- upvalues: u21 (ref), u20 (ref), u12 (ref)
                u21 = true;
                u20:Disconnect();
                u20 = nil;
                u12 = false;
            end);
            task.delay(10, function() --[[ Line: 136 ]]
                -- upvalues: u21 (ref), u20 (ref), u12 (ref)
                if u21 then
                else
                    u21 = true;
                    u20:Disconnect();
                    u20 = nil;
                    u12 = false;
                end;
            end);
        end;
    end);
    local u36 = {
        [Enum.HumanoidStateType.FallingDown] = function() --[[ Line: 147 ]]
            -- upvalues: u18 (copy)
            for v23 in pairs(u18) do
                if v23 ~= nil then
                    v23.Playing = false;
                    u18[v23] = nil;
                end;
            end;
        end,
        [Enum.HumanoidStateType.GettingUp] = function() --[[ Line: 151 ]]
            -- upvalues: u18 (copy), u11 (copy)
            for v24 in pairs(u18) do
                if v24 ~= nil then
                    v24.Playing = false;
                    u18[v24] = nil;
                end;
            end;
            local l__GettingUp__4 = u11.GettingUp;
            l__GettingUp__4.TimePosition = 0;
            l__GettingUp__4.Playing = true;
        end,
        [Enum.HumanoidStateType.Jumping] = function() --[[ Line: 156 ]]
            -- upvalues: u18 (copy), u11 (copy)
            for v25 in pairs(u18) do
                if v25 ~= nil then
                    v25.Playing = false;
                    u18[v25] = nil;
                end;
            end;
            local l__Jumping__5 = u11.Jumping;
            l__Jumping__5.TimePosition = 0;
            l__Jumping__5.Playing = true;
        end,
        [Enum.HumanoidStateType.Swimming] = function() --[[ Line: 161 ]]
            -- upvalues: u10 (copy), u11 (copy), u18 (copy)
            local v26 = math.abs(u10.Velocity.Y);
            if v26 > 0.1 then
                u11.Splash.Volume = math.clamp((v26 - 100) * 0.72 / 250 + 0.28, 0, 1);
                local l__Splash__6 = u11.Splash;
                l__Splash__6.TimePosition = 0;
                l__Splash__6.Playing = true;
            end;
            local l__Swimming__7 = u11.Swimming;
            for v27 in pairs(u18) do
                if v27 ~= l__Swimming__7 then
                    v27.Playing = false;
                    u18[v27] = nil;
                end;
            end;
            u11.Swimming.Playing = true;
            u18[u11.Swimming] = true;
        end,
        [Enum.HumanoidStateType.Freefall] = function() --[[ Line: 172 ]]
            -- upvalues: u11 (copy), u18 (copy)
            u11.FreeFalling.Volume = 0;
            local l__FreeFalling__8 = u11.FreeFalling;
            for v28 in pairs(u18) do
                if v28 ~= l__FreeFalling__8 then
                    v28.Playing = false;
                    u18[v28] = nil;
                end;
            end;
            u18[u11.FreeFalling] = true;
        end,
        [Enum.HumanoidStateType.Landed] = function() --[[ Line: 178 ]]
            -- upvalues: u18 (copy), u10 (copy), u11 (copy)
            for v29 in pairs(u18) do
                if v29 ~= nil then
                    v29.Playing = false;
                    u18[v29] = nil;
                end;
            end;
            local v30 = math.abs(u10.Velocity.Y);
            if v30 > 75 then
                u11.Landing.Volume = math.clamp((v30 - 50) * 1 / 50 + 0, 0, 1);
                local l__Landing__9 = u11.Landing;
                l__Landing__9.TimePosition = 0;
                l__Landing__9.Playing = true;
            end;
        end,
        [Enum.HumanoidStateType.Running] = function() --[[ Line: 187 ]]
            -- upvalues: u11 (copy), u18 (copy)
            local l__Running__10 = u11.Running;
            for v31 in pairs(u18) do
                if v31 ~= l__Running__10 then
                    v31.Playing = false;
                    u18[v31] = nil;
                end;
            end;
            u11.Running.Playing = true;
            u18[u11.Running] = true;
        end,
        [Enum.HumanoidStateType.Climbing] = function() --[[ Line: 193 ]]
            -- upvalues: u11 (copy), u10 (copy), u18 (copy)
            local l__Climbing__11 = u11.Climbing;
            if math.abs(u10.Velocity.Y) > 0.1 then
                l__Climbing__11.Playing = true;
                for v32 in pairs(u18) do
                    if v32 ~= l__Climbing__11 then
                        v32.Playing = false;
                        u18[v32] = nil;
                    end;
                end;
            else
                for v33 in pairs(u18) do
                    if v33 ~= nil then
                        v33.Playing = false;
                        u18[v33] = nil;
                    end;
                end;
            end;
            u18[l__Climbing__11] = true;
        end,
        [Enum.HumanoidStateType.Seated] = function() --[[ Line: 204 ]]
            -- upvalues: u18 (copy)
            for v34 in pairs(u18) do
                if v34 ~= nil then
                    v34.Playing = false;
                    u18[v34] = nil;
                end;
            end;
        end,
        [Enum.HumanoidStateType.Dead] = function() --[[ Line: 208 ]]
            -- upvalues: u18 (copy), u11 (copy)
            for v35 in pairs(u18) do
                if v35 ~= nil then
                    v35.Playing = false;
                    u18[v35] = nil;
                end;
            end;
            local l__Died__12 = u11.Died;
            l__Died__12.TimePosition = 0;
            l__Died__12.Playing = true;
        end
    };
    local u44 = {
        [u11.Climbing] = function(_, p37, p38) --[[ Line: 216 ]]
            p37.Playing = p38.Magnitude > 0.1;
        end,
        [u11.FreeFalling] = function(p39, p40, p41) --[[ Line: 220 ]]
            if p41.Magnitude > 75 then
                p40.Volume = math.clamp(p40.Volume + 0.9 * p39, 0, 1);
            else
                p40.Volume = 0;
            end;
        end,
        [u11.Running] = function(_, p42, p43) --[[ Line: 228 ]]
            -- upvalues: l__Footsteps__3 (ref), u9 (copy), u12 (ref), l__Players__1 (ref)
            p42.SoundId = l__Footsteps__3:WaitForChild(u9.FloorMaterial.Name).SoundId;
            p42.PlaybackSpeed = l__Footsteps__3:WaitForChild(u9.FloorMaterial.Name).PlaybackSpeed * (p43.Magnitude / 20);
            p42.Volume = u12 and 0 or l__Footsteps__3:WaitForChild(u9.FloorMaterial.Name).Volume * (p43.Magnitude / 12) * l__Players__1.LocalPlayer.Character:WaitForChild("ACS_Client"):WaitForChild("Stances"):WaitForChild("Loudness").Value;
            p42.EmitterSize = l__Footsteps__3:WaitForChild(u9.FloorMaterial.Name).Volume * (p43.Magnitude / 12) * 50 * l__Players__1.LocalPlayer.Character:WaitForChild("ACS_Client"):WaitForChild("Stances"):WaitForChild("Loudness").Value;
            if l__Footsteps__3:FindFirstChild(u9.FloorMaterial.Name) == nil then
                p42.SoundId = l__Footsteps__3:WaitForChild("nil Sound").SoundId;
                p42.PlaybackSpeed = l__Footsteps__3:WaitForChild("nil Sound").PlaybackSpeed;
                p42.EmitterSize = l__Footsteps__3:WaitForChild("nil Sound").Volume;
                p42.Volume = u12 and 0 or l__Footsteps__3:WaitForChild("nil Sound").Volume;
            end;
        end
    };
    local u45 = {
        [Enum.HumanoidStateType.RunningNoPhysics] = Enum.HumanoidStateType.Running
    };
    local u46 = u45[u9:GetState()] or u9:GetState();
    local u50 = u9.StateChanged:Connect(function(_, p47) --[[ Line: 253 ]]
        -- upvalues: u45 (copy), u46 (ref), u36 (copy)
        local v48 = u45[p47] or p47;
        if v48 ~= u46 then
            local v49 = u36[v48];
            if v49 then
                v49();
            end;
            u46 = v48;
        end;
    end);
    local u54 = l__RunService__2.Stepped:Connect(function(_, p51) --[[ Line: 267 ]]
        -- upvalues: u18 (copy), u44 (copy), u10 (copy)
        for v52 in pairs(u18) do
            local v53 = u44[v52];
            if v53 then
                v53(p51, v52, u10.Velocity);
            end;
        end;
    end);
    local u55 = nil;
    local u56 = nil;
    local u57 = nil;
    local function v58() --[[ Line: 282 ]]
        -- upvalues: u50 (copy), u54 (copy), u55 (ref), u56 (ref), u57 (ref), u22 (copy)
        u50:Disconnect();
        u54:Disconnect();
        u55:Disconnect();
        u56:Disconnect();
        u57:Disconnect();
        u22:Disconnect();
    end;
    u55 = u9.AncestryChanged:Connect(function(_, p59) --[[ Line: 291 ]]
        -- upvalues: u50 (copy), u54 (copy), u55 (ref), u56 (ref), u57 (ref), u22 (copy)
        if not p59 then
            u50:Disconnect();
            u54:Disconnect();
            u55:Disconnect();
            u56:Disconnect();
            u57:Disconnect();
            u22:Disconnect();
        end;
    end);
    u56 = u10.AncestryChanged:Connect(function(_, p60) --[[ Line: 297 ]]
        -- upvalues: u50 (copy), u54 (copy), u55 (ref), u56 (ref), u57 (ref), u22 (copy)
        if not p60 then
            u50:Disconnect();
            u54:Disconnect();
            u55:Disconnect();
            u56:Disconnect();
            u57:Disconnect();
            u22:Disconnect();
        end;
    end);
    u57 = p8.CharacterAdded:Connect(v58);
end;
l__Players__1.PlayerAdded:Connect(function(u62) --[[ Name: playerAdded, Line 306 ]]
    -- upvalues: u7 (copy), u61 (copy)
    local function v66(p63) --[[ Line: 307 ]]
        -- upvalues: u7 (ref), u62 (copy), u61 (ref)
        if not p63.Parent then
            u7(p63.AncestryChanged, u62.CharacterAdded);
        end;
        if u62.Character == p63 and p63.Parent then
            local v64 = p63:FindFirstChildOfClass("Humanoid");
            while p63:IsDescendantOf(game) and not v64 do
                u7(p63.ChildAdded, p63.AncestryChanged, u62.CharacterAdded);
                v64 = p63:FindFirstChildOfClass("Humanoid");
            end;
            if u62.Character == p63 and p63:IsDescendantOf(game) then
                local v65 = p63:FindFirstChild("HumanoidRootPart");
                while p63:IsDescendantOf(game) and not v65 do
                    u7(p63.ChildAdded, p63.AncestryChanged, v64.AncestryChanged, u62.CharacterAdded);
                    v65 = p63:FindFirstChild("HumanoidRootPart");
                end;
                if v65 and (v64:IsDescendantOf(game) and (p63:IsDescendantOf(game) and u62.Character == p63)) then
                    u61(u62, v64, v65);
                end;
            end;
        end;
    end;
    if u62.Character then
        v66(u62.Character);
    end;
    u62.CharacterAdded:Connect(v66);
end);
for _, u67 in ipairs(l__Players__1:GetPlayers()) do
    local function v71(p68) --[[ Line: 307 ]]
        -- upvalues: u7 (copy), u67 (copy), u61 (copy)
        if not p68.Parent then
            u7(p68.AncestryChanged, u67.CharacterAdded);
        end;
        if u67.Character == p68 and p68.Parent then
            local v69 = p68:FindFirstChildOfClass("Humanoid");
            while p68:IsDescendantOf(game) and not v69 do
                u7(p68.ChildAdded, p68.AncestryChanged, u67.CharacterAdded);
                v69 = p68:FindFirstChildOfClass("Humanoid");
            end;
            if u67.Character == p68 and p68:IsDescendantOf(game) then
                local v70 = p68:FindFirstChild("HumanoidRootPart");
                while p68:IsDescendantOf(game) and not v70 do
                    u7(p68.ChildAdded, p68.AncestryChanged, v69.AncestryChanged, u67.CharacterAdded);
                    v70 = p68:FindFirstChild("HumanoidRootPart");
                end;
                if v70 and (v69:IsDescendantOf(game) and (p68:IsDescendantOf(game) and u67.Character == p68)) then
                    u61(u67, v69, v70);
                end;
            end;
        end;
    end;
    if u67.Character then
        v71(u67.Character);
    end;
    u67.CharacterAdded:Connect(v71);
end;
repeat
    task.wait();
until l__Players__1.LocalPlayer.Character;
local l__Character__13 = l__Players__1.LocalPlayer.Character;
local l__Running__14 = l__Character__13:WaitForChild("HumanoidRootPart"):WaitForChild("Running");
local l__Humanoid__15 = l__Character__13:WaitForChild("Humanoid");
local u72 = 0;
l__Humanoid__15.Changed:Connect(function(_) --[[ Line: 369 ]] end);
l__Humanoid__15.Running:connect(function(p73) --[[ Line: 373 ]]
    -- upvalues: l__Running__14 (copy), l__Footsteps__3 (copy), l__Humanoid__15 (copy), u72 (ref)
    l__Running__14.PlaybackSpeed = l__Footsteps__3:WaitForChild(l__Humanoid__15.FloorMaterial.Name).PlaybackSpeed * (p73 / 16) * (math.random(30, 50) / 40);
    l__Running__14.Volume = l__Footsteps__3:WaitForChild(l__Humanoid__15.FloorMaterial.Name).Volume * (u72 / 12);
    l__Running__14.EmitterSize = l__Footsteps__3:WaitForChild(l__Humanoid__15.FloorMaterial.Name).Volume * (u72 / 12) * 50;
    u72 = p73;
end);