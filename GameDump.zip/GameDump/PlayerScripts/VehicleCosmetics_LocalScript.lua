-- Roblox: Players.SilverAce293026.PlayerScripts.VehicleCosmetics
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

game:GetService("TweenService");
local l__RunService__1 = game:GetService("RunService");
local l__ReplicatedStorage__2 = game:GetService("ReplicatedStorage");
local l__Players__3 = game:GetService("Players");
local l__Vehicles__4 = l__ReplicatedStorage__2:WaitForChild("Vehicles");
local l__WheelSmoke__5 = l__ReplicatedStorage__2:WaitForChild("VFX"):WaitForChild("VehicleCosmetic"):WaitForChild("WheelSmoke");
local l__Modules__6 = l__ReplicatedStorage__2:WaitForChild("Modules");
local u1 = {};
local function v16(p2) --[[ Line: 18 ]]
    -- upvalues: l__Vehicles__4 (copy), l__WheelSmoke__5 (copy), u1 (copy)
    if p2:IsA("Model") then
        if l__Vehicles__4:FindFirstChild(p2.Name) then
            local v3 = p2:FindFirstChild("Wheels");
            if v3 then
                local v4 = {};
                for _, v5 in v3:GetChildren() do
                    local v6 = 1;
                    local v7 = nil;
                    while v5:FindFirstChild("Wheel" .. v6) do
                        v7 = v5["Wheel" .. v6];
                        table.insert(v4, v7);
                        v6 = v6 + 1;
                    end;
                    if not v7 then
                        return;
                    end;
                end;
                local v8 = {};
                local v9 = {};
                for _, v10 in v4 do
                    local v11 = Instance.new("Attachment");
                    v11.Name = "VFXAttach";
                    v11.Parent = p2.PrimaryPart;
                    v11.WorldPosition = v10.Position + Vector3.new(0, -v10.Size.Y / 2, 0);
                    local v12 = l__WheelSmoke__5:Clone();
                    v12.Parent = v11;
                    v12.Enabled = true;
                    v12.Rate = 0;
                    table.insert(v8, v12);
                    table.insert(v9, v10);
                end;
                local v13 = RaycastParams.new();
                v13.FilterDescendantsInstances = { p2 };
                v13.FilterType = Enum.RaycastFilterType.Exclude;
                local u14 = {
                    Vehicle = p2,
                    Emitters = v8,
                    Params = v13,
                    Wheels = v9
                };
                table.insert(u1, u14);
                p2.Destroying:Connect(function() --[[ Line: 80 ]]
                    -- upvalues: u1 (ref), u14 (copy)
                    local v15 = table.find(u1, u14);
                    if v15 then
                        table.remove(u1, v15);
                    end;
                end);
            end;
        end;
    end;
end;
for _, v17 in require(l__Modules__6:WaitForChild("VehicleModule")).TycoonVehicleFolders do
    v17.ChildAdded:Connect(v16);
    for _, v18 in v17:GetChildren() do
        v16(v18);
    end;
end;
local function u24() --[[ Line: 94 ]]
    -- upvalues: l__Players__3 (copy), u1 (copy)
    local l__Character__7 = l__Players__3.LocalPlayer.Character;
    if l__Character__7 then
        local l__PrimaryPart__8 = l__Character__7.PrimaryPart;
        if l__PrimaryPart__8 then
            for _, v19 in u1 do
                if v19.Vehicle then
                    local l__PrimaryPart__9 = v19.Vehicle.PrimaryPart;
                    if l__PrimaryPart__9 then
                        if (l__PrimaryPart__9.Position - l__PrimaryPart__8.Position).Magnitude > 100 then
                            for _, v20 in v19.Emitters do
                                v20.Enabled = false;
                            end;
                        else
                            local l__Magnitude__10 = l__PrimaryPart__9.AssemblyLinearVelocity.Magnitude;
                            for v21, v22 in v19.Emitters do
                                local v23 = workspace:Raycast(v19.Wheels[v21].Position, Vector3.new(0, -3, 0), v19.Params);
                                v22.Enabled = v23;
                                if v23 then
                                    local _ = v23.Instance.Material;
                                    l__Magnitude__10 = l__Magnitude__10 < 3 and 0 or l__Magnitude__10;
                                    v22.Rate = math.floor(l__Magnitude__10);
                                end;
                            end;
                        end;
                    end;
                end;
            end;
        end;
    end;
end;
l__RunService__1.Heartbeat:Connect(function() --[[ Line: 128 ]]
    -- upvalues: u24 (copy)
    local v25, v26 = pcall(u24);
    if not v25 then
        warn(v26);
    end;
end);