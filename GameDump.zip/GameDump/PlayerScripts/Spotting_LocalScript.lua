-- Roblox: Players.SilverAce293026.PlayerScripts.Spotting
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__RunService__2 = game:GetService("RunService");
local l__Players__3 = game:GetService("Players");
if require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig")).Mode == "Deathmatch" then
else
    local l__LocalPlayer__4 = l__Players__3.LocalPlayer;
    local u1 = {};
    local u2 = Instance.new("ScreenGui");
    u2.Name = "SpottingUISizingUtil";
    u2.Parent = l__LocalPlayer__4:WaitForChild("PlayerGui");
    local u3 = RaycastParams.new();
    u3.FilterType = Enum.RaycastFilterType.Exclude;
    u3.CollisionGroup = "CamCast";
    local u4 = {};
    local function u21() --[[ Line: 24 ]]
        -- upvalues: l__LocalPlayer__4 (copy), u3 (copy), u2 (copy), u4 (copy), l__Players__3 (copy), l__ReplicatedStorage__1 (copy)
        local l__CurrentCamera__5 = workspace.CurrentCamera;
        local l__Character__6 = l__LocalPlayer__4.Character;
        if not l__Character__6 then
            return;
        end;
        local v5 = l__Character__6:FindFirstChild("Humanoid");
        if not v5 then
            return;
        end;
        if v5.Health < 1 then
            return;
        end;
        u3.FilterDescendantsInstances = { l__LocalPlayer__4.Character, l__CurrentCamera__5 };
        local l__AbsoluteSize__7 = u2.AbsoluteSize;
        local v6 = l__AbsoluteSize__7 / 2;
        local v7 = 7 / 200;
        local v8 = l__AbsoluteSize__7.X * v7;
        local v9 = l__AbsoluteSize__7.Y * v7;
        local v10 = {
            X = v6.X - v8,
            Y = v6.Y - v9
        };
        local v11 = {
            X = v6.X + v8,
            Y = v6.Y + v9
        };
        for _, v12 in u4 do
            local v13 = l__Players__3:GetPlayerFromCharacter(v12);
            if v13 and v13.Team ~= l__LocalPlayer__4.Team then
                local l__PrimaryPart__8 = v12.PrimaryPart;
                if l__PrimaryPart__8 then
                    local _, _ = l__CurrentCamera__5:WorldToScreenPoint(l__PrimaryPart__8.Position);
                    local v14 = false;
                    for _, v15 in v12:GetChildren() do
                        if v15:IsA("BasePart") then
                            local v16 = l__CurrentCamera__5:WorldToScreenPoint(v15.Position);
                            local v17 = Vector2.new(v16.X, v16.Y);
                            if v17.X > v10.X and (v17.Y > v10.Y and (v17.X < v11.X and v17.Y < v11.Y)) then
                                v14 = true;
                                break;
                            end;
                        end;
                    end;
                    if v14 and (l__PrimaryPart__8.Position - l__CurrentCamera__5.CFrame.Position).Magnitude < 1000 then
                        local l__Position__9 = l__CurrentCamera__5.CFrame.Position;
                        local v18 = workspace:Raycast(l__Position__9, (l__PrimaryPart__8.Position - l__Position__9).Unit * 1000, u3);
                        if not v18 or (not v18.Instance or v18.Instance:IsDescendantOf(v12)) then
                            local v19 = (v13:GetAttribute("SpotExpiry") or 0) - os.time();
                            local v20 = math.max(0, v19);
                            if not v13:GetAttribute("Spotted") or v20 <= 2 then
                                l__ReplicatedStorage__1.PlayerEvents.SpotPlayer:FireServer(v13);
                            end;
                        end;
                    end;
                end;
            end;
        end;
    end;
    local function v24(p22) --[[ Line: 104 ]]
        -- upvalues: l__LocalPlayer__4 (copy), u1 (copy), u4 (copy)
        if p22 == l__LocalPlayer__4 then
        else
            u1[p22] = {
                Connections = {},
                Objects = {}
            };
            p22.CharacterAdded:Connect(function(u23) --[[ Name: onNewCharacter, Line 108 ]]
                -- upvalues: u4 (ref)
                table.insert(u4, u23);
                u23.Destroying:Connect(function() --[[ Line: 110 ]]
                    -- upvalues: u4 (ref), u23 (copy)
                    if table.find(u4, u23) then
                        table.remove(u4, u23);
                    end;
                end);
            end);
            local l__Character__10 = p22.Character;
            if l__Character__10 then
                table.insert(u4, l__Character__10);
                l__Character__10.Destroying:Connect(function() --[[ Line: 110 ]]
                    -- upvalues: u4 (ref), l__Character__10 (copy)
                    if table.find(u4, l__Character__10) then
                        table.remove(u4, l__Character__10);
                    end;
                end);
            end;
        end;
    end;
    local u25 = 0;
    l__RunService__2.RenderStepped:Connect(function(p26) --[[ Line: 140 ]]
        -- upvalues: u25 (ref), u21 (copy)
        u25 = u25 + p26;
        if u25 >= 0.3 then
            u25 = 0;
            local v27, v28 = pcall(u21);
            if not v27 then
                warn(v28);
            end;
        end;
    end);
    l__Players__3.PlayerAdded:Connect(v24);
    l__Players__3.PlayerRemoving:Connect(function(p29) --[[ Name: ProcessLeavingPlayer, Line 124 ]]
        -- upvalues: u1 (copy)
        if u1[p29] then
            local u30 = u1[p29];
            pcall(function() --[[ Line: 127 ]]
                -- upvalues: u30 (copy)
                for _, v31 in u30.Connections do
                    v31:Disconnect();
                end;
                for _, v32 in u30.Objects do
                    v32:Destroy();
                end;
            end);
            u1[p29] = nil;
        end;
    end);
    for _, v33 in l__Players__3:GetChildren() do
        v24(v33);
    end;
end;