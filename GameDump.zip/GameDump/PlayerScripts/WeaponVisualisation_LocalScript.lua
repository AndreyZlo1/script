-- Roblox: Players.SilverAce293026.PlayerScripts.WeaponVisualisation
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__ReplicatedConfig__2 = require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig"));
if l__ReplicatedConfig__2.FeatureToggles.WeaponVisualisation then
    local u1 = l__ReplicatedConfig__2.Mode ~= "GroundWar";
    local l__Players__3 = game:GetService("Players");
    local l__ACS_Engine__4 = l__ReplicatedStorage__1:WaitForChild("ACS_Engine");
    local l__GunModels__5 = l__ACS_Engine__4:WaitForChild("GunModels");
    local l__AttachmentsUtil__6 = require(l__ACS_Engine__4:WaitForChild("Modules"):WaitForChild("AttachmentsUtil"));
    local l__LocalPlayer__7 = l__Players__3.LocalPlayer;
    local u2 = {};
    local function u6(p3) --[[ Line: 18 ]]
        for _, v4 in p3:GetDescendants() do
            if v4:IsA("BasePart") then
                v4.Anchored = false;
                v4.CanCollide = false;
                v4.CanTouch = false;
                v4.CanQuery = false;
                v4.Massless = true;
                if v4.Name ~= "Handle" then
                    local v5 = Instance.new("WeldConstraint", p3.Handle);
                    v5.Part0 = p3.Handle;
                    v5.Part1 = v4;
                end;
            end;
        end;
    end;
    local u7 = {
        Primary = CFrame.new(-0.7, 0.1, 0) * CFrame.Angles(0, 4.71238898038469, -0.8726646259971648),
        Primary2 = CFrame.new(0.6, -0.5, 0.2) * CFrame.Angles(0, -1.5707963267948966, 1.5707963267948966),
        Secondary = CFrame.new(-1.1, 0, 0) * CFrame.Angles(1.5707963267948966, 0.08726646259971647, 0)
    };
    local u8 = {};
    local function u58(u9, p10) --[[ Line: 58 ]]
        -- upvalues: u1 (copy), l__LocalPlayer__7 (copy), u8 (copy), u7 (copy), u2 (copy), l__GunModels__5 (copy), u6 (copy), l__AttachmentsUtil__6 (copy)
        if u1 or u9 == l__LocalPlayer__7 then
            for _, v11 in u8[u9].character do
                v11:Disconnect();
            end;
            u8[u9].character = {};
            local u12 = Instance.new("Folder", p10);
            u12.Name = "WepVisualisation";
            if p10:WaitForChild("HumanoidRootPart", 10) then
                local l__UpperTorso__8 = p10:WaitForChild("UpperTorso", 10);
                if l__UpperTorso__8 then
                    local l__LowerTorso__9 = p10:WaitForChild("LowerTorso", 10);
                    if l__LowerTorso__9 then
                        local u13 = {
                            customization = {}
                        };
                        local l__Backpack__10 = u9:WaitForChild("Backpack");
                        local function u43(p14, p15) --[[ Line: 92 ]]
                            -- upvalues: u7 (ref), u2 (ref), l__GunModels__5 (ref), u6 (ref), u12 (copy), l__LowerTorso__9 (copy), l__UpperTorso__8 (copy), u9 (copy), l__AttachmentsUtil__6 (ref), u13 (ref)
                            if not u7[p15] then
                                return;
                            end;
                            local l__Name__11 = p14.Name;
                            local u16, v17, v18, u19, u20;
                            if not u2[l__Name__11] then
                                local v21 = l__GunModels__5:WaitForChild(l__Name__11, 10);
                                if not v21 then
                                    u16 = nil;
                                    if u16 then
                                        u16.Parent = u12;
                                        v17 = Instance.new("Motor6D", u16.Handle);
                                        v17.Part0 = u16.Handle;
                                        v17.Part1 = p15 == "Secondary" and l__LowerTorso__9 or l__UpperTorso__8;
                                        v17.C0 = u7[p15] or CFrame.new();
                                        v18 = u9.StarterGear:WaitForChild(p14.Name, 30);
                                        if v18 then
                                            u19 = v18:WaitForChild("Customization", 30);
                                            u20 = function() --[[ Name: processAttachments, Line 112 ]]
                                                -- upvalues: u19 (copy), l__AttachmentsUtil__6 (ref), u16 (copy)
                                                local v33 = {};
                                                for v34, v35 in u19:GetAttributes() do
                                                    if v34 ~= "Camo" then
                                                        table.insert(v33, v35);
                                                    end;
                                                end;
                                                local v36 = {};
                                                for _, v37 in v33 do
                                                    local v38 = l__AttachmentsUtil__6.getAttDataFromHash(v37);
                                                    if v38 then
                                                        table.insert(v36, v38);
                                                    end;
                                                end;
                                                l__AttachmentsUtil__6.loadAttachments(u16, v36);
                                                local v39 = u16:FindFirstChild("SightMark", true);
                                                local v40 = v39 and v39:FindFirstChildOfClass("SurfaceGui");
                                                if v40 then
                                                    v40.Enabled = false;
                                                end;
                                                for _, v41 in u16:GetDescendants() do
                                                    if v41:IsA("Decal") then
                                                        v41:Destroy();
                                                    end;
                                                end;
                                            end;
                                            if u19 and not u13.customization[p14] then
                                                u20();
                                                u13.customization[p14] = u19.Changed:Connect(function() --[[ Line: 145 ]]
                                                    -- upvalues: u16 (copy), u20 (copy)
                                                    for _, v42 in u16:GetChildren() do
                                                        if v42:GetAttribute("Category") then
                                                            v42:Destroy();
                                                        end;
                                                    end;
                                                    u20();
                                                end);
                                            end;
                                            return;
                                        else
                                            return;
                                        end;
                                    else
                                        warn("Failed to create visualisation for weapon", p14.Name);
                                        return;
                                    end;
                                end;
                                local v32 = v21:Clone();
                                u6(v32);
                                u2[l__Name__11] = v32;
                            end;
                            u16 = u2[l__Name__11]:Clone();
                            if u16 then
                                u16.Parent = u12;
                                v17 = Instance.new("Motor6D", u16.Handle);
                                v17.Part0 = u16.Handle;
                                v17.Part1 = p15 == "Secondary" and l__LowerTorso__9 or l__UpperTorso__8;
                                v17.C0 = u7[p15] or CFrame.new();
                                v18 = u9.StarterGear:WaitForChild(p14.Name, 30);
                                if v18 then
                                    u19 = v18:WaitForChild("Customization", 30);
                                    u20 = function() --[[ Name: processAttachments, Line 112 ]]
                                        -- upvalues: u19 (copy), l__AttachmentsUtil__6 (ref), u16 (copy)
                                        local v33 = {};
                                        for v34, v35 in u19:GetAttributes() do
                                            if v34 ~= "Camo" then
                                                table.insert(v33, v35);
                                            end;
                                        end;
                                        local v36 = {};
                                        for _, v37 in v33 do
                                            local v38 = l__AttachmentsUtil__6.getAttDataFromHash(v37);
                                            if v38 then
                                                table.insert(v36, v38);
                                            end;
                                        end;
                                        l__AttachmentsUtil__6.loadAttachments(u16, v36);
                                        local v39 = u16:FindFirstChild("SightMark", true);
                                        local v40 = v39 and v39:FindFirstChildOfClass("SurfaceGui");
                                        if v40 then
                                            v40.Enabled = false;
                                        end;
                                        for _, v41 in u16:GetDescendants() do
                                            if v41:IsA("Decal") then
                                                v41:Destroy();
                                            end;
                                        end;
                                    end;
                                    if u19 and not u13.customization[p14] then
                                        u20();
                                        u13.customization[p14] = u19.Changed:Connect(function() --[[ Line: 145 ]]
                                            -- upvalues: u16 (copy), u20 (copy)
                                            for _, v42 in u16:GetChildren() do
                                                if v42:GetAttribute("Category") then
                                                    v42:Destroy();
                                                end;
                                            end;
                                            u20();
                                        end);
                                    end;
                                end;
                            else
                                warn("Failed to create visualisation for weapon", p14.Name);
                            end;
                        end;
                        local function u48(u44) --[[ Line: 156 ]]
                            -- upvalues: u13 (ref), l__Backpack__10 (copy), u43 (copy)
                            local v45;
                            if u44:IsA("Tool") then
                                v45 = u44:GetAttribute("Slot");
                                if not v45 or v45 == "None" then
                                    v45 = nil;
                                end;
                            else
                                v45 = nil;
                            end;
                            if not u13[u44] then
                                u13[u44] = u44:GetAttributeChangedSignal("Slot"):Connect(function() --[[ Line: 160 ]]
                                    -- upvalues: u44 (copy), l__Backpack__10 (ref), u43 (ref)
                                    if u44.Parent == l__Backpack__10 then
                                        local v46 = u44;
                                        local v47;
                                        if v46:IsA("Tool") then
                                            v47 = v46:GetAttribute("Slot");
                                            if not v47 or v47 == "None" then
                                                v47 = nil;
                                            end;
                                        else
                                            v47 = nil;
                                        end;
                                        if v47 then
                                            u43(u44, v47);
                                        end;
                                    end;
                                end);
                            end;
                            if v45 then
                                u43(u44, v45);
                            end;
                        end;
                        u13.backpackAdd = l__Backpack__10.ChildAdded:Connect(u48);
                        u13.backpackRemove = l__Backpack__10.ChildRemoved:Connect(function(p49) --[[ Name: processRemovedBackpackChild, Line 173 ]]
                            -- upvalues: u12 (copy)
                            local v50 = u12:FindFirstChild(p49.Name);
                            if v50 then
                                v50:Destroy();
                            end;
                        end);
                        u13.seatPart = p10:WaitForChild("Humanoid").Seated:Connect(function(p51, _) --[[ Line: 184 ]]
                            -- upvalues: l__Backpack__10 (copy), u48 (copy), u12 (copy)
                            if p51 then
                                for _, v52 in l__Backpack__10:GetChildren() do
                                    local v53 = u12:FindFirstChild(v52.Name);
                                    if v53 then
                                        v53:Destroy();
                                    end;
                                end;
                            else
                                for _, v54 in l__Backpack__10:GetChildren() do
                                    u48(v54);
                                end;
                            end;
                        end);
                        local u55 = u13;
                        for _, u56 in l__Backpack__10:GetChildren() do
                            coroutine.wrap(function() --[[ Line: 197 ]]
                                -- upvalues: u48 (copy), u56 (copy)
                                u48(u56);
                            end)();
                        end;
                        p10.Humanoid.Died:Connect(function() --[[ Line: 202 ]]
                            -- upvalues: u55 (ref)
                            if u55 then
                                for _, v57 in u55 do
                                    v57:Disconnect();
                                end;
                                u55 = nil;
                            end;
                        end);
                    end;
                end;
            end;
        end;
    end;
    local function u61(u59) --[[ Line: 213 ]]
        -- upvalues: u8 (copy), u58 (copy)
        u8[u59] = {
            player = {},
            character = {}
        };
        table.insert(u8[u59].player, u59.CharacterAdded:Connect(function(p60) --[[ Line: 219 ]]
            -- upvalues: u58 (ref), u59 (copy)
            u58(u59, p60);
        end));
        if u59.Character then
            u58(u59, u59.Character);
        end;
    end;
    l__Players__3.PlayerAdded:Connect(u61);
    l__Players__3.PlayerRemoving:Connect(function(p62) --[[ Name: processLeavingPlayer, Line 228 ]]
        -- upvalues: u8 (copy)
        if u8[p62] then
            for _, v63 in u8[p62] do
                for _, v64 in v63 do
                    v64:Disconnect();
                end;
            end;
            u8[p62] = nil;
        end;
    end);
    for _, u65 in l__Players__3:GetChildren() do
        coroutine.wrap(function() --[[ Line: 244 ]]
            -- upvalues: u61 (copy), u65 (copy)
            u61(u65);
        end)();
    end;
end;