-- Roblox: Players.SilverAce293026.PlayerScripts.MinigameClient
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
game:GetService("ReplicatedFirst"):WaitForChild("LoadingScript");
local l__Players__2 = game:GetService("Players");
local l__RunService__3 = game:GetService("RunService");
game:GetService("StarterGui");
local l__ReplicatedConfig__4 = require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig"));
local l__LocalPlayer__5 = l__Players__2.LocalPlayer;
local l__PlayerGui__6 = l__LocalPlayer__5:WaitForChild("PlayerGui");
local l__FadeGui__7 = l__PlayerGui__6:WaitForChild("FadeGui");
local l__FadeModule__8 = require(l__FadeGui__7:WaitForChild("FadeModule"));
local l__Modules__9 = l__ReplicatedStorage__1:WaitForChild("Modules");
local l__MusicModule__10 = require(l__Modules__9:WaitForChild("MusicModule"));
local l__MinigameEvent__11 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents"):WaitForChild("MinigameEvent");
local l__Common__12 = require(script:WaitForChild("Common"));
local u1 = {
    ["Team Deathmatch"] = require(script:WaitForChild("TeamDeathmatch")),
    ["Team Gun Game"] = require(script:WaitForChild("TeamGunGame")),
    ["Ground War"] = require(script:WaitForChild("GroundWar")),
    ["Free For All"] = require(script:WaitForChild("FreeForAll")),
    ["Team Randomizer"] = require(script:WaitForChild("TeamRandomizer")),
    Infected = require(script:WaitForChild("Infected")),
    ["Sniper Only"] = require(script:WaitForChild("TeamSnipers"))
};
local u2 = {};
local u3 = nil;
function u2.GameStarted(p4) --[[ Line: 45 ]]
    -- upvalues: u3 (ref), l__Common__12 (copy), u1 (copy)
    u3 = p4;
    local l__SetActiveElements__13 = l__Common__12.MinigameGui.SetActiveElements;
    local v5;
    if u3 then
        v5 = u1[u3];
    else
        v5 = nil;
    end;
    l__SetActiveElements__13(v5.InterfaceElements);
end;
function u2.ShowNotification(p6) --[[ Line: 50 ]]
    -- upvalues: l__Common__12 (copy)
    l__Common__12.MinigameGui.CreateNotification(p6);
end;
function u2.KillMenu() --[[ Line: 54 ]] end;
l__LocalPlayer__5.CharacterAdded:Connect(function(u7) --[[ Name: onNewCharacter, Line 58 ]]
    -- upvalues: u2 (copy)
    local function v8() --[[ Line: 59 ]]
        -- upvalues: u7 (copy), u2 (ref)
        if u7:GetAttribute("Deployed") then
            u2.KillMenu();
        end;
    end;
    u7:GetAttributeChangedSignal("Deployed"):Connect(v8);
    if u7:GetAttribute("Deployed") then
        u2.KillMenu();
    end;
end);
if l__LocalPlayer__5.Character then
    local l__Character__14 = l__LocalPlayer__5.Character;
    l__Character__14:GetAttributeChangedSignal("Deployed"):Connect(function() --[[ Name: update, Line 59 ]]
        -- upvalues: l__Character__14 (copy), u2 (copy)
        if l__Character__14:GetAttribute("Deployed") then
            u2.KillMenu();
        end;
    end);
    if l__Character__14:GetAttribute("Deployed") then
        u2.KillMenu();
    end;
end;
function u2.GameEnded(p9, ...) --[[ Line: 74 ]]
    -- upvalues: u3 (ref), u1 (copy), l__Common__12 (copy), l__PlayerGui__6 (copy), l__LocalPlayer__5 (copy), l__RunService__3 (copy), l__MusicModule__10 (copy), l__FadeModule__8 (copy), l__ReplicatedConfig__4 (copy), l__ReplicatedStorage__1 (copy)
    local v10;
    if u3 then
        v10 = u1[u3];
    else
        v10 = nil;
    end;
    if not v10 then
        return;
    end;
    local v11;
    if u3 then
        v11 = u1[u3];
    else
        v11 = nil;
    end;
    if v11.ActiveConnetions then
        local v12;
        if u3 then
            v12 = u1[u3];
        else
            v12 = nil;
        end;
        for _, v13 in v12.ActiveConnections do
            v13:Disconnect();
        end;
        local v14;
        if u3 then
            v14 = u1[u3];
        else
            v14 = nil;
        end;
        v14.ActiveConnections = {};
    end;
    local v15;
    if u3 then
        v15 = u1[u3];
    else
        v15 = nil;
    end;
    if v15.Cleanup then
        local v16 = { ... };
        local v17;
        if u3 then
            v17 = u1[u3];
        else
            v17 = nil;
        end;
        v17.Cleanup(unpack(v16));
    end;
    u3 = nil;
    l__Common__12.MinigameGui.SetActiveElements({});
    l__PlayerGui__6.LoadingGui.Frame.Menu.PlayButtonFrame.PlayButton.Visible = false;
    local l__Character__15 = l__LocalPlayer__5.Character;
    if l__Character__15 then
        l__Character__15.Humanoid:UnequipTools();
        l__RunService__3.RenderStepped:Wait();
    end;
    local v18 = l__PlayerGui__6:FindFirstChild("CustomToolbar");
    if v18 then
        v18.Enabled = false;
    end;
    local u19 = true;
    for _, v20 in { l__PlayerGui__6.GameUI.LoadoutUI.Main } do
        if v20.Visible then
            u19 = false;
            break;
        end;
    end;
    if u19 then
        l__MusicModule__10.fadeMusic(false);
        l__FadeModule__8.FadeYield(true);
        game.Lighting.Blur.Size = 0;
        l__PlayerGui__6.LoadingGui.Enabled = false;
        l__MusicModule__10.setHardpointPlaying(true, 118, 1.5);
        local v21;
        if l__ReplicatedConfig__4.Mode == "GroundWar" then
            v21 = l__ReplicatedStorage__1.DMNoMapCamPart:Clone();
            v21.Parent = workspace;
        else
            v21 = workspace:WaitForChild("Minigames"):FindFirstChild("Map", true):WaitForChild("CamPart");
        end;
        local l__CurrentCamera__16 = workspace.CurrentCamera;
        l__CurrentCamera__16.CameraType = Enum.CameraType.Scriptable;
        l__CurrentCamera__16.CameraSubject = nil;
        l__CurrentCamera__16.CFrame = v21.CFrame;
        task.wait(1);
    end;
    if p9 and u19 then
        l__Common__12.MinigameGui.RunEndGameUI(unpack({ ... }));
    end;
    if u19 then
        task.delay(35, function() --[[ Line: 148 ]]
            -- upvalues: l__MusicModule__10 (ref), l__FadeModule__8 (ref), l__Common__12 (ref), l__PlayerGui__6 (ref), l__ReplicatedConfig__4 (ref), u19 (ref)
            l__MusicModule__10.setHardpointPlaying(false);
            l__FadeModule__8.FadeYield(true);
            l__Common__12.MinigameGui.HideEndGameUI();
            task.wait(1);
            local l__LoadingGui__17 = l__PlayerGui__6.LoadingGui;
            local v22;
            if l__ReplicatedConfig__4.Mode == "Tycoon" then
                v22 = false;
            else
                v22 = u19;
            end;
            l__LoadingGui__17.Enabled = v22;
            l__MusicModule__10.fadeMusic(true);
            local v23 = l__ReplicatedConfig__4.Mode == "Tycoon" and l__PlayerGui__6:FindFirstChild("CustomToolbar");
            if v23 then
                v23.Enabled = true;
            end;
            l__FadeModule__8.FadeYield(false);
        end);
    end;
end;
l__MinigameEvent__11.OnClientEvent:Connect(function(p24, ...) --[[ Line: 167 ]]
    -- upvalues: u2 (copy), u3 (ref), u1 (copy)
    local v25 = { ... };
    if u2[p24] then
        u2[p24](unpack(v25));
    elseif u3 then
        local v26;
        if u3 then
            v26 = u1[u3];
        else
            v26 = nil;
        end;
        if v26[p24] then
            local v27;
            if u3 then
                v27 = u1[u3];
            else
                v27 = nil;
            end;
            v27[p24](unpack(v25));
        end;
    end;
end);
if l__ReplicatedConfig__4.Mode == "Deathmatch" or l__ReplicatedConfig__4.Mode == "GroundWar" then
    if not u3 then
        l__MinigameEvent__11:FireServer("StateResend");
    end;
end;