-- Roblox: Players.SilverAce293026.PlayerScripts.QuestClient
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__Players__2 = game:GetService("Players");
local l__PlayerEvents__3 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents");
local l__Modules__4 = l__ReplicatedStorage__1:WaitForChild("Modules");
local l__ShowQuest__5 = l__PlayerEvents__3:WaitForChild("ShowQuest");
local l__RewardQuest__6 = l__PlayerEvents__3:WaitForChild("RewardQuest");
local l__LocalPlayer__7 = l__Players__2.LocalPlayer;
local l__PlayerGui__8 = l__LocalPlayer__7:WaitForChild("PlayerGui");
local l__ContextArrowModule__9 = require(l__Modules__4:WaitForChild("ContextArrowModule"));
local l__QuestGui__10 = l__PlayerGui__8:WaitForChild("QuestGui");
local l__QuestGuiModule__11 = require(l__QuestGui__10:WaitForChild("QuestGuiModule"));
local l__RewardGui__12 = l__PlayerGui__8:WaitForChild("RewardGui");
local l__RewardGuiModule__13 = require(l__RewardGui__12:WaitForChild("RewardGuiModule"));
l__ShowQuest__5.OnClientEvent:Connect(function(p1, p2) --[[ Name: UpdateGui, Line 32 ]]
    -- upvalues: l__QuestGuiModule__11 (copy), l__ContextArrowModule__9 (copy), l__LocalPlayer__7 (copy)
    l__QuestGuiModule__11.Set(p1, p2);
    l__ContextArrowModule__9.Clear();
    local v3 = p1.Steps[p2];
    local l__Type__14 = v3.Goal.Type;
    local l__Value__15 = l__LocalPlayer__7:WaitForChild("AssociatedTycoon").Value;
    local v4 = workspace:WaitForChild(l__Value__15);
    if l__Type__14 == "MoneyBalance" then
        l__ContextArrowModule__9.SetTarget(v4.CashGiver.CashCollectButton);
    else
        if l__Type__14 == "Construction" then
            local v5 = v4:WaitForChild("BuyButtons"):WaitForChild(v3.Goal.Target, 10);
            if not v5 then
                return;
            end;
            l__ContextArrowModule__9.SetTarget(v5.PrimaryPart);
        end;
    end;
end);
l__RewardQuest__6.OnClientEvent:Connect(function(p6) --[[ Name: EndQuest, Line 25 ]]
    -- upvalues: l__QuestGuiModule__11 (copy), l__ContextArrowModule__9 (copy), l__RewardGuiModule__13 (copy)
    l__QuestGuiModule__11.Clear();
    l__ContextArrowModule__9.Clear();
    l__RewardGuiModule__13.ShowReward(p6);
end);