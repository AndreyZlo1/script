-- Roblox: Players.SilverAce293026.PlayerScripts.MusicPlayer
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Modules__1 = game:GetService("ReplicatedStorage"):WaitForChild("Modules");
require(l__Modules__1:WaitForChild("MusicModule"));
local l__PreSong__2 = l__Modules__1.MusicModule:WaitForChild("PreSong");
local v1 = {
    l__Modules__1.MusicModule:WaitForChild("Song1"),
    l__Modules__1.MusicModule:WaitForChild("Song2"),
    l__Modules__1.MusicModule:WaitForChild("Song3"),
    l__Modules__1.MusicModule:WaitForChild("Song4"),
    l__Modules__1.MusicModule:WaitForChild("Song5")
};
local l__Sound__3 = l__Modules__1.MusicModule:WaitForChild("Sound");
l__Modules__1.MusicModule:WaitForChild("Hardpoint"):Play();
local v2 = 0;
while true do
    l__Sound__3:Stop();
    while v2 == l__PreSong__2.Value do
        v2 = v1[math.random(1, 3)].Value;
    end;
    l__Sound__3.SoundId = "http://www.roblox.com/asset/?id=" .. v2;
    task.wait(5);
    local l__TimeLength__4 = l__Sound__3.TimeLength;
    l__PreSong__2.Value = v2;
    l__Sound__3:Play();
    task.wait(l__TimeLength__4);
end;