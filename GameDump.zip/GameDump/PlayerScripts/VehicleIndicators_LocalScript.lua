-- Roblox: Players.SilverAce293026.PlayerScripts.VehicleIndicators
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Players__1 = game:GetService("Players");
local l__ReplicatedStorage__2 = game:GetService("ReplicatedStorage");
local _ = l__Players__1.LocalPlayer;
local l__Helicopters__3 = l__ReplicatedStorage__2:WaitForChild("Helicopters");
local l__Vehicles__4 = l__ReplicatedStorage__2:WaitForChild("Vehicles");
local l__ReplicatedConfig__5 = require(l__ReplicatedStorage__2:WaitForChild("ReplicatedConfig"));
local v1 = l__ReplicatedConfig__5.Mode == "GroundWar";
local l__LocalPlayer__6 = l__Players__1.LocalPlayer;
local l__HeliIndicator__7 = script:WaitForChild("HeliIndicator");
local l__LandIndicator__8 = script:WaitForChild("LandIndicator");
local l__PlaneIndicator__9 = script:WaitForChild("PlaneIndicator");
local v2;
if l__ReplicatedConfig__5.Mode == "Tycoon" then
    local l__Value__10 = l__LocalPlayer__6:WaitForChild("AssociatedTycoon").Value;
    v2 = workspace:WaitForChild(l__Value__10):WaitForChild("SpawnedVehicles");
else
    v2 = nil;
end;
local u3 = {};
local function u14(u4) --[[ Line: 40 ]]
    -- upvalues: l__Vehicles__4 (copy), l__LandIndicator__8 (copy), l__Helicopters__3 (copy), l__HeliIndicator__7 (copy), l__PlaneIndicator__9 (copy), l__LocalPlayer__6 (copy), l__Players__1 (copy)
    local v5 = l__Vehicles__4:FindFirstChild(u4.Name) and l__LandIndicator__8 or (l__Helicopters__3:FindFirstChild(u4.Name) and l__HeliIndicator__7 or l__PlaneIndicator__9);
    local u6 = v5:Clone();
    if v5 == l__LandIndicator__8 then
        local l__Required__11 = u4:WaitForChild("Required");
        local v7 = l__Required__11:FindFirstChild("TankSeat");
        local v8 = l__Required__11:FindFirstChild("ApcSeat");
        u6.Container.Icon.Image = string.format("rbxassetid://%s", u4.Name == "Humvee" and 18750335323 or (v8 and 18750323016 or (v7 and 18749936435 or 18315761362)));
    end;
    local l__Required__12 = u4:WaitForChild("Required");
    local v9 = os.time();
    local u10;
    repeat
        u10 = l__Required__12:FindFirstChildOfClass("VehicleSeat");
        task.wait(0.1);
    until u10 or os.time() > v9 + 15;
    if u10 then
        u6.Parent = u10;
        local function v13() --[[ Line: 76 ]]
            -- upvalues: u10 (ref), u4 (copy), u6 (copy), l__LocalPlayer__6 (ref), l__Players__1 (ref)
            local l__Occupant__13 = u10.Occupant;
            if u4:GetAttribute("Respawn") == nil then
                u6.Container.Timer.Visible = false;
                if l__Occupant__13 == nil then
                    u6.Enabled = true;
                    u6.Container.Icon.ImageColor3 = Color3.fromRGB(255, 255, 255);
                elseif l__Occupant__13 == l__LocalPlayer__6.Character.Humanoid then
                    u6.Enabled = false;
                else
                    u6.Enabled = true;
                    local v11 = l__Players__1:GetPlayerFromCharacter((l__Occupant__13:FindFirstAncestorOfClass("Model")));
                    if l__LocalPlayer__6:GetAttribute("MG_Team") == v11:GetAttribute("MG_Team") then
                        u6.Container.Icon.ImageColor3 = Color3.fromRGB(85, 255, 127);
                    else
                        u6.Container.Icon.ImageColor3 = Color3.fromRGB(255, 88, 88);
                    end;
                end;
            else
                u6.Enabled = true;
                u6.Container.Icon.ImageColor3 = Color3.fromRGB(255, 255, 255);
                task.spawn(function() --[[ Line: 83 ]]
                    -- upvalues: u4 (ref), u6 (ref)
                    while u4 and (u4:GetAttribute("Respawn") and u6.Enabled) do
                        local v12 = u4:GetAttribute("Respawn") - os.time();
                        u6.Container.Timer.Text = math.max(v12, 0);
                        task.wait(1);
                    end;
                end);
                u6.Container.Timer.Visible = true;
            end;
        end;
        u4:GetAttributeChangedSignal("Respawn"):Connect(v13);
        u10:GetPropertyChangedSignal("Occupant"):Connect(v13);
        v13();
    else
        u6:Destroy();
    end;
end;
if v2 then
    v2.ChildAdded:Connect(u14);
end;
if v1 then
    local l__GWVehicles__14 = workspace:WaitForChild("GWVehicles");
    local function v20() --[[ Line: 132 ]]
        -- upvalues: l__LocalPlayer__6 (copy), u3 (ref), l__GWVehicles__14 (copy), u14 (copy)
        local v15 = l__LocalPlayer__6:GetAttribute("MG_Team");
        for _, v16 in u3 do
            v16:Disconnect();
        end;
        u3 = {};
        if v15 == nil then
        else
            local v17 = l__GWVehicles__14[v15];
            local v18 = v17.ChildAdded:Connect(u14);
            table.insert(u3, v18);
            for _, v19 in v17:GetChildren() do
                u14(v19);
            end;
        end;
    end;
    l__LocalPlayer__6:GetAttributeChangedSignal("MG_Team"):Connect(v20);
    v20();
end;