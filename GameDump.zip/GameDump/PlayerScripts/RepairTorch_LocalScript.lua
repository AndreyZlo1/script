-- Roblox: Players.SilverAce293026.PlayerScripts.RepairTorch
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__CollectionService__2 = game:GetService("CollectionService");
local l__RunService__3 = game:GetService("RunService");
local l__LocalPlayer__4 = game:GetService("Players").LocalPlayer;
local l__RepairTorchAmount__5 = require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig")).RepairTorchAmount;
local u1 = false;
local u2 = {};
local function u5(p3) --[[ Line: 16 ]]
    -- upvalues: l__LocalPlayer__4 (copy)
    if p3:GetAttribute("RepairableTimestamp") > os.time() then
        return false;
    end;
    if l__LocalPlayer__4.Character then
        if l__LocalPlayer__4.Character:FindFirstChild("Humanoid").Health == 0 then
            return false;
        end;
        local v4 = p3:GetAttribute("RepairingPlayer");
        return not v4 and true or v4 == l__LocalPlayer__4.Name;
    end;
end;
local function v11(p6) --[[ Line: 32 ]]
    -- upvalues: u1 (ref), l__CollectionService__2 (copy), u5 (copy)
    u1 = false;
    p6.ChildAdded:Connect(function(p7) --[[ Line: 34 ]]
        -- upvalues: l__CollectionService__2 (ref), u5 (ref), u1 (ref)
        if p7.Name == "Blowtorch" then
            for _, v8 in l__CollectionService__2:GetTagged("RepairPrompt") do
                v8.Enabled = u5((v8:FindFirstAncestorOfClass("Model")));
                u1 = true;
            end;
        end;
    end);
    p6.ChildRemoved:Connect(function(p9) --[[ Line: 44 ]]
        -- upvalues: l__CollectionService__2 (ref), u1 (ref)
        if p9.Name == "Blowtorch" then
            for _, v10 in l__CollectionService__2:GetTagged("RepairPrompt") do
                v10.Enabled = false;
                u1 = false;
            end;
        end;
    end);
end;
local function v19(u12) --[[ Line: 54 ]]
    -- upvalues: l__RunService__3 (copy), u2 (copy), l__RepairTorchAmount__5 (copy)
    l__RunService__3.Heartbeat:Wait();
    local v13 = u12:FindFirstAncestorOfClass("Model");
    local l__Parent__6 = u12.Parent;
    local u14 = l__Parent__6:FindFirstChild("Prompt") or l__Parent__6:FindFirstChild("ProximityPrompt");
    local l__VehicleHealth__7 = v13:WaitForChild("Params"):WaitForChild("VehicleHealth");
    table.insert(u2, u12);
    v13.Destroying:Connect(function() --[[ Line: 65 ]]
        -- upvalues: u2 (ref), l__VehicleHealth__7 (copy)
        local v15 = table.find(u2, l__VehicleHealth__7);
        if v15 then
            table.remove(u2, v15);
        end;
    end);
    if u14 then
        u14.PromptShown:Connect(function() --[[ Line: 78 ]]
            -- upvalues: u14 (ref), u12 (copy)
            if u14 then
                u12.UIOffset = Vector2.new(150, 0);
            end;
        end);
        u14.PromptHidden:Connect(function() --[[ Line: 81 ]]
            -- upvalues: u14 (ref), u12 (copy)
            if u14 then
                u12.UIOffset = Vector2.new(0, 0);
            end;
        end);
    else
        l__Parent__6.ChildAdded:Connect(function(p16) --[[ Line: 85 ]]
            -- upvalues: u14 (ref), u12 (copy)
            if p16:IsA("ProximityPrompt") then
                u14 = p16;
                u14.PromptShown:Connect(function() --[[ Line: 88 ]]
                    -- upvalues: u14 (ref), u12 (ref)
                    if u14 then
                        u12.UIOffset = Vector2.new(150, 0);
                    end;
                end);
                u14.PromptHidden:Connect(function() --[[ Line: 91 ]]
                    -- upvalues: u14 (ref), u12 (ref)
                    if u14 then
                        u12.UIOffset = Vector2.new(0, 0);
                    end;
                end);
            end;
        end);
    end;
    local u17 = false;
    u12.PromptButtonHoldBegan:Connect(function() --[[ Line: 99 ]]
        -- upvalues: u17 (ref)
        u17 = true;
    end);
    u12.PromptButtonHoldEnded:Connect(function() --[[ Line: 102 ]]
        -- upvalues: u17 (ref)
        u17 = false;
    end);
    local u18 = l__VehicleHealth__7:GetAttribute("MaxHealth");
    l__VehicleHealth__7.Changed:Connect(function() --[[ Line: 107 ]]
        -- upvalues: u17 (ref), l__VehicleHealth__7 (copy), u18 (copy), l__RepairTorchAmount__5 (ref), u12 (copy)
        if u17 then
        else
            u12.HoldDuration = (u18 - l__VehicleHealth__7.Value) / l__RepairTorchAmount__5 + 0.1;
        end;
    end);
end;
local function v24() --[[ Line: 116 ]]
    -- upvalues: u2 (copy), u5 (copy), u1 (ref)
    os.time();
    for _, v20 in u2 do
        if v20.Parent then
            local v21 = v20:FindFirstAncestorOfClass("Model");
            if v21 and v21:FindFirstChild("Required") then
                local l__PrimaryPart__8 = v21.PrimaryPart;
                if l__PrimaryPart__8 then
                    local v22 = l__PrimaryPart__8:FindFirstChild("RepairPrompt");
                    if v22 then
                        local v23 = u5(v21);
                        if v23 then
                            v23 = u1;
                        end;
                        v22.Enabled = v23;
                    end;
                end;
            end;
        end;
    end;
end;
l__CollectionService__2:GetInstanceAddedSignal("RepairPrompt"):Connect(v19);
for _, v25 in l__CollectionService__2:GetTagged("RepairPrompt") do
    v19(v25);
end;
l__LocalPlayer__4.CharacterAdded:Connect(v11);
if l__LocalPlayer__4.Character then
    v11(l__LocalPlayer__4.Character);
end;
while true do
    local v26, v27 = pcall(v24);
    if not v26 then
        warn(v27);
    end;
    task.wait(0.1);
end;