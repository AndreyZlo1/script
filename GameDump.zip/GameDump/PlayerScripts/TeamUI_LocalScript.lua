-- Roblox: Players.SilverAce293026.PlayerScripts.TeamUI
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

game:GetService("ReplicatedStorage");
local l__Players__1 = game:GetService("Players");
local l__RunService__2 = game:GetService("RunService");
local l__LocalPlayer__3 = l__Players__1.LocalPlayer;
local u1 = Instance.new("ScreenGui");
u1.Name = "TeamUISizingUtil";
u1.Parent = l__LocalPlayer__3:WaitForChild("PlayerGui");
local u2 = {};
local u3 = {};
local u4 = {
    Focused = script:WaitForChild("FriendlyFocused"),
    Unfocused = script:WaitForChild("FriendlyUnfocused")
};
({
    Focused = nil
}).Unfocused = script:WaitForChild("EnemyUnfocused");
local function u17(p5, p6) --[[ Line: 26 ]]
    -- upvalues: l__LocalPlayer__3 (copy), u2 (copy), u4 (copy), l__RunService__2 (copy)
    local u7 = p5.Character or p5.CharacterAdded:Wait();
    local u8 = u7:FindFirstChild("Humanoid");
    local v9 = p5:GetAttribute("MG_Team");
    if v9 and v9 ~= "" then
        local v10 = l__LocalPlayer__3:GetAttribute("MG_Team");
        if v10 and v10 ~= "" then
            for _, v11 in u2[p5].UIs do
                v11:Destroy();
            end;
            if v9 == v10 then
                local u12 = (p6 and u4.Focused or u4.Unfocused):Clone();
                u12.Parent = u7:WaitForChild("HumanoidRootPart", 30);
                if not (u12 and u12.Parent) then
                    return;
                end;
                table.insert(u2[p5].UIs, u12);
                if p6 then
                    u12.PName.Text = p5.DisplayName;
                    local u14 = u8.Changed:Connect(function() --[[ Line: 55 ]]
                        -- upvalues: u8 (copy), u12 (copy)
                        local v13 = math.clamp(u8.Health / u8.MaxHealth, 0, 1);
                        u12.Bar.Bar.Size = UDim2.new(v13, 0, 1, 0);
                    end);
                    local u16 = l__RunService__2.Heartbeat:Connect(function() --[[ Line: 63 ]]
                        -- upvalues: u7 (copy), l__LocalPlayer__3 (ref), u12 (copy)
                        local l__PrimaryPart__4 = u7.PrimaryPart;
                        if l__PrimaryPart__4 then
                            if l__LocalPlayer__3.Character then
                                local l__PrimaryPart__5 = l__LocalPlayer__3.Character.PrimaryPart;
                                if l__PrimaryPart__5 then
                                    local v15 = math.ceil((l__PrimaryPart__5.Position - l__PrimaryPart__4.Position).Magnitude / 2.4);
                                    u12.Distance.Text = string.format("%sm", v15);
                                end;
                            end;
                        end;
                    end);
                    u12.Destroying:Connect(function() --[[ Line: 76 ]]
                        -- upvalues: u14 (ref), u16 (ref)
                        u14:Disconnect();
                        u14 = nil;
                        u16:Disconnect();
                        u16 = nil;
                    end);
                end;
            end;
        end;
    end;
end;
local function u20(p18, _) --[[ Line: 88 ]]
    -- upvalues: u2 (copy), u17 (copy)
    for _, v19 in u2[p18].UIs do
        v19:Destroy();
    end;
    u2[p18].UIs = {};
    u17(p18);
end;
local function v25(u21) --[[ Line: 97 ]]
    -- upvalues: u2 (copy), u20 (copy), l__LocalPlayer__3 (copy), l__Players__1 (copy), u17 (copy)
    u2[u21] = {
        UIs = {}
    };
    local v23 = u21.CharacterAdded:Connect(function(p22) --[[ Line: 100 ]]
        -- upvalues: u20 (ref), u21 (copy)
        u20(u21, p22);
    end);
    if u21.Character then
        u20(u21, u21.Character);
    end;
    local v24 = { v23, (u21:GetAttributeChangedSignal("MG_Team"):Connect(function() --[[ Line: 108 ]]
            -- upvalues: u21 (copy), l__LocalPlayer__3 (ref), l__Players__1 (ref), u17 (ref)
            if u21 == l__LocalPlayer__3 then
                for _, _ in l__Players__1:GetChildren() do
                    u17(u21);
                end;
            end;
        end)) };
    u2[u21].Conns = v24;
    u17(u21);
end;
l__Players__1.PlayerAdded:Connect(v25);
l__Players__1.PlayerRemoving:Connect(function(p26) --[[ Name: onRemovingPlayer, Line 126 ]]
    -- upvalues: u2 (copy)
    if u2[p26] then
        for _, v27 in u2[p26].Conns do
            v27:Disconnect();
        end;
        for _, v28 in u2[p26].UIs do
            v28:Destroy();
        end;
        u2[p26] = nil;
    end;
end);
local function v41() --[[ Line: 139 ]]
    -- upvalues: u1 (copy), l__Players__1 (copy), u3 (copy), u17 (copy), l__LocalPlayer__3 (copy)
    local l__CurrentCamera__6 = workspace.CurrentCamera;
    local l__AbsoluteSize__7 = u1.AbsoluteSize;
    local v29 = l__AbsoluteSize__7 / 2;
    local v30 = 10 / 200;
    local v31 = l__AbsoluteSize__7.X * v30;
    local v32 = l__AbsoluteSize__7.Y * v30;
    local v33 = {
        X = v29.X - v31,
        Y = v29.Y - v32
    };
    local v34 = {
        X = v29.X + v31,
        Y = v29.Y + v32
    };
    for _, v35 in l__Players__1:GetChildren() do
        if v35 == l__LocalPlayer__3 then
            if u3[v35] then
                u3[v35] = nil;
                u17(v35, false);
            end;
        else
            local l__Character__8 = v35.Character;
            if l__Character__8 then
                local l__PrimaryPart__9 = l__Character__8.PrimaryPart;
                if l__PrimaryPart__9 then
                    local _, v36 = l__CurrentCamera__6:WorldToScreenPoint(l__PrimaryPart__9.Position);
                    if v36 then
                        local v37 = false;
                        for _, v38 in l__Character__8:GetChildren() do
                            if v38:IsA("BasePart") then
                                local v39 = l__CurrentCamera__6:WorldToScreenPoint(v38.Position);
                                local v40 = Vector2.new(v39.X, v39.Y);
                                if v40.X > v33.X and (v40.Y > v33.Y and (v40.X < v34.X and v40.Y < v34.Y)) then
                                    v37 = true;
                                    break;
                                end;
                            end;
                        end;
                        if v37 then
                            if not u3[v35] then
                                u3[v35] = true;
                                u17(v35, true);
                            end;
                        elseif u3[v35] then
                            u3[v35] = nil;
                            u17(v35, false);
                        end;
                    elseif u3[v35] then
                        u3[v35] = nil;
                        u17(v35, false);
                    end;
                elseif u3[v35] then
                    u3[v35] = nil;
                    u17(v35, false);
                end;
            elseif u3[v35] then
                u3[v35] = nil;
                u17(v35, false);
            end;
        end;
    end;
end;
for _, v42 in l__Players__1:GetChildren() do
    v25(v42);
end;
while true do
    local v43, v44;
    repeat
        task.wait(0.1);
        v43, v44 = pcall(v41);
    until not v43;
    warn("TeamUI runloop error:", v44);
end;