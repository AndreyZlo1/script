-- Roblox: Players.SilverAce293026.PlayerScripts.WeaponVisualisation2
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
game:GetService("RunService");
local l__ReplicatedConfig__2 = require(l__ReplicatedStorage__1:WaitForChild("ReplicatedConfig"));
if l__ReplicatedConfig__2.FeatureToggles.WeaponVisualisation then
    local l__Players__3 = game:GetService("Players");
    local l__ACS_Engine__4 = l__ReplicatedStorage__1:WaitForChild("ACS_Engine");
    local l__GunModels__5 = l__ACS_Engine__4:WaitForChild("GunModels");
    local l__AttachmentsUtil__6 = require(l__ACS_Engine__4:WaitForChild("Modules"):WaitForChild("AttachmentsUtil"));
    if l__ReplicatedConfig__2.Mode == "Tycoon" then
        local u1 = {
            Primary = CFrame.new(-0.7, 0.1, 0) * CFrame.Angles(0, 4.71238898038469, -0.8726646259971648),
            Primary2 = CFrame.new(0.6, -0.5, 0.2) * CFrame.Angles(0, -1.5707963267948966, 1.5707963267948966),
            Secondary = CFrame.new(-1.1, 0, 0) * CFrame.Angles(1.5707963267948966, 0.08726646259971647, 0)
        };
        local u2 = {};
        local function u6(p3) --[[ Line: 31 ]]
            for _, v4 in p3:GetDescendants() do
                if v4:IsA("BasePart") then
                    if v4:HasTag("ShowVPOnly") then
                        v4.Transparency = 1;
                    end;
                    v4.Anchored = false;
                    v4.CanCollide = false;
                    v4.CanTouch = false;
                    v4.CanQuery = false;
                    v4.Massless = true;
                    if v4.Name ~= "Handle" then
                        local v5 = Instance.new("WeldConstraint", p3.Handle);
                        v5.Part0 = p3.Handle;
                        v5.Part1 = v4;
                    end;
                end;
            end;
        end;
        local u7 = {};
        local function u47(p8, u9) --[[ Line: 68 ]]
            -- upvalues: l__Players__3 (copy), u7 (copy), u1 (copy), u2 (copy), l__GunModels__5 (copy), u6 (copy), l__AttachmentsUtil__6 (copy)
            if p8.Parent ~= l__Players__3 then
                return;
            end;
            if u7[u9] then
                return;
            end;
            local u10;
            if u9:IsA("Tool") then
                u10 = u9:GetAttribute("Slot");
                if not u10 or u10 == "None" then
                    u10 = nil;
                end;
            else
                u10 = nil;
            end;
            if not u10 then
                return;
            end;
            if not u1[u10] then
                return;
            end;
            u7[u9] = {};
            local l__UpperTorso__7 = p8.Character:WaitForChild("UpperTorso", 10);
            if not l__UpperTorso__7 then
                return;
            end;
            local l__LowerTorso__8 = p8.Character:WaitForChild("LowerTorso", 10);
            if not l__LowerTorso__8 then
                return;
            end;
            local l__Name__9 = u9.Name;
            local u11, u12, u13, u14, v15, u16, u17, v18, v19, u20;
            if not u2[l__Name__9] then
                local v21 = l__GunModels__5:WaitForChild(l__Name__9, 60);
                if not v21 then
                    u11 = nil;
                    u12 = p8.Character.WepVisualisation;
                    u13 = p8:WaitForChild("Backpack");
                    u14 = u9:WaitForChild("Customization", 30);
                    v15 = function() --[[ Name: update, Line 92 ]]
                        -- upvalues: u9 (copy), u13 (copy), u11 (ref), u12 (copy), u10 (copy), l__LowerTorso__8 (copy), l__UpperTorso__7 (copy), u1 (ref)
                        if u9.Parent == u13 then
                            u11.Parent = u12;
                            local v35 = Instance.new("Motor6D", u11.Handle);
                            v35.Name = "VisMotor";
                            v35.Part0 = u11.Handle;
                            v35.Part1 = u10 == "Secondary" and l__LowerTorso__8 or l__UpperTorso__7;
                            v35.C0 = u1[u10] or CFrame.new();
                        elseif u11 then
                            local v36 = u11:FindFirstChild("VisMotor");
                            if v36 then
                                v36:Destroy();
                            end;
                            u11.Parent = nil;
                        end;
                    end;
                    u16 = function() --[[ Name: updateAttachments, Line 112 ]]
                        -- upvalues: u14 (copy), u11 (ref), l__AttachmentsUtil__6 (ref)
                        if u14 then
                            if u11 then
                                local v37 = {};
                                for v38, v39 in u14:GetAttributes() do
                                    if v38 ~= "Camo" then
                                        table.insert(v37, v39);
                                    end;
                                end;
                                local v40 = {};
                                for _, v41 in v37 do
                                    local v42 = l__AttachmentsUtil__6.getAttDataFromHash(v41);
                                    if v42 then
                                        table.insert(v40, v42);
                                    end;
                                end;
                                l__AttachmentsUtil__6.loadAttachments(u11, v40);
                                local v43 = u11:FindFirstChild("SightMark", true);
                                local v44 = v43 and v43:FindFirstChildOfClass("SurfaceGui");
                                if v44 then
                                    v44.Enabled = false;
                                end;
                                for _, v45 in u11:GetDescendants() do
                                    if v45:IsA("Decal") then
                                        v45:Destroy();
                                    end;
                                end;
                            end;
                        end;
                    end;
                    u17 = 0;
                    v18 = function() --[[ Name: batchUpdateAttachments, Line 147 ]]
                        -- upvalues: u17 (ref), u16 (copy)
                        u17 = u17 + 1;
                        local u46 = u17;
                        task.delay(1, function() --[[ Line: 150 ]]
                            -- upvalues: u17 (ref), u46 (copy), u16 (ref)
                            if u17 == u46 then
                                u16();
                            end;
                        end);
                    end;
                    u9.Destroying:Connect(function() --[[ Line: 156 ]]
                        -- upvalues: u11 (ref), u7 (ref), u9 (copy)
                        u11:Destroy();
                        u11 = nil;
                        u7[u9] = nil;
                    end);
                    v19 = u9:GetPropertyChangedSignal("Parent"):Connect(v15);
                    u14.AttributeChanged:Connect(v18);
                    v15();
                    u17 = u17 + 1;
                    u20 = u17;
                    task.delay(1, function() --[[ Line: 150 ]]
                        -- upvalues: u17 (ref), u20 (copy), u16 (copy)
                        if u17 == u20 then
                            u16();
                        end;
                    end);
                    table.insert(u7[u9], v19);
                    return;
                end;
                local v34 = v21:Clone();
                u6(v34);
                u2[l__Name__9] = v34;
            end;
            u11 = u2[l__Name__9]:Clone();
            u12 = p8.Character.WepVisualisation;
            u13 = p8:WaitForChild("Backpack");
            u14 = u9:WaitForChild("Customization", 30);
            v15 = function() --[[ Name: update, Line 92 ]]
                -- upvalues: u9 (copy), u13 (copy), u11 (ref), u12 (copy), u10 (copy), l__LowerTorso__8 (copy), l__UpperTorso__7 (copy), u1 (ref)
                if u9.Parent == u13 then
                    u11.Parent = u12;
                    local v35 = Instance.new("Motor6D", u11.Handle);
                    v35.Name = "VisMotor";
                    v35.Part0 = u11.Handle;
                    v35.Part1 = u10 == "Secondary" and l__LowerTorso__8 or l__UpperTorso__7;
                    v35.C0 = u1[u10] or CFrame.new();
                elseif u11 then
                    local v36 = u11:FindFirstChild("VisMotor");
                    if v36 then
                        v36:Destroy();
                    end;
                    u11.Parent = nil;
                end;
            end;
            u16 = function() --[[ Name: updateAttachments, Line 112 ]]
                -- upvalues: u14 (copy), u11 (ref), l__AttachmentsUtil__6 (ref)
                if u14 then
                    if u11 then
                        local v37 = {};
                        for v38, v39 in u14:GetAttributes() do
                            if v38 ~= "Camo" then
                                table.insert(v37, v39);
                            end;
                        end;
                        local v40 = {};
                        for _, v41 in v37 do
                            local v42 = l__AttachmentsUtil__6.getAttDataFromHash(v41);
                            if v42 then
                                table.insert(v40, v42);
                            end;
                        end;
                        l__AttachmentsUtil__6.loadAttachments(u11, v40);
                        local v43 = u11:FindFirstChild("SightMark", true);
                        local v44 = v43 and v43:FindFirstChildOfClass("SurfaceGui");
                        if v44 then
                            v44.Enabled = false;
                        end;
                        for _, v45 in u11:GetDescendants() do
                            if v45:IsA("Decal") then
                                v45:Destroy();
                            end;
                        end;
                    end;
                end;
            end;
            u17 = 0;
            v18 = function() --[[ Name: batchUpdateAttachments, Line 147 ]]
                -- upvalues: u17 (ref), u16 (copy)
                u17 = u17 + 1;
                local u46 = u17;
                task.delay(1, function() --[[ Line: 150 ]]
                    -- upvalues: u17 (ref), u46 (copy), u16 (ref)
                    if u17 == u46 then
                        u16();
                    end;
                end);
            end;
            u9.Destroying:Connect(function() --[[ Line: 156 ]]
                -- upvalues: u11 (ref), u7 (ref), u9 (copy)
                u11:Destroy();
                u11 = nil;
                u7[u9] = nil;
            end);
            v19 = u9:GetPropertyChangedSignal("Parent"):Connect(v15);
            u14.AttributeChanged:Connect(v18);
            v15();
            u17 = u17 + 1;
            u20 = u17;
            task.delay(1, function() --[[ Line: 150 ]]
                -- upvalues: u17 (ref), u20 (copy), u16 (copy)
                if u17 == u20 then
                    u16();
                end;
            end);
            table.insert(u7[u9], v19);
        end;
        local function u53(u48, p49) --[[ Line: 172 ]]
            -- upvalues: u47 (copy)
            local l__Backpack__10 = u48:WaitForChild("Backpack");
            local v50 = Instance.new("Folder");
            v50.Name = "WepVisualisation";
            v50.Parent = p49;
            l__Backpack__10.ChildAdded:Connect(function(p51) --[[ Line: 179 ]]
                -- upvalues: u47 (ref), u48 (copy)
                u47(u48, p51);
            end);
            for _, v52 in l__Backpack__10:GetChildren() do
                u47(u48, v52);
            end;
        end;
        l__Players__3.PlayerAdded:Connect(function(u54) --[[ Name: onNewPlayer, Line 188 ]]
            -- upvalues: u53 (copy)
            u54.CharacterAdded:Connect(function(p55) --[[ Line: 189 ]]
                -- upvalues: u53 (ref), u54 (copy)
                u53(u54, p55);
            end);
            if u54.Character then
                u53(u54, u54.Character);
            end;
        end);
        for _, u56 in l__Players__3:GetChildren() do
            u56.CharacterAdded:Connect(function(p57) --[[ Line: 189 ]]
                -- upvalues: u53 (copy), u56 (copy)
                u53(u56, p57);
            end);
            if u56.Character then
                u53(u56, u56.Character);
            end;
        end;
    end;
end;