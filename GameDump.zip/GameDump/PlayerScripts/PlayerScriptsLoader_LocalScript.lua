-- Roblox: Players.SilverAce293026.PlayerScripts.PlayerScriptsLoader
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

require(script.Parent:WaitForChild("PlayerModule"));