-- Roblox: Players.SilverAce293026.PlayerScripts.PlayerModule.ControlModule.TouchThumbstick
-- Class: ModuleScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

game:GetService("Players");
local l__GuiService__1 = game:GetService("GuiService");
local l__UserInputService__2 = game:GetService("UserInputService");
UserSettings():GetService("UserGameSettings");
local v1, v2 = pcall(function() --[[ Line: 13 ]]
    return UserSettings():IsUserFeatureEnabled("UserClampClassicThumbstick");
end);
local u3 = v1 and v2;
local l__BaseCharacterController__3 = require(script.Parent:WaitForChild("BaseCharacterController"));
local u4 = setmetatable({}, l__BaseCharacterController__3);
u4.__index = u4;
function u4.new() --[[ Line: 26 ]]
    -- upvalues: l__BaseCharacterController__3 (copy), u4 (copy)
    local v5 = l__BaseCharacterController__3.new();
    local v6 = setmetatable(v5, u4);
    v6.isFollowStick = false;
    v6.thumbstickFrame = nil;
    v6.moveTouchObject = nil;
    v6.onTouchMovedConn = nil;
    v6.onTouchEndedConn = nil;
    v6.screenPos = nil;
    v6.stickImage = nil;
    v6.thumbstickSize = nil;
    return v6;
end;
function u4.Enable(p7, p8, p9) --[[ Line: 41 ]]
    if p8 == nil then
        return false;
    end;
    local v10 = p8 and true or false;
    if p7.enabled == v10 then
        return true;
    end;
    p7.moveVector = Vector3.new(0, 0, 0);
    p7.isJumping = false;
    if v10 then
        if not p7.thumbstickFrame then
            p7:Create(p9);
        end;
        p7.thumbstickFrame.Visible = true;
    else
        p7.thumbstickFrame.Visible = false;
        p7:OnInputEnded();
    end;
    p7.enabled = v10;
end;
function u4.OnInputEnded(p11) --[[ Line: 62 ]]
    p11.thumbstickFrame.Position = p11.screenPos;
    p11.stickImage.Position = UDim2.new(0, p11.thumbstickFrame.Size.X.Offset / 2 - p11.thumbstickSize / 4, 0, p11.thumbstickFrame.Size.Y.Offset / 2 - p11.thumbstickSize / 4);
    p11.moveVector = Vector3.new(0, 0, 0);
    p11.isJumping = false;
    p11.thumbstickFrame.Position = p11.screenPos;
    p11.moveTouchObject = nil;
end;
function u4.Create(u12, p13) --[[ Line: 71 ]]
    -- upvalues: u3 (ref), l__UserInputService__2 (copy), l__GuiService__1 (copy)
    if u12.thumbstickFrame then
        u12.thumbstickFrame:Destroy();
        u12.thumbstickFrame = nil;
        if u12.onTouchMovedConn then
            u12.onTouchMovedConn:Disconnect();
            u12.onTouchMovedConn = nil;
        end;
        if u12.onTouchEndedConn then
            u12.onTouchEndedConn:Disconnect();
            u12.onTouchEndedConn = nil;
        end;
    end;
    local v14 = math.min(p13.AbsoluteSize.X, p13.AbsoluteSize.Y) <= 500;
    u12.thumbstickSize = v14 and 70 or 120;
    u12.screenPos = v14 and UDim2.new(0, u12.thumbstickSize / 2 - 10, 1, -u12.thumbstickSize - 20) or UDim2.new(0, u12.thumbstickSize / 2, 1, -u12.thumbstickSize * 1.75);
    u12.thumbstickFrame = Instance.new("Frame");
    u12.thumbstickFrame.Name = "ThumbstickFrame";
    u12.thumbstickFrame.Active = true;
    u12.thumbstickFrame.Visible = false;
    u12.thumbstickFrame.Size = UDim2.new(0, u12.thumbstickSize, 0, u12.thumbstickSize);
    u12.thumbstickFrame.Position = u12.screenPos;
    u12.thumbstickFrame.BackgroundTransparency = 1;
    local v15 = Instance.new("ImageLabel");
    v15.Name = "OuterImage";
    v15.Image = "rbxasset://textures/ui/TouchControlsSheet.png";
    v15.ImageRectOffset = Vector2.new();
    v15.ImageRectSize = Vector2.new(220, 220);
    v15.BackgroundTransparency = 1;
    v15.Size = UDim2.new(0, u12.thumbstickSize, 0, u12.thumbstickSize);
    v15.Position = UDim2.new(0, 0, 0, 0);
    v15.Parent = u12.thumbstickFrame;
    u12.stickImage = Instance.new("ImageLabel");
    u12.stickImage.Name = "StickImage";
    u12.stickImage.Image = "rbxasset://textures/ui/TouchControlsSheet.png";
    u12.stickImage.ImageRectOffset = Vector2.new(220, 0);
    u12.stickImage.ImageRectSize = Vector2.new(111, 111);
    u12.stickImage.BackgroundTransparency = 1;
    u12.stickImage.Size = UDim2.new(0, u12.thumbstickSize / 2, 0, u12.thumbstickSize / 2);
    u12.stickImage.Position = UDim2.new(0, u12.thumbstickSize / 2 - u12.thumbstickSize / 4, 0, u12.thumbstickSize / 2 - u12.thumbstickSize / 4);
    u12.stickImage.ZIndex = 2;
    u12.stickImage.Parent = u12.thumbstickFrame;
    local u16 = nil;
    local function u22(p17) --[[ Line: 146 ]]
        -- upvalues: u16 (ref), u12 (copy)
        local v18 = Vector2.new(p17.X - u16.X, p17.Y - u16.Y);
        local l__magnitude__4 = v18.magnitude;
        local v19 = u12.thumbstickFrame.AbsoluteSize.X / 2;
        if u12.isFollowStick and v19 < l__magnitude__4 then
            local v20 = v18.unit * v19;
            u12.thumbstickFrame.Position = UDim2.new(0, p17.X - u12.thumbstickFrame.AbsoluteSize.X / 2 - v20.X, 0, p17.Y - u12.thumbstickFrame.AbsoluteSize.Y / 2 - v20.Y);
        else
            local v21 = math.min(l__magnitude__4, v19);
            v18 = v18.unit * v21;
        end;
        u12.stickImage.Position = UDim2.new(0, v18.X + u12.stickImage.AbsoluteSize.X / 2, 0, v18.Y + u12.stickImage.AbsoluteSize.Y / 2);
    end;
    u12.thumbstickFrame.InputBegan:Connect(function(p23) --[[ Line: 163 ]]
        -- upvalues: u12 (copy), u16 (ref)
        if u12.moveTouchObject or (p23.UserInputType ~= Enum.UserInputType.Touch or p23.UserInputState ~= Enum.UserInputState.Begin) then
        else
            u12.moveTouchObject = p23;
            u12.thumbstickFrame.Position = UDim2.new(0, p23.Position.X - u12.thumbstickFrame.Size.X.Offset / 2, 0, p23.Position.Y - u12.thumbstickFrame.Size.Y.Offset / 2);
            u16 = Vector2.new(u12.thumbstickFrame.AbsolutePosition.X + u12.thumbstickFrame.AbsoluteSize.X / 2, u12.thumbstickFrame.AbsolutePosition.Y + u12.thumbstickFrame.AbsoluteSize.Y / 2);
            Vector2.new(p23.Position.X - u16.X, p23.Position.Y - u16.Y);
        end;
    end);
    u12.onTouchMovedConn = l__UserInputService__2.TouchMoved:Connect(function(p24, _) --[[ Line: 178 ]]
        -- upvalues: u12 (copy), u16 (ref), u3 (ref), u22 (copy)
        if p24 == u12.moveTouchObject then
            u16 = Vector2.new(u12.thumbstickFrame.AbsolutePosition.X + u12.thumbstickFrame.AbsoluteSize.X / 2, u12.thumbstickFrame.AbsolutePosition.Y + u12.thumbstickFrame.AbsoluteSize.Y / 2);
            local v25 = Vector2.new(p24.Position.X - u16.X, p24.Position.Y - u16.Y) / (u12.thumbstickSize / 2);
            local l__magnitude__5 = v25.magnitude;
            local v26;
            if l__magnitude__5 < 0.05 then
                v26 = Vector3.new();
            else
                local v27;
                if u3 then
                    v27 = v25.unit * math.min(1, (l__magnitude__5 - 0.05) / 0.95);
                else
                    v27 = v25.unit * ((l__magnitude__5 - 0.05) / 0.95);
                end;
                v26 = Vector3.new(v27.X, 0, v27.Y);
            end;
            u12.moveVector = v26;
            u22(p24.Position);
        end;
    end);
    u12.onTouchEndedConn = l__UserInputService__2.TouchEnded:Connect(function(p28, _) --[[ Line: 188 ]]
        -- upvalues: u12 (copy)
        if p28 == u12.moveTouchObject then
            u12:OnInputEnded();
        end;
    end);
    l__GuiService__1.MenuOpened:Connect(function() --[[ Line: 194 ]]
        -- upvalues: u12 (copy)
        if u12.moveTouchObject then
            u12:OnInputEnded();
        end;
    end);
    u12.thumbstickFrame.Parent = p13;
end;
return u4;