-- Roblox: Players.SilverAce293026.PlayerScripts.LocalMessages
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__TextChatService__1 = game:GetService("TextChatService");
local l__Players__2 = game:GetService("Players");
local l__PolicyService__3 = game:GetService("PolicyService");
local l__LocalPlayer__4 = l__Players__2.LocalPlayer;
local v1 = { "If you\'re enjoying the game, don\'t forget to <font color=\'#AAFFAA\'>Like</font> and <font color=\'#FFFF00\'>Favorite</font>!", "Capture hardpoints to earn <font color=\'#AAFFAA\'>extra income</font> for you and your team!", "Click \'Modes\' to try out our Arena gamemode!" };
local v2, v3 = pcall(function() --[[ Line: 15 ]]
    -- upvalues: l__PolicyService__3 (copy), l__LocalPlayer__4 (copy)
    return l__PolicyService__3:GetPolicyInfoForPlayerAsync(l__LocalPlayer__4);
end);
local v4;
if v2 then
    v4 = table.find(v3.AllowedExternalLinkReferences, "Discord") ~= nil;
else
    v4 = false;
end;
for _, v5 in v1 do
    l__TextChatService__1:WaitForChild("TextChannels"):WaitForChild("RBXSystem"):DisplaySystemMessage(v5);
    task.wait(180);
end;