-- Roblox: Players.SilverAce293026.PlayerScripts.SquadNotifications
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__ReplicatedStorage__1 = game:GetService("ReplicatedStorage");
local l__StarterGui__2 = game:GetService("StarterGui");
local l__Players__3 = game:GetService("Players");
local l__Debris__4 = game:GetService("Debris");
local l__LocalPlayer__5 = l__Players__3.LocalPlayer;
local l__ShopGui__6 = l__LocalPlayer__5:WaitForChild("PlayerGui"):WaitForChild("ShopGui");
local l__SquadMessageBox__7 = l__ShopGui__6:WaitForChild("SquadMessageBox");
local l__MessageBox__8 = require(l__SquadMessageBox__7:WaitForChild("MessageBox"));
local l__SquadInviteBox__9 = l__ShopGui__6:WaitForChild("SquadInviteBox");
local l__PlayerEvents__10 = l__ReplicatedStorage__1:WaitForChild("PlayerEvents");
local l__SquadNotifyInvite__11 = l__PlayerEvents__10:WaitForChild("SquadNotifyInvite");
local l__SquadAcceptInvite__12 = l__PlayerEvents__10:WaitForChild("SquadAcceptInvite");
local l__SquadEvent__13 = l__PlayerEvents__10:WaitForChild("SquadEvent");
local u1 = false;
l__SquadNotifyInvite__11.OnClientEvent:Connect(function(p2, u3) --[[ Line: 22 ]]
    -- upvalues: u1 (ref), l__Debris__4 (copy), l__SquadInviteBox__9 (copy), l__SquadAcceptInvite__12 (copy), l__MessageBox__8 (copy)
    if u1 then
        repeat
            task.wait();
        until not u1;
    end;
    u1 = true;
    local u4 = Instance.new("BindableFunction");
    u4.Parent = script;
    l__Debris__4:AddItem(u4, 15);
    local u5 = {};
    function u4.OnInvoke(p6) --[[ Line: 40 ]]
        -- upvalues: l__SquadInviteBox__9 (ref), u5 (ref), u1 (ref), l__SquadAcceptInvite__12 (ref), u3 (copy), l__MessageBox__8 (ref)
        l__SquadInviteBox__9.Visible = false;
        for _, v7 in u5 do
            v7:Disconnect();
        end;
        u5 = {};
        u1 = false;
        if p6 == nil or p6 == "" then
        elseif p6 == "Decline" then
        else
            local v8, v9 = l__SquadAcceptInvite__12:InvokeServer(u3);
            if not v8 then
                l__MessageBox__8.Show("Error", v9 or "Unknown error");
            end;
        end;
    end;
    task.delay(15, function() --[[ Line: 52 ]]
        -- upvalues: u4 (copy), u1 (ref), l__SquadInviteBox__9 (ref), u5 (ref)
        if u4 and u4.Parent then
            u1 = false;
            l__SquadInviteBox__9.Visible = false;
            for _, v10 in u5 do
                v10:Disconnect();
            end;
            u5 = {};
        end;
    end);
    l__SquadInviteBox__9.Visible = true;
    l__SquadInviteBox__9.Details.TextLabel.Text = string.format("%s invited you to their squad!", p2.Sender.DisplayName);
    u5 = { l__SquadInviteBox__9.BottomAction.AcceptButton.ButtonFrame.Button.Activated:Connect(function() --[[ Line: 60 ]]
            -- upvalues: u4 (copy)
            u4:Invoke("Accept");
        end), (l__SquadInviteBox__9.BottomAction.DeclineButton.ButtonFrame.Button.Activated:Connect(function() --[[ Line: 64 ]]
            -- upvalues: u4 (copy)
            u4:Invoke("Decline");
        end)) };
end);
local u14 = {
    NewLeader = function(p11) --[[ Name: NewLeader, Line 72 ]]
        -- upvalues: l__LocalPlayer__5 (copy)
        return p11 == l__LocalPlayer__5 and "You are the new leader of your squad!" or string.format("%s is the new leader of your squad", p11.DisplayName);
    end,
    Join = function(p12) --[[ Name: Join, Line 78 ]]
        -- upvalues: l__LocalPlayer__5 (copy)
        if p12 ~= l__LocalPlayer__5 then
            return string.format("%s joined your squad", p12.DisplayName);
        end;
    end,
    Left = function(p13) --[[ Name: Left, Line 82 ]]
        -- upvalues: l__LocalPlayer__5 (copy)
        if p13 ~= l__LocalPlayer__5 then
            return string.format("%s left your squad", p13.DisplayName);
        end;
    end,
    Kicked = function() --[[ Name: Kicked, Line 86 ]]
        return "You were kicked from your squad";
    end
};
l__SquadEvent__13.OnClientEvent:Connect(function(p15, ...) --[[ Line: 91 ]]
    -- upvalues: u14 (copy), l__StarterGui__2 (copy)
    local v16 = { ... };
    if u14[p15] then
        local v17 = u14[p15](unpack(v16));
        if v17 then
            l__StarterGui__2:SetCore("SendNotification", {
                Title = "Squad",
                Duration = 3,
                Text = v17
            });
        end;
    end;
end);