-- Roblox: Players.SilverAce293026.PlayerScripts.Killcam
-- Class: LocalScript
-- Method: bytecode

-- Decompiled with Potassium's decompiler.

local l__Players__1 = game:GetService("Players");
local l__Lighting__2 = game:GetService("Lighting");
local l__RunService__3 = game:GetService("RunService");
local l__TweenService__4 = game:GetService("TweenService");
local l__ReplicatedStorage__5 = game:GetService("ReplicatedStorage");
local l__KillEvent__6 = l__ReplicatedStorage__5:WaitForChild("GameplayEvents"):WaitForChild("KillEvent");
local l__ACS_Engine__7 = l__ReplicatedStorage__5:WaitForChild("ACS_Engine");
local l__GunModels__8 = l__ACS_Engine__7:WaitForChild("GunModels");
local l__AttachmentsUtil__9 = require(l__ACS_Engine__7:WaitForChild("Modules"):WaitForChild("AttachmentsUtil"));
local l__Modules__10 = l__ReplicatedStorage__5:WaitForChild("Modules");
local l__TaggingModule__11 = require(l__Modules__10:WaitForChild("TaggingModule"));
local l__GuiModule__12 = require(l__Modules__10:WaitForChild("GuiModule"));
local u1 = TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out);
local l__DeathBW__13 = l__Lighting__2:WaitForChild("DeathBW");
local l__LocalPlayer__14 = l__Players__1.LocalPlayer;
local l__KillcamGui__15 = l__LocalPlayer__14:WaitForChild("PlayerGui"):WaitForChild("KillcamGui");
local u2 = {
    ContentArea = l__KillcamGui__15:WaitForChild("ContentArea"),
    Bottom = l__KillcamGui__15.ContentArea:WaitForChild("Bottom")
};
local u3 = {};
for _, v4 in {
    "Damage",
    "Health",
    "PlayerInfo",
    "WeaponInfo",
    "YouFoe"
} do
    u3[v4] = u2.Bottom:WaitForChild(v4);
end;
local u5 = Instance.new("Camera");
u5.Parent = script;
u5.CFrame = CFrame.new();
local u6 = {};
local u7 = {
    Head = "Head",
    LeftFoot = "LeftLeg",
    LeftLowerLeg = "LeftLeg",
    LeftUpperLeg = "LeftLeg",
    RightFoot = "RightLeg",
    RightLowerLeg = "RightLeg",
    RightUpperLeg = "RightLeg",
    LeftHand = "LeftArm",
    LeftLowerArm = "LeftArm",
    LeftUpperArm = "LeftArm",
    RightHand = "RightArm",
    RightLowerArm = "RightArm",
    RightUpperArm = "RightArm",
    UpperTorso = "Torso",
    LowerTorso = "Torso"
};
local u8 = {
    Head = { "Head" },
    LeftLeg = { "LeftFoot", "LeftLowerLeg", "LeftUpperLeg" },
    LeftArm = { "LeftHand", "LeftLowerArm", "LeftUpperArm" },
    RightLeg = { "RightFoot", "RightLowerLeg", "RightUpperLeg" },
    RightArm = { "RightHand", "RightLowerArm", "RightUpperArm" },
    Torso = { "UpperTorso", "LowerTorso", "HumanoidRootPart" }
};
for _, v9 in l__Players__1:GetChildren() do
    u6[v9] = {
        KilledMe = 0,
        KilledThem = 0
    };
end;
l__Players__1.PlayerAdded:Connect(function(p10) --[[ Line: 74 ]]
    -- upvalues: u6 (copy)
    u6[p10] = {
        KilledMe = 0,
        KilledThem = 0
    };
end);
l__Players__1.PlayerRemoving:Connect(function(p11) --[[ Line: 78 ]]
    -- upvalues: u6 (copy)
    u6[p11] = nil;
end);
l__KillEvent__6.OnClientEvent:Connect(function(_, _, _, _, p12) --[[ Line: 82 ]]
    -- upvalues: u6 (copy)
    if u6[p12] then
        local v13 = u6[p12];
        v13.KilledThem = v13.KilledThem + 1;
    end;
end);
local u14 = {};
local u15 = {};
local function v18() --[[ Line: 91 ]]
    -- upvalues: u14 (ref), u15 (ref), l__DeathBW__13 (copy), l__KillcamGui__15 (copy), l__LocalPlayer__14 (copy)
    for _, v16 in u14 do
        v16:Disconnect();
    end;
    for _, v17 in u15 do
        v17:Destroy();
    end;
    u14 = {};
    u15 = {};
    l__DeathBW__13.Enabled = false;
    l__KillcamGui__15.Enabled = false;
    local l__CurrentCamera__16 = workspace.CurrentCamera;
    l__CurrentCamera__16.CameraType = Enum.CameraType.Custom;
    if l__LocalPlayer__14.Character then
        l__CurrentCamera__16.CameraSubject = l__LocalPlayer__14.Character:WaitForChild("Humanoid");
    end;
end;
l__LocalPlayer__14.CharacterAdded:Connect(v18);
v18();
local function u66(p19, u20) --[[ Line: 116 ]]
    -- upvalues: l__Players__1 (copy), u6 (copy), u3 (copy), l__TaggingModule__11 (copy), l__LocalPlayer__14 (copy), u7 (copy), u8 (copy), l__GunModels__8 (copy), l__ReplicatedStorage__5 (copy), u5 (copy), l__GuiModule__12 (copy), l__AttachmentsUtil__9 (copy), u15 (ref), l__RunService__3 (copy), l__TweenService__4 (copy), u14 (ref), l__DeathBW__13 (copy), u1 (copy), u2 (copy), l__KillcamGui__15 (copy)
    if p19 then
        local u21 = p19:FindFirstChild("Humanoid");
        if u21 then
            local v22 = l__Players__1:GetPlayerFromCharacter(p19);
            if v22 then
                local v23 = u6[v22];
                v23.KilledMe = v23.KilledMe + 1;
                u3.Health.Bar.Fill.Size = UDim2.new(u21.Health / u21.MaxHealth, 0, 1, 0);
                local l__PlayerInfo__17 = u3.PlayerInfo;
                l__PlayerInfo__17.Icon.Image = l__Players__1:GetUserThumbnailAsync(v22.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size150x150);
                l__PlayerInfo__17.Content.PlayerName.Text = string.format("@%s", v22.Name);
                l__PlayerInfo__17.Content.DisplayName.Text = v22.DisplayName;
                local l__YouFoe__18 = u3.YouFoe;
                l__YouFoe__18.Title.Text = string.format("You - %s", v22.Name);
                l__YouFoe__18.Score.Text = string.format("%s - %s", u6[v22].KilledThem, u6[v22].KilledMe);
                local v24 = 0;
                local v25 = {};
                for _, v26 in l__TaggingModule__11.GetShooterTags(p19, l__LocalPlayer__14) do
                    v24 = v24 + v26.Damage;
                    if v26.PartName and not table.find(v25, v26.PartName) then
                        table.insert(v25, v26.PartName);
                    end;
                end;
                local v27 = math.floor(v24);
                local v28 = {};
                local v29 = {};
                for _, v30 in v25 do
                    local v31 = u7[v30];
                    if not table.find(v28, v31) then
                        v28[v31] = true;
                        local v32 = u8[v31];
                        table.move(v32, 1, #v32, #v29 + 1, v29);
                    end;
                end;
                local l__Damage__19 = u3.Damage;
                for _, v33 in l__Damage__19.ViewportFrame.Rig:GetChildren() do
                    if v33:IsA("BasePart") then
                        v33.Color = table.find(v29, v33.Name) and Color3.fromRGB(255, 0, 0) or Color3.fromRGB(255, 255, 255);
                    end;
                end;
                l__Damage__19.Amount.Text = string.format("%s damage dealt", v27);
                local l__WeaponInfo__20 = u3.WeaponInfo;
                l__WeaponInfo__20.Title.Text = u20.WeaponName;
                local u34 = l__GunModels__8:FindFirstChild(u20.WeaponName) == nil;
                local u35 = nil;
                (function() --[[ Name: getModel, Line 193 ]]
                    -- upvalues: u34 (copy), u21 (copy), u35 (ref), l__ReplicatedStorage__5 (ref), l__GunModels__8 (ref), u20 (copy)
                    if u34 then
                        local l__SeatPart__21 = u21.SeatPart;
                        if l__SeatPart__21 then
                            local v36 = l__SeatPart__21:FindFirstAncestorOfClass("Model");
                            u35 = l__ReplicatedStorage__5.Helicopters:FindFirstChild(v36.Name) or l__ReplicatedStorage__5.Vehicles:FindFirstChild(v36.Name);
                        end;
                    else
                        u35 = l__GunModels__8:FindFirstChild(u20.WeaponName);
                    end;
                end)();
                local l__ViewportFrame__22 = l__WeaponInfo__20.ViewportFrame;
                l__ViewportFrame__22.CurrentCamera = u5;
                local v37 = u35;
                for _, v38 in l__ViewportFrame__22:GetChildren() do
                    v38:Destroy();
                end;
                local u39 = {};
                if v37 then
                    local u40 = v37:Clone();
                    u40.Parent = l__ViewportFrame__22;
                    l__GuiModule__12.CameraZoom.zoomToExtents(u5, u40, table.unpack(u34 and { 135, -30 } or { 0, 0 }));
                    if not u34 then
                        local v41 = p19:FindFirstChild(u20.WeaponName) or v22.Backpack:FindFirstChild(u20.WeaponName);
                        local u42;
                        if v41 then
                            local v43 = v41:FindFirstChild("Customization");
                            u42 = v43 and v43:GetAttributes() or {};
                        else
                            u42 = {};
                        end;
                        (function() --[[ Name: processAttachments, Line 230 ]]
                            -- upvalues: u42 (ref), l__AttachmentsUtil__9 (ref), u39 (copy), u40 (copy)
                            local v44 = {};
                            for _, v45 in u42 do
                                local v46 = l__AttachmentsUtil__9.getAttDataFromHash(v45);
                                if v46 then
                                    table.insert(v44, v46);
                                    table.insert(u39, v46);
                                end;
                            end;
                            l__AttachmentsUtil__9.loadAttachments(u40, v44);
                            local v47 = u40:FindFirstChild("SightMark", true);
                            local v48 = v47 and v47:FindFirstChildOfClass("SurfaceGui");
                            if v48 then
                                v48.Enabled = false;
                            end;
                            for _, v49 in u40:GetDescendants() do
                                if v49:IsA("Decal") then
                                    v49:Destroy();
                                end;
                            end;
                        end)();
                    end;
                end;
                local v50 = {};
                for _, v51 in u39 do
                    table.insert(v50, v51.Name);
                end;
                local l__Attachments__23 = l__WeaponInfo__20.Attachments;
                local l__Prototype__24 = l__Attachments__23.Prototype;
                for _, v52 in l__Attachments__23:GetChildren() do
                    if v52 ~= l__Prototype__24 and v52:IsA("TextLabel") then
                        v52:Destroy();
                    end;
                end;
                for _, v53 in v50 do
                    local v54 = l__Prototype__24:Clone();
                    v54.Name = "Attachment";
                    v54.Text = v53;
                    v54.Parent = l__Attachments__23;
                    v54.Visible = true;
                end;
                local l__CurrentCamera__25 = workspace.CurrentCamera;
                l__CurrentCamera__25.CameraType = Enum.CameraType.Scriptable;
                l__CurrentCamera__25.CameraSubject = nil;
                local l__PrimaryPart__26 = p19.PrimaryPart;
                local v55 = Instance.new("Highlight");
                v55.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop;
                v55.Parent = p19;
                table.insert(u15, v55);
                local v59 = l__RunService__3.RenderStepped:Connect(function(p56) --[[ Line: 291 ]]
                    -- upvalues: l__CurrentCamera__25 (copy), l__TweenService__4 (ref), l__PrimaryPart__26 (copy)
                    local l__CFrame__27 = l__CurrentCamera__25.CFrame;
                    local v57 = l__TweenService__4:GetValue(p56, Enum.EasingStyle.Sine, Enum.EasingDirection.Out);
                    local v58;
                    if l__PrimaryPart__26 then
                        v58 = CFrame.new(l__CFrame__27.Position, l__PrimaryPart__26.Position);
                    else
                        v58 = l__CFrame__27;
                    end;
                    l__CurrentCamera__25.CFrame = l__CFrame__27:Lerp(v58, v57);
                end);
                table.insert(u14, v59);
                l__DeathBW__13.Saturation = 0;
                l__DeathBW__13.Enabled = true;
                l__TweenService__4:Create(l__DeathBW__13, u1, {
                    Saturation = -1
                }):Play();
                task.wait(1);
                local v60 = {};
                for _, v61 in u2.Bottom:GetChildren() do
                    local l__UIGradient__28 = v61.UIGradient;
                    l__UIGradient__28.Offset = Vector2.new(1, 1);
                    local v62 = l__TweenService__4;
                    local v63 = u1;
                    local v64 = {
                        Offset = Vector2.new(-1, -1)
                    };
                    table.insert(v60, v62:Create(l__UIGradient__28, v63, v64));
                end;
                l__KillcamGui__15.Enabled = true;
                for _, v65 in v60 do
                    v65:Play();
                end;
            end;
        end;
    end;
end;
l__LocalPlayer__14.CharacterAdded:Connect(function(u67) --[[ Name: onNewCharacter, Line 331 ]]
    -- upvalues: l__TaggingModule__11 (copy), u66 (copy)
    u67:WaitForChild("Humanoid").Died:Connect(function() --[[ Line: 333 ]]
        -- upvalues: l__TaggingModule__11 (ref), u67 (copy), u66 (ref)
        local v68 = l__TaggingModule__11.GetKillDetails(u67);
        if v68 and v68.Killer then
            u66(v68.Killer.Player.Character, v68.Killer);
        end;
    end);
end);
if l__LocalPlayer__14.Character then
    local l__Character__29 = l__LocalPlayer__14.Character;
    l__Character__29:WaitForChild("Humanoid").Died:Connect(function() --[[ Line: 333 ]]
        -- upvalues: l__TaggingModule__11 (copy), l__Character__29 (copy), u66 (copy)
        local v69 = l__TaggingModule__11.GetKillDetails(l__Character__29);
        if v69 and v69.Killer then
            u66(v69.Killer.Player.Character, v69.Killer);
        end;
    end);
end;